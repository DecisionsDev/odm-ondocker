;              
CREATE USER IF NOT EXISTS "RTS" SALT 'a948616417edf4db' HASH '523a131d379377848175eedcdfc2d2c70fbbab915edf9615fccebbd13077b1bc' ADMIN;         
CREATE SEQUENCE "PUBLIC"."SCENARIOSUITERESOURCEIDENTITY" START WITH 1;         
CREATE SEQUENCE "PUBLIC"."RULEPACKAGEIDENTITY" START WITH 33;  
CREATE SEQUENCE "PUBLIC"."OPERATIONIDENTITY" START WITH 33;    
CREATE SEQUENCE "PUBLIC"."DEPLOYMENTERRORIDENTITY" START WITH 33;              
CREATE SEQUENCE "PUBLIC"."RULEPROJECTTAGIDENTITY" START WITH 129;              
CREATE SEQUENCE "PUBLIC"."PROXYIDENTITY" START WITH 129;       
CREATE SEQUENCE "PUBLIC"."VOCABULARYIDENTITY" START WITH 33;   
CREATE SEQUENCE "PUBLIC"."USRIDENTITY" START WITH 33;          
CREATE SEQUENCE "PUBLIC"."OVERRIDDENRULEIDENTITY" START WITH 1;
CREATE SEQUENCE "PUBLIC"."RULEAPPPROPERTYIDENTITY" START WITH 1;               
CREATE SEQUENCE "PUBLIC"."GROUPIDENTITITY" START WITH 1;       
CREATE SEQUENCE "PUBLIC"."VSINPUTDATAIDENTITY" START WITH 33;  
CREATE SEQUENCE "PUBLIC"."PARAMETERIDENTITY" START WITH 1;     
CREATE SEQUENCE "PUBLIC"."DEPVERSIONPOLICYIDENTITY" START WITH 33;             
CREATE SEQUENCE "PUBLIC"."VERSIONIDENTITY" START WITH 385;     
CREATE SEQUENCE "PUBLIC"."RULESETIDENTITY" START WITH 1;       
CREATE SEQUENCE "PUBLIC"."EXTRACTORIDENTITY" START WITH 33;    
CREATE SEQUENCE "PUBLIC"."DSDEPLOYMENTREPORTIDENTITY" START WITH 33;           
CREATE SEQUENCE "PUBLIC"."VTDETAILIDENTITY" START WITH 33;     
CREATE SEQUENCE "PUBLIC"."RULESETPROPERTYIDENTITY" START WITH 1;               
CREATE SEQUENCE "PUBLIC"."VTCRESOURCEIDENTITY" START WITH 33;  
CREATE SEQUENCE "PUBLIC"."SECGRPIDENTITY" START WITH 33;       
CREATE SEQUENCE "PUBLIC"."PROJECTINFOIDENTITY" START WITH 65;  
CREATE SEQUENCE "PUBLIC"."ACTIVITYCOMMENTLINKIDENTITY" START WITH 1;           
CREATE SEQUENCE "PUBLIC"."VTRTSINFOIDENTITY" START WITH 33;    
CREATE SEQUENCE "PUBLIC"."RTSRESOURCEIDENTITY" START WITH 33;  
CREATE SEQUENCE "PUBLIC"."DEPLOYMENTIDENTITY" START WITH 65;   
CREATE SEQUENCE "PUBLIC"."USERGROUPIDENTITY" START WITH 33;    
CREATE SEQUENCE "PUBLIC"."SERVERIDENTITY" START WITH 33;       
CREATE SEQUENCE "PUBLIC"."RULEPROJECTIDENTITY" START WITH 33;  
CREATE SEQUENCE "PUBLIC"."EVENTIDENTITY" START WITH 1;         
CREATE SEQUENCE "PUBLIC"."PERMISSIONIDENTITY" START WITH 1;    
CREATE SEQUENCE "PUBLIC"."VSCONFIGIDENTITY" START WITH 33;     
CREATE SEQUENCE "PUBLIC"."RULEFLOWIDENTITY" START WITH 33;     
CREATE SEQUENCE "PUBLIC"."ACMTATCHMTIDENTITY" START WITH 1;    
CREATE SEQUENCE "PUBLIC"."RULEARTIFACTIDENTITY" START WITH 33; 
CREATE SEQUENCE "PUBLIC"."OPNEWVIDENTITY" START WITH 33;       
CREATE SEQUENCE "PUBLIC"."SYSTEMLOCKIDENTITY" START WITH 33;   
CREATE SEQUENCE "PUBLIC"."DECISIONMODELIDENTITY" START WITH 1; 
CREATE SEQUENCE "PUBLIC"."ACTIVITYSUBSCRIPTIONIDENTITY" START WITH 1;          
CREATE SEQUENCE "PUBLIC"."OPERATIONVARIABLEIDENTITY" START WITH 33;            
CREATE SEQUENCE "PUBLIC"."VSMODELIDENTITY" START WITH 33;      
CREATE SEQUENCE "PUBLIC"."OPERATIONTAGIDENTITY" START WITH 1;  
CREATE SEQUENCE "PUBLIC"."RULEARTIFACTTAGIDENTITY" START WITH 1;               
CREATE SEQUENCE "PUBLIC"."BOMPATHENTRYIDENTITY" START WITH 65; 
CREATE SEQUENCE "PUBLIC"."RULEFLOWTAGIDENTITY" START WITH 1;   
CREATE SEQUENCE "PUBLIC"."BOM2XOMMAPPINGIDENTITY" START WITH 33;               
CREATE SEQUENCE "PUBLIC"."DEPOPERATIONIDENTITY" START WITH 33; 
CREATE SEQUENCE "PUBLIC"."OPLATESTVIDENTITY" START WITH 33;    
CREATE SEQUENCE "PUBLIC"."VTCASEIDENTITY" START WITH 1;        
CREATE SEQUENCE "PUBLIC"."VSMETRICIDENTITY" START WITH 33;     
CREATE SEQUENCE "PUBLIC"."USERSETTINGIDENTITY" START WITH 33;  
CREATE SEQUENCE "PUBLIC"."LDAPPROPERTYIDENTITY" START WITH 1;  
CREATE SEQUENCE "PUBLIC"."GROUPROLEIDENTITY" START WITH 33;    
CREATE SEQUENCE "PUBLIC"."ACTIVITYLOCKIDENTITY" START WITH 1;  
CREATE SEQUENCE "PUBLIC"."DEPPROPERTYTAGIDENTITY" START WITH 1;
CREATE SEQUENCE "PUBLIC"."SCENARIOSUITEREPORTIDENTITY" START WITH 1;           
CREATE SEQUENCE "PUBLIC"."TASKIDENTITY" START WITH 1;          
CREATE SEQUENCE "PUBLIC"."MERGEREPORTIDENTITY" START WITH 1;   
CREATE SEQUENCE "PUBLIC"."DEFINITIONIDENTITY" START WITH 33;   
CREATE SEQUENCE "PUBLIC"."LOCKTBLIDENTITY" START WITH 1;       
CREATE SEQUENCE "PUBLIC"."INITIALVALUEIDENTITY" START WITH 1;  
CREATE SEQUENCE "PUBLIC"."BOMIDENTITY" START WITH 33;          
CREATE SEQUENCE "PUBLIC"."TEMPLATEIDENTITY" START WITH 1;      
CREATE SEQUENCE "PUBLIC"."SECURITYROLEIDENTITY" START WITH 33; 
CREATE SEQUENCE "PUBLIC"."SCENARIOTESTREPORTIDENTITY" START WITH 1;            
CREATE SEQUENCE "PUBLIC"."ARGUMENTIDENTITY" START WITH 1;      
CREATE SEQUENCE "PUBLIC"."MESSAGEMAPIDENTITY" START WITH 1;    
CREATE SEQUENCE "PUBLIC"."LDAPCONNECTIONIDENTITY" START WITH 1;
CREATE SEQUENCE "PUBLIC"."METAMODELIDENTITY" START WITH 33;    
CREATE SEQUENCE "PUBLIC"."ABSTRACTQUERYIDENTITY" START WITH 33;
CREATE SEQUENCE "PUBLIC"."VARIABLEIDENTITY" START WITH 33;     
CREATE SEQUENCE "PUBLIC"."VSKPIIDENTITY" START WITH 65;        
CREATE SEQUENCE "PUBLIC"."VTREPORTIDENTITY" START WITH 33;     
CREATE SEQUENCE "PUBLIC"."RTSSCHEMAIDENTITY" START WITH 1;     
CREATE SEQUENCE "PUBLIC"."DEPENDENCYIDENTITY" START WITH 33;   
CREATE SEQUENCE "PUBLIC"."CONNECTIONENTRYIDENTITY" START WITH 1;               
CREATE SEQUENCE "PUBLIC"."DEPOPERATIONPROPERTYIDENTITY" START WITH 65;         
CREATE SEQUENCE "PUBLIC"."DEPTARGETIDENTITY" START WITH 33;    
CREATE SEQUENCE "PUBLIC"."USERPROPERTYIDENTITY" START WITH 1;  
CREATE SEQUENCE "PUBLIC"."DEPGROUPIDENTITY" START WITH 33;     
CREATE SEQUENCE "PUBLIC"."SCOPEELEMENTIDENTITY" START WITH 1;  
CREATE SEQUENCE "PUBLIC"."VTSUITEIDENTITY" START WITH 33;      
CREATE SEQUENCE "PUBLIC"."BASELINEIDENTITY" START WITH 65;     
CREATE SEQUENCE "PUBLIC"."GROUPUSERIDENTITY" START WITH 33;    
CREATE SEQUENCE "PUBLIC"."PROFILEIDENTITY" START WITH 1;       
CREATE SEQUENCE "PUBLIC"."TESTREPORTIDENTITY" START WITH 1;    
CREATE SEQUENCE "PUBLIC"."PRJRESOURCEIDENTITY" START WITH 33;  
CREATE SEQUENCE "PUBLIC"."RULEAPPIDENTITY" START WITH 1;       
CREATE SEQUENCE "PUBLIC"."ACTIVITYCOMMENTACCESSIDENTITY" START WITH 1;         
CREATE SEQUENCE "PUBLIC"."VARIABLESETIDENTITY" START WITH 33;  
CREATE SEQUENCE "PUBLIC"."SCENARIOSUITEKPIREPORTIDENTITY" START WITH 1;        
CREATE SEQUENCE "PUBLIC"."SCENARIOSUITEIDENTITY" START WITH 1; 
CREATE SEQUENCE "PUBLIC"."VSREPORTIDENTITY" START WITH 33;     
CREATE SEQUENCE "PUBLIC"."VTROINFOIDENTITY" START WITH 33;     
CREATE SEQUENCE "PUBLIC"."ACTIVITYCOMMENTIDENTITY" START WITH 161;             
CREATE CACHED TABLE "PUBLIC"."ALGORITHMKIND"(
    "VALUE" VARCHAR(30) NOT NULL,
    "DEPRECATED" BOOLEAN
);    
ALTER TABLE "PUBLIC"."ALGORITHMKIND" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_7" PRIMARY KEY("VALUE");              
-- 2 +/- SELECT COUNT(*) FROM PUBLIC.ALGORITHMKIND;            
INSERT INTO "PUBLIC"."ALGORITHMKIND" VALUES
('default', FALSE),
('sequential', FALSE);         
CREATE CACHED TABLE "PUBLIC"."AUTHENTICATIONKIND"(
    "VALUE" VARCHAR(30) NOT NULL,
    "DEPRECATED" BOOLEAN
);               
ALTER TABLE "PUBLIC"."AUTHENTICATIONKIND" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_C" PRIMARY KEY("VALUE");         
-- 2 +/- SELECT COUNT(*) FROM PUBLIC.AUTHENTICATIONKIND;       
INSERT INTO "PUBLIC"."AUTHENTICATIONKIND" VALUES
('BASIC_AUTH', FALSE),
('OAUTH', FALSE);      
CREATE CACHED TABLE "PUBLIC"."BASELINEKIND"(
    "VALUE" VARCHAR(30) NOT NULL,
    "DEPRECATED" BOOLEAN
);     
ALTER TABLE "PUBLIC"."BASELINEKIND" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_6" PRIMARY KEY("VALUE");               
-- 10 +/- SELECT COUNT(*) FROM PUBLIC.BASELINEKIND;            
INSERT INTO "PUBLIC"."BASELINEKIND" VALUES
('Null', FALSE),
('Standard', FALSE),
('Deployment', FALSE),
('Branch', FALSE),
('Migrated', FALSE),
('RecycleBin', FALSE),
('Phantom', FALSE),
('Temporary', FALSE),
('DsDeployment', FALSE),
('Internal', FALSE); 
CREATE CACHED TABLE "PUBLIC"."DEPLOYMENTVERSIONNINGKIND"(
    "VALUE" VARCHAR(30) NOT NULL,
    "DEPRECATED" BOOLEAN
);        
ALTER TABLE "PUBLIC"."DEPLOYMENTVERSIONNINGKIND" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_4" PRIMARY KEY("VALUE");  
-- 5 +/- SELECT COUNT(*) FROM PUBLIC.DEPLOYMENTVERSIONNINGKIND;
INSERT INTO "PUBLIC"."DEPLOYMENTVERSIONNINGKIND" VALUES
('NO_CHANGE', FALSE),
('MANUAL', FALSE),
('INCREMENT_MINOR', FALSE),
('INCREMENT_MAJOR', FALSE),
('RESET', FALSE);     
CREATE CACHED TABLE "PUBLIC"."DIRECTIONKIND"(
    "VALUE" VARCHAR(30) NOT NULL,
    "DEPRECATED" BOOLEAN
);    
ALTER TABLE "PUBLIC"."DIRECTIONKIND" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_9" PRIMARY KEY("VALUE");              
-- 3 +/- SELECT COUNT(*) FROM PUBLIC.DIRECTIONKIND;            
INSERT INTO "PUBLIC"."DIRECTIONKIND" VALUES
('IN', FALSE),
('OUT', FALSE),
('INOUT', FALSE);   
CREATE CACHED TABLE "PUBLIC"."EXITCRITERIAKIND"(
    "VALUE" VARCHAR(30) NOT NULL,
    "DEPRECATED" BOOLEAN
); 
ALTER TABLE "PUBLIC"."EXITCRITERIAKIND" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_D" PRIMARY KEY("VALUE");           
-- 3 +/- SELECT COUNT(*) FROM PUBLIC.EXITCRITERIAKIND;         
INSERT INTO "PUBLIC"."EXITCRITERIAKIND" VALUES
('none', FALSE),
('rule', FALSE),
('ruleinstance', FALSE);      
CREATE CACHED TABLE "PUBLIC"."ILRGROUP"(
    "ID" INTEGER NOT NULL,
    "NAME" VARCHAR(255)
); 
ALTER TABLE "PUBLIC"."ILRGROUP" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_E" PRIMARY KEY("ID");      
-- 4 +/- SELECT COUNT(*) FROM PUBLIC.ILRGROUP; 
INSERT INTO "PUBLIC"."ILRGROUP" VALUES
(5, 'rtsConfigManagers'),
(6, 'rtsAdministrators'),
(7, 'rtsInstallers'),
(8, 'rtsUsers');              
CREATE CACHED TABLE "PUBLIC"."INPUTKIND"(
    "VALUE" VARCHAR(30) NOT NULL,
    "DEPRECATED" BOOLEAN
);        
ALTER TABLE "PUBLIC"."INPUTKIND" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_B" PRIMARY KEY("VALUE");  
-- 2 +/- SELECT COUNT(*) FROM PUBLIC.INPUTKIND;
INSERT INTO "PUBLIC"."INPUTKIND" VALUES
('DataProvider', FALSE),
('ExcelFile', FALSE);         
CREATE CACHED TABLE "PUBLIC"."METAMODEL"(
    "ID" INTEGER NOT NULL,
    "TYPE" VARCHAR(255)
);
ALTER TABLE "PUBLIC"."METAMODEL" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_67" PRIMARY KEY("ID");    
-- 149 +/- SELECT COUNT(*) FROM PUBLIC.METAMODEL;              
INSERT INTO "PUBLIC"."METAMODEL" VALUES
(1, 'brm.Query'),
(2, 'brm.Element'),
(3, 'brm.BasicModelElement'),
(4, 'brm.PackageElement'),
(5, 'brm.RulePackage'),
(6, 'brm.Hierarchy'),
(7, 'brm.BasicLock'),
(8, 'brm.Lock'),
(9, 'brm.ActivityLock'),
(10, 'brm.SystemLock'),
(11, 'brm.ModelElement'),
(12, 'brm.ProjectElement'),
(13, 'brm.AbstractQuery'),
(14, 'brm.Baseline'),
(15, 'brm.ReferencingBsln'),
(16, 'brm.TimestampBsln'),
(17, 'brm.Branch'),
(18, 'brm.Snapshot'),
(19, 'brm.ManagedBranch'),
(20, 'brm.Activity'),
(21, 'brm.ChangeAct'),
(22, 'brm.ValidationAct'),
(23, 'brm.Release'),
(24, 'brm.RuleArtifact'),
(25, 'brm.SmartView'),
(26, 'brm.BOM'),
(27, 'brm.BusinessRule'),
(28, 'brm.DecisionTable'),
(29, 'brm.DecisionTree'),
(30, 'brm.Definition'),
(31, 'brm.Template'),
(32, 'brm.BRLRule'),
(33, 'brm.Tag'),
(34, 'brm.Vocabulary'),
(35, 'brm.Proxy'),
(36, 'brm.TechnicalRule'),
(37, 'brm.Function'),
(38, 'brm.TypedElement'),
(39, 'brm.Variable'),
(40, 'brm.Parameter'),
(41, 'brm.VariableSet'),
(42, 'brm.Extractor'),
(43, 'brm.Rule'),
(44, 'brm.InitialValue'),
(45, 'brm.ProjectInfo'),
(46, 'brm.RuleProject'),
(47, 'brm.BOMPathEntry'),
(48, 'brm.Task'),
(49, 'brm.FunctionTask'),
(50, 'brm.RuleTask'),
(51, 'brm.Ruleflow'),
(52, 'brm.ProjectBOMEntry'),
(53, 'brm.BOMEntry'),
(54, 'brm.Dependency'),
(55, 'brm.MessageMap'),
(56, 'brm.ActionRule'),
(57, 'brm.RuleApp'),
(58, 'brm.Ruleset'),
(59, 'brm.UserSetting'),
(60, 'brm.ScopeElement'),
(61, 'brm.RuleAppProperty'),
(62, 'brm.RuleArtifactTag'),
(63, 'brm.BOM2XOMMapping'),
(64, 'brm.RulesetProperty'),
(65, 'brm.OverriddenRule'),
(66, 'brm.RuleProjectTag'),
(67, 'brm.Argument'),
(68, 'brm.RuleflowTag'),
(69, 'brm.Schema'),
(70, 'brm.Simulation'),
(71, 'brm.ScenarioSuite'),
(72, 'brm.ScenarioSuiteReport'),
(73, 'brm.TestSuite'),
(74, 'brm.Server'),
(75, 'brm.ScenarioSuiteResource'),
(76, 'brm.ScenarioTestReport'),
(77, 'brm.ScenarioSuiteKPIReport'),
(78, 'brm.TestReport'),
(79, 'brm.ConnectionEntry'),
(80, 'brm.Resource'),
(81, 'brm.EventElement'),
(82, 'brm.EventArtifact'),
(83, 'brm.Filter'),
(84, 'brm.EventRuleArtifact'),
(85, 'brm.EventRule'),
(86, 'brm.EventRuleGroup'),
(87, 'brm.NamedConstant'),
(88, 'brm.EventObjectArtifact'),
(89, 'brm.BusinessObject'),
(90, 'brm.EventObject'),
(91, 'brm.ActionObject'),
(92, 'brm.Action'),
(93, 'brm.Event'),
(94, 'brm.EventFlow'),
(95, 'brm.DataConnection'),
(96, 'brm.File'),
(97, 'brm.Chart'),
(98, 'brm.MergeReport'),
(99, 'brm.ActivityComment'),
(100, 'brm.ActivityCommentAttachment'),
(101, 'brm.ActivityCommentAccess'),
(102, 'brm.ActivityCommentLink'),
(103, 'brm.ActivityCommentEvent'),
(104, 'brm.ActivitySubscription'),
(105, 'brm.ActivityUserComment'),
(106, 'brm.Profile'),
(107, 'brm.DecisionModel'),
(108, 'dsm.Operation'),
(109, 'dsm.OperationTag'),
(110, 'dsm.OperationVariable'),
(111, 'dsm.Deployment'),
(112, 'dsm.DepGroup'),
(113, 'dsm.DepOperation'),
(114, 'dsm.DepPropertyTag'),
(115, 'dsm.DepOperationProperty'),
(116, 'dsm.DepTarget'),
(117, 'dsm.DepVersionPolicy'),
(118, 'dsm.DsDeploymentBsln'),
(119, 'dsm.DSDeploymentReport'),
(120, 'dsm.OperationDeployedVersion'),
(121, 'dsm.OperationLatestDeployedVersion'),
(122, 'dsm.OperationNewDeployedVersion'),
(123, 'dsm.DeploymentError'),
(124, 'validation.Metric'),
(125, 'validation.KPI'),
(126, 'validation.SimulationModel'),
(127, 'validation.InputData'),
(128, 'validation.SimulationReport'),
(129, 'validation.SimulationConfiguration'),
(130, 'validation.ValidationElement'),
(131, 'validation.SimulationElement'),
(132, 'validation.TestSuite'),
(133, 'validation.TestElement'),
(134, 'validation.TestReport'),
(135, 'validation.TestCaseResource'),
(136, 'validation.TestCase'),
(137, 'validation.TestDetail'),
(138, 'validation.TestOperationInfo'),
(139, 'validation.ReportOperationInfo'),
(140, 'validation.ReportTestSuiteInfo'),
(141, 'admin.User'),
(142, 'admin.SecurityGroup'),
(143, 'admin.LdapConnection'),
(144, 'admin.LdapProperty'),
(145, 'admin.SecurityRole'),
(146, 'admin.UserProperty'),
(147, 'admin.UserGroup'),
(148, 'admin.GroupRole'),
(149, 'admin.GroupUser'); 
CREATE CACHED TABLE "PUBLIC"."LDAPCONNECTION"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "GROUPMEMBER" VARCHAR(50),
    "GROUPNAMEATTRIBUTE" VARCHAR(750),
    "GROUPSEARCHBASE" VARCHAR(750),
    "GROUPSEARCHFILTER" CLOB(52428800),
    "LDAPURL" VARCHAR(750),
    "MEMBERID" VARCHAR(50),
    "SEARCHCONNECTIONDN" VARCHAR(750),
    "SEARCHCONNECTIONPASSWORD" VARCHAR(255),
    "USEREMAILATTRIBUTE" VARCHAR(255),
    "USERNAMEATTRIBUTE" VARCHAR(255),
    "CREATEDBY" VARCHAR(100),
    "CREATEDON" TIMESTAMP,
    "LASTCHANGEDBY" VARCHAR(100),
    "LASTCHANGEDON" TIMESTAMP,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL
);               
ALTER TABLE "PUBLIC"."LDAPCONNECTION" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_D2" PRIMARY KEY("ID");               
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.LDAPCONNECTION;           
CREATE UNIQUE INDEX "PUBLIC"."LDAPCONNECTIONUUIDUNIQUE" ON "PUBLIC"."LDAPCONNECTION"("UUID");  
CREATE INDEX "PUBLIC"."FKLDAPCONNECTIONTYPIDX" ON "PUBLIC"."LDAPCONNECTION"("TYPE");           
CREATE CACHED TABLE "PUBLIC"."LDAPPROPERTY"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CONTAINER" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "VALUE" CLOB(52428800)
);         
ALTER TABLE "PUBLIC"."LDAPPROPERTY" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_2" PRIMARY KEY("ID");  
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.LDAPPROPERTY;             
CREATE INDEX "PUBLIC"."LDAPPROPERTY_CONTAINER" ON "PUBLIC"."LDAPPROPERTY"("CONTAINER");        
CREATE INDEX "PUBLIC"."FKLDAPPROPERTYTYPIDX" ON "PUBLIC"."LDAPPROPERTY"("TYPE");               
CREATE CACHED TABLE "PUBLIC"."METRICKIND"(
    "VALUE" VARCHAR(30) NOT NULL,
    "DEPRECATED" BOOLEAN
);       
ALTER TABLE "PUBLIC"."METRICKIND" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_F" PRIMARY KEY("VALUE"); 
-- 5 +/- SELECT COUNT(*) FROM PUBLIC.METRICKIND;               
INSERT INTO "PUBLIC"."METRICKIND" VALUES
('Numeric', FALSE),
('DateTime', FALSE),
('Boolean', FALSE),
('String', FALSE),
('Domain', FALSE);    
CREATE CACHED TABLE "PUBLIC"."NAMEDCONSTANTTYPE"(
    "VALUE" VARCHAR(30) NOT NULL,
    "DEPRECATED" BOOLEAN
);
ALTER TABLE "PUBLIC"."NAMEDCONSTANTTYPE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_A" PRIMARY KEY("VALUE");          
-- 6 +/- SELECT COUNT(*) FROM PUBLIC.NAMEDCONSTANTTYPE;        
INSERT INTO "PUBLIC"."NAMEDCONSTANTTYPE" VALUES
('Unspecified', FALSE),
('String', FALSE),
('Integer', FALSE),
('Real', FALSE),
('DateTime', FALSE),
('Boolean', FALSE);       
CREATE CACHED TABLE "PUBLIC"."ORDERINGKIND"(
    "VALUE" VARCHAR(30) NOT NULL,
    "DEPRECATED" BOOLEAN
);     
ALTER TABLE "PUBLIC"."ORDERINGKIND" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_CF" PRIMARY KEY("VALUE");              
-- 3 +/- SELECT COUNT(*) FROM PUBLIC.ORDERINGKIND;             
INSERT INTO "PUBLIC"."ORDERINGKIND" VALUES
('default', FALSE),
('literal', FALSE),
('sorted', FALSE);          
CREATE CACHED TABLE "PUBLIC"."PACKAGEKIND"(
    "VALUE" VARCHAR(30) NOT NULL,
    "DEPRECATED" BOOLEAN
);      
ALTER TABLE "PUBLIC"."PACKAGEKIND" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_B6" PRIMARY KEY("VALUE");               
-- 29 +/- SELECT COUNT(*) FROM PUBLIC.PACKAGEKIND;             
INSERT INTO "PUBLIC"."PACKAGEKIND" VALUES
('Rule', FALSE),
('Template', FALSE),
('Query', FALSE),
('Resource', FALSE),
('BOM', FALSE),
('Testing', FALSE),
('EventArtifact', FALSE),
('EventObject', FALSE),
('ActionObject', FALSE),
('BusinessObject', FALSE),
('NamedConstant', FALSE),
('Event', FALSE),
('Action', FALSE),
('File', FALSE),
('DataConnection', FALSE),
('EventFlow', FALSE),
('Chart', FALSE),
('Operation', FALSE),
('Deployment', FALSE),
('DSDeploymentReport', FALSE),
('TestSuite', FALSE),
('TestReport', FALSE),
('TestCase', FALSE),
('Metric', FALSE),
('KPI', FALSE),
('InputData', FALSE),
('SimulationModel', FALSE),
('SimulationConfiguration', FALSE),
('SimulationReport', FALSE);        
CREATE CACHED TABLE "PUBLIC"."PERMISSION"(
    "ID" INTEGER NOT NULL,
    "ILRGROUP" VARCHAR(255) NOT NULL,
    "TYPE" VARCHAR(40) NOT NULL,
    "ILRLEVEL" VARCHAR(40) NOT NULL,
    "ARGS" VARCHAR(255) NOT NULL,
    "ILRORDER" INTEGER NOT NULL
);         
ALTER TABLE "PUBLIC"."PERMISSION" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_FE" PRIMARY KEY("ID");   
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.PERMISSION;               
CREATE CACHED TABLE "PUBLIC"."PROFILE"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "PICTURE" BLOB,
    "USERID" VARCHAR(100)
);               
ALTER TABLE "PUBLIC"."PROFILE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_1" PRIMARY KEY("ID");       
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.PROFILE;  
CREATE INDEX "PUBLIC"."FKPROFILETYPIDX" ON "PUBLIC"."PROFILE"("TYPE");         
CREATE CACHED TABLE "PUBLIC"."PROXY"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "DESTNAME" VARCHAR(255),
    "DESTUUID" VARCHAR(46),
    "REFERENCE" VARCHAR(255),
    "SOURCEUUID" VARCHAR(46)
);           
ALTER TABLE "PUBLIC"."PROXY" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_48" PRIMARY KEY("ID");        
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.PROXY;    
CREATE INDEX "PUBLIC"."FKPROXYTYPIDX" ON "PUBLIC"."PROXY"("TYPE");             
CREATE CACHED TABLE "PUBLIC"."REPORTSTATUSKIND"(
    "VALUE" VARCHAR(30) NOT NULL,
    "DEPRECATED" BOOLEAN
); 
ALTER TABLE "PUBLIC"."REPORTSTATUSKIND" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_26" PRIMARY KEY("VALUE");          
-- 7 +/- SELECT COUNT(*) FROM PUBLIC.REPORTSTATUSKIND;         
INSERT INTO "PUBLIC"."REPORTSTATUSKIND" VALUES
('STARTING', FALSE),
('STARTED', FALSE),
('STOPPING', FALSE),
('STOPPED', FALSE),
('FAILED', FALSE),
('COMPLETED', FALSE),
('ABORTED', FALSE);  
CREATE CACHED TABLE "PUBLIC"."RTSRESOURCE"(
    "ID" INTEGER NOT NULL,
    "NAME" VARCHAR(255),
    "VERSION" INTEGER,
    "CONTENT" CLOB(52428800)
);         
ALTER TABLE "PUBLIC"."RTSRESOURCE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_5" PRIMARY KEY("ID");   
-- 16 +/- SELECT COUNT(*) FROM PUBLIC.RTSRESOURCE;             
INSERT INTO "PUBLIC"."RTSRESOURCE" VALUES
(1, 'teamserver.extensionModel', 16, STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<!--\n   Licensed Materials - Property of IBM\n   5725-B69 5655-Y31 5655-Y17\n   Copyright IBM Corp. 1987, 2016 All Rights Reserved\n   US Government Users Restricted Rights - Use, duplication or\n   disclosure restricted by GSA ADP Schedule Contract with\n   IBM Corp.\n-->\n<model:extension-model xmlns:model=\"http://ilog.rules.brms.extension/model\" name=\"defaultExtension\" nsURI=\"http://ilog.rules.brms.extension/default\">\n\t<add-property className=\"BusinessRule\"/>\n\t<add-property className=\"Rule\">\n\t\t<property extractable=\"true\" name=\"effectiveDate\" type=\"Date\">\n\t\t\t<annotation id=\"validator-class\" value=\"ilog.rules.teamserver.web.validator.IlrComparablePropertyValidator\" />\n\t\t\t<annotation id=\"validator-compared-property\" value=\"expirationDate\" />\n\t\t\t<annotation id=\"validator-constraint\" value=\"LESSTHAN\" />\n\t\t</property>\n\t\t<property extractable=\"true\" name=\"expirationDate\" type=\"Date\" />\n\t\t<property extractable=\"true\" name=\"status\" type=\"Status\" />\n\t</add-property>\n\t<add-property className=\"EventArtifact\">\n\t\t<property name=\"effectiveDate\" type=\"Date\">\n\t\t\t<annotation id=\"validator-class\" value=\"ilog.rules.teamserver.web.validator.IlrComparablePropertyValidator\" />\n\t\t\t<annotation id=\"validator-compared-property\" value=\"expirationDate\" />\n\t\t\t<annotation id=\"validator-constraint\" value=\"LESSTHAN\" />\n\t\t</property>\n\t\t<property name=\"expirationDate\" type=\"Date\" />\n\t\t<property name=\"status\" required=\"true\" type=\"Status\" />\n\t</add-property>\n\t<enum name=\"Status\" />\n\t<avoidValidate>true</avoidValidate>\n</model:extension-model>\n')),
(2, 'teamserver.extensionData', 16, STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<!--\n   Licensed Materials - Property of IBM\n   5725-B69 5655-Y31 5655-Y17\n   Copyright IBM Corp. 1987, 2016 All Rights Reserved\n   US Government Users Restricted Rights - Use, duplication or\n   disclosure restricted by GSA ADP Schedule Contract with\n   IBM Corp.\n-->\n<data:extension-data xmlns:data=\"http://ilog.rules.brms.extension/data\" modelNsURI=\"http://ilog.rules.brms.extension/default\">\n\t<enum-data name=\"Status\">\n\t\t<item>new</item>\n\t\t<item>defined</item>\n\t\t<item>validated</item>\n\t\t<item>rejected</item>\n\t\t<item>deployable</item>\n\t</enum-data>\n</data:extension-data>\n')),
(3, 'teamserver.messages_de', 16, STRINGDECODE('# Licensed Materials - Property of IBM\r\n# 5655-Y31 5725-W47 5737-A28 5725-B69 5737-H06 5737-I23\r\n# Copyright IBM Corp. 2009, 2023 All Rights Reserved\r\n# US Government Users Restricted Rights - Use, duplication or\r\n# disclosure restricted by GSA ADP Schedule Contract with\r\n# IBM Corp.\r\n\r\n# NLS_ENCODING=UNICODE\r\n# NLS_MESSAGEFORMAT_VAR\r\n\r\nbrm.custom.MyRule=Meine Regel\r\nbrm.custom.MyRule.new=Neue Instanz meiner Regel\r\nbrm.custom.Requirement=Voraussetzung\r\n\r\nrf_status=RF-Status\r\ngeography=Region\r\nalternate=Alternativ\r\nstatus=Status\r\neffectiveDate=Stichtag\r\nexpirationDate=Ablaufdatum\r\neditRequirements=Voraussetzungen\r\ntext=Text\r\nurl=URL\r\n%emptyMyRule_key=Meine Regel leer\r\n\r\n# Values for the Status enumeration. Will be used in sentences such as \"Rule Artifact status : New\".\r\n# Translate ''new'' key as male gender\r\nnew=Neu\r\nvalidated=Validiert\r\ndefined=Definiert\r\nrejected=Abgelehnt\r\ninactive=Inaktiv\r\ndeployable=Implementierbar\r\n')),
(4, 'teamserver.messages_ru', 16, STRINGDECODE('# Licensed Materials - Property of IBM\r\n# 5655-Y31 5725-W47 5737-A28 5725-B69 5737-H06 5737-I23\r\n# Copyright IBM Corp. 2009, 2023 All Rights Reserved\r\n# US Government Users Restricted Rights - Use, duplication or\r\n# disclosure restricted by GSA ADP Schedule Contract with\r\n# IBM Corp.\r\n\r\n# NLS_ENCODING=UNICODE\r\n# NLS_MESSAGEFORMAT_VAR\r\n\r\nbrm.custom.MyRule=\\u041c\\u043e\\u0435 \\u043f\\u0440\\u0430\\u0432\\u0438\\u043b\\u043e\r\nbrm.custom.MyRule.new=\\u041d\\u043e\\u0432\\u044b\\u0439 \\u044d\\u043a\\u0437\\u0435\\u043c\\u043f\\u043b\\u044f\\u0440 \\u041c\\u043e\\u0435\\u0433\\u043e \\u043f\\u0440\\u0430\\u0432\\u0438\\u043b\\u0430\r\nbrm.custom.Requirement=\\u0422\\u0440\\u0435\\u0431\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f\r\n\r\nrf_status=\\u0421\\u043e\\u0441\\u0442\\u043e\\u044f\\u043d\\u0438\\u0435 RF\r\ngeography=\\u0413\\u0435\\u043e\\u0433\\u0440\\u0430\\u0444\\u0438\\u044f\r\nalternate=\\u0418\\u0437\\u043c\\u0435\\u043d\\u0438\\u0442\\u044c\r\nstatus=\\u0421\\u043e\\u0441\\u0442\\u043e\\u044f\\u043d\\u0438\\u0435\r\neffectiveDate=\\u0424\\u0430\\u043a\\u0442\\u0438\\u0447\\u0435\\u0441\\u043a\\u0430\\u044f \\u0434\\u0430\\u0442\\u0430\r\nexpirationDate=\\u0421\\u0440\\u043e\\u043a \\u0434\\u0435\\u0439\\u0441\\u0442\\u0432\\u0438\\u044f\r\neditRequirements=\\u0422\\u0440\\u0435\\u0431\\u043e\\u0432\\u0430\\u043d\\u0438\\u044f\r\ntext=\\u0422\\u0435\\u043a\\u0441\\u0442\r\nurl=URL\r\n%emptyMyRule_key=\\u041e\\u0447\\u0438\\u0441\\u0442\\u0438\\u0442\\u044c \\u043c\\u043e\\u0435 \\u043f\\u0440\\u0430\\u0432\\u0438\\u043b\\u043e\r\n\r\n# Values for the Status enumeration. Will be used in sentences such as \"Rule Artifact status : New\".\r\n# Translate ''new'' key as male gender\r\nnew=\\u041d\\u043e\\u0432\\u043e\\u0435\r\nvalidated=\\u041f\\u0440\\u043e\\u0432\\u0435\\u0440\\u0435\\u043d\\u043e\r\ndefined=\\u041e\\u043f\\u0440\\u0435\\u0434\\u0435\\u043b\\u0435\\u043d\\u043e\r\nrejected=\\u041e\\u0442\\u043a\\u043b\\u043e\\u043d\\u0435\\u043d\\u043e\r\ninactive=\\u041d\\u0435\\u0430\\u043a\\u0442\\u0438\\u0432\\u043d\\u043e\r\ndeployable=\\u0414\\u043e\\u0441\\u0442\\u0443\\u043f\\u043d\\u043e \\u0434\\u043b\\u044f \\u0440\\u0430\\u0437\\u0432\\u0435\\u0440\\u0442\\u044b\\u0432\\u0430\\u043d\\u0438\\u044f\r\n'));        
INSERT INTO "PUBLIC"."RTSRESOURCE" VALUES
(5, 'teamserver.messages_ko', 16, STRINGDECODE('# Licensed Materials - Property of IBM\r\n# 5655-Y31 5725-W47 5737-A28 5725-B69 5737-H06 5737-I23\r\n# Copyright IBM Corp. 2009, 2023 All Rights Reserved\r\n# US Government Users Restricted Rights - Use, duplication or\r\n# disclosure restricted by GSA ADP Schedule Contract with\r\n# IBM Corp.\r\n\r\n# NLS_ENCODING=UNICODE\r\n# NLS_MESSAGEFORMAT_VAR\r\n\r\nbrm.custom.MyRule=\\ub0b4 \\uaddc\\uce59\r\nbrm.custom.MyRule.new=\\ub0b4 \\uaddc\\uce59\\uc758 \\uc0c8 \\uc778\\uc2a4\\ud134\\uc2a4\r\nbrm.custom.Requirement=\\uc694\\uad6c\\uc0ac\\ud56d\r\n\r\nrf_status=RF \\uc0c1\\ud0dc\r\ngeography=\\uc9c0\\uc5ed\r\nalternate=\\ub300\\uccb4\r\nstatus=\\uc0c1\\ud0dc\r\neffectiveDate=\\uc720\\ud6a8 \\ub0a0\\uc9dc\r\nexpirationDate=\\ub9cc\\uae30 \\ub0a0\\uc9dc\r\neditRequirements=\\uc694\\uad6c\\uc0ac\\ud56d\r\ntext=\\ud14d\\uc2a4\\ud2b8\r\nurl=URL\r\n%emptyMyRule_key=\\ub0b4 \\uaddc\\uce59 \\ube44\\uc6c0\r\n\r\n# Values for the Status enumeration. Will be used in sentences such as \"Rule Artifact status : New\".\r\n# Translate ''new'' key as male gender\r\nnew=\\uc0c8\\ub85c \\uc791\\uc131\r\nvalidated=\\uc720\\ud6a8\\uc131 \\uac80\\uc99d\\ub428\r\ndefined=\\uc815\\uc758\\ub428\r\nrejected=\\uac70\\ubd80\\ub428\r\ninactive=\\ube44\\ud65c\\uc131\r\ndeployable=\\ubc30\\uce58 \\uac00\\ub2a5\r\n')),
(6, 'teamserver.messages_en', 16, STRINGDECODE('# Licensed Materials - Property of IBM\r\n# 5655-Y31 5725-W47 5737-A28 5725-B69 5737-H06 5737-I23\r\n# Copyright IBM Corp. 2009, 2023 All Rights Reserved\r\n# US Government Users Restricted Rights - Use, duplication or\r\n# disclosure restricted by GSA ADP Schedule Contract with\r\n# IBM Corp.\r\n\r\n# NLS_ENCODING=UNICODE\r\n# NLS_MESSAGEFORMAT_VAR\r\n\r\nbrm.custom.MyRule=My Rule\r\nbrm.custom.MyRule.new=New instance of My Rule\r\nbrm.custom.Requirement=Requirement\r\n\r\nrf_status=RF Status\r\ngeography=Geography\r\nalternate=Alternate\r\nstatus=Status\r\neffectiveDate=Effective Date\r\nexpirationDate=Expiration Date\r\neditRequirements=Requirements\r\ntext=Text\r\nurl=URL\r\n%emptyMyRule_key=Empty My Rule\r\n\r\n# Values for the Status enumeration. Will be used in sentences such as \"Rule Artifact status : New\".\r\n# Translate ''new'' key as male gender\r\nnew=New\r\nvalidated=Validated\r\ndefined=Defined\r\nrejected=Rejected\r\ninactive=Inactive\r\ndeployable=Deployable\r\n')),
(7, 'teamserver.messages_it', 16, STRINGDECODE('# Licensed Materials - Property of IBM\r\n# 5655-Y31 5725-W47 5737-A28 5725-B69 5737-H06 5737-I23\r\n# Copyright IBM Corp. 2009, 2023 All Rights Reserved\r\n# US Government Users Restricted Rights - Use, duplication or\r\n# disclosure restricted by GSA ADP Schedule Contract with\r\n# IBM Corp.\r\n\r\n# NLS_ENCODING=UNICODE\r\n# NLS_MESSAGEFORMAT_VAR\r\n\r\nbrm.custom.MyRule=Regola personale\r\nbrm.custom.MyRule.new=Nuova istanza di Regola personale\r\nbrm.custom.Requirement=Requisito\r\n\r\nrf_status=Stato RF\r\ngeography=Geografia\r\nalternate=Alternativo\r\nstatus=Stato\r\neffectiveDate=Data di validit\\u00e0\r\nexpirationDate=Data di scadenza\r\neditRequirements=Requisiti\r\ntext=Testo\r\nurl=URL\r\n%emptyMyRule_key=Regola personale vuota\r\n\r\n# Values for the Status enumeration. Will be used in sentences such as \"Rule Artifact status : New\".\r\n# Translate ''new'' key as male gender\r\nnew=Nuovo\r\nvalidated=Convalidato\r\ndefined=Definito\r\nrejected=Rifiutata\r\ninactive=Inattivo\r\ndeployable=Distribuibile\r\n')),
(8, 'teamserver.messages_pt_BR', 16, STRINGDECODE('# Licensed Materials - Property of IBM\r\n# 5655-Y31 5725-W47 5737-A28 5725-B69 5737-H06 5737-I23\r\n# Copyright IBM Corp. 2009, 2023 All Rights Reserved\r\n# US Government Users Restricted Rights - Use, duplication or\r\n# disclosure restricted by GSA ADP Schedule Contract with\r\n# IBM Corp.\r\n\r\n# NLS_ENCODING=UNICODE\r\n# NLS_MESSAGEFORMAT_VAR\r\n\r\nbrm.custom.MyRule=Minha Regra\r\nbrm.custom.MyRule.new=Nova inst\\u00e2ncia de Minha Regra\r\nbrm.custom.Requirement=Requisito\r\n\r\nrf_status=Status de RF\r\ngeography=Geografia\r\nalternate=Alternate\r\nstatus=Status\r\neffectiveDate=Data Efetiva\r\nexpirationDate=Data de Expira\\u00e7\\u00e3o\r\neditRequirements=Requisitos\r\ntext=Texto\r\nurl=URL\r\n%emptyMyRule_key=Esvaziar Minha Regra\r\n\r\n# Values for the Status enumeration. Will be used in sentences such as \"Rule Artifact status : New\".\r\n# Translate ''new'' key as male gender\r\nnew=Novo\r\nvalidated=Validado\r\ndefined=Definido\r\nrejected=Rejeitado\r\ninactive=Inativo\r\ndeployable=Implement\\u00e1vel\r\n'));              
INSERT INTO "PUBLIC"."RTSRESOURCE" VALUES
(9, 'teamserver.messages_fr', 16, STRINGDECODE('# Licensed Materials - Property of IBM\r\n# 5655-Y31 5725-W47 5737-A28 5725-B69 5737-H06 5737-I23\r\n# Copyright IBM Corp. 2009, 2023 All Rights Reserved\r\n# US Government Users Restricted Rights - Use, duplication or\r\n# disclosure restricted by GSA ADP Schedule Contract with\r\n# IBM Corp.\r\n\r\n# NLS_ENCODING=UNICODE\r\n# NLS_MESSAGEFORMAT_VAR\r\n\r\nbrm.custom.MyRule=Ma r\\u00e8gle\r\nbrm.custom.MyRule.new=Nouvelle instance de Ma r\\u00e8gle\r\nbrm.custom.Requirement=Exigence\r\n\r\nrf_status=Statut du flux d''ex\\u00e9cution\r\ngeography=G\\u00e9ographie\r\nalternate=Alternatif\r\nstatus=Statut\r\neffectiveDate=Date d''entr\\u00e9e en vigueur\r\nexpirationDate=Date d''expiration\r\neditRequirements=Exigences\r\ntext=Texte\r\nurl=URL\r\n%emptyMyRule_key=Ma r\\u00e8gle vide\r\n\r\n# Values for the Status enumeration. Will be used in sentences such as \"Rule Artifact status : New\".\r\n#\r\n# Translate all keys as MALE gender !!!\r\nnew=Nouveau\r\nvalidated=Valid\\u00e9\r\ndefined=D\\u00e9fini\r\nrejected=Rejet\\u00e9\r\ninactive=Inactif\r\ndeployable=D\\u00e9ployable\r\n')),
(10, 'teamserver.messages_es', 16, STRINGDECODE('# Licensed Materials - Property of IBM\r\n# 5655-Y31 5725-W47 5737-A28 5725-B69 5737-H06 5737-I23\r\n# Copyright IBM Corp. 2009, 2023 All Rights Reserved\r\n# US Government Users Restricted Rights - Use, duplication or\r\n# disclosure restricted by GSA ADP Schedule Contract with\r\n# IBM Corp.\r\n\r\n# NLS_ENCODING=UNICODE\r\n# NLS_MESSAGEFORMAT_VAR\r\n\r\nbrm.custom.MyRule=Mi regla\r\nbrm.custom.MyRule.new=Nueva instancia de Mi regla\r\nbrm.custom.Requirement=Requisito\r\n\r\nrf_status=Estado de RF\r\ngeography=Geograf\\u00eda\r\nalternate=Alternativo\r\nstatus=Estado\r\neffectiveDate=Fecha de efectividad\r\nexpirationDate=Fecha de caducidad\r\neditRequirements=Requisitos\r\ntext=Texto\r\nurl=URL\r\n%emptyMyRule_key=Vaciar Mi regla\r\n\r\n# Values for the Status enumeration. Will be used in sentences such as \"Rule Artifact status : New\".\r\n# Translate ''new'' key as male gender\r\nnew=Nuevo\r\nvalidated=Validado\r\ndefined=Definida\r\nrejected=Rechazada\r\ninactive=Inactiva\r\ndeployable=Desplegable\r\n')),
(11, 'teamserver.messages_zh', 16, STRINGDECODE('# Licensed Materials - Property of IBM\r\n# 5655-Y31 5725-W47 5737-A28 5725-B69 5737-H06 5737-I23\r\n# Copyright IBM Corp. 2009, 2023 All Rights Reserved\r\n# US Government Users Restricted Rights - Use, duplication or\r\n# disclosure restricted by GSA ADP Schedule Contract with\r\n# IBM Corp.\r\n\r\n# NLS_ENCODING=UNICODE\r\n# NLS_MESSAGEFORMAT_VAR\r\n\r\nbrm.custom.MyRule=\\u6211\\u7684\\u89c4\\u5219\r\nbrm.custom.MyRule.new=\\u65b0\\u5efa\\u6211\\u7684\\u89c4\\u5219\\u5b9e\\u4f8b\r\nbrm.custom.Requirement=\\u8981\\u6c42\r\n\r\nrf_status=RF \\u72b6\\u6001\r\ngeography=\\u5730\\u7406\\u4f4d\\u7f6e\r\nalternate=\\u5907\\u7528\r\nstatus=\\u72b6\\u6001\r\neffectiveDate=\\u751f\\u6548\\u65e5\\u671f\r\nexpirationDate=\\u622a\\u6b62\\u65e5\\u671f\r\neditRequirements=\\u8981\\u6c42\r\ntext=\\u6587\\u672c\r\nurl=URL\r\n%emptyMyRule_key=\\u6e05\\u7a7a\\u6211\\u7684\\u89c4\\u5219\r\n\r\n# Values for the Status enumeration. Will be used in sentences such as \"Rule Artifact status : New\".\r\n# Translate ''new'' key as male gender\r\nnew=\\u65b0\\u5efa\r\nvalidated=\\u5df2\\u9a8c\\u8bc1\r\ndefined=\\u5df2\\u5b9a\\u4e49\r\nrejected=\\u5df2\\u62d2\\u7edd\r\ninactive=\\u672a\\u6fc0\\u6d3b\r\ndeployable=\\u53ef\\u90e8\\u7f72\r\n')),
(12, 'teamserver.messages_zh_TW', 16, STRINGDECODE('# Licensed Materials - Property of IBM\r\n# 5655-Y31 5725-W47 5737-A28 5725-B69 5737-H06 5737-I23\r\n# Copyright IBM Corp. 2009, 2023 All Rights Reserved\r\n# US Government Users Restricted Rights - Use, duplication or\r\n# disclosure restricted by GSA ADP Schedule Contract with\r\n# IBM Corp.\r\n\r\n# NLS_ENCODING=UNICODE\r\n# NLS_MESSAGEFORMAT_VAR\r\n\r\nbrm.custom.MyRule=\\u6211\\u7684\\u898f\\u5247\r\nbrm.custom.MyRule.new=\\u300c\\u6211\\u7684\\u898f\\u5247\\u300d\\u7684\\u65b0\\u5be6\\u4f8b\r\nbrm.custom.Requirement=\\u9700\\u6c42\r\n\r\nrf_status=RF \\u72c0\\u614b\r\ngeography=\\u5730\\u7406\r\nalternate=\\u66ff\\u4ee3\r\nstatus=\\u72c0\\u614b\r\neffectiveDate=\\u6709\\u6548\\u65e5\\u671f\r\nexpirationDate=\\u5230\\u671f\\u65e5\r\neditRequirements=\\u9700\\u6c42\r\ntext=\\u6587\\u5b57\r\nurl=URL\r\n%emptyMyRule_key=\\u6e05\\u7a7a\\u300c\\u6211\\u7684\\u898f\\u5247\\u300d\r\n\r\n# Values for the Status enumeration. Will be used in sentences such as \"Rule Artifact status : New\".\r\n# Translate ''new'' key as male gender\r\nnew=\\u65b0\\u5efa\r\nvalidated=\\u5df2\\u9a57\\u8b49\r\ndefined=\\u5df2\\u5b9a\\u7fa9\r\nrejected=\\u62d2\\u7d55\r\ninactive=\\u975e\\u4f5c\\u7528\\u4e2d\r\ndeployable=\\u53ef\\u90e8\\u7f72\r\n'));
INSERT INTO "PUBLIC"."RTSRESOURCE" VALUES
(13, 'teamserver.messages_ja', 16, STRINGDECODE('# Licensed Materials - Property of IBM\r\n# 5655-Y31 5725-W47 5737-A28 5725-B69 5737-H06 5737-I23\r\n# Copyright IBM Corp. 2009, 2023 All Rights Reserved\r\n# US Government Users Restricted Rights - Use, duplication or\r\n# disclosure restricted by GSA ADP Schedule Contract with\r\n# IBM Corp.\r\n\r\n# NLS_ENCODING=UNICODE\r\n# NLS_MESSAGEFORMAT_VAR\r\n\r\nbrm.custom.MyRule=\\u30de\\u30a4\\u30fb\\u30eb\\u30fc\\u30eb\r\nbrm.custom.MyRule.new=\\u30de\\u30a4\\u30fb\\u30eb\\u30fc\\u30eb\\u306e\\u65b0\\u898f\\u30a4\\u30f3\\u30b9\\u30bf\\u30f3\\u30b9\r\nbrm.custom.Requirement=\\u8981\\u4ef6\r\n\r\nrf_status=RF \\u72b6\\u6cc1\r\ngeography=\\u30b8\\u30aa\\u30b0\\u30e9\\u30d5\\u30a3\\u30fc\r\nalternate=\\u4ee3\\u66ff\r\nstatus=\\u72b6\\u6cc1\r\neffectiveDate=\\u767a\\u52b9\\u65e5\r\nexpirationDate=\\u6709\\u52b9\\u671f\\u9650\r\neditRequirements=\\u8981\\u4ef6\r\ntext=\\u30c6\\u30ad\\u30b9\\u30c8\r\nurl=URL\r\n%emptyMyRule_key=\\u30de\\u30a4\\u30fb\\u30eb\\u30fc\\u30eb\\u3092\\u7a7a\\u306b\\u3059\\u308b\r\n\r\n# Values for the Status enumeration. Will be used in sentences such as \"Rule Artifact status : New\".\r\n# Translate ''new'' key as male gender\r\nnew=\\u65b0\\u898f\r\nvalidated=\\u691c\\u8a3c\\u6e08\\u307f\r\ndefined=\\u5b9a\\u7fa9\\u6e08\\u307f\r\nrejected=\\u62d2\\u5426\\u6e08\\u307f\r\ninactive=\\u975e\\u30a2\\u30af\\u30c6\\u30a3\\u30d6\r\ndeployable=\\u914d\\u5e03\\u53ef\\u80fd\r\n')),
(14, 'teamserver.messages_pl', 16, STRINGDECODE('# Licensed Materials - Property of IBM\r\n# 5655-Y31 5725-W47 5737-A28 5725-B69 5737-H06 5737-I23\r\n# Copyright IBM Corp. 2009, 2023 All Rights Reserved\r\n# US Government Users Restricted Rights - Use, duplication or\r\n# disclosure restricted by GSA ADP Schedule Contract with\r\n# IBM Corp.\r\n\r\n# NLS_ENCODING=UNICODE\r\n# NLS_MESSAGEFORMAT_VAR\r\n\r\nbrm.custom.MyRule=Moja regu\\u0142a\r\nbrm.custom.MyRule.new=Nowa instancja mojej regu\\u0142y\r\nbrm.custom.Requirement=Wymaganie\r\n\r\nrf_status=Status RF\r\ngeography=Geografia\r\nalternate=Naprzemienne\r\nstatus=Status\r\neffectiveDate=Data obowi\\u0105zywania\r\nexpirationDate=Data wa\\u017cno\\u015bci\r\neditRequirements=Wymagania\r\ntext=Tekst\r\nurl=Adres URL\r\n%emptyMyRule_key=Wyczy\\u015b\\u0107 moj\\u0105 regu\\u0142\\u0119\r\n\r\n# Values for the Status enumeration. Will be used in sentences such as \"Rule Artifact status : New\".\r\n# Translate ''new'' key as male gender\r\nnew=Nowe\r\nvalidated=Sprawdzone\r\ndefined=Zdefiniowane\r\nrejected=Odrzucone\r\ninactive=Nieaktywne\r\ndeployable=Wdra\\u017calne\r\n')),
(15, 'teamserver.messages_nl', 16, STRINGDECODE('# Licensed Materials - Property of IBM\r\n# 5655-Y31 5725-W47 5737-A28 5725-B69 5737-H06 5737-I23\r\n# Copyright IBM Corp. 2009, 2023 All Rights Reserved\r\n# US Government Users Restricted Rights - Use, duplication or\r\n# disclosure restricted by GSA ADP Schedule Contract with\r\n# IBM Corp.\r\n\r\n# NLS_ENCODING=UNICODE\r\n# NLS_MESSAGEFORMAT_VAR\r\n\r\nbrm.custom.MyRule=Mijn regel\r\nbrm.custom.MyRule.new=Nieuwe instance van Mijn regel\r\nbrm.custom.Requirement=Vereiste\r\n\r\nrf_status=RF-status\r\ngeography=Geografie\r\nalternate=Alternatief\r\nstatus=Status\r\neffectiveDate=Ingangsdatum\r\nexpirationDate=Vervaldatum\r\neditRequirements=Vereisten\r\ntext=Tekst\r\nurl=URL\r\n%emptyMyRule_key=Lege Mijn regel\r\n\r\n# Values for the Status enumeration. Will be used in sentences such as \"Rule Artifact status : New\".\r\n# Translate ''new'' key as male gender\r\nnew=Nieuw\r\nvalidated=Gevalideerd\r\ndefined=Gedefinieerd\r\nrejected=Afgewezen\r\ninactive=Inactief\r\ndeployable=Implementeerbaar\r\n')),
(16, 'teamserver.usersRolesRegistry', 16, STRINGDECODE('<dc-usermanagement>\n\t<role name=\"rtsAdministrator\"/>\n\t<role name=\"rtsConfigManager\"/>\n\t<role name=\"rtsInstaller\"/>\n\t<role name=\"rtsUser\"/>\n\n\t<group name=\"rtsAdministrators\" roles=\"rtsAdministrator\"/>\n\t<group name=\"rtsConfigManagers\" roles=\"rtsConfigManager\"/>\n\t<group name=\"rtsInstallers\" roles=\"rtsInstaller\"/>\n\t<group name=\"rtsUsers\" roles=\"rtsUser\"/>\n\t\n        <user name=\"odmAdmin\" groups=\"rtsAdministrators, rtsInstallers, rtsConfigManagers, rtsUsers\"/>\n\t<user name=\"rtsAdmin\" groups=\"rtsAdministrators, rtsInstallers, rtsConfigManagers, rtsUsers\"/>\n\t<user name=\"rtsConfig\" groups=\"rtsConfigManagers, rtsUsers\"/>\n\t<user name=\"rtsUser1\" groups=\"rtsUsers\"/>\n\t<user name=\"rtsUser2\" groups=\"rtsUsers\"/>\n</dc-usermanagement>\n')); 
CREATE CACHED TABLE "PUBLIC"."RULEAPP"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CREATEDBY" VARCHAR(100),
    "CREATEDON" TIMESTAMP,
    "LASTCHANGEDBY" VARCHAR(100),
    "LASTCHANGEDON" TIMESTAMP,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "DEPLOYEDBASELINES" CLOB(52428800),
    "DESCRIPTION" VARCHAR(255),
    "DISPLAYNAME" VARCHAR(255),
    "MAJOR" INTEGER,
    "MINOR" INTEGER
);               
ALTER TABLE "PUBLIC"."RULEAPP" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_8" PRIMARY KEY("ID");       
-- 1 +/- SELECT COUNT(*) FROM PUBLIC.RULEAPP;  
INSERT INTO "PUBLIC"."RULEAPP" VALUES
(2147483647, 1, NULL, NULL, NULL, NULL, 'Dummy record for internal purposes.', '.', NULL, NULL, NULL, NULL, NULL);       
CREATE UNIQUE INDEX "PUBLIC"."RULEAPPUUIDUNIQUE" ON "PUBLIC"."RULEAPP"("UUID");
CREATE INDEX "PUBLIC"."FKRULEAPPTYPIDX" ON "PUBLIC"."RULEAPP"("TYPE");         
CREATE CACHED TABLE "PUBLIC"."RULEAPPPROPERTY"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CONTAINER" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "VALUE" CLOB(52428800)
);      
ALTER TABLE "PUBLIC"."RULEAPPPROPERTY" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_16" PRIMARY KEY("ID");              
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.RULEAPPPROPERTY;          
CREATE INDEX "PUBLIC"."RULEAPPPROPERTY_CONTAINER" ON "PUBLIC"."RULEAPPPROPERTY"("CONTAINER");  
CREATE UNIQUE INDEX "PUBLIC"."RULEAPPPROPERTYNAMEUNIQUE" ON "PUBLIC"."RULEAPPPROPERTY"("CONTAINER", "NAME");   
CREATE INDEX "PUBLIC"."FKRULEAPPPROPERTYTYPIDX" ON "PUBLIC"."RULEAPPPROPERTY"("TYPE");         
CREATE CACHED TABLE "PUBLIC"."RULEPROJECT"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CREATEDBY" VARCHAR(100),
    "CREATEDON" TIMESTAMP,
    "LASTCHANGEDBY" VARCHAR(100),
    "LASTCHANGEDON" TIMESTAMP,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "ADVANCEDPROPERTIES" CLOB(52428800),
    "DECISIONSERVICE" BOOLEAN NOT NULL,
    "DESCRIPTION" CLOB(52428800),
    "PLATFORM" VARCHAR(30),
    "VERSION" INTEGER NOT NULL
);              
ALTER TABLE "PUBLIC"."RULEPROJECT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_EA" PRIMARY KEY("ID");  
-- 7 +/- SELECT COUNT(*) FROM PUBLIC.RULEPROJECT;              
INSERT INTO "PUBLIC"."RULEPROJECT" VALUES
(1, 46, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:19', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:19', 'Loan Validation Base', '95bee8f8-0a4f-4533-ad36-0edac68b228b', NULL, FALSE, NULL, 'java', 0),
(2, 46, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:38', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39', 'Loan Validation Check', '359be0d1-38c8-4d01-ad76-4d879da1ec96', NULL, FALSE, NULL, 'java', 0),
(3, 46, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39', 'Loan Validation Determination', 'a2912fa3-51a9-4041-bc88-d100f2d705ba', NULL, FALSE, NULL, 'java', 0),
(4, 46, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', 'Loan Validation Scoring', '46932af5-a9bc-4f10-9d33-ae691074e8e0', NULL, FALSE, NULL, 'java', 0),
(5, 46, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:22', 'Loan Validation Service', '4ea8ed3f-98a0-4b25-853c-6cc857215ae8', NULL, TRUE, NULL, 'java', 0),
(6, 46, 'odmAdmin', TIMESTAMP '2023-05-04 14:35:15', 'odmAdmin', TIMESTAMP '2023-05-04 14:35:31', 'Miniloan Service', 'f4440cab-4dca-471c-8a9e-ec05ede7c031', NULL, TRUE, NULL, 'java', 0),
(2147483647, 1, NULL, NULL, NULL, NULL, 'Dummy record for internal purposes.', '.', NULL, FALSE, NULL, NULL, 0);     
CREATE UNIQUE INDEX "PUBLIC"."RULEPROJECTUUIDUNIQUE" ON "PUBLIC"."RULEPROJECT"("UUID");        
CREATE INDEX "PUBLIC"."FKRULEPROJECTTYPIDX" ON "PUBLIC"."RULEPROJECT"("TYPE"); 
CREATE CACHED TABLE "PUBLIC"."BRSTUDIO"(
    "UUID" VARCHAR(46) NOT NULL,
    "PROJECT" INTEGER NOT NULL,
    "ELTORIGINALID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL
); 
ALTER TABLE "PUBLIC"."BRSTUDIO" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_4C" PRIMARY KEY("UUID");   
-- 125 +/- SELECT COUNT(*) FROM PUBLIC.BRSTUDIO;               
INSERT INTO "PUBLIC"."BRSTUDIO" VALUES
('2c4314aa-0a44-4a32-aabc-0978ea434414', 1, 1, 25),
('fc4ffffa-050b-453c-985b-75a9ed15fd71', 1, 2, 25),
('84957601-3998-4e62-b051-4d8c566555df', 1, 3, 25),
('cf615ea3-7c2d-4da6-8c48-f67d30642239', 1, 4, 25),
('34d9feee-0900-4d89-b92e-fb3c2e424a90', 1, 5, 25),
('a7caa1f7-0257-4cc3-a464-561d2fd8a274', 1, 1, 5),
('a5f8bd3d-d967-41bb-94cb-454672e27811', 1, 1, 26),
('66f69a65-d7fa-4596-b8ad-08e837c89800', 1, 1, 41),
('3abc737a-ba41-4dcf-a7d1-012b9484f9f8', 1, 2, 41),
('81640342-7aa9-4c1a-867e-ee6bc21dba20', 1, 1, 63),
('298ef717-efd8-4b46-9bfc-28f2f82612b0', 1, 1, 34),
('70d9ac8b-6d1d-4ec6-8841-ccb8278cc6ed', 1, 1, 80),
('e84c8ea0-d58a-46de-8d12-2c0d4ea10e6f', 2, 6, 25),
('640f5094-4ada-4076-a880-99deb51fccaa', 2, 7, 25),
('f28458de-dd47-401c-a76c-2ca6809153b2', 2, 8, 25),
('9bad0a10-0116-495d-89e2-dd645ff1fdcd', 2, 9, 25),
('104cfd87-169d-4fc5-a8ef-df8916aa6be3', 2, 10, 25),
('278f8627-849d-4dd4-b5a0-feda2ecf3c5a', 2, 2, 5),
('d964a314-487c-43ef-9940-b0726a8fc55f', 2, 3, 5),
('d73ae58b-f6c9-41e2-8e2e-1160f3e965db', 2, 4, 5),
('e9c4e688-8ece-4347-bc80-59347e408398', 2, 1, 56),
('85980264-7328-45e2-bc8b-fc8dbbf429c9', 2, 2, 56),
('3d0baca6-b708-4be4-893a-fa988452dfb9', 2, 3, 56),
('f7871a3e-5f1e-4d7d-b235-4e6129919c57', 2, 4, 56),
('b0361335-f157-4660-a3dc-146c8e301ddb', 2, 5, 56),
('c5b9e0ce-c668-4a77-9f0a-8ea444e459e0', 2, 6, 56),
('ed377117-aad4-4b38-b60e-321402b9e308', 3, 11, 25),
('9095db28-53e5-4a92-b5ad-4e6dbc2bac84', 3, 12, 25),
('0e79f418-496e-4629-bd2b-ff3c8faec5f7', 3, 13, 25),
('3430526e-0856-49ad-9625-2a0e78b2999f', 3, 14, 25),
('103301f2-abce-4e4f-9b0e-2ba4916ea0c9', 3, 15, 25),
('ca657f70-727c-407b-b460-7110aee225e9', 3, 5, 5),
('270c3761-353a-44c7-b9ca-0fd08ba926d9', 3, 6, 5),
('48827069-467c-4c12-8d23-06eb9d0ba48f', 3, 7, 28),
('c7be44d1-ca4c-4108-92e2-3816134e66a2', 3, 8, 56),
('350b2987-2b8e-4a0c-99fe-d06ab0af90ba', 3, 9, 56),
('c8dafd02-cb18-4a33-ba0c-ec0dfd12e8b8', 3, 10, 56),
('842c35bf-47f4-41f5-a6f8-f43dfe302609', 3, 11, 56),
('67bf4528-7e1c-4ef0-8089-3407e1d0c224', 3, 12, 56),
('639203c5-bd7d-4696-bb7e-eee46e008cb0', 3, 13, 28),
('966338e1-cfde-4e21-861b-3a7335ff0df2', 3, 1, 51),
('bfd94025-3f29-48be-81b9-9eb2676f252f', 3, 1, 108),
('0a2753aa-35fd-4809-a699-c2612203e73a', 4, 16, 25),
('cb284b67-21aa-4efb-a4c4-3add35a9cabf', 4, 17, 25),
('6ef01662-0512-4888-933e-1b295d3cdd5a', 4, 18, 25),
('46eea6b1-2d30-4d73-8c6b-82eadc2f6f5c', 4, 19, 25),
('7e30a7c4-2add-43cb-8e19-e9d6d00c896f', 4, 20, 25),
('034cc72e-0fb3-4b12-9341-281508191005', 4, 7, 5),
('7c47ee41-f999-4157-b91a-be48d7e4facf', 4, 14, 28),
('f8ebe74d-bf29-48fd-a9f4-a4b7cd124d14', 4, 15, 56),
('b1ade762-dc28-4abc-8033-e300be183560', 4, 16, 56),
('59352b03-2138-4986-9347-52e771a8bb16', 4, 17, 28),
('2ee02474-d7ae-4410-beba-d3b55a6df36f', 4, 18, 56),
('1e28b410-f5bd-44b4-9cb6-8f9784895282', 4, 19, 28),
('bfad24fb-ca9b-4564-80c1-8ac1fcce01c2', 4, 2, 51),
('51e8a165-61db-4065-99fc-292399966857', 4, 3, 108),
('527ab526-cbf0-421f-a715-465ac765fc19', 5, 21, 25),
('74ff73d2-ecf2-4d60-a6bf-0a921afba8e2', 5, 22, 25),
('302ea0d5-55d3-41f9-9e30-c37f671f85c1', 5, 23, 25),
('0baddb90-5ce9-455d-a169-5814c8a3763d', 5, 24, 25),
('cc1eba8b-5d7b-433b-862e-fc1b7f037377', 5, 25, 25),
('fe849835-b11b-472d-bf90-bf84c5306c7c', 5, 8, 5),
('f5dc0b49-f2a1-467d-abb0-059d6e0d5c62', 5, 3, 51),
('2ea0f1ac-f84b-4ae6-a617-c361168d274d', 5, 26, 1),
('d757de3a-495c-405f-8067-8b01ddfc98cd', 5, 2, 80),
('1b0002ea-1a08-4d78-a322-b9de0b255169', 5, 1, 111),
('e97915be-0315-444e-9102-58cfa5f7bc03', 5, 2, 111),
('9017e68b-1f53-496e-998f-5d41393e1c84', 5, 5, 108),
('7e5cbd47-fb79-4430-a17c-85ec1b2ebe6c', 5, 6, 108),
('ad67b0f6-5623-443e-a4fd-503eb91efbc6', 5, 1, 132),
('f471d78a-6d65-4402-8361-24e106ad9ae1', 5, 1, 129),
('7acb83d6-6aec-4e0a-b03b-1a852dfa276d', 5, 1, 126),
('e871171f-b312-42ca-82e6-98d44c94eca8', 5, 1, 127),
('0c7bd617-4dd8-41fd-aba5-e3d968bc465f', 5, 1, 124),
('13fb2d83-117e-4860-a20d-4af3e5dd1aa2', 5, 2, 124),
('9d7c5dba-a4ff-494b-8638-b8b227789392', 5, 3, 124),
('95100df6-2f0e-4ab5-9127-fd2cf0847a9c', 5, 4, 124),
('e036e33c-61f9-488a-a76c-58e927ab79ab', 5, 5, 124);
INSERT INTO "PUBLIC"."BRSTUDIO" VALUES
('47e7db0c-407b-4304-9a16-d683c73e2291', 5, 6, 124),
('7539ac5f-4a30-40d0-ae3e-a781f31dddec', 5, 7, 124),
('3518d0b4-3130-4418-8ed3-5a1f48e13727', 5, 8, 124),
('34053b24-dbaf-4390-a637-e5b5afbf303a', 5, 9, 124),
('37b256af-3b6b-4f92-b514-cf2d8e3bc0d7', 5, 10, 124),
('ad2c05ab-2460-420f-84db-f689b257bd2a', 5, 11, 124),
('3a9f1f4a-6509-4a95-b48d-1ce8f212d5fc', 5, 1, 125),
('c410d2b9-24ab-4e52-b070-52faef32248d', 5, 2, 125),
('c94eeec0-e48c-4866-ad45-b3ca93f86ead', 5, 3, 125),
('a673100c-2c31-4689-94be-624adf1ecfbc', 5, 4, 125),
('5e8ebe3c-14f3-4367-b7e6-51fbd8ad44dc', 5, 5, 125),
('6e5f028e-68e0-4db7-91eb-8b5eda29e0e1', 5, 6, 125),
('c95d53b0-f3f5-4c9b-b03d-f09c20d77776', 5, 7, 125),
('fdb5d919-5624-46cd-bcc3-ed704c0ac3c4', 5, 8, 125),
('5a1c14db-765e-48a7-bd8d-e99c32c1441f', 5, 9, 125),
('ca7f1b56-5bd8-411f-968e-12fe72733fa1', 5, 10, 125),
('cf4a0300-92a2-4107-83f4-234cf2057836', 5, 11, 125),
('3df57d06-a824-4ebe-bce9-cb0ddca0ed90', 5, 12, 125),
('e906b8eb-4289-4269-9f24-de0d7be50d56', 5, 13, 125),
('9b6551dd-92bb-4242-ab66-4b514583b365', 5, 14, 125),
('65fe17c7-bb02-4df7-a280-d94964ff4995', 5, 15, 125),
('a7821ace-49c0-4e39-b61d-b8657068372d', 5, 16, 125),
('a1fb618e-b087-4eaf-b53a-cb6adacc5e5d', 6, 27, 25),
('a36d8662-22fe-40e2-ac51-b2ca3e9a9870', 6, 28, 25),
('1e28047e-1847-4fda-a8d2-207114d6641a', 6, 29, 25),
('c34a3ea3-ce9c-4361-a959-fa891a82257c', 6, 30, 25),
('0ac0ebdd-99e1-4dbb-a2cb-b95109fb0bba', 6, 31, 25),
('b518810c-90e9-4508-b774-2cd02304e71c', 6, 9, 5),
('14871ffa-5aeb-4078-865e-f3d08d54ab77', 6, 10, 5),
('7f852e6a-8858-4c95-b072-9bb68f56417a', 6, 11, 5),
('d3f41bc5-5c35-4232-aa7b-23ae87e16477', 6, 2, 26),
('9366419c-718c-450d-a9b5-b4bec89535a4', 6, 3, 80),
('cbb8ced6-1bcf-452d-962f-12938c8e7da6', 6, 2, 34),
('b8f926e7-3133-4e64-9732-429d94bcea23', 6, 2, 63),
('91025540-61cb-4392-9731-d5c155081a58', 6, 20, 28),
('f5ad9c90-3892-433d-88ad-12de47e9d6ae', 6, 21, 56),
('9bc888e9-e5d9-4cd1-948b-2c435648e0d9', 6, 22, 56),
('f52ba17a-2a7e-4caa-9092-fecf906fcd6d', 6, 4, 51),
('50dc8154-1da8-4263-8666-d33e4e8b6c79', 6, 23, 56),
('92d289c8-4db8-4669-bb9f-4a48010ba78c', 6, 3, 41),
('44b9b9ad-f66d-408e-8ef0-61c8fe12f445', 6, 25, 111),
('30b58bec-77bb-430f-a9dd-2ed16dfa4426', 6, 9, 108),
('ce759625-8110-4715-92c2-973863fdad33', 6, 1, 119),
('c835a179-6a90-42a2-9339-eb340247d932', 5, 2, 119),
('b33ecf66-d7a1-4086-b47c-37b0011735f9', 5, 3, 119),
('75c12e25-15c5-4ddb-8b7f-fdc9e7b7be26', 5, 1, 128),
('674f531e-3197-4b99-9716-00d108e65cba', 5, 1, 134);              
CREATE INDEX "PUBLIC"."FKBRSTUDIOPRJCTIDX" ON "PUBLIC"."BRSTUDIO"("PROJECT");  
CREATE INDEX "PUBLIC"."FKBRSTUDIOTYPIDX" ON "PUBLIC"."BRSTUDIO"("TYPE");       
CREATE CACHED TABLE "PUBLIC"."CONNECTIONENTRY"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "BASETYPE" VARCHAR(255),
    "BRANCH" VARCHAR(30),
    "ENTRYTYPE" VARCHAR(255),
    "LOCALCHECKSUM" VARCHAR(100),
    "QUALIFIEDNAME" CLOB(52428800),
    "REMOTECHECKSUM" VARCHAR(100),
    "URL" CLOB(52428800),
    "UUID" VARCHAR(46),
    "CONTAINER" INTEGER NOT NULL
);    
ALTER TABLE "PUBLIC"."CONNECTIONENTRY" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_6E" PRIMARY KEY("ID");              
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.CONNECTIONENTRY;          
CREATE INDEX "PUBLIC"."CONNECTIONENTRY_CONTAINER" ON "PUBLIC"."CONNECTIONENTRY"("CONTAINER");  
CREATE INDEX "PUBLIC"."FKCONNECTIONENTRYTYPIDX" ON "PUBLIC"."CONNECTIONENTRY"("TYPE");         
CREATE CACHED TABLE "PUBLIC"."MERGEREPORT"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CREATEDBY" VARCHAR(100),
    "CREATEDON" TIMESTAMP,
    "LASTCHANGEDBY" VARCHAR(100),
    "LASTCHANGEDON" TIMESTAMP,
    "PROJECT" INTEGER NOT NULL,
    "SOURCEBRANCH" VARCHAR(255) NOT NULL,
    "TARGETBRANCH" VARCHAR(255) NOT NULL,
    "VALUE" BLOB,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL
);       
ALTER TABLE "PUBLIC"."MERGEREPORT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_BF" PRIMARY KEY("ID");  
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.MERGEREPORT;              
CREATE UNIQUE INDEX "PUBLIC"."MERGEREPORTUUIDUNIQUE" ON "PUBLIC"."MERGEREPORT"("UUID");        
CREATE INDEX "PUBLIC"."FKMERGEREPORTTYPIDX" ON "PUBLIC"."MERGEREPORT"("TYPE"); 
CREATE CACHED TABLE "PUBLIC"."RULESET"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CONTAINER" INTEGER NOT NULL,
    "BASELINE" VARCHAR(255) NOT NULL,
    "ILRDEBUG" BOOLEAN,
    "DESCRIPTION" VARCHAR(255),
    "DISPLAYNAME" VARCHAR(255),
    "ENABLED" BOOLEAN,
    "EXTRACTOR" VARCHAR(255),
    "MAJOR" INTEGER,
    "MINOR" INTEGER,
    "NAME" VARCHAR(255) NOT NULL,
    "PROJECT" VARCHAR(255) NOT NULL,
    "RULESETPROPERTIES" CLOB(52428800),
    "URL" CLOB(52428800)
);      
ALTER TABLE "PUBLIC"."RULESET" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_87" PRIMARY KEY("ID");      
-- 1 +/- SELECT COUNT(*) FROM PUBLIC.RULESET;  
INSERT INTO "PUBLIC"."RULESET" VALUES
(2147483647, 1, 2147483647, '.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Dummy record for internal purposes.', '.', NULL, NULL);      
CREATE INDEX "PUBLIC"."RULESET_CONTAINER" ON "PUBLIC"."RULESET"("CONTAINER");  
CREATE INDEX "PUBLIC"."FKRULESETTYPIDX" ON "PUBLIC"."RULESET"("TYPE");         
CREATE CACHED TABLE "PUBLIC"."BASELINE"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "AUTHORS" CLOB(52428800),
    "BASELINEKIND" VARCHAR(30) NOT NULL,
    "DEPNAME" VARCHAR(255),
    "DOCUMENTATION" CLOB(52428800),
    "EVENTIDSTRING" VARCHAR(50),
    "FROZEN" BOOLEAN,
    "PARENT" INTEGER,
    "READABLEVERSION" INTEGER NOT NULL,
    "CREATEDBY" VARCHAR(100),
    "CREATEDON" TIMESTAMP,
    "LASTCHANGEDBY" VARCHAR(100),
    "LASTCHANGEDON" TIMESTAMP,
    "GROUPS" CLOB(52428800),
    "SECURITYENFORCED" BOOLEAN NOT NULL,
    "SECURITYINHERITED" BOOLEAN NOT NULL,
    "APPROVERS" CLOB(52428800),
    "OWNER" VARCHAR(100) NOT NULL,
    "STATUS" VARCHAR(50) NOT NULL,
    "TARGETDATE" TIMESTAMP,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEAPP" INTEGER,
    "RULESET" INTEGER,
    "CONTAINER" INTEGER NOT NULL,
    "MAXVERSIONID" INTEGER NOT NULL,
    "DEPLOYMENTID" VARCHAR(100)
);            
ALTER TABLE "PUBLIC"."BASELINE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_C8" PRIMARY KEY("ID");     
-- 30 +/- SELECT COUNT(*) FROM PUBLIC.BASELINE;
INSERT INTO "PUBLIC"."BASELINE" VALUES
(1, 17, NULL, 'Branch', NULL, NULL, NULL, TRUE, NULL, 1, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:19', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:19', NULL, FALSE, FALSE, NULL, '.', '.', NULL, '%current_key', '51e37248-a6bd-48d5-b5ec-7683a1319adc', 2147483647, 2147483647, 1, 2147483647, NULL),
(2, 15, NULL, 'RecycleBin', NULL, NULL, NULL, TRUE, 1, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:19', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:19', NULL, FALSE, TRUE, NULL, '.', '.', NULL, '8d364a97-796b-4927-9389-41c0c286ff31', 'ed34604f-92d4-4818-aa74-a049a4600888', NULL, NULL, 1, 0, NULL),
(3, 15, NULL, 'Phantom', NULL, NULL, NULL, TRUE, 1, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:19', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:19', NULL, FALSE, TRUE, NULL, '.', '.', NULL, 'phantom', '5dc88adc-2985-4c62-b9f0-5bedfcbcd28e', NULL, NULL, 1, 0, NULL),
(4, 17, NULL, 'Branch', NULL, NULL, NULL, TRUE, NULL, 1, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:38', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:38', NULL, FALSE, FALSE, NULL, '.', '.', NULL, '%current_key', 'ccf7ef2a-5bb4-4bd9-8b9d-b08eec334aab', 2147483647, 2147483647, 2, 2147483647, NULL),
(5, 15, NULL, 'RecycleBin', NULL, NULL, NULL, TRUE, 4, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:38', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:38', NULL, FALSE, TRUE, NULL, '.', '.', NULL, '35b614a0-8da6-46b7-8e5f-363ec83577c6', 'eb381326-0b48-4d3f-b3ff-07c0bf0445c1', NULL, NULL, 2, 0, NULL),
(6, 15, NULL, 'Phantom', NULL, NULL, NULL, TRUE, 4, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:38', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:38', NULL, FALSE, TRUE, NULL, '.', '.', NULL, 'phantom', '8b1c2bf4-154e-478d-9d55-baa9f0aa69c4', NULL, NULL, 2, 0, NULL),
(7, 17, NULL, 'Branch', NULL, NULL, NULL, TRUE, NULL, 1, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39', NULL, FALSE, FALSE, NULL, '.', '.', NULL, '%current_key', 'c73807f2-e010-49bc-8a56-5ee68aa673be', 2147483647, 2147483647, 3, 2147483647, NULL),
(8, 15, NULL, 'RecycleBin', NULL, NULL, NULL, TRUE, 7, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39', NULL, FALSE, TRUE, NULL, '.', '.', NULL, '3898279d-7788-4c24-8c81-66c61b09b4ea', '4e3a285b-6bd3-4c09-ad1c-7a9662b38eeb', NULL, NULL, 3, 0, NULL),
(9, 15, NULL, 'Phantom', NULL, NULL, NULL, TRUE, 7, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39', NULL, FALSE, TRUE, NULL, '.', '.', NULL, 'phantom', '044d12b0-10ca-4050-a6bb-41abfd83077a', NULL, NULL, 3, 0, NULL),
(10, 17, NULL, 'Branch', NULL, NULL, NULL, TRUE, NULL, 1, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', NULL, FALSE, FALSE, NULL, '.', '.', NULL, '%current_key', '3a735d0f-696c-493c-bd6b-90e6baf8ad22', 2147483647, 2147483647, 4, 2147483647, NULL),
(11, 15, NULL, 'RecycleBin', NULL, NULL, NULL, TRUE, 10, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', NULL, FALSE, TRUE, NULL, '.', '.', NULL, 'fe370916-a06c-4f52-abd7-333a93da1790', 'c6c6010a-6b88-40ea-87cc-e7186baecc81', NULL, NULL, 4, 0, NULL),
(12, 15, NULL, 'Phantom', NULL, NULL, NULL, TRUE, 10, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', NULL, FALSE, TRUE, NULL, '.', '.', NULL, 'phantom', 'da40086d-7d9d-4f9f-a9b6-69dc57612655', NULL, NULL, 4, 0, NULL),
(13, 17, NULL, 'Branch', NULL, NULL, NULL, TRUE, NULL, 1, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', NULL, FALSE, FALSE, NULL, '.', '.', NULL, '%current_key', '66c67a4f-18cd-43c3-89d3-8d1fc4770ffa', 2147483647, 2147483647, 5, 2147483647, NULL),
(14, 15, NULL, 'RecycleBin', NULL, NULL, NULL, TRUE, 13, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', NULL, FALSE, TRUE, NULL, '.', '.', NULL, '0dd58349-7199-4b63-8e66-5ec33f139137', '13b08be4-5d6b-45b6-b10d-dac3586a9994', NULL, NULL, 5, 0, NULL),
(15, 15, NULL, 'Phantom', NULL, NULL, NULL, TRUE, 13, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', NULL, FALSE, TRUE, NULL, '.', '.', NULL, 'phantom', 'e876a40f-e8d0-455d-bcf2-0f3a63207d16', NULL, NULL, 5, 0, NULL);    
INSERT INTO "PUBLIC"."BASELINE" VALUES
(16, 17, NULL, 'Branch', NULL, NULL, NULL, TRUE, NULL, 1, 'odmAdmin', TIMESTAMP '2023-05-04 14:35:15', 'odmAdmin', TIMESTAMP '2023-05-04 14:35:15', NULL, FALSE, FALSE, NULL, '.', '.', NULL, '%current_key', '1a0a9ab7-42c1-48ee-815b-e3f255f6f9bc', 2147483647, 2147483647, 6, 2147483647, NULL),
(17, 15, NULL, 'RecycleBin', NULL, NULL, NULL, TRUE, 16, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:35:15', 'odmAdmin', TIMESTAMP '2023-05-04 14:35:15', NULL, FALSE, TRUE, NULL, '.', '.', NULL, '809c1b18-37cc-497a-ac0f-a31c2fbce252', '03819a1d-0972-4318-b34d-269eb4737453', NULL, NULL, 6, 0, NULL),
(18, 15, NULL, 'Phantom', NULL, NULL, NULL, TRUE, 16, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:35:15', 'odmAdmin', TIMESTAMP '2023-05-04 14:35:15', NULL, FALSE, TRUE, NULL, '.', '.', NULL, 'phantom', 'b1049f1d-178e-466a-963a-4f895809d3c1', NULL, NULL, 6, 0, NULL),
(19, 118, NULL, 'DsDeployment', 'Miniloan_2023-05-04_15-35-30-235', NULL, NULL, TRUE, 16, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:35:31', 'odmAdmin', TIMESTAMP '2023-05-04 14:35:31', NULL, FALSE, TRUE, NULL, '.', '.', NULL, 'Miniloan_2023-05-04_15-35-30-235', 'd33f7f78-bd3b-49d5-8a73-c2a0c350e33f', 2147483647, 2147483647, 6, 360, 'dsm.Deployment:25:34'),
(20, 118, NULL, 'DsDeployment', 'production_deployment_2023-05-04_15-36-04-536', NULL, NULL, TRUE, 1, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:36:05', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:05', NULL, FALSE, TRUE, NULL, '.', '.', NULL, 'production_deployment_2023-05-04_15-36-04-536', '87c109f1-5dba-42d9-a815-4d62871f9fcb', 2147483647, 2147483647, 1, 361, NULL),
(21, 118, NULL, 'DsDeployment', 'production_deployment_2023-05-04_15-36-04-536', NULL, NULL, TRUE, 4, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:36:05', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:05', NULL, FALSE, TRUE, NULL, '.', '.', NULL, 'production_deployment_2023-05-04_15-36-04-536', '682f55b7-cfe8-4412-9643-845c3ed09586', 2147483647, 2147483647, 2, 362, NULL),
(22, 118, NULL, 'DsDeployment', 'production_deployment_2023-05-04_15-36-04-536', NULL, NULL, TRUE, 7, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:36:05', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:05', NULL, FALSE, TRUE, NULL, '.', '.', NULL, 'production_deployment_2023-05-04_15-36-04-536', 'ce83224a-f88d-47b5-a5c2-dd99b59f41d8', 2147483647, 2147483647, 3, 363, NULL),
(23, 118, NULL, 'DsDeployment', 'production_deployment_2023-05-04_15-36-04-536', NULL, NULL, TRUE, 10, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:36:06', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:06', NULL, FALSE, TRUE, NULL, '.', '.', NULL, 'production_deployment_2023-05-04_15-36-04-536', 'd39cc077-f77f-4c73-a146-47f25c2d9312', 2147483647, 2147483647, 4, 364, NULL),
(24, 118, NULL, 'DsDeployment', 'production_deployment_2023-05-04_15-36-04-536', NULL, NULL, TRUE, 13, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:36:06', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:06', NULL, FALSE, TRUE, NULL, '.', '.', NULL, 'production_deployment_2023-05-04_15-36-04-536', '6d3a16c2-c9b1-444b-b7b7-cce0eb7cf74c', 2147483647, 2147483647, 5, 365, 'dsm.Deployment:2:24'),
(25, 118, NULL, 'DsDeployment', 'test_deployment_2023-05-04_15-36-19-681', NULL, NULL, TRUE, 1, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:36:22', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:22', NULL, FALSE, TRUE, NULL, '.', '.', NULL, 'test_deployment_2023-05-04_15-36-19-681', '53f91573-c957-4f9e-84d9-00ff5cf6f393', 2147483647, 2147483647, 1, 366, NULL),
(26, 118, NULL, 'DsDeployment', 'test_deployment_2023-05-04_15-36-19-681', NULL, NULL, TRUE, 4, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:36:22', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:22', NULL, FALSE, TRUE, NULL, '.', '.', NULL, 'test_deployment_2023-05-04_15-36-19-681', '0e83c1f4-818b-4b64-b88d-f0a8928fe1a0', 2147483647, 2147483647, 2, 367, NULL),
(27, 118, NULL, 'DsDeployment', 'test_deployment_2023-05-04_15-36-19-681', NULL, NULL, TRUE, 7, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:36:22', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:22', NULL, FALSE, TRUE, NULL, '.', '.', NULL, 'test_deployment_2023-05-04_15-36-19-681', 'f3d16ebd-f76b-423b-bfcc-df2019d9844f', 2147483647, 2147483647, 3, 368, NULL); 
INSERT INTO "PUBLIC"."BASELINE" VALUES
(28, 118, NULL, 'DsDeployment', 'test_deployment_2023-05-04_15-36-19-681', NULL, NULL, TRUE, 10, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:36:22', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:22', NULL, FALSE, TRUE, NULL, '.', '.', NULL, 'test_deployment_2023-05-04_15-36-19-681', '314a675d-b7cc-436e-83e9-253d4b2afb87', 2147483647, 2147483647, 4, 369, NULL),
(29, 118, NULL, 'DsDeployment', 'test_deployment_2023-05-04_15-36-19-681', NULL, NULL, TRUE, 13, 0, 'odmAdmin', TIMESTAMP '2023-05-04 14:36:22', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:22', NULL, FALSE, TRUE, NULL, '.', '.', NULL, 'test_deployment_2023-05-04_15-36-19-681', '454cdf94-93ae-435d-983f-1ee5547d5475', 2147483647, 2147483647, 5, 370, 'dsm.Deployment:1:16'),
(2147483647, 1, NULL, 'Null', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, FALSE, TRUE, NULL, '.', '.', NULL, 'Dummy record for internal purposes.', '.', NULL, NULL, 2147483647, 0, NULL);        
CREATE INDEX "PUBLIC"."BSLN_CONTAINER" ON "PUBLIC"."BASELINE"("CONTAINER");    
CREATE UNIQUE INDEX "PUBLIC"."BSLNUUIDUNIQUE" ON "PUBLIC"."BASELINE"("UUID");  
CREATE INDEX "PUBLIC"."BASELINEDATEIDX" ON "PUBLIC"."BASELINE"("LASTCHANGEDON");               
CREATE INDEX "PUBLIC"."BASELINEPARENTIDX" ON "PUBLIC"."BASELINE"("PARENT", "TYPE");            
CREATE INDEX "PUBLIC"."FKBSLNTYPIDX" ON "PUBLIC"."BASELINE"("TYPE");           
CREATE CACHED TABLE "PUBLIC"."BSLNLFTRGT"(
    "ID" INTEGER NOT NULL,
    "LFT" INTEGER NOT NULL,
    "RGT" INTEGER NOT NULL,
    "CONTAINER" INTEGER NOT NULL,
    "MAXVERSIONID" INTEGER,
    "PARENT" INTEGER,
    "TYPE" INTEGER NOT NULL
);               
ALTER TABLE "PUBLIC"."BSLNLFTRGT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_87D" PRIMARY KEY("ID");  
-- 30 +/- SELECT COUNT(*) FROM PUBLIC.BSLNLFTRGT;              
INSERT INTO "PUBLIC"."BSLNLFTRGT" VALUES
(1, 1, 14, 1, 2147483647, NULL, 17),
(2, 12, 13, 1, 0, 1, 15),
(3, 10, 11, 1, 0, 1, 15),
(4, 7, 20, 2, 2147483647, NULL, 17),
(5, 18, 19, 2, 0, 4, 15),
(6, 16, 17, 2, 0, 4, 15),
(7, 13, 26, 3, 2147483647, NULL, 17),
(8, 24, 25, 3, 0, 7, 15),
(9, 22, 23, 3, 0, 7, 15),
(10, 19, 32, 4, 2147483647, NULL, 17),
(11, 30, 31, 4, 0, 10, 15),
(12, 28, 29, 4, 0, 10, 15),
(13, 25, 38, 5, 2147483647, NULL, 17),
(14, 36, 37, 5, 0, 13, 15),
(15, 34, 35, 5, 0, 13, 15),
(16, 31, 38, 6, 2147483647, NULL, 17),
(17, 36, 37, 6, 0, 16, 15),
(18, 34, 35, 6, 0, 16, 15),
(19, 32, 33, 6, 360, 16, 118),
(20, 8, 9, 1, 361, 1, 118),
(21, 14, 15, 2, 362, 4, 118),
(22, 20, 21, 3, 363, 7, 118),
(23, 26, 27, 4, 364, 10, 118),
(24, 32, 33, 5, 365, 13, 118),
(25, 6, 7, 1, 366, 1, 118),
(26, 12, 13, 2, 367, 4, 118),
(27, 18, 19, 3, 368, 7, 118),
(28, 24, 25, 4, 369, 10, 118),
(29, 30, 31, 5, 370, 13, 118),
(2147483647, 0, 0, 2147483647, 0, 2147483647, 1); 
CREATE INDEX "PUBLIC"."BSLNLFTRGTANCIDX" ON "PUBLIC"."BSLNLFTRGT"("CONTAINER", "LFT", "RGT");  
CREATE INDEX "PUBLIC"."BSLNLFTRGTIDX" ON "PUBLIC"."BSLNLFTRGT"("CONTAINER", "TYPE", "LFT", "RGT");             
CREATE INDEX "PUBLIC"."BSLNLFTRGTPARENTIDX" ON "PUBLIC"."BSLNLFTRGT"("CONTAINER", "LFT", "RGT", "PARENT");     
CREATE INDEX "PUBLIC"."BSLNLFTRGTPARIDX2" ON "PUBLIC"."BSLNLFTRGT"("PARENT", "LFT", "RGT", "TYPE");            
CREATE INDEX "PUBLIC"."BSLNLFTRGTTYPEIDX" ON "PUBLIC"."BSLNLFTRGT"("TYPE");    
CREATE CACHED TABLE "PUBLIC"."MERGEINFO"(
    "LOCALBSLN" INTEGER NOT NULL,
    "REMOTEBSLN" INTEGER NOT NULL,
    "LASTVERSION" INTEGER NOT NULL
);           
ALTER TABLE "PUBLIC"."MERGEINFO" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_71" PRIMARY KEY("LOCALBSLN", "REMOTEBSLN");               
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.MERGEINFO;
CREATE INDEX "PUBLIC"."FKMERGEINFOLCLBSLNIDX" ON "PUBLIC"."MERGEINFO"("LOCALBSLN");            
CREATE INDEX "PUBLIC"."FKMERGEINFORMTBSLNIDX" ON "PUBLIC"."MERGEINFO"("REMOTEBSLN");           
CREATE CACHED TABLE "PUBLIC"."MERGEDTLS"(
    "LOCALBSLN" INTEGER NOT NULL,
    "REMOTEBSLN" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "VERSION" INTEGER NOT NULL
);               
ALTER TABLE "PUBLIC"."MERGEDTLS" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_71A" PRIMARY KEY("LOCALBSLN", "REMOTEBSLN", "ORIGINALID", "TYPE");        
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.MERGEDTLS;
CREATE INDEX "PUBLIC"."FKMERGEDTLSLCLBSLNIDX" ON "PUBLIC"."MERGEDTLS"("LOCALBSLN");            
CREATE CACHED TABLE "PUBLIC"."PROJECTINFO"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "BASELINE" INTEGER,
    "BUILDMODE" VARCHAR(30),
    "CATEGORIES" CLOB(52428800),
    "CONFIGFILE" CLOB(52428800),
    "DECISIONSERVICE" BOOLEAN NOT NULL,
    "DYNAMICXOM" CLOB(52428800),
    "MIGRATEDTOOPERATIONID" VARCHAR(46),
    "MIGRATIONFLAG" INTEGER NOT NULL,
    "PROJECT" INTEGER
);    
ALTER TABLE "PUBLIC"."PROJECTINFO" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_485" PRIMARY KEY("ID"); 
-- 29 +/- SELECT COUNT(*) FROM PUBLIC.PROJECTINFO;             
INSERT INTO "PUBLIC"."PROJECTINFO" VALUES
(1, 45, 1, 'DecisionEngine', 'any', NULL, FALSE, NULL, NULL, 3, 1),
(2, 45, 2, NULL, NULL, NULL, FALSE, NULL, NULL, 0, 1),
(3, 45, 3, NULL, NULL, NULL, FALSE, NULL, NULL, 0, 1),
(4, 45, 4, 'DecisionEngine', 'any', NULL, FALSE, NULL, NULL, 3, 2),
(5, 45, 5, NULL, NULL, NULL, FALSE, NULL, NULL, 0, 2),
(6, 45, 6, NULL, NULL, NULL, FALSE, NULL, NULL, 0, 2),
(7, 45, 7, 'DecisionEngine', 'any', NULL, FALSE, NULL, NULL, 3, 3),
(8, 45, 8, NULL, NULL, NULL, FALSE, NULL, NULL, 0, 3),
(9, 45, 9, NULL, NULL, NULL, FALSE, NULL, NULL, 0, 3),
(10, 45, 10, 'DecisionEngine', 'any', NULL, FALSE, NULL, '63c5002f-6e99-4346-9eaf-8f85b2550a40', 3, 4),
(11, 45, 11, NULL, NULL, NULL, FALSE, NULL, NULL, 0, 4),
(12, 45, 12, NULL, NULL, NULL, FALSE, NULL, NULL, 0, 4),
(13, 45, 13, 'DecisionEngine', 'any', NULL, TRUE, NULL, NULL, 3, 5),
(14, 45, 14, NULL, NULL, NULL, FALSE, NULL, NULL, 0, 5),
(15, 45, 15, NULL, NULL, NULL, FALSE, NULL, NULL, 0, 5),
(16, 45, 16, 'DecisionEngine', 'any', NULL, TRUE, NULL, '33a64099-9f21-4b28-9d24-b61f1ae28e50', 3, 6),
(17, 45, 17, NULL, NULL, NULL, FALSE, NULL, NULL, 0, 6),
(18, 45, 18, NULL, NULL, NULL, FALSE, NULL, NULL, 0, 6),
(19, 45, 19, 'DecisionEngine', 'any', NULL, TRUE, NULL, '33a64099-9f21-4b28-9d24-b61f1ae28e50', 3, 6),
(20, 45, 20, 'DecisionEngine', 'any', NULL, FALSE, NULL, NULL, 3, 1),
(21, 45, 21, 'DecisionEngine', 'any', NULL, FALSE, NULL, NULL, 3, 2),
(22, 45, 22, 'DecisionEngine', 'any', NULL, FALSE, NULL, NULL, 3, 3),
(23, 45, 23, 'DecisionEngine', 'any', NULL, FALSE, NULL, '63c5002f-6e99-4346-9eaf-8f85b2550a40', 3, 4),
(24, 45, 24, 'DecisionEngine', 'any', NULL, TRUE, NULL, NULL, 3, 5),
(25, 45, 25, 'DecisionEngine', 'any', NULL, FALSE, NULL, NULL, 3, 1),
(26, 45, 26, 'DecisionEngine', 'any', NULL, FALSE, NULL, NULL, 3, 2),
(27, 45, 27, 'DecisionEngine', 'any', NULL, FALSE, NULL, NULL, 3, 3),
(28, 45, 28, 'DecisionEngine', 'any', NULL, FALSE, NULL, '63c5002f-6e99-4346-9eaf-8f85b2550a40', 3, 4),
(29, 45, 29, 'DecisionEngine', 'any', NULL, TRUE, NULL, NULL, 3, 5); 
CREATE UNIQUE INDEX "PUBLIC"."PRJINFOBSLNIDX" ON "PUBLIC"."PROJECTINFO"("BASELINE");           
CREATE INDEX "PUBLIC"."FKPROJECTINFOTYPIDX" ON "PUBLIC"."PROJECTINFO"("TYPE"); 
CREATE CACHED TABLE "PUBLIC"."DEPENDENCY"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "BASELINENAME" VARCHAR(255),
    "PROJECTNAME" VARCHAR(255),
    "CONTAINER" INTEGER NOT NULL
);        
ALTER TABLE "PUBLIC"."DEPENDENCY" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_1B" PRIMARY KEY("ID");   
-- 18 +/- SELECT COUNT(*) FROM PUBLIC.DEPENDENCY;              
INSERT INTO "PUBLIC"."DEPENDENCY" VALUES
(1, 54, '%current_key', 'Loan Validation Base', 4),
(2, 54, '%current_key', 'Loan Validation Base', 7),
(3, 54, '%current_key', 'Loan Validation Base', 10),
(4, 54, '%current_key', 'Loan Validation Scoring', 13),
(5, 54, '%current_key', 'Loan Validation Determination', 13),
(6, 54, '%current_key', 'Loan Validation Check', 13),
(7, 54, 'production_deployment_2023-05-04_15-36-04-536', 'Loan Validation Base', 21),
(8, 54, 'production_deployment_2023-05-04_15-36-04-536', 'Loan Validation Base', 22),
(9, 54, 'production_deployment_2023-05-04_15-36-04-536', 'Loan Validation Base', 23),
(10, 54, 'production_deployment_2023-05-04_15-36-04-536', 'Loan Validation Scoring', 24),
(11, 54, 'production_deployment_2023-05-04_15-36-04-536', 'Loan Validation Determination', 24),
(12, 54, 'production_deployment_2023-05-04_15-36-04-536', 'Loan Validation Check', 24),
(13, 54, 'test_deployment_2023-05-04_15-36-19-681', 'Loan Validation Base', 26),
(14, 54, 'test_deployment_2023-05-04_15-36-19-681', 'Loan Validation Base', 27),
(15, 54, 'test_deployment_2023-05-04_15-36-19-681', 'Loan Validation Base', 28),
(16, 54, 'test_deployment_2023-05-04_15-36-19-681', 'Loan Validation Scoring', 29),
(17, 54, 'test_deployment_2023-05-04_15-36-19-681', 'Loan Validation Determination', 29),
(18, 54, 'test_deployment_2023-05-04_15-36-19-681', 'Loan Validation Check', 29);       
CREATE INDEX "PUBLIC"."DEPENDENCY_CONTAINER" ON "PUBLIC"."DEPENDENCY"("CONTAINER");            
CREATE INDEX "PUBLIC"."DEPBSLNIDX" ON "PUBLIC"."DEPENDENCY"("BASELINENAME", "PROJECTNAME", "CONTAINER");       
CREATE INDEX "PUBLIC"."FKDEPENDENCYTYPIDX" ON "PUBLIC"."DEPENDENCY"("TYPE");   
CREATE CACHED TABLE "PUBLIC"."MESSAGEMAP"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "BODY" CLOB(52428800),
    "LOCALE" VARCHAR(30),
    "CONTAINER" INTEGER NOT NULL
);    
ALTER TABLE "PUBLIC"."MESSAGEMAP" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_B8" PRIMARY KEY("ID");   
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.MESSAGEMAP;               
CREATE INDEX "PUBLIC"."MESSAGEMAP_CONTAINER" ON "PUBLIC"."MESSAGEMAP"("CONTAINER");            
CREATE INDEX "PUBLIC"."FKMESSAGEMAPTYPIDX" ON "PUBLIC"."MESSAGEMAP"("TYPE");   
CREATE CACHED TABLE "PUBLIC"."PARAMETER"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "DIRECTION" VARCHAR(30) NOT NULL,
    "ILRORDER" INTEGER NOT NULL,
    "CONTAINER" INTEGER NOT NULL,
    "BOMTYPE" CLOB(52428800) NOT NULL,
    "INITIALVALUE" CLOB(52428800),
    "NAME" VARCHAR(255) NOT NULL,
    "VERBALIZATION" CLOB(52428800)
);   
ALTER TABLE "PUBLIC"."PARAMETER" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_1A" PRIMARY KEY("ID");    
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.PARAMETER;
CREATE INDEX "PUBLIC"."PARAMETER_CONTAINER" ON "PUBLIC"."PARAMETER"("CONTAINER");              
CREATE UNIQUE INDEX "PUBLIC"."PARAMETERNAMEUNIQUE" ON "PUBLIC"."PARAMETER"("NAME", "CONTAINER");               
CREATE INDEX "PUBLIC"."FKPARAMETERTYPIDX" ON "PUBLIC"."PARAMETER"("TYPE");     
CREATE CACHED TABLE "PUBLIC"."RTSSCHEMA"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CONTAINER" INTEGER NOT NULL,
    "BODY" CLOB(52428800),
    "LOCATION" CLOB(52428800),
    "NAMESPACE" CLOB(52428800)
);
ALTER TABLE "PUBLIC"."RTSSCHEMA" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_4B" PRIMARY KEY("ID");    
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.RTSSCHEMA;
CREATE INDEX "PUBLIC"."RTSSCHEMA_CONTAINER" ON "PUBLIC"."RTSSCHEMA"("CONTAINER");              
CREATE INDEX "PUBLIC"."FKRTSSCHEMATYPIDX" ON "PUBLIC"."RTSSCHEMA"("TYPE");     
CREATE CACHED TABLE "PUBLIC"."RULEPROJECTTAG"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CONTAINER" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "VALUE" CLOB(52428800)
);       
ALTER TABLE "PUBLIC"."RULEPROJECTTAG" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_9C" PRIMARY KEY("ID");               
-- 67 +/- SELECT COUNT(*) FROM PUBLIC.RULEPROJECTTAG;          
INSERT INTO "PUBLIC"."RULEPROJECTTAG" VALUES
(1, 66, 1, 'outputLocation', 'output'),
(2, 66, 1, 'BOMEntry|platform:/Loan Validation Base/bom/model.bom', 'xom:/Loan Validation Base/loan-validation-xom'),
(3, 66, 1, 'LibraryXOMPathEntry|0|org.eclipse.jdt.launching.JRE_CONTAINER', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:LibraryXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"org.eclipse.jdt.launching.JRE_CONTAINER\" url=\"file:org.eclipse.jdt.launching.JRE_CONTAINER\" kind=\"LIBRARY\" exported=\"false\"/>\n')),
(4, 66, 1, 'SystemXOMPathEntry|1|loan-validation-xom', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"loan-validation-xom\" url=\"platform:/loan-validation-xom\" kind=\"JAVA_PROJECT\" exported=\"true\"/>\n')),
(5, 66, 1, 'missingDependencies', 'loan-validation-xom'),
(6, 66, 4, 'outputLocation', 'output'),
(7, 66, 4, 'LibraryXOMPathEntry|0|org.eclipse.jdt.launching.JRE_CONTAINER', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:LibraryXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"org.eclipse.jdt.launching.JRE_CONTAINER\" url=\"file:org.eclipse.jdt.launching.JRE_CONTAINER\" kind=\"LIBRARY\"/>\n')),
(8, 66, 4, 'SystemXOMPathEntry|1|Loan Validation Base', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"Loan Validation Base\" url=\"platform:/Loan Validation Base\" kind=\"RULE_PROJECT\"/>\n')),
(9, 66, 7, 'outputLocation', 'output'),
(10, 66, 7, 'LibraryXOMPathEntry|0|org.eclipse.jdt.launching.JRE_CONTAINER', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:LibraryXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"org.eclipse.jdt.launching.JRE_CONTAINER\" url=\"file:org.eclipse.jdt.launching.JRE_CONTAINER\" kind=\"LIBRARY\"/>\n')),
(11, 66, 7, 'SystemXOMPathEntry|1|Loan Validation Base', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"Loan Validation Base\" url=\"platform:/Loan Validation Base\" kind=\"RULE_PROJECT\"/>\n')),
(12, 66, 10, 'outputLocation', 'output'),
(13, 66, 10, 'LibraryXOMPathEntry|0|org.eclipse.jdt.launching.JRE_CONTAINER', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:LibraryXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"org.eclipse.jdt.launching.JRE_CONTAINER\" url=\"file:org.eclipse.jdt.launching.JRE_CONTAINER\" kind=\"LIBRARY\" exported=\"false\"/>\n')),
(14, 66, 10, 'SystemXOMPathEntry|1|Loan Validation Base', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"Loan Validation Base\" url=\"platform:/Loan Validation Base\" kind=\"RULE_PROJECT\"/>\n')),
(15, 66, 13, 'outputLocation', 'output'),
(16, 66, 13, 'LibraryXOMPathEntry|0|org.eclipse.jdt.launching.JRE_CONTAINER', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:LibraryXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"org.eclipse.jdt.launching.JRE_CONTAINER\" url=\"file:org.eclipse.jdt.launching.JRE_CONTAINER\" kind=\"LIBRARY\"/>\n'));
INSERT INTO "PUBLIC"."RULEPROJECTTAG" VALUES
(17, 66, 13, 'SystemXOMPathEntry|1|Loan Validation Determination', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"Loan Validation Determination\" url=\"platform:/Loan Validation Determination\" kind=\"RULE_PROJECT\"/>\n')),
(18, 66, 13, 'SystemXOMPathEntry|2|Loan Validation Check', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"Loan Validation Check\" url=\"platform:/Loan Validation Check\" kind=\"RULE_PROJECT\"/>\n')),
(19, 66, 13, 'SystemXOMPathEntry|3|Loan Validation Scoring', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"Loan Validation Scoring\" url=\"platform:/Loan Validation Scoring\" kind=\"RULE_PROJECT\"/>\n')),
(20, 66, 16, 'outputLocation', 'output'),
(21, 66, 16, 'BOMEntry|platform:/Miniloan Service/bom/miniloan.bom', 'xom:/Miniloan Service/miniloan-xom'),
(22, 66, 16, 'LibraryXOMPathEntry|0|org.eclipse.jdt.launching.JRE_CONTAINER', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:LibraryXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"org.eclipse.jdt.launching.JRE_CONTAINER\" url=\"file:org.eclipse.jdt.launching.JRE_CONTAINER\" kind=\"LIBRARY\"/>\n')),
(23, 66, 16, 'SystemXOMPathEntry|1|miniloan-xom', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"miniloan-xom\" url=\"platform:/miniloan-xom\" kind=\"JAVA_PROJECT\"/>\n')),
(24, 66, 16, 'missingDependencies', 'miniloan-xom'),
(25, 66, 19, 'outputLocation', 'output'),
(26, 66, 19, 'BOMEntry|platform:/Miniloan Service/bom/miniloan.bom', 'xom:/Miniloan Service/miniloan-xom'),
(27, 66, 19, 'LibraryXOMPathEntry|0|org.eclipse.jdt.launching.JRE_CONTAINER', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:LibraryXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"org.eclipse.jdt.launching.JRE_CONTAINER\" url=\"file:org.eclipse.jdt.launching.JRE_CONTAINER\" kind=\"LIBRARY\"/>\n')),
(28, 66, 19, 'SystemXOMPathEntry|1|miniloan-xom', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"miniloan-xom\" url=\"platform:/miniloan-xom\" kind=\"JAVA_PROJECT\"/>\n')),
(29, 66, 19, 'missingDependencies', 'miniloan-xom'),
(30, 66, 20, 'outputLocation', 'output'),
(31, 66, 20, 'BOMEntry|platform:/Loan Validation Base/bom/model.bom', 'xom:/Loan Validation Base/loan-validation-xom'),
(32, 66, 20, 'LibraryXOMPathEntry|0|org.eclipse.jdt.launching.JRE_CONTAINER', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:LibraryXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"org.eclipse.jdt.launching.JRE_CONTAINER\" url=\"file:org.eclipse.jdt.launching.JRE_CONTAINER\" kind=\"LIBRARY\" exported=\"false\"/>\n')),
(33, 66, 20, 'SystemXOMPathEntry|1|loan-validation-xom', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"loan-validation-xom\" url=\"platform:/loan-validation-xom\" kind=\"JAVA_PROJECT\" exported=\"true\"/>\n'));        
INSERT INTO "PUBLIC"."RULEPROJECTTAG" VALUES
(34, 66, 20, 'missingDependencies', 'loan-validation-xom'),
(35, 66, 21, 'outputLocation', 'output'),
(36, 66, 21, 'LibraryXOMPathEntry|0|org.eclipse.jdt.launching.JRE_CONTAINER', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:LibraryXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"org.eclipse.jdt.launching.JRE_CONTAINER\" url=\"file:org.eclipse.jdt.launching.JRE_CONTAINER\" kind=\"LIBRARY\"/>\n')),
(37, 66, 21, 'SystemXOMPathEntry|1|Loan Validation Base', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"Loan Validation Base\" url=\"platform:/Loan Validation Base\" kind=\"RULE_PROJECT\"/>\n')),
(38, 66, 22, 'outputLocation', 'output'),
(39, 66, 22, 'LibraryXOMPathEntry|0|org.eclipse.jdt.launching.JRE_CONTAINER', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:LibraryXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"org.eclipse.jdt.launching.JRE_CONTAINER\" url=\"file:org.eclipse.jdt.launching.JRE_CONTAINER\" kind=\"LIBRARY\"/>\n')),
(40, 66, 22, 'SystemXOMPathEntry|1|Loan Validation Base', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"Loan Validation Base\" url=\"platform:/Loan Validation Base\" kind=\"RULE_PROJECT\"/>\n')),
(41, 66, 23, 'outputLocation', 'output'),
(42, 66, 23, 'LibraryXOMPathEntry|0|org.eclipse.jdt.launching.JRE_CONTAINER', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:LibraryXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"org.eclipse.jdt.launching.JRE_CONTAINER\" url=\"file:org.eclipse.jdt.launching.JRE_CONTAINER\" kind=\"LIBRARY\" exported=\"false\"/>\n')),
(43, 66, 23, 'SystemXOMPathEntry|1|Loan Validation Base', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"Loan Validation Base\" url=\"platform:/Loan Validation Base\" kind=\"RULE_PROJECT\"/>\n')),
(44, 66, 24, 'outputLocation', 'output'),
(45, 66, 24, 'LibraryXOMPathEntry|0|org.eclipse.jdt.launching.JRE_CONTAINER', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:LibraryXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"org.eclipse.jdt.launching.JRE_CONTAINER\" url=\"file:org.eclipse.jdt.launching.JRE_CONTAINER\" kind=\"LIBRARY\"/>\n')),
(46, 66, 24, 'SystemXOMPathEntry|1|Loan Validation Determination', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"Loan Validation Determination\" url=\"platform:/Loan Validation Determination\" kind=\"RULE_PROJECT\"/>\n')),
(47, 66, 24, 'SystemXOMPathEntry|2|Loan Validation Check', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"Loan Validation Check\" url=\"platform:/Loan Validation Check\" kind=\"RULE_PROJECT\"/>\n'));   
INSERT INTO "PUBLIC"."RULEPROJECTTAG" VALUES
(48, 66, 24, 'SystemXOMPathEntry|3|Loan Validation Scoring', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"Loan Validation Scoring\" url=\"platform:/Loan Validation Scoring\" kind=\"RULE_PROJECT\"/>\n')),
(49, 66, 25, 'outputLocation', 'output'),
(50, 66, 25, 'BOMEntry|platform:/Loan Validation Base/bom/model.bom', 'xom:/Loan Validation Base/loan-validation-xom'),
(51, 66, 25, 'LibraryXOMPathEntry|0|org.eclipse.jdt.launching.JRE_CONTAINER', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:LibraryXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"org.eclipse.jdt.launching.JRE_CONTAINER\" url=\"file:org.eclipse.jdt.launching.JRE_CONTAINER\" kind=\"LIBRARY\" exported=\"false\"/>\n')),
(52, 66, 25, 'SystemXOMPathEntry|1|loan-validation-xom', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"loan-validation-xom\" url=\"platform:/loan-validation-xom\" kind=\"JAVA_PROJECT\" exported=\"true\"/>\n')),
(53, 66, 25, 'missingDependencies', 'loan-validation-xom'),
(54, 66, 26, 'outputLocation', 'output'),
(55, 66, 26, 'LibraryXOMPathEntry|0|org.eclipse.jdt.launching.JRE_CONTAINER', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:LibraryXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"org.eclipse.jdt.launching.JRE_CONTAINER\" url=\"file:org.eclipse.jdt.launching.JRE_CONTAINER\" kind=\"LIBRARY\"/>\n')),
(56, 66, 26, 'SystemXOMPathEntry|1|Loan Validation Base', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"Loan Validation Base\" url=\"platform:/Loan Validation Base\" kind=\"RULE_PROJECT\"/>\n')),
(57, 66, 27, 'outputLocation', 'output'),
(58, 66, 27, 'LibraryXOMPathEntry|0|org.eclipse.jdt.launching.JRE_CONTAINER', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:LibraryXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"org.eclipse.jdt.launching.JRE_CONTAINER\" url=\"file:org.eclipse.jdt.launching.JRE_CONTAINER\" kind=\"LIBRARY\"/>\n')),
(59, 66, 27, 'SystemXOMPathEntry|1|Loan Validation Base', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"Loan Validation Base\" url=\"platform:/Loan Validation Base\" kind=\"RULE_PROJECT\"/>\n')),
(60, 66, 28, 'outputLocation', 'output'),
(61, 66, 28, 'LibraryXOMPathEntry|0|org.eclipse.jdt.launching.JRE_CONTAINER', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:LibraryXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"org.eclipse.jdt.launching.JRE_CONTAINER\" url=\"file:org.eclipse.jdt.launching.JRE_CONTAINER\" kind=\"LIBRARY\" exported=\"false\"/>\n')),
(62, 66, 28, 'SystemXOMPathEntry|1|Loan Validation Base', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"Loan Validation Base\" url=\"platform:/Loan Validation Base\" kind=\"RULE_PROJECT\"/>\n'));              
INSERT INTO "PUBLIC"."RULEPROJECTTAG" VALUES
(63, 66, 29, 'outputLocation', 'output'),
(64, 66, 29, 'LibraryXOMPathEntry|0|org.eclipse.jdt.launching.JRE_CONTAINER', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:LibraryXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"org.eclipse.jdt.launching.JRE_CONTAINER\" url=\"file:org.eclipse.jdt.launching.JRE_CONTAINER\" kind=\"LIBRARY\"/>\n')),
(65, 66, 29, 'SystemXOMPathEntry|1|Loan Validation Determination', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"Loan Validation Determination\" url=\"platform:/Loan Validation Determination\" kind=\"RULE_PROJECT\"/>\n')),
(66, 66, 29, 'SystemXOMPathEntry|2|Loan Validation Check', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"Loan Validation Check\" url=\"platform:/Loan Validation Check\" kind=\"RULE_PROJECT\"/>\n')),
(67, 66, 29, 'SystemXOMPathEntry|3|Loan Validation Scoring', STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ilog.rules.studio.model.xom:SystemXOMPathEntry xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\" xmlns:ilog.rules.studio.model.xom=\"http://ilog.rules.studio/model/xom.ecore\" name=\"Loan Validation Scoring\" url=\"platform:/Loan Validation Scoring\" kind=\"RULE_PROJECT\"/>\n'));     
CREATE INDEX "PUBLIC"."RLPRJTAG_CONTAINER" ON "PUBLIC"."RULEPROJECTTAG"("CONTAINER");          
CREATE UNIQUE INDEX "PUBLIC"."RLPRJTAGNAMEUNIQUE" ON "PUBLIC"."RULEPROJECTTAG"("CONTAINER", "NAME");           
CREATE INDEX "PUBLIC"."FKRLPRJTAGTYPIDX" ON "PUBLIC"."RULEPROJECTTAG"("TYPE"); 
CREATE CACHED TABLE "PUBLIC"."RULESETPROPERTY"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CONTAINER" INTEGER NOT NULL,
    "ILRKEY" CLOB(52428800),
    "VALUE" CLOB(52428800)
);           
ALTER TABLE "PUBLIC"."RULESETPROPERTY" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_60" PRIMARY KEY("ID");              
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.RULESETPROPERTY;          
CREATE INDEX "PUBLIC"."RULESETPROPERTY_CONTAINER" ON "PUBLIC"."RULESETPROPERTY"("CONTAINER");  
CREATE INDEX "PUBLIC"."FKRULESETPROPERTYTYPIDX" ON "PUBLIC"."RULESETPROPERTY"("TYPE");         
CREATE CACHED TABLE "PUBLIC"."SCENARIOSUITEREPORT"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CREATEDBY" VARCHAR(100),
    "CREATEDON" TIMESTAMP,
    "LASTCHANGEDBY" VARCHAR(100),
    "LASTCHANGEDON" TIMESTAMP,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "ARCHIVEERRORS" BOOLEAN,
    "ARCHIVEWARNINGS" BOOLEAN,
    "BRANCH" INTEGER NOT NULL,
    "EXECUTEDBY" VARCHAR(255),
    "NBERRORS" INTEGER NOT NULL,
    "NBFAILURES" INTEGER NOT NULL,
    "NBSCENARIOS" INTEGER NOT NULL,
    "OPTIONS" CLOB(5242880),
    "PROJECT" INTEGER NOT NULL,
    "RUNBASELINE" VARCHAR(255) NOT NULL,
    "SCENARIOSUITEFQN" VARCHAR(255) NOT NULL,
    "SCENARIOSUITEID" INTEGER NOT NULL,
    "SCENARIOSUITEOID" INTEGER NOT NULL,
    "SERVERNAME" VARCHAR(255) NOT NULL
);      
ALTER TABLE "PUBLIC"."SCENARIOSUITEREPORT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_B7" PRIMARY KEY("ID");          
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.SCENARIOSUITEREPORT;      
CREATE UNIQUE INDEX "PUBLIC"."SCENARIOSUITEREPORTNAMEUNIQUE" ON "PUBLIC"."SCENARIOSUITEREPORT"("NAME", "SCENARIOSUITEFQN", "SCENARIOSUITEOID", "PROJECT", "BRANCH");           
CREATE UNIQUE INDEX "PUBLIC"."SCENARIOSUITEREPORTUUIDUNIQUE" ON "PUBLIC"."SCENARIOSUITEREPORT"("UUID");        
CREATE INDEX "PUBLIC"."FKSCENARIOSUITEREPORTTYPIDX" ON "PUBLIC"."SCENARIOSUITEREPORT"("TYPE"); 
CREATE CACHED TABLE "PUBLIC"."SCENARIOSUITEKPIREPORT"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "DATA" BLOB,
    "ILRINDEX" INTEGER NOT NULL,
    "KPICLASSNAME" VARCHAR(255) NOT NULL,
    "KPIRESULTCLASSNAME" VARCHAR(255) NOT NULL,
    "CONTAINER" INTEGER NOT NULL
); 
ALTER TABLE "PUBLIC"."SCENARIOSUITEKPIREPORT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_AB" PRIMARY KEY("ID");       
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.SCENARIOSUITEKPIREPORT;   
CREATE INDEX "PUBLIC"."SCSUITEKPIRPRT_CONTAINER" ON "PUBLIC"."SCENARIOSUITEKPIREPORT"("CONTAINER");            
CREATE INDEX "PUBLIC"."FKSCSUITEKPIRPRTTYPIDX" ON "PUBLIC"."SCENARIOSUITEKPIREPORT"("TYPE");   
CREATE CACHED TABLE "PUBLIC"."SCENARIOTESTREPORT"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CONTAINER" INTEGER NOT NULL,
    "ERRORCAUSE" CLOB(52428800),
    "ERRORMESSAGE" CLOB(52428800),
    "EXECUTIONID" VARCHAR(255),
    "ILRINDEX" INTEGER NOT NULL,
    "NAME" CLOB(52428800) NOT NULL,
    "NBERRORS" INTEGER NOT NULL,
    "NBFAILURES" INTEGER NOT NULL,
    "NBTESTS" INTEGER NOT NULL,
    "STATUS" VARCHAR(255) NOT NULL
);
ALTER TABLE "PUBLIC"."SCENARIOTESTREPORT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_A0" PRIMARY KEY("ID");           
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.SCENARIOTESTREPORT;       
CREATE INDEX "PUBLIC"."SCTSTRPRT_CONTAINER" ON "PUBLIC"."SCENARIOTESTREPORT"("CONTAINER");     
CREATE INDEX "PUBLIC"."FKSCTSTRPRTTYPIDX" ON "PUBLIC"."SCENARIOTESTREPORT"("TYPE");            
CREATE CACHED TABLE "PUBLIC"."SCHEMAVERSION"(
    "VERSION" VARCHAR(255)
);    
-- 1 +/- SELECT COUNT(*) FROM PUBLIC.SCHEMAVERSION;            
INSERT INTO "PUBLIC"."SCHEMAVERSION" VALUES
('JRules 8.11.1'); 
CREATE CACHED TABLE "PUBLIC"."SECURITYPROFILEKIND"(
    "VALUE" VARCHAR(30) NOT NULL,
    "DEPRECATED" BOOLEAN
);              
ALTER TABLE "PUBLIC"."SECURITYPROFILEKIND" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_56" PRIMARY KEY("VALUE");       
-- 4 +/- SELECT COUNT(*) FROM PUBLIC.SECURITYPROFILEKIND;      
INSERT INTO "PUBLIC"."SECURITYPROFILEKIND" VALUES
('READONLY', FALSE),
('FULLACCESS', FALSE),
('CUSTOM', FALSE),
('NOACCESS', FALSE);          
CREATE CACHED TABLE "PUBLIC"."SECGRP"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "DESCRIPTION" CLOB(52428800),
    "FROMLDAP" BOOLEAN,
    "SECURITYPROFILE" VARCHAR(30),
    "CREATEDBY" VARCHAR(100),
    "CREATEDON" TIMESTAMP,
    "LASTCHANGEDBY" VARCHAR(100),
    "LASTCHANGEDON" TIMESTAMP,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL
);     
ALTER TABLE "PUBLIC"."SECGRP" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_91" PRIMARY KEY("ID");       
-- 4 +/- SELECT COUNT(*) FROM PUBLIC.SECGRP;   
INSERT INTO "PUBLIC"."SECGRP" VALUES
(1, 142, NULL, FALSE, NULL, 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'rtsAdministrators', '23a4fbc6-b6a0-4e0e-8251-2501ab9ac6a9'),
(2, 142, NULL, FALSE, NULL, 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'rtsConfigManagers', '0d6ee486-121b-45e2-91c6-93ea01175f61'),
(3, 142, NULL, FALSE, NULL, 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'rtsInstallers', 'b20993b5-8a02-4cde-9488-10c479089661'),
(4, 142, NULL, FALSE, NULL, 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'rtsUsers', '3f65670c-d832-48a7-bb24-61f5703daec7');
CREATE UNIQUE INDEX "PUBLIC"."SECGRPUUIDUNIQUE" ON "PUBLIC"."SECGRP"("UUID");  
CREATE INDEX "PUBLIC"."FKSECGRPTYPIDX" ON "PUBLIC"."SECGRP"("TYPE");           
CREATE CACHED TABLE "PUBLIC"."SECURITYROLE"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CUSTOMROLE" BOOLEAN,
    "CREATEDBY" VARCHAR(100),
    "CREATEDON" TIMESTAMP,
    "LASTCHANGEDBY" VARCHAR(100),
    "LASTCHANGEDON" TIMESTAMP,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL
);  
ALTER TABLE "PUBLIC"."SECURITYROLE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_BA" PRIMARY KEY("ID"); 
-- 4 +/- SELECT COUNT(*) FROM PUBLIC.SECURITYROLE;             
INSERT INTO "PUBLIC"."SECURITYROLE" VALUES
(1, 145, FALSE, 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'rtsAdministrator', '94a35f09-e15c-4ddd-941f-225d5c96f320'),
(2, 145, FALSE, 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'rtsConfigManager', '16837d72-22b0-4ca1-9362-2c9edec624b9'),
(3, 145, FALSE, 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'rtsInstaller', 'c72b0487-9046-4109-9f04-fd322f669c3a'),
(4, 145, FALSE, 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'rtsUser', '3fe69699-c2e6-447c-b79e-d56882efed6d');              
CREATE UNIQUE INDEX "PUBLIC"."SECURITYROLEUUIDUNIQUE" ON "PUBLIC"."SECURITYROLE"("UUID");      
CREATE INDEX "PUBLIC"."FKSECURITYROLETYPIDX" ON "PUBLIC"."SECURITYROLE"("TYPE");               
CREATE CACHED TABLE "PUBLIC"."GROUPROLE"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "ILRROLE" INTEGER,
    "CONTAINER" INTEGER NOT NULL
);   
ALTER TABLE "PUBLIC"."GROUPROLE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_4D" PRIMARY KEY("ID");    
-- 4 +/- SELECT COUNT(*) FROM PUBLIC.GROUPROLE;
INSERT INTO "PUBLIC"."GROUPROLE" VALUES
(1, 148, 1, 1),
(2, 148, 2, 2),
(3, 148, 3, 3),
(4, 148, 4, 4);        
CREATE INDEX "PUBLIC"."GROUPROLE_CONTAINER" ON "PUBLIC"."GROUPROLE"("CONTAINER");              
CREATE INDEX "PUBLIC"."FKGROUPROLETYPIDX" ON "PUBLIC"."GROUPROLE"("TYPE");     
CREATE CACHED TABLE "PUBLIC"."SERVERKIND"(
    "VALUE" VARCHAR(30) NOT NULL,
    "DEPRECATED" BOOLEAN
);       
ALTER TABLE "PUBLIC"."SERVERKIND" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_B0" PRIMARY KEY("VALUE");
-- 4 +/- SELECT COUNT(*) FROM PUBLIC.SERVERKIND;               
INSERT INTO "PUBLIC"."SERVERKIND" VALUES
('RES', FALSE),
('RSO', FALSE),
('EVENT', FALSE),
('DECISION_RUNNER', FALSE);         
CREATE CACHED TABLE "PUBLIC"."SERVER"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CREATEDBY" VARCHAR(100),
    "CREATEDON" TIMESTAMP,
    "LASTCHANGEDBY" VARCHAR(100),
    "LASTCHANGEDON" TIMESTAMP,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "AUTHENTICATIONKIND" VARCHAR(30),
    "AUTHENTICATIONPROVIDER" VARCHAR(128),
    "DESCRIPTION" CLOB(52428800),
    "LOGINSERVER" VARCHAR(255),
    "PASSWORD" VARCHAR(255),
    "SERVERKIND" VARCHAR(30),
    "URL" VARCHAR(750)
);            
ALTER TABLE "PUBLIC"."SERVER" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_919" PRIMARY KEY("ID");      
-- 2 +/- SELECT COUNT(*) FROM PUBLIC.SERVER;   
INSERT INTO "PUBLIC"."SERVER" VALUES
(1, 74, 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:11', 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:11', 'Decision Service Execution', '0c97ade0-1eeb-4bd2-aba8-24a5de529c3d', 'BASIC_AUTH', NULL, 'Use this server to deploy decision services that you want to execute.', 'odmAdmin', '{v1:odm2}a33pYnys5r1dH7M5mNLhsQ==', 'RES', 'http://localhost:9060/res'),
(2, 74, 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'Test and Simulation Execution', 'bd24816c-00ad-4e56-b4a7-a83038903ca1', 'BASIC_AUTH', NULL, 'Use this server to run tests and simulations for decision services.', 'odmAdmin', '{v1:odm2}a33pYnys5r1dH7M5mNLhsQ==', 'DECISION_RUNNER', 'http://localhost:9060/DecisionRunner'); 
CREATE UNIQUE INDEX "PUBLIC"."SERVERNAMEUNIQUE" ON "PUBLIC"."SERVER"("NAME", "SERVERKIND");    
CREATE UNIQUE INDEX "PUBLIC"."SERVERUUIDUNIQUE" ON "PUBLIC"."SERVER"("UUID");  
CREATE INDEX "PUBLIC"."FKSERVERTYPIDX" ON "PUBLIC"."SERVER"("TYPE");           
CREATE CACHED TABLE "PUBLIC"."SNAPSHOTCREATIONKIND"(
    "VALUE" VARCHAR(30) NOT NULL,
    "DEPRECATED" BOOLEAN
);             
ALTER TABLE "PUBLIC"."SNAPSHOTCREATIONKIND" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_28" PRIMARY KEY("VALUE");      
-- 3 +/- SELECT COUNT(*) FROM PUBLIC.SNAPSHOTCREATIONKIND;     
INSERT INTO "PUBLIC"."SNAPSHOTCREATIONKIND" VALUES
('ALWAYS', FALSE),
('USEROPTION', FALSE),
('NEVER', FALSE); 
CREATE CACHED TABLE "PUBLIC"."STATUS"(
    "VALUE" VARCHAR(30) NOT NULL,
    "DEPRECATED" BOOLEAN
);           
ALTER TABLE "PUBLIC"."STATUS" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_92" PRIMARY KEY("VALUE");    
-- 5 +/- SELECT COUNT(*) FROM PUBLIC.STATUS;   
INSERT INTO "PUBLIC"."STATUS" VALUES
('new', FALSE),
('defined', FALSE),
('validated', FALSE),
('rejected', FALSE),
('deployable', FALSE);     
CREATE CACHED TABLE "PUBLIC"."SYSTEMLOCK"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "BRANCH" INTEGER NOT NULL,
    "ELEMENTID" INTEGER NOT NULL,
    "ELEMENTTYPE" INTEGER NOT NULL,
    "MODELID" INTEGER,
    "TOGGLE" VARCHAR(5)
);      
ALTER TABLE "PUBLIC"."SYSTEMLOCK" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_43" PRIMARY KEY("BRANCH", "ELEMENTID", "ELEMENTTYPE");   
-- 7 +/- SELECT COUNT(*) FROM PUBLIC.SYSTEMLOCK;               
INSERT INTO "PUBLIC"."SYSTEMLOCK" VALUES
(1, 10, 2147483647, 2147483647, 46, 1305564291, NULL),
(2, 10, 3, 1, 46, 1305564291, NULL),
(3, 10, 6, 2, 46, 1305564291, NULL),
(4, 10, 9, 3, 46, 1305564291, NULL),
(5, 10, 12, 4, 46, 1305564291, NULL),
(6, 10, 15, 5, 46, 1305564291, NULL),
(7, 10, 18, 6, 46, 1305564291, NULL);               
CREATE INDEX "PUBLIC"."FKSYSTEMLOCKTYPIDX" ON "PUBLIC"."SYSTEMLOCK"("TYPE");   
CREATE CACHED TABLE "PUBLIC"."TESTREPORT"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CONTAINER" INTEGER NOT NULL,
    "ERRORCAUSE" CLOB(52428800),
    "ERRORMESSAGE" CLOB(52428800),
    "EXPECTEDVALUES" CLOB(52428800),
    "HIGHLIGHT" BOOLEAN,
    "MESSAGE" CLOB(52428800),
    "NAME" CLOB(52428800) NOT NULL,
    "OBSERVEDVALUES" CLOB(52428800),
    "SCENARIOTESTREPORTINDEX" INTEGER NOT NULL,
    "STATUS" VARCHAR(255) NOT NULL
);            
ALTER TABLE "PUBLIC"."TESTREPORT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_B7F" PRIMARY KEY("ID");  
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.TESTREPORT;               
CREATE INDEX "PUBLIC"."TESTREPORT_CONTAINER" ON "PUBLIC"."TESTREPORT"("CONTAINER");            
CREATE INDEX "PUBLIC"."FKTESTREPORTTYPIDX" ON "PUBLIC"."TESTREPORT"("TYPE");   
CREATE CACHED TABLE "PUBLIC"."UPDATETYPEKIND"(
    "VALUE" VARCHAR(30) NOT NULL,
    "DEPRECATED" BOOLEAN
);   
ALTER TABLE "PUBLIC"."UPDATETYPEKIND" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_85" PRIMARY KEY("VALUE");            
-- 56 +/- SELECT COUNT(*) FROM PUBLIC.UPDATETYPEKIND;          
INSERT INTO "PUBLIC"."UPDATETYPEKIND" VALUES
('Create', FALSE),
('Update', FALSE),
('BranchCreate', FALSE),
('SnapshotCreate', FALSE),
('SnapshotRestore', FALSE),
('Delete', FALSE),
('Rename', FALSE),
('BranchUpdate', FALSE),
('BranchRename', FALSE),
('SnapshotUpdate', FALSE),
('SnapshotRename', FALSE),
('DecisionServiceCreate', FALSE),
('ReleaseDeploy', FALSE),
('ReleaseUndeploy', FALSE),
('ActivityCreate', FALSE),
('ActivityCancel', FALSE),
('ActivityUpdate', FALSE),
('ActivityRename', FALSE),
('ActivityOwnerAssign', FALSE),
('ActivityApproverAssign', FALSE),
('ActivityApproverRemove', FALSE),
('ActivityStatusUpdate', FALSE),
('ActivityApprove', FALSE),
('ActivityReject', FALSE),
('ActivityGoalUpdate', FALSE),
('ActivityDueDateUpdate', FALSE),
('ActivityAuthorComplete', FALSE),
('ActivityAuthorAssign', FALSE),
('ActivityAuthorRemove', FALSE),
('ActivityTesterComplete', FALSE),
('ActivityTesterAssign', FALSE),
('ActivityTesterRemove', FALSE),
('ActivityTestPlanUpdate', FALSE),
('ActivityReopen', FALSE),
('ActivityClose', FALSE),
('ActivityDelete', FALSE),
('ActivityMerge', FALSE),
('ActivityAuthorResume', FALSE),
('ActivityTesterResume', FALSE),
('TestSuiteCreate', FALSE),
('TestSuiteUpdateMulti', FALSE),
('TestSuiteUpdateSingle', FALSE),
('TestSuiteRename', FALSE),
('TestSuiteDelete', FALSE),
('TestCaseUpload', FALSE),
('TestCaseDelete', FALSE),
('TestReportMerge', FALSE),
('DConfigCreate', FALSE),
('DConfigUpdate', FALSE),
('DConfigRename', FALSE),
('DConfigDelete', FALSE),
('DReportCreate', FALSE),
('DReportUpdate', FALSE),
('DReportDelete', FALSE),
('DeploymentStarted', FALSE),
('DeploymentComplete', FALSE);       
CREATE CACHED TABLE "PUBLIC"."USERSETTING"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "ILRKEY" VARCHAR(750) NOT NULL,
    "USERNAME" VARCHAR(100),
    "VALUE" CLOB(52428800)
);             
ALTER TABLE "PUBLIC"."USERSETTING" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_81" PRIMARY KEY("ID");  
-- 25 +/- SELECT COUNT(*) FROM PUBLIC.USERSETTING;             
INSERT INTO "PUBLIC"."USERSETTING" VALUES
(1, 59, 'teamserver.internal.dbSchemaId', '__ilog_rule_teamserver__', '1305564291'),
(2, 59, 'teamserver.locale', '__ilog_rule_teamserver__', 'en_US'),
(3, 59, 'internal.IlrServer.0c97ade0-1eeb-4bd2-aba8-24a5de529c3d.groups', '__ilog_rule_teamserver__', 'all_key'),
(4, 59, 'internal.IlrServer.0c97ade0-1eeb-4bd2-aba8-24a5de529c3d.extended', '__ilog_rule_teamserver__', '{"production":false,"builtIn":false}'),
(5, 59, 'internal.IlrServer.bd24816c-00ad-4e56-b4a7-a83038903ca1.groups', '__ilog_rule_teamserver__', 'all_key'),
(6, 59, 'internal.IlrServer.bd24816c-00ad-4e56-b4a7-a83038903ca1.extended', '__ilog_rule_teamserver__', '{"production":false,"builtIn":false}'),
(7, 59, 'teamserver.includeDebugInfoInRulesetArchive', '__ilog_rule_teamserver__', 'true'),
(8, 59, 'decisioncenter.web.dt.rowOrderingMode', '__ilog_rule_teamserver__', 'Automatic'),
(9, 59, 'com.ibm.rules.decisioncenter.nps.disabled', '__ilog_rule_teamserver__', 'true'),
(10, 59, 'decisioncenter.enableReportListsPagination', '__ilog_rule_teamserver__', 'true'),
(11, 59, 'teamserver.internal.bomVocCacheUUID', '__ilog_rule_teamserver__', '1aeceb21-0c1f-4ca2-8c01-2c28b80347b3'),
(12, 59, 'teamserver.internal.availableGroupsCacheUUID', '__ilog_rule_teamserver__', '2c5ba49b-e34a-460c-a599-cd4d23bc241b'),
(13, 59, 'teamserver.internal.server.uuid', '__ilog_rule_teamserver__', '08311efa-20ad-453b-917d-757d162bd74d'),
(14, 59, 'com.ibm.rules.decisioncenter.ldap.sync.users-and-groups', '__ilog_rule_teamserver__', 'None'),
(15, 59, 'teamserver.internal.recreateCheck_9.179.1.181:9060/decisioncenter', '__ilog_rule_teamserver__', 'Checked'),
(16, 59, 'ServerContextPath', '__ilog_rule_teamserver__', '/decisioncenter'),
(17, 59, 'ServerHostname', '__ilog_rule_teamserver__', 'vtt-odm631-l-1.fyre.ibm.com'),
(18, 59, 'teamserver.server.isSecure', '__ilog_rule_teamserver__', 'false'),
(19, 59, 'ServerPort', '__ilog_rule_teamserver__', '9080'),
(20, 59, 'internal.nps.user', 'odmAdmin', '{"userId":"odmAdmin","initialLoginDate":1683207034221,"loginDate":1683207160458,"lastSurveyInviteDate":0}'),
(21, 59, 'lastVisitedTabs', 'odmAdmin', '{"/t":"library","/t/library#overviewds;branchesTabContainer_brm.RuleProject:5:5":"branchesTab","/t/library#overviewds;branchesTabContainer_brm.RuleProject:6:6":"branchesTab","/t/library#overviewbranch;overviewTabContainer":"TestsTab2"}'),
(22, 59, 'lastAutoFollowCheck', 'odmAdmin', '2023.05.04 15:35:59 +0200'),
(23, 59, 'teamserver.internal.variablesUUID', '__ilog_rule_teamserver__', 'b92e4f7d-32d4-4179-9ec2-fb525a2f1bdb'),
(24, 59, 'openedProjects', 'odmAdmin', 'f4440cab-4dca-471c-8a9e-ec05ede7c0311683207315000,4ea8ed3f-98a0-4b25-853c-6cc857215ae81683207281000'),
(25, 59, 'contentViewFiltersForDATab', 'odmAdmin', 'brm.RuleProject:6:6={"artifactTypeGroups":["RULES"],"recycleBinDateFilter":[{"key":"ALWAYS","value":"n/a","checkBox":true}]}');          
CREATE INDEX "PUBLIC"."USERSETTINGIDX" ON "PUBLIC"."USERSETTING"("USERNAME", "ILRKEY");        
CREATE INDEX "PUBLIC"."FKUSERSETTINGTYPIDX" ON "PUBLIC"."USERSETTING"("TYPE"); 
CREATE CACHED TABLE "PUBLIC"."USR"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "DISPLAYNAME" VARCHAR(255),
    "EMAIL" VARCHAR(100),
    "FROMLDAP" BOOLEAN,
    "LASTLOGGEDIN" TIMESTAMP,
    "CREATEDBY" VARCHAR(100),
    "CREATEDON" TIMESTAMP,
    "LASTCHANGEDBY" VARCHAR(100),
    "LASTCHANGEDON" TIMESTAMP,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL
);     
ALTER TABLE "PUBLIC"."USR" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_14" PRIMARY KEY("ID");          
-- 5 +/- SELECT COUNT(*) FROM PUBLIC.USR;      
INSERT INTO "PUBLIC"."USR" VALUES
(1, 141, '', '', FALSE, TIMESTAMP '2023-05-04 14:32:40.4', 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'odmAdmin', TIMESTAMP '2023-05-04 14:32:40', 'odmAdmin', '2c39e46b-ac90-4bd3-8eb4-b00a9cd31301'),
(2, 141, '', '', FALSE, NULL, 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'rtsAdmin', '8d9b3bb2-18bf-41e5-903c-f028cf1236c5'),
(3, 141, '', '', FALSE, NULL, 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'rtsConfig', '229d9ac3-55e2-495b-bcd0-475551e7d5a5'),
(4, 141, '', '', FALSE, NULL, 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'rtsUser1', 'd26901fc-002b-4328-acf7-e6647befd5c5'),
(5, 141, '', '', FALSE, NULL, 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', TIMESTAMP '2023-05-04 14:30:12', 'rtsUser2', 'f68995ef-c69b-4e7e-90a9-bad05f31b8a5');            
CREATE UNIQUE INDEX "PUBLIC"."USRUUIDUNIQUE" ON "PUBLIC"."USR"("UUID");        
CREATE INDEX "PUBLIC"."FKUSRTYPIDX" ON "PUBLIC"."USR"("TYPE"); 
CREATE CACHED TABLE "PUBLIC"."GROUPUSER"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "MEMBER" INTEGER NOT NULL,
    "CONTAINER" INTEGER NOT NULL
);           
ALTER TABLE "PUBLIC"."GROUPUSER" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_4DC" PRIMARY KEY("ID");   
-- 12 +/- SELECT COUNT(*) FROM PUBLIC.GROUPUSER;               
INSERT INTO "PUBLIC"."GROUPUSER" VALUES
(1, 149, 1, 1),
(2, 149, 1, 3),
(3, 149, 1, 2),
(4, 149, 1, 4),
(5, 149, 2, 1),
(6, 149, 2, 3),
(7, 149, 2, 2),
(8, 149, 2, 4),
(9, 149, 3, 2),
(10, 149, 3, 4),
(11, 149, 4, 4),
(12, 149, 5, 4);     
CREATE INDEX "PUBLIC"."GROUPUSER_CONTAINER" ON "PUBLIC"."GROUPUSER"("CONTAINER");              
CREATE INDEX "PUBLIC"."FKGROUPUSERTYPIDX" ON "PUBLIC"."GROUPUSER"("TYPE");     
CREATE CACHED TABLE "PUBLIC"."USERGROUP"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CONTAINER" INTEGER NOT NULL,
    "GRP" INTEGER NOT NULL
);              
ALTER TABLE "PUBLIC"."USERGROUP" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_BAC" PRIMARY KEY("ID");   
-- 12 +/- SELECT COUNT(*) FROM PUBLIC.USERGROUP;               
INSERT INTO "PUBLIC"."USERGROUP" VALUES
(1, 147, 1, 1),
(2, 147, 1, 3),
(3, 147, 1, 2),
(4, 147, 1, 4),
(5, 147, 2, 1),
(6, 147, 2, 3),
(7, 147, 2, 2),
(8, 147, 2, 4),
(9, 147, 3, 2),
(10, 147, 3, 4),
(11, 147, 4, 4),
(12, 147, 5, 4);     
CREATE INDEX "PUBLIC"."USERGROUP_CONTAINER" ON "PUBLIC"."USERGROUP"("CONTAINER");              
CREATE INDEX "PUBLIC"."FKUSERGROUPTYPIDX" ON "PUBLIC"."USERGROUP"("TYPE");     
CREATE CACHED TABLE "PUBLIC"."USERPROPERTY"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CONTAINER" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "VALUE" CLOB(52428800)
);         
ALTER TABLE "PUBLIC"."USERPROPERTY" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_1D" PRIMARY KEY("ID"); 
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.USERPROPERTY;             
CREATE INDEX "PUBLIC"."USERPROPERTY_CONTAINER" ON "PUBLIC"."USERPROPERTY"("CONTAINER");        
CREATE INDEX "PUBLIC"."FKUSERPROPERTYTYPIDX" ON "PUBLIC"."USERPROPERTY"("TYPE");               
CREATE CACHED TABLE "PUBLIC"."VERSION"(
    "ID" INTEGER NOT NULL,
    "MAJOR" INTEGER,
    "MINOR" INTEGER,
    "USERNAME" VARCHAR(100),
    "COMMENTAIRE" VARCHAR(500),
    "VERSDATE" TIMESTAMP,
    "ELTORIGINALID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "DELETED" BOOLEAN NOT NULL,
    "SYSVERS" BOOLEAN NOT NULL,
    "PROJECT" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "MERGEDFROMBASELINE" INTEGER,
    "MERGEDFROMVERSION" INTEGER
);   
ALTER TABLE "PUBLIC"."VERSION" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_3" PRIMARY KEY("ID");       
-- 259 +/- SELECT COUNT(*) FROM PUBLIC.VERSION;
INSERT INTO "PUBLIC"."VERSION" VALUES
(1, 1, 0, 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', NULL, TIMESTAMP '2023-05-04 14:30:11', 1, 74, FALSE, FALSE, 2147483647, 2147483647, NULL, NULL),
(2, 1, 0, 'authorizedUser:7ca35e88-0b3e-4642-887f-a3d1b3786581', NULL, TIMESTAMP '2023-05-04 14:30:12', 2, 74, FALSE, FALSE, 2147483647, 2147483647, NULL, NULL),
(3, 2, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:19', 1, 46, FALSE, FALSE, 2147483647, 2147483647, NULL, NULL),
(4, 5, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 1, 45, FALSE, FALSE, 1, 1, NULL, NULL),
(5, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:19', 2, 45, FALSE, FALSE, 1, 2, NULL, NULL),
(6, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:19', 3, 45, FALSE, FALSE, 1, 3, NULL, NULL),
(7, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:37', 1, 25, FALSE, FALSE, 1, 1, NULL, NULL),
(8, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:37', 2, 25, FALSE, FALSE, 1, 1, NULL, NULL),
(9, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:37', 3, 25, FALSE, FALSE, 1, 1, NULL, NULL),
(10, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:37', 4, 25, FALSE, FALSE, 1, 1, NULL, NULL),
(11, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:37', 5, 25, FALSE, FALSE, 1, 1, NULL, NULL),
(12, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:38', 1, 5, FALSE, FALSE, 1, 1, NULL, NULL),
(13, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:38', 1, 26, FALSE, FALSE, 1, 1, NULL, NULL),
(14, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:38', 1, 41, FALSE, FALSE, 1, 1, NULL, NULL),
(15, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:38', 2, 41, FALSE, FALSE, 1, 1, NULL, NULL),
(16, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:38', 1, 63, FALSE, FALSE, 1, 1, NULL, NULL),
(17, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:38', 1, 34, FALSE, FALSE, 1, 1, NULL, NULL),
(18, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:38', 1, 80, FALSE, FALSE, 1, 1, NULL, NULL),
(20, 2, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 2, 46, FALSE, FALSE, 2147483647, 2147483647, NULL, NULL),
(21, 4, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 4, 45, FALSE, FALSE, 2, 4, NULL, NULL),
(22, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 5, 45, FALSE, FALSE, 2, 5, NULL, NULL),
(23, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 6, 45, FALSE, FALSE, 2, 6, NULL, NULL),
(24, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 6, 25, FALSE, FALSE, 2, 4, NULL, NULL),
(25, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 7, 25, FALSE, FALSE, 2, 4, NULL, NULL),
(26, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 8, 25, FALSE, FALSE, 2, 4, NULL, NULL),
(27, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 9, 25, FALSE, FALSE, 2, 4, NULL, NULL),
(28, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 10, 25, FALSE, FALSE, 2, 4, NULL, NULL),
(29, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 2, 5, FALSE, FALSE, 2, 4, NULL, NULL),
(30, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 3, 5, FALSE, FALSE, 2, 4, NULL, NULL),
(31, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 4, 5, FALSE, FALSE, 2, 4, NULL, NULL),
(32, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 1, 56, FALSE, FALSE, 2, 4, NULL, NULL),
(33, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 2, 56, FALSE, FALSE, 2, 4, NULL, NULL),
(34, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 3, 56, FALSE, FALSE, 2, 4, NULL, NULL),
(35, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 4, 56, FALSE, FALSE, 2, 4, NULL, NULL),
(36, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 5, 56, FALSE, FALSE, 2, 4, NULL, NULL),
(37, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 6, 56, FALSE, FALSE, 2, 4, NULL, NULL),
(38, 2, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 3, 46, FALSE, FALSE, 2147483647, 2147483647, NULL, NULL),
(39, 5, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 7, 45, FALSE, FALSE, 3, 7, NULL, NULL),
(40, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 8, 45, FALSE, FALSE, 3, 8, NULL, NULL);            
INSERT INTO "PUBLIC"."VERSION" VALUES
(41, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 9, 45, FALSE, FALSE, 3, 9, NULL, NULL),
(42, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 11, 25, FALSE, FALSE, 3, 7, NULL, NULL),
(43, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 12, 25, FALSE, FALSE, 3, 7, NULL, NULL),
(44, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 13, 25, FALSE, FALSE, 3, 7, NULL, NULL),
(45, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 14, 25, FALSE, FALSE, 3, 7, NULL, NULL),
(46, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:39', 15, 25, FALSE, FALSE, 3, 7, NULL, NULL),
(47, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 5, 5, FALSE, FALSE, 3, 7, NULL, NULL),
(48, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 6, 5, FALSE, FALSE, 3, 7, NULL, NULL),
(49, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 7, 28, FALSE, FALSE, 3, 7, NULL, NULL),
(50, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 8, 56, FALSE, FALSE, 3, 7, NULL, NULL),
(51, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 9, 56, FALSE, FALSE, 3, 7, NULL, NULL),
(52, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 10, 56, FALSE, FALSE, 3, 7, NULL, NULL),
(53, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 11, 56, FALSE, FALSE, 3, 7, NULL, NULL),
(54, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 12, 56, FALSE, FALSE, 3, 7, NULL, NULL),
(55, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 13, 28, FALSE, FALSE, 3, 7, NULL, NULL),
(56, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 1, 51, FALSE, FALSE, 3, 7, NULL, NULL),
(57, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 1, 108, FALSE, FALSE, 3, 7, NULL, NULL),
(59, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 1, 108, FALSE, FALSE, 3, 7, NULL, NULL),
(60, 2, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 4, 46, FALSE, FALSE, 2147483647, 2147483647, NULL, NULL),
(61, 5, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 10, 45, FALSE, FALSE, 4, 10, NULL, NULL),
(62, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 11, 45, FALSE, FALSE, 4, 11, NULL, NULL),
(63, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 12, 45, FALSE, FALSE, 4, 12, NULL, NULL),
(64, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 16, 25, FALSE, FALSE, 4, 10, NULL, NULL),
(65, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 17, 25, FALSE, FALSE, 4, 10, NULL, NULL),
(66, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 18, 25, FALSE, FALSE, 4, 10, NULL, NULL),
(67, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 19, 25, FALSE, FALSE, 4, 10, NULL, NULL),
(68, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 20, 25, FALSE, FALSE, 4, 10, NULL, NULL),
(69, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 7, 5, FALSE, FALSE, 4, 10, NULL, NULL),
(70, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 14, 28, FALSE, FALSE, 4, 10, NULL, NULL),
(71, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 15, 56, FALSE, FALSE, 4, 10, NULL, NULL),
(72, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 16, 56, FALSE, FALSE, 4, 10, NULL, NULL),
(73, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 17, 28, FALSE, FALSE, 4, 10, NULL, NULL),
(74, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 18, 56, FALSE, FALSE, 4, 10, NULL, NULL),
(75, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 19, 28, FALSE, FALSE, 4, 10, NULL, NULL),
(76, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 2, 51, FALSE, FALSE, 4, 10, NULL, NULL),
(77, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:40', 3, 108, FALSE, FALSE, 4, 10, NULL, NULL),
(79, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 3, 108, FALSE, FALSE, 4, 10, NULL, NULL),
(80, 5, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:36:22', 5, 46, FALSE, FALSE, 2147483647, 2147483647, NULL, NULL),
(81, 6, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 13, 45, FALSE, FALSE, 5, 13, NULL, NULL),
(82, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 14, 45, FALSE, FALSE, 5, 14, NULL, NULL);        
INSERT INTO "PUBLIC"."VERSION" VALUES
(83, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 15, 45, FALSE, FALSE, 5, 15, NULL, NULL),
(84, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 21, 25, FALSE, FALSE, 5, 13, NULL, NULL),
(85, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 22, 25, FALSE, FALSE, 5, 13, NULL, NULL),
(86, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 23, 25, FALSE, FALSE, 5, 13, NULL, NULL),
(87, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 24, 25, FALSE, FALSE, 5, 13, NULL, NULL),
(88, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 25, 25, FALSE, FALSE, 5, 13, NULL, NULL),
(89, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 8, 5, FALSE, FALSE, 5, 13, NULL, NULL),
(90, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 3, 51, FALSE, FALSE, 5, 13, NULL, NULL),
(91, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 26, 1, FALSE, FALSE, 5, 13, NULL, NULL),
(92, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 2, 80, FALSE, FALSE, 5, 13, NULL, NULL),
(93, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 1, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(94, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 2, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(95, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 5, 108, FALSE, FALSE, 5, 13, NULL, NULL),
(96, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 6, 108, FALSE, FALSE, 5, 13, NULL, NULL),
(97, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 1, 132, FALSE, FALSE, 5, 13, NULL, NULL),
(98, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 1, 129, FALSE, FALSE, 5, 13, NULL, NULL),
(99, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 1, 126, FALSE, FALSE, 5, 13, NULL, NULL),
(100, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 1, 127, FALSE, FALSE, 5, 13, NULL, NULL),
(101, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 1, 124, FALSE, FALSE, 5, 13, NULL, NULL),
(102, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 2, 124, FALSE, FALSE, 5, 13, NULL, NULL),
(103, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 3, 124, FALSE, FALSE, 5, 13, NULL, NULL),
(104, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 4, 124, FALSE, FALSE, 5, 13, NULL, NULL),
(105, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 5, 124, FALSE, FALSE, 5, 13, NULL, NULL),
(106, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 6, 124, FALSE, FALSE, 5, 13, NULL, NULL),
(107, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 7, 124, FALSE, FALSE, 5, 13, NULL, NULL),
(108, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 8, 124, FALSE, FALSE, 5, 13, NULL, NULL),
(109, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 9, 124, FALSE, FALSE, 5, 13, NULL, NULL),
(110, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:41', 10, 124, FALSE, FALSE, 5, 13, NULL, NULL),
(111, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 11, 124, FALSE, FALSE, 5, 13, NULL, NULL),
(112, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 1, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(113, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 2, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(114, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 3, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(115, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 4, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(116, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 5, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(117, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 6, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(118, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 7, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(119, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 8, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(120, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 9, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(121, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 10, 125, FALSE, FALSE, 5, 13, NULL, NULL);              
INSERT INTO "PUBLIC"."VERSION" VALUES
(122, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 11, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(123, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 12, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(124, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 13, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(125, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 14, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(126, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 15, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(127, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 16, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(224, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 5, 108, FALSE, FALSE, 5, 13, NULL, NULL),
(225, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 6, 108, FALSE, FALSE, 5, 13, NULL, NULL),
(226, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 1, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(227, 1, 2, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 1, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(228, 1, 3, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 1, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(229, 1, 4, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 1, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(230, 1, 5, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:42', 1, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(231, 1, 6, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 1, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(232, 1, 7, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 1, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(233, 1, 8, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 1, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(234, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 1, 132, FALSE, FALSE, 5, 13, NULL, NULL),
(235, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 1, 129, FALSE, FALSE, 5, 13, NULL, NULL),
(236, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 1, 126, FALSE, FALSE, 5, 13, NULL, NULL),
(237, 1, 2, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 1, 126, FALSE, FALSE, 5, 13, NULL, NULL),
(238, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 1, 127, FALSE, FALSE, 5, 13, NULL, NULL),
(239, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 1, 124, FALSE, FALSE, 5, 13, NULL, NULL),
(240, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 2, 124, FALSE, FALSE, 5, 13, NULL, NULL),
(241, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 3, 124, FALSE, FALSE, 5, 13, NULL, NULL),
(242, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 4, 124, FALSE, FALSE, 5, 13, NULL, NULL),
(243, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 5, 124, FALSE, FALSE, 5, 13, NULL, NULL),
(244, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 6, 124, FALSE, FALSE, 5, 13, NULL, NULL),
(245, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 7, 124, FALSE, FALSE, 5, 13, NULL, NULL),
(246, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 8, 124, FALSE, FALSE, 5, 13, NULL, NULL),
(247, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 9, 124, FALSE, FALSE, 5, 13, NULL, NULL),
(248, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 10, 124, FALSE, FALSE, 5, 13, NULL, NULL),
(249, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 11, 124, FALSE, FALSE, 5, 13, NULL, NULL),
(250, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 1, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(251, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 2, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(252, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 3, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(253, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 4, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(254, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:43', 5, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(255, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:44', 6, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(256, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:44', 7, 125, FALSE, FALSE, 5, 13, NULL, NULL);   
INSERT INTO "PUBLIC"."VERSION" VALUES
(257, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:44', 8, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(258, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:44', 9, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(259, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:44', 10, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(260, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:44', 11, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(261, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:44', 12, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(262, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:44', 13, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(263, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:44', 14, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(264, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:44', 15, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(265, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:44', 16, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(266, 1, 9, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:44', 1, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(267, 1, 10, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:44', 1, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(268, 1, 11, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:44', 1, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(269, 1, 12, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:44', 1, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(270, 1, 13, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 1, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(271, 1, 14, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 1, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(272, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 2, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(273, 1, 2, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 2, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(274, 1, 3, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 2, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(275, 1, 4, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 2, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(276, 1, 5, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 2, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(277, 1, 6, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 2, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(278, 1, 7, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 2, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(279, 1, 8, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 2, 111, FALSE, FALSE, 5, 13, NULL, NULL),
(280, 1, 2, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 1, 129, FALSE, FALSE, 5, 13, NULL, NULL),
(281, 1, 3, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 1, 129, FALSE, FALSE, 5, 13, NULL, NULL),
(282, 1, 2, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 14, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(283, 1, 2, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 16, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(284, 1, 2, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 1, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(285, 1, 2, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 2, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(286, 1, 2, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 3, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(287, 1, 2, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 4, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(288, 1, 2, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 7, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(289, 1, 2, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 8, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(290, 1, 2, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 5, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(291, 1, 2, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 6, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(292, 1, 3, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 7, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(293, 1, 3, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 8, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(294, 1, 2, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 9, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(295, 1, 2, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 10, 125, FALSE, FALSE, 5, 13, NULL, NULL);            
INSERT INTO "PUBLIC"."VERSION" VALUES
(296, 1, 2, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:45', 11, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(297, 1, 2, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:46', 12, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(298, 1, 2, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:46', 13, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(299, 1, 3, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:46', 14, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(300, 1, 2, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:46', 15, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(301, 1, 3, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:46', 16, 125, FALSE, FALSE, 5, 13, NULL, NULL),
(302, 1, 3, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:46', 1, 126, FALSE, FALSE, 5, 13, NULL, NULL),
(303, 1, 4, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:46', 1, 126, FALSE, FALSE, 5, 13, NULL, NULL),
(304, 1, 5, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:46', 1, 126, FALSE, FALSE, 5, 13, NULL, NULL),
(305, 1, 6, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:46', 1, 126, FALSE, FALSE, 5, 13, NULL, NULL),
(306, 1, 7, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:46', 1, 126, FALSE, FALSE, 5, 13, NULL, NULL),
(307, 1, 8, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:46', 1, 126, FALSE, FALSE, 5, 13, NULL, NULL),
(308, 1, 9, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:46', 1, 126, FALSE, FALSE, 5, 13, NULL, NULL),
(309, 1, 10, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:46', 1, 126, FALSE, FALSE, 5, 13, NULL, NULL),
(310, 1, 11, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:34:46', 1, 126, FALSE, FALSE, 5, 13, NULL, NULL),
(311, 4, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:31', 6, 46, FALSE, FALSE, 2147483647, 2147483647, NULL, NULL),
(312, 5, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 16, 45, FALSE, FALSE, 6, 16, NULL, NULL),
(313, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 17, 45, FALSE, FALSE, 6, 17, NULL, NULL),
(314, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 18, 45, FALSE, FALSE, 6, 18, NULL, NULL),
(315, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 27, 25, FALSE, FALSE, 6, 16, NULL, NULL),
(316, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 28, 25, FALSE, FALSE, 6, 16, NULL, NULL),
(317, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 29, 25, FALSE, FALSE, 6, 16, NULL, NULL),
(318, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 30, 25, FALSE, FALSE, 6, 16, NULL, NULL),
(319, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 31, 25, FALSE, FALSE, 6, 16, NULL, NULL),
(320, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 9, 5, FALSE, FALSE, 6, 16, NULL, NULL),
(321, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 10, 5, FALSE, FALSE, 6, 16, NULL, NULL),
(322, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 11, 5, FALSE, FALSE, 6, 16, NULL, NULL),
(323, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 2, 26, FALSE, FALSE, 6, 16, NULL, NULL),
(324, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 3, 80, FALSE, FALSE, 6, 16, NULL, NULL),
(325, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 2, 34, FALSE, FALSE, 6, 16, NULL, NULL),
(326, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 2, 63, FALSE, FALSE, 6, 16, NULL, NULL),
(327, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 20, 28, FALSE, FALSE, 6, 16, NULL, NULL),
(328, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 21, 56, FALSE, FALSE, 6, 16, NULL, NULL),
(329, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 22, 56, FALSE, FALSE, 6, 16, NULL, NULL),
(330, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 4, 51, FALSE, FALSE, 6, 16, NULL, NULL),
(331, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 23, 56, FALSE, FALSE, 6, 16, NULL, NULL),
(332, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 3, 41, FALSE, FALSE, 6, 16, NULL, NULL),
(333, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 25, 111, FALSE, FALSE, 6, 16, NULL, NULL),
(334, 1, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 9, 108, FALSE, FALSE, 6, 16, NULL, NULL);            
INSERT INTO "PUBLIC"."VERSION" VALUES
(348, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:15', 9, 108, FALSE, FALSE, 6, 16, NULL, NULL),
(349, 1, 2, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:16', 9, 108, FALSE, FALSE, 6, 16, NULL, NULL),
(350, 1, 3, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:16', 9, 108, FALSE, FALSE, 6, 16, NULL, NULL),
(351, 1, 1, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:16', 25, 111, FALSE, FALSE, 6, 16, NULL, NULL),
(352, 1, 2, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:16', 25, 111, FALSE, FALSE, 6, 16, NULL, NULL),
(353, 1, 3, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:16', 25, 111, FALSE, FALSE, 6, 16, NULL, NULL),
(354, 1, 4, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:16', 25, 111, FALSE, FALSE, 6, 16, NULL, NULL),
(355, 1, 5, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:16', 25, 111, FALSE, FALSE, 6, 16, NULL, NULL),
(356, 1, 6, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:16', 25, 111, FALSE, FALSE, 6, 16, NULL, NULL),
(357, 1, 7, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:16', 25, 111, FALSE, FALSE, 6, 16, NULL, NULL),
(358, 1, 8, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:16', 25, 111, FALSE, FALSE, 6, 16, NULL, NULL),
(359, 1, 9, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:16', 25, 111, FALSE, FALSE, 6, 16, NULL, NULL),
(360, 2, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:35:31', 19, 45, FALSE, FALSE, 6, 19, NULL, NULL),
(361, 2, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:36:05', 20, 45, FALSE, FALSE, 1, 20, NULL, NULL),
(362, 2, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:36:05', 21, 45, FALSE, FALSE, 2, 21, NULL, NULL),
(363, 2, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:36:06', 22, 45, FALSE, FALSE, 3, 22, NULL, NULL),
(364, 2, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:36:06', 23, 45, FALSE, FALSE, 4, 23, NULL, NULL),
(365, 2, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:36:06', 24, 45, FALSE, FALSE, 5, 24, NULL, NULL),
(366, 2, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:36:22', 25, 45, FALSE, FALSE, 1, 25, NULL, NULL),
(367, 2, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:36:22', 26, 45, FALSE, FALSE, 2, 26, NULL, NULL),
(368, 2, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:36:22', 27, 45, FALSE, FALSE, 3, 27, NULL, NULL),
(369, 2, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:36:22', 28, 45, FALSE, FALSE, 4, 28, NULL, NULL),
(370, 2, 0, 'odmAdmin', NULL, TIMESTAMP '2023-05-04 14:36:22', 29, 45, FALSE, FALSE, 5, 29, NULL, NULL),
(2147483647, NULL, NULL, NULL, 'Dummy record for internal purposes.', TIMESTAMP '2023-05-04 00:00:00', 2147483647, 1, FALSE, TRUE, 2147483647, 2147483647, NULL, NULL);          
CREATE INDEX "PUBLIC"."VERSIONELT" ON "PUBLIC"."VERSION"("ELTORIGINALID", "TYPE");             
CREATE INDEX "PUBLIC"."VERSION_PRJBRANCH" ON "PUBLIC"."VERSION"("PROJECT", "BASELINE", "TYPE", "ELTORIGINALID");               
CREATE INDEX "PUBLIC"."FKVERSIONTYPIDX" ON "PUBLIC"."VERSION"("TYPE");         
CREATE INDEX "PUBLIC"."FKVERSIONPRJCTIDX" ON "PUBLIC"."VERSION"("PROJECT");    
CREATE INDEX "PUBLIC"."FKVERSIONBSLNIDX" ON "PUBLIC"."VERSION"("BASELINE");    
CREATE CACHED TABLE "PUBLIC"."LVIPBRCH"(
    "VERSION" INTEGER NOT NULL,
    "ELTORIGINALID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "PARENTBRCH" INTEGER NOT NULL,
    "CHILDBRCH" INTEGER NOT NULL
);             
ALTER TABLE "PUBLIC"."LVIPBRCH" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_1D4" PRIMARY KEY("VERSION", "CHILDBRCH");  
-- 231 +/- SELECT COUNT(*) FROM PUBLIC.LVIPBRCH;               
INSERT INTO "PUBLIC"."LVIPBRCH" VALUES
(323, 2, 26, 16, 19),
(325, 2, 34, 16, 19),
(326, 2, 63, 16, 19),
(332, 3, 41, 16, 19),
(324, 3, 80, 16, 19),
(330, 4, 51, 16, 19),
(320, 9, 5, 16, 19),
(350, 9, 108, 16, 19),
(321, 10, 5, 16, 19),
(322, 11, 5, 16, 19),
(312, 16, 45, 16, 19),
(327, 20, 28, 16, 19),
(328, 21, 56, 16, 19),
(329, 22, 56, 16, 19),
(331, 23, 56, 16, 19),
(359, 25, 111, 16, 19),
(315, 27, 25, 16, 19),
(316, 28, 25, 16, 19),
(317, 29, 25, 16, 19),
(318, 30, 25, 16, 19),
(319, 31, 25, 16, 19),
(12, 1, 5, 1, 20),
(7, 1, 25, 1, 20),
(13, 1, 26, 1, 20),
(17, 1, 34, 1, 20),
(14, 1, 41, 1, 20),
(4, 1, 45, 1, 20),
(16, 1, 63, 1, 20),
(18, 1, 80, 1, 20),
(8, 2, 25, 1, 20),
(15, 2, 41, 1, 20),
(9, 3, 25, 1, 20),
(10, 4, 25, 1, 20),
(11, 5, 25, 1, 20),
(32, 1, 56, 4, 21),
(29, 2, 5, 4, 21),
(33, 2, 56, 4, 21),
(30, 3, 5, 4, 21),
(34, 3, 56, 4, 21),
(31, 4, 5, 4, 21),
(21, 4, 45, 4, 21),
(35, 4, 56, 4, 21),
(36, 5, 56, 4, 21),
(24, 6, 25, 4, 21),
(37, 6, 56, 4, 21),
(25, 7, 25, 4, 21),
(26, 8, 25, 4, 21),
(27, 9, 25, 4, 21),
(28, 10, 25, 4, 21),
(56, 1, 51, 7, 22),
(59, 1, 108, 7, 22),
(47, 5, 5, 7, 22),
(48, 6, 5, 7, 22),
(49, 7, 28, 7, 22),
(39, 7, 45, 7, 22),
(50, 8, 56, 7, 22),
(51, 9, 56, 7, 22),
(52, 10, 56, 7, 22),
(42, 11, 25, 7, 22),
(53, 11, 56, 7, 22),
(43, 12, 25, 7, 22),
(54, 12, 56, 7, 22),
(44, 13, 25, 7, 22),
(55, 13, 28, 7, 22),
(45, 14, 25, 7, 22),
(46, 15, 25, 7, 22),
(76, 2, 51, 10, 23),
(79, 3, 108, 10, 23),
(69, 7, 5, 10, 23),
(61, 10, 45, 10, 23),
(70, 14, 28, 10, 23),
(71, 15, 56, 10, 23),
(64, 16, 25, 10, 23),
(72, 16, 56, 10, 23),
(65, 17, 25, 10, 23),
(73, 17, 28, 10, 23),
(66, 18, 25, 10, 23),
(74, 18, 56, 10, 23),
(67, 19, 25, 10, 23),
(75, 19, 28, 10, 23),
(68, 20, 25, 10, 23),
(271, 1, 111, 13, 24),
(239, 1, 124, 13, 24),
(284, 1, 125, 13, 24),
(310, 1, 126, 13, 24),
(238, 1, 127, 13, 24),
(281, 1, 129, 13, 24),
(234, 1, 132, 13, 24),
(92, 2, 80, 13, 24),
(279, 2, 111, 13, 24),
(240, 2, 124, 13, 24),
(285, 2, 125, 13, 24),
(90, 3, 51, 13, 24),
(241, 3, 124, 13, 24),
(286, 3, 125, 13, 24),
(242, 4, 124, 13, 24),
(287, 4, 125, 13, 24),
(224, 5, 108, 13, 24),
(243, 5, 124, 13, 24),
(290, 5, 125, 13, 24),
(225, 6, 108, 13, 24),
(244, 6, 124, 13, 24),
(291, 6, 125, 13, 24),
(245, 7, 124, 13, 24),
(292, 7, 125, 13, 24),
(89, 8, 5, 13, 24),
(246, 8, 124, 13, 24),
(293, 8, 125, 13, 24),
(247, 9, 124, 13, 24),
(294, 9, 125, 13, 24),
(248, 10, 124, 13, 24),
(295, 10, 125, 13, 24),
(249, 11, 124, 13, 24),
(296, 11, 125, 13, 24),
(297, 12, 125, 13, 24),
(81, 13, 45, 13, 24),
(298, 13, 125, 13, 24),
(299, 14, 125, 13, 24),
(300, 15, 125, 13, 24),
(301, 16, 125, 13, 24),
(84, 21, 25, 13, 24),
(85, 22, 25, 13, 24),
(86, 23, 25, 13, 24),
(87, 24, 25, 13, 24),
(88, 25, 25, 13, 24),
(91, 26, 1, 13, 24),
(12, 1, 5, 1, 25),
(7, 1, 25, 1, 25),
(13, 1, 26, 1, 25),
(17, 1, 34, 1, 25),
(14, 1, 41, 1, 25),
(4, 1, 45, 1, 25),
(16, 1, 63, 1, 25),
(18, 1, 80, 1, 25),
(8, 2, 25, 1, 25),
(15, 2, 41, 1, 25),
(9, 3, 25, 1, 25),
(10, 4, 25, 1, 25),
(11, 5, 25, 1, 25),
(32, 1, 56, 4, 26),
(29, 2, 5, 4, 26),
(33, 2, 56, 4, 26),
(30, 3, 5, 4, 26),
(34, 3, 56, 4, 26),
(31, 4, 5, 4, 26),
(21, 4, 45, 4, 26),
(35, 4, 56, 4, 26),
(36, 5, 56, 4, 26),
(24, 6, 25, 4, 26),
(37, 6, 56, 4, 26),
(25, 7, 25, 4, 26),
(26, 8, 25, 4, 26),
(27, 9, 25, 4, 26),
(28, 10, 25, 4, 26),
(56, 1, 51, 7, 27),
(59, 1, 108, 7, 27),
(47, 5, 5, 7, 27),
(48, 6, 5, 7, 27),
(49, 7, 28, 7, 27),
(39, 7, 45, 7, 27),
(50, 8, 56, 7, 27),
(51, 9, 56, 7, 27),
(52, 10, 56, 7, 27),
(42, 11, 25, 7, 27),
(53, 11, 56, 7, 27),
(43, 12, 25, 7, 27),
(54, 12, 56, 7, 27),
(44, 13, 25, 7, 27),
(55, 13, 28, 7, 27),
(45, 14, 25, 7, 27),
(46, 15, 25, 7, 27),
(76, 2, 51, 10, 28),
(79, 3, 108, 10, 28),
(69, 7, 5, 10, 28),
(61, 10, 45, 10, 28),
(70, 14, 28, 10, 28),
(71, 15, 56, 10, 28),
(64, 16, 25, 10, 28),
(72, 16, 56, 10, 28),
(65, 17, 25, 10, 28),
(73, 17, 28, 10, 28),
(66, 18, 25, 10, 28),
(74, 18, 56, 10, 28),
(67, 19, 25, 10, 28),
(75, 19, 28, 10, 28),
(68, 20, 25, 10, 28),
(271, 1, 111, 13, 29),
(239, 1, 124, 13, 29),
(284, 1, 125, 13, 29),
(310, 1, 126, 13, 29),
(238, 1, 127, 13, 29);               
INSERT INTO "PUBLIC"."LVIPBRCH" VALUES
(281, 1, 129, 13, 29),
(234, 1, 132, 13, 29),
(92, 2, 80, 13, 29),
(279, 2, 111, 13, 29),
(240, 2, 124, 13, 29),
(285, 2, 125, 13, 29),
(90, 3, 51, 13, 29),
(241, 3, 124, 13, 29),
(286, 3, 125, 13, 29),
(242, 4, 124, 13, 29),
(287, 4, 125, 13, 29),
(224, 5, 108, 13, 29),
(243, 5, 124, 13, 29),
(290, 5, 125, 13, 29),
(225, 6, 108, 13, 29),
(244, 6, 124, 13, 29),
(291, 6, 125, 13, 29),
(245, 7, 124, 13, 29),
(292, 7, 125, 13, 29),
(89, 8, 5, 13, 29),
(246, 8, 124, 13, 29),
(293, 8, 125, 13, 29),
(247, 9, 124, 13, 29),
(294, 9, 125, 13, 29),
(248, 10, 124, 13, 29),
(295, 10, 125, 13, 29),
(249, 11, 124, 13, 29),
(296, 11, 125, 13, 29),
(297, 12, 125, 13, 29),
(81, 13, 45, 13, 29),
(298, 13, 125, 13, 29),
(299, 14, 125, 13, 29),
(300, 15, 125, 13, 29),
(301, 16, 125, 13, 29),
(84, 21, 25, 13, 29),
(85, 22, 25, 13, 29),
(86, 23, 25, 13, 29),
(87, 24, 25, 13, 29),
(88, 25, 25, 13, 29),
(91, 26, 1, 13, 29);       
CREATE INDEX "PUBLIC"."LVIPBIDX" ON "PUBLIC"."LVIPBRCH"("ELTORIGINALID", "TYPE", "PARENTBRCH");
CREATE INDEX "PUBLIC"."FKLVIPBRCHVRSNIDX" ON "PUBLIC"."LVIPBRCH"("VERSION");   
CREATE INDEX "PUBLIC"."FKLVIPBRCHTYPIDX" ON "PUBLIC"."LVIPBRCH"("TYPE");       
CREATE INDEX "PUBLIC"."FKLVIPBRCHPRNTBRCHIDX" ON "PUBLIC"."LVIPBRCH"("PARENTBRCH");            
CREATE INDEX "PUBLIC"."FKLVIPBRCHCHLDBRCHIDX" ON "PUBLIC"."LVIPBRCH"("CHILDBRCH");             
CREATE CACHED TABLE "PUBLIC"."BASELINECONTENT"(
    "BASELINE" INTEGER NOT NULL,
    "VERSION" INTEGER NOT NULL
);             
ALTER TABLE "PUBLIC"."BASELINECONTENT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_58" PRIMARY KEY("VERSION", "BASELINE");             
-- 37 +/- SELECT COUNT(*) FROM PUBLIC.BASELINECONTENT;         
INSERT INTO "PUBLIC"."BASELINECONTENT" VALUES
(2147483647, 2147483647),
(1, 2147483647),
(2, 7),
(2, 8),
(2, 9),
(2, 10),
(2, 11),
(4, 2147483647),
(5, 24),
(5, 25),
(5, 26),
(5, 27),
(5, 28),
(7, 2147483647),
(8, 42),
(8, 43),
(8, 44),
(8, 45),
(8, 46),
(10, 2147483647),
(11, 64),
(11, 65),
(11, 66),
(11, 67),
(11, 68),
(13, 2147483647),
(14, 84),
(14, 85),
(14, 86),
(14, 87),
(14, 88),
(16, 2147483647),
(17, 315),
(17, 316),
(17, 317),
(17, 318),
(17, 319);
CREATE INDEX "PUBLIC"."FKBASELINECONTENTBSLNIDX" ON "PUBLIC"."BASELINECONTENT"("BASELINE");    
CREATE INDEX "PUBLIC"."FKBASELINECONTENTVRSNIDX" ON "PUBLIC"."BASELINECONTENT"("VERSION");     
CREATE CACHED TABLE "PUBLIC"."LOCKTBL"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "BRANCH" INTEGER NOT NULL,
    "ELEMENTID" INTEGER NOT NULL,
    "ELEMENTTYPE" INTEGER NOT NULL,
    "OWNER" VARCHAR(100),
    "PERSISTENT" BOOLEAN,
    "ROOTLOCKID" INTEGER,
    "SESSIONID" VARCHAR(40),
    "SYSTEM" BOOLEAN
);        
ALTER TABLE "PUBLIC"."LOCKTBL" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_3E" PRIMARY KEY("BRANCH", "ELEMENTID", "ELEMENTTYPE");      
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.LOCKTBL;  
CREATE INDEX "PUBLIC"."FKLOCKTBLTYPIDX" ON "PUBLIC"."LOCKTBL"("TYPE");         
CREATE CACHED TABLE "PUBLIC"."RULEPACKAGE"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER,
    "PACKAGEKIND" VARCHAR(30) NOT NULL,
    "PARENT" INTEGER,
    "RULEORDER" CLOB(52428800)
);    
ALTER TABLE "PUBLIC"."RULEPACKAGE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_CC" PRIMARY KEY("ID");  
-- 11 +/- SELECT COUNT(*) FROM PUBLIC.RULEPACKAGE;             
INSERT INTO "PUBLIC"."RULEPACKAGE" VALUES
(1, 5, 12, 2147483647, 1, 1, 'xom-libraries', 'a7caa1f7-0257-4cc3-a464-561d2fd8a274', NULL, NULL, 1, 'Resource', NULL, NULL),
(2, 5, 29, 2147483647, 2, 4, 'validation', '278f8627-849d-4dd4-b5a0-feda2ecf3c5a', NULL, NULL, 2, 'Rule', NULL, NULL),
(3, 5, 30, 2147483647, 3, 4, 'loan', 'd964a314-487c-43ef-9940-b0726a8fc55f', NULL, NULL, 2, 'Rule', 2, NULL),
(4, 5, 31, 2147483647, 4, 4, 'borrower', 'd73ae58b-f6c9-41e2-8e2e-1160f3e965db', NULL, NULL, 2, 'Rule', 2, NULL),
(5, 5, 47, 2147483647, 5, 7, 'eligibility', 'ca657f70-727c-407b-b460-7110aee225e9', NULL, NULL, 3, 'Rule', NULL, NULL),
(6, 5, 48, 2147483647, 6, 7, 'insurance', '270c3761-353a-44c7-b9ca-0fd08ba926d9', NULL, NULL, 3, 'Rule', NULL, NULL),
(7, 5, 69, 2147483647, 7, 10, 'computation', '034cc72e-0fb3-4b12-9341-281508191005', NULL, NULL, 4, 'Rule', NULL, NULL),
(8, 5, 89, 2147483647, 8, 13, 'META-INF', 'fe849835-b11b-472d-bf90-bf84c5306c7c', NULL, NULL, 5, 'Resource', NULL, NULL),
(9, 5, 320, 2147483647, 9, 16, 'xom-libraries', 'b518810c-90e9-4508-b774-2cd02304e71c', NULL, NULL, 6, 'Resource', NULL, NULL),
(10, 5, 321, 2147483647, 10, 16, 'eligibility', '14871ffa-5aeb-4078-865e-f3d08d54ab77', NULL, NULL, 6, 'Rule', NULL, NULL),
(11, 5, 322, 2147483647, 11, 16, 'validation', '7f852e6a-8858-4c95-b072-9bb68f56417a', NULL, NULL, 6, 'Rule', NULL, NULL);         
CREATE INDEX "PUBLIC"."RULEPACKAGE_PRJBRANCH" ON "PUBLIC"."RULEPACKAGE"("PROJECT", "BASELINE");
CREATE UNIQUE INDEX "PUBLIC"."RULEPACKAGENAMEUNIQUE" ON "PUBLIC"."RULEPACKAGE"("BASELINE", "NAME", "PARENT", "PACKAGEKIND", "ENDID");          
CREATE UNIQUE INDEX "PUBLIC"."RULEPACKAGEUUIDUNIQUE" ON "PUBLIC"."RULEPACKAGE"("UUID", "BASELINE", "ENDID");   
CREATE INDEX "PUBLIC"."FOLDERPARENTIDX" ON "PUBLIC"."RULEPACKAGE"("PARENT", "ENDID");          
CREATE UNIQUE INDEX "PUBLIC"."FOLDERVERSION" ON "PUBLIC"."RULEPACKAGE"("ORIGINALID", "TYPE", "PARENT", "STARTID", "ENDID");    
CREATE INDEX "PUBLIC"."FKRULEPACKAGETYPIDX" ON "PUBLIC"."RULEPACKAGE"("TYPE"); 
CREATE INDEX "PUBLIC"."FKRULEPACKAGESTRTDIDX" ON "PUBLIC"."RULEPACKAGE"("STARTID");            
CREATE INDEX "PUBLIC"."FKRULEPACKAGENDDIDX" ON "PUBLIC"."RULEPACKAGE"("ENDID");
CREATE INDEX "PUBLIC"."FKRULEPACKAGEBSLNIDX" ON "PUBLIC"."RULEPACKAGE"("BASELINE");            
CREATE INDEX "PUBLIC"."FKRULEPACKAGEDIDX" ON "PUBLIC"."RULEPACKAGE"("UUID");   
CREATE INDEX "PUBLIC"."FKRULEPACKAGEPRNTIDX" ON "PUBLIC"."RULEPACKAGE"("PARENT");              
CREATE CACHED TABLE "PUBLIC"."RULEPACKAGESIBLING"(
    "ID" INTEGER NOT NULL
);
ALTER TABLE "PUBLIC"."RULEPACKAGESIBLING" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_81F" PRIMARY KEY("ID");          
-- 11 +/- SELECT COUNT(*) FROM PUBLIC.RULEPACKAGESIBLING;      
INSERT INTO "PUBLIC"."RULEPACKAGESIBLING" VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11);      
CREATE CACHED TABLE "PUBLIC"."ABSTRACTQUERY"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "DEFINITION" CLOB(52428800),
    "INCLUDEDEPENDENCIES" BOOLEAN,
    "LOCALE" VARCHAR(30),
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER,
    "PROPERTYPATH" CLOB(52428800)
);    
ALTER TABLE "PUBLIC"."ABSTRACTQUERY" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_439" PRIMARY KEY("ID");               
-- 31 +/- SELECT COUNT(*) FROM PUBLIC.ABSTRACTQUERY;           
INSERT INTO "PUBLIC"."ABSTRACTQUERY" VALUES
(1, 25, 7, 2147483647, 1, 1, 'Find all business rules', FALSE, 'en_US', '%businessRulesView_key', '2c4314aa-0a44-4a32-aabc-0978ea434414', NULL, NULL, NULL, 1, 'rulePackage'),
(2, 25, 8, 2147483647, 2, 1, 'Find all templates', FALSE, 'en_US', '%templatesView_key', 'fc4ffffa-050b-453c-985b-75a9ed15fd71', NULL, NULL, NULL, 1, 'rulePackage'),
(3, 25, 9, 2147483647, 3, 1, 'Find all ruleflows', FALSE, 'en_US', '%ruleflowsView_key', '84957601-3998-4e62-b051-4d8c566555df', NULL, NULL, NULL, 1, NULL),
(4, 25, 10, 2147483647, 4, 1, 'Find all simulations', FALSE, 'en_US', '%simulationsView_key', 'cf615ea3-7c2d-4da6-8c48-f67d30642239', NULL, NULL, NULL, 1, 'rulePackage'),
(5, 25, 11, 2147483647, 5, 1, 'Find all test suites', FALSE, 'en_US', '%testSuitesView_key', '34d9feee-0900-4d89-b92e-fb3c2e424a90', NULL, NULL, NULL, 1, 'rulePackage'),
(6, 25, 24, 2147483647, 6, 4, 'Find all business rules', FALSE, 'en_US', '%businessRulesView_key', 'e84c8ea0-d58a-46de-8d12-2c0d4ea10e6f', NULL, NULL, NULL, 2, 'rulePackage'),
(7, 25, 25, 2147483647, 7, 4, 'Find all templates', FALSE, 'en_US', '%templatesView_key', '640f5094-4ada-4076-a880-99deb51fccaa', NULL, NULL, NULL, 2, 'rulePackage'),
(8, 25, 26, 2147483647, 8, 4, 'Find all ruleflows', FALSE, 'en_US', '%ruleflowsView_key', 'f28458de-dd47-401c-a76c-2ca6809153b2', NULL, NULL, NULL, 2, NULL),
(9, 25, 27, 2147483647, 9, 4, 'Find all simulations', FALSE, 'en_US', '%simulationsView_key', '9bad0a10-0116-495d-89e2-dd645ff1fdcd', NULL, NULL, NULL, 2, 'rulePackage'),
(10, 25, 28, 2147483647, 10, 4, 'Find all test suites', FALSE, 'en_US', '%testSuitesView_key', '104cfd87-169d-4fc5-a8ef-df8916aa6be3', NULL, NULL, NULL, 2, 'rulePackage'),
(11, 25, 42, 2147483647, 11, 7, 'Find all business rules', FALSE, 'en_US', '%businessRulesView_key', 'ed377117-aad4-4b38-b60e-321402b9e308', NULL, NULL, NULL, 3, 'rulePackage'),
(12, 25, 43, 2147483647, 12, 7, 'Find all templates', FALSE, 'en_US', '%templatesView_key', '9095db28-53e5-4a92-b5ad-4e6dbc2bac84', NULL, NULL, NULL, 3, 'rulePackage'),
(13, 25, 44, 2147483647, 13, 7, 'Find all ruleflows', FALSE, 'en_US', '%ruleflowsView_key', '0e79f418-496e-4629-bd2b-ff3c8faec5f7', NULL, NULL, NULL, 3, NULL),
(14, 25, 45, 2147483647, 14, 7, 'Find all simulations', FALSE, 'en_US', '%simulationsView_key', '3430526e-0856-49ad-9625-2a0e78b2999f', NULL, NULL, NULL, 3, 'rulePackage'),
(15, 25, 46, 2147483647, 15, 7, 'Find all test suites', FALSE, 'en_US', '%testSuitesView_key', '103301f2-abce-4e4f-9b0e-2ba4916ea0c9', NULL, NULL, NULL, 3, 'rulePackage'),
(16, 25, 64, 2147483647, 16, 10, 'Find all business rules', FALSE, 'en_US', '%businessRulesView_key', '0a2753aa-35fd-4809-a699-c2612203e73a', NULL, NULL, NULL, 4, 'rulePackage'),
(17, 25, 65, 2147483647, 17, 10, 'Find all templates', FALSE, 'en_US', '%templatesView_key', 'cb284b67-21aa-4efb-a4c4-3add35a9cabf', NULL, NULL, NULL, 4, 'rulePackage'),
(18, 25, 66, 2147483647, 18, 10, 'Find all ruleflows', FALSE, 'en_US', '%ruleflowsView_key', '6ef01662-0512-4888-933e-1b295d3cdd5a', NULL, NULL, NULL, 4, NULL),
(19, 25, 67, 2147483647, 19, 10, 'Find all simulations', FALSE, 'en_US', '%simulationsView_key', '46eea6b1-2d30-4d73-8c6b-82eadc2f6f5c', NULL, NULL, NULL, 4, 'rulePackage'),
(20, 25, 68, 2147483647, 20, 10, 'Find all test suites', FALSE, 'en_US', '%testSuitesView_key', '7e30a7c4-2add-43cb-8e19-e9d6d00c896f', NULL, NULL, NULL, 4, 'rulePackage'),
(21, 25, 84, 2147483647, 21, 13, 'Find all business rules', FALSE, 'en_US', '%businessRulesView_key', '527ab526-cbf0-421f-a715-465ac765fc19', NULL, NULL, NULL, 5, 'rulePackage'),
(22, 25, 85, 2147483647, 22, 13, 'Find all templates', FALSE, 'en_US', '%templatesView_key', '74ff73d2-ecf2-4d60-a6bf-0a921afba8e2', NULL, NULL, NULL, 5, 'rulePackage'),
(23, 25, 86, 2147483647, 23, 13, 'Find all ruleflows', FALSE, 'en_US', '%ruleflowsView_key', '302ea0d5-55d3-41f9-9e30-c37f671f85c1', NULL, NULL, NULL, 5, NULL),
(24, 25, 87, 2147483647, 24, 13, 'Find all simulations', FALSE, 'en_US', '%simulationsView_key', '0baddb90-5ce9-455d-a169-5814c8a3763d', NULL, NULL, NULL, 5, 'rulePackage');        
INSERT INTO "PUBLIC"."ABSTRACTQUERY" VALUES
(25, 25, 88, 2147483647, 25, 13, 'Find all test suites', FALSE, 'en_US', '%testSuitesView_key', 'cc1eba8b-5d7b-433b-862e-fc1b7f037377', NULL, NULL, NULL, 5, 'rulePackage'),
(26, 1, 91, 2147483647, 26, 13, STRINGDECODE('Find all business rules \n\t\t such that the status of each business rule is validated'), TRUE, 'en_US', 'validated rules query', '2ea0f1ac-f84b-4ae6-a617-c361168d274d', NULL, NULL, NULL, 5, NULL),
(27, 25, 315, 2147483647, 27, 16, 'Find all business rules', FALSE, 'en_US', '%businessRulesView_key', 'a1fb618e-b087-4eaf-b53a-cb6adacc5e5d', NULL, NULL, NULL, 6, 'rulePackage'),
(28, 25, 316, 2147483647, 28, 16, 'Find all templates', FALSE, 'en_US', '%templatesView_key', 'a36d8662-22fe-40e2-ac51-b2ca3e9a9870', NULL, NULL, NULL, 6, 'rulePackage'),
(29, 25, 317, 2147483647, 29, 16, 'Find all ruleflows', FALSE, 'en_US', '%ruleflowsView_key', '1e28047e-1847-4fda-a8d2-207114d6641a', NULL, NULL, NULL, 6, NULL),
(30, 25, 318, 2147483647, 30, 16, 'Find all simulations', FALSE, 'en_US', '%simulationsView_key', 'c34a3ea3-ce9c-4361-a959-fa891a82257c', NULL, NULL, NULL, 6, 'rulePackage'),
(31, 25, 319, 2147483647, 31, 16, 'Find all test suites', FALSE, 'en_US', '%testSuitesView_key', '0ac0ebdd-99e1-4dbb-a2cb-b95109fb0bba', NULL, NULL, NULL, 6, 'rulePackage');     
CREATE INDEX "PUBLIC"."ABSTRACTQUERY_PRJBRANCH" ON "PUBLIC"."ABSTRACTQUERY"("PROJECT", "BASELINE");            
CREATE UNIQUE INDEX "PUBLIC"."ABSTRACTQUERYUUIDUNIQUE" ON "PUBLIC"."ABSTRACTQUERY"("UUID", "BASELINE", "ENDID");               
CREATE INDEX "PUBLIC"."FKABSTRACTQUERYTYPIDX" ON "PUBLIC"."ABSTRACTQUERY"("TYPE");             
CREATE INDEX "PUBLIC"."FKABSTRACTQUERYSTRTDIDX" ON "PUBLIC"."ABSTRACTQUERY"("STARTID");        
CREATE INDEX "PUBLIC"."FKABSTRACTQUERYNDDIDX" ON "PUBLIC"."ABSTRACTQUERY"("ENDID");            
CREATE INDEX "PUBLIC"."FKABSTRACTQUERYBSLNIDX" ON "PUBLIC"."ABSTRACTQUERY"("BASELINE");        
CREATE INDEX "PUBLIC"."FKABSTRACTQUERYDIDX" ON "PUBLIC"."ABSTRACTQUERY"("UUID");               
CREATE INDEX "PUBLIC"."FKABSTRACTQUERYRLPCKGIDX" ON "PUBLIC"."ABSTRACTQUERY"("RULEPACKAGE");   
CREATE CACHED TABLE "PUBLIC"."ACTIVITYLOCK"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "ELTBASETYPE" INTEGER NOT NULL,
    "ELTNAME" VARCHAR(255) NOT NULL,
    "ELTPACKAGE" INTEGER,
    "JUSTIFYINGVID" INTEGER,
    "OWNER" INTEGER NOT NULL,
    "BRANCH" INTEGER NOT NULL,
    "ELEMENTID" INTEGER NOT NULL,
    "ELEMENTTYPE" INTEGER NOT NULL
);      
ALTER TABLE "PUBLIC"."ACTIVITYLOCK" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_EB" PRIMARY KEY("ID"); 
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.ACTIVITYLOCK;             
CREATE INDEX "PUBLIC"."ACTIVITYLOCKELTIDX" ON "PUBLIC"."ACTIVITYLOCK"("ELEMENTID", "ELEMENTTYPE", "BRANCH");   
CREATE INDEX "PUBLIC"."FKACTIVITYLOCKTYPIDX" ON "PUBLIC"."ACTIVITYLOCK"("TYPE");               
CREATE INDEX "PUBLIC"."FKACTIVITYLOCKLTPCKGIDX" ON "PUBLIC"."ACTIVITYLOCK"("ELTPACKAGE");      
CREATE CACHED TABLE "PUBLIC"."BOM"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "BODY" CLOB(52428800),
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER
);    
ALTER TABLE "PUBLIC"."BOM" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_10" PRIMARY KEY("ID");          
-- 2 +/- SELECT COUNT(*) FROM PUBLIC.BOM;      
CREATE TABLE IF NOT EXISTS SYSTEM_LOB_STREAM(ID INT NOT NULL, PART INT NOT NULL, CDATA VARCHAR, BDATA BINARY); 
CREATE PRIMARY KEY SYSTEM_LOB_STREAM_PRIMARY_KEY ON SYSTEM_LOB_STREAM(ID, PART);               
CREATE ALIAS IF NOT EXISTS SYSTEM_COMBINE_CLOB FOR "org.h2.command.dml.ScriptCommand.combineClob";             
CREATE ALIAS IF NOT EXISTS SYSTEM_COMBINE_BLOB FOR "org.h2.command.dml.ScriptCommand.combineBlob";             
INSERT INTO SYSTEM_LOB_STREAM VALUES(0, 0, STRINGDECODE('\nproperty origin \"xom:/Loan Validation Base/loan-validation-xom\"\nproperty uuid \"a5f8bd3d-d967-41bb-94cb-454672e27811\"\npackage loan;\n\n\npublic class Borrower\n        extends java.io.Serializable\n{\n\n    public class Bankruptcy\n            extends java.io.Serializable\n    {\n        public readonly int chapter;\n        public readonly java.util.Date date;\n        public readonly string reason;\n        public Bankruptcy(loan.Borrower arg1, java.util.Date arg2, int arg3, string arg4);\n    }\n\n    public class SSN\n            extends java.io.Serializable\n    {\n        public readonly string areaNumber;\n        public readonly int digits;\n        public readonly string fullNumber;\n        public readonly string groupCode;\n        public readonly string serialNumber;\n        public SSN(loan.Borrower arg1, string arg2);\n        public SSN(loan.Borrower arg1, string arg2, string arg3, string arg4);\n        public string toString();\n    }\n    public readonly loan.Borrower.SSN SSN\n                property \"factory.ignore\" \"true\";\n    public readonly string SSNCode;\n    public readonly int age;\n    public readonly java.util.Date birthDate;\n    public int creditScore;\n    public readonly string firstName;\n    public readonly string lastName;\n    public readonly int latestBankruptcyChapter;\n    public readonly java.util.Date latestBankruptcyDate;\n    public readonly string latestBankruptcyReason;\n    public loan.Borrower spouse\n                property \"factory.ignore\" \"true\";\n    public readonly loan.Borrower.SSN ssn;\n    public int yearlyIncome;\n    public string zipCode;\n    public Borrower(string firstName, string lastName, java.util.Date birthDate, string SSNCode);\n    public int getBankruptcyAge();\n    public boolean hasLatestBankrupcy();\n    public void setLatestBankruptcy(java.util.Date arg1, int arg2, string arg3);\n    public string toString();\n}\n\npublic class DateUtil\n{\n    public DateUtil();\n    public static java.util.Date addDays(java.util.Date arg1, int arg2);\n    public static java.util.Date dateAsDay(java.util.Date arg);\n    public static string format(java.util.Date arg);\n    public static int getAge(java.util.Date arg1, java.util.Date arg2);\n    public static int getDuration(java.util.Date arg1, java.util.Date arg2);\n    public static java.util.Iterator iterator(java.util.Date arg1, java.util.Date arg2);\n    public static java.util.Date makeDate(int arg1, int arg2, int arg3);\n    public static java.util.Date now();\n}\n\npublic class LoanRequest\n        extends loan.LoanUtil, java.io.Serializable\n{\n    public readonly int amount;\n    public readonly int duration;\n    public double loanToValue;\n    public readonly int numberOfMonthlyPayments;\n    public readonly java.util.Date startDate;\n    public LoanRequest(java.util.Date startDate, int numberOfMonthlyPayments, int amount, double loanToValue);\n    public string toString();\n}\n\npublic class LoanUtil\n        extends java.io.Serializable\n{\n    public LoanUtil();\n    public static boolean containsOnlyDigits(string arg);\n    public static string formattedAmount(double arg);\n    public static string formattedPercentage(double arg);\n    public static double getMonthlyRepayment(double amount, int rate, double arg3);\n}\n\npublic class Report\n        extends loan.LoanUtil, java.io.Serializable\n{\n    public boolean approved;\n    public readonly loan.Borrower borrower;\n    public readonly string insurance;\n    public double insuranceRate;\n    public boolean insuranceRequired;\n    public readonly loan.LoanRequest loan;\n    public readonly string message;\n    public readonly java.util.List messages domain 0,* class string;\n    public double monthlyRepayment;\n    public boolean validData;\n    public double yearlyInterestRate;\n    public readonly double yearlyRepayment;\n    public Report(loan.Borrower arg1, loan.LoanRequest arg2);\n    public void addMessage(string arg);\n    public void approveLoan(string message)\n                property update \"true\";\n    public void rejectData(string message);\n    public void rejectLoan(string message)\n                property update \"true\";\n    public st'), NULL);             
INSERT INTO SYSTEM_LOB_STREAM VALUES(0, 1, STRINGDECODE('ring toString();\n}\n\n'), NULL);     
INSERT INTO "PUBLIC"."BOM" VALUES
(1, 26, 13, 2147483647, 1, 1, SYSTEM_COMBINE_CLOB(0), 'model', 'a5f8bd3d-d967-41bb-94cb-454672e27811', NULL, NULL, NULL, 1),
(2, 26, 323, 2147483647, 2, 16, STRINGDECODE('\nproperty loadGetterSetterAsProperties \"true\"\nproperty origin \"xom:/Miniloan Service/miniloan-xom\"\nproperty uuid \"d3f41bc5-5c35-4232-aa7b-23ae87e16477\"\npackage miniloan;\n\n\npublic class Borrower\n{\n    public int creditScore;\n    public readonly string name;\n    public int yearlyIncome;\n    public Borrower(string name, int creditScore, int yearlyIncome)\n                property \"ilog.rules.engine.dataio.forConversion\" \"true\";\n    public Borrower();\n}\n\npublic class Loan\n{\n    public readonly int amount;\n    public readonly string approvalStatus\n                property \"factory.ignore\" \"true\";\n    public boolean approved\n                property \"factory.ignore\" \"true\";\n    public readonly int duration;\n    public readonly java.util.Collection messages domain 0,* class string;\n    public readonly double yearlyInterestRate;\n    public readonly int yearlyRepayment;\n    public Loan(int amount, int duration, double yearlyInterestRate)\n                property \"ilog.rules.engine.dataio.forConversion\" \"true\";\n    public Loan();\n    public void addToMessages(string arg);\n    public void reject();\n    public void removeFromMessages(string arg);\n}\n\n'), 'miniloan', 'd3f41bc5-5c35-4232-aa7b-23ae87e16477', NULL, NULL, NULL, 6);        
CREATE INDEX "PUBLIC"."BOM_PRJBRANCH" ON "PUBLIC"."BOM"("PROJECT", "BASELINE");
CREATE UNIQUE INDEX "PUBLIC"."BOMUUIDUNIQUE" ON "PUBLIC"."BOM"("UUID", "BASELINE", "ENDID");   
CREATE INDEX "PUBLIC"."FKBOMTYPIDX" ON "PUBLIC"."BOM"("TYPE"); 
CREATE INDEX "PUBLIC"."FKBOMSTRTDIDX" ON "PUBLIC"."BOM"("STARTID");            
CREATE INDEX "PUBLIC"."FKBOMNDDIDX" ON "PUBLIC"."BOM"("ENDID");
CREATE INDEX "PUBLIC"."FKBOMBSLNIDX" ON "PUBLIC"."BOM"("BASELINE");            
CREATE INDEX "PUBLIC"."FKBOMDIDX" ON "PUBLIC"."BOM"("UUID");   
CREATE INDEX "PUBLIC"."FKBOMRLPCKGIDX" ON "PUBLIC"."BOM"("RULEPACKAGE");       
CREATE CACHED TABLE "PUBLIC"."BOM2XOMMAPPING"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "BODY" CLOB(52428800),
    "PLATFORM" VARCHAR(30),
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER
);             
ALTER TABLE "PUBLIC"."BOM2XOMMAPPING" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_90" PRIMARY KEY("ID");               
-- 2 +/- SELECT COUNT(*) FROM PUBLIC.BOM2XOMMAPPING;           
INSERT INTO "PUBLIC"."BOM2XOMMAPPING" VALUES
(1, 63, 16, 2147483647, 1, 1, STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?><b2x:translation xmlns:b2x=\"http://schemas.ilog.com/JRules/1.3/Translation\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://schemas.ilog.com/JRules/1.3/Translation ilog/rules/schemas/1_3/b2x.xsd\">\n    <id>81640342-7aa9-4c1a-867e-ee6bc21dba20</id>\n    <lang>ARL</lang>\n    <class>\n        <businessName>loan.Borrower</businessName>\n        <attribute>\n            <name>age</name>\n            <getter language=\"arl\"><![CDATA[\n            return loan.DateUtil.getAge(this.getBirthDate(), loan.DateUtil.now());\n\n            ]]></getter>\n        </attribute>\n        <attribute>\n            <name>ssn</name>\n            <getter language=\"arl\"><![CDATA[\n            return this.getSSN();\n\n            ]]></getter>\n        </attribute>\n        <method>\n            <name>getBankruptcyAge</name>\n            <body language=\"arl\"><![CDATA[\n            return loan.DateUtil.getAge(this.latestBankruptcyDate, loan.DateUtil.now());\n\n            ]]></body>\n        </method>\n    </class>\n    <class>\n        <businessName>loan.Report</businessName>\n        <method>\n            <name>approveLoan</name>\n            <parameter type=\"java.lang.String\"/>\n            <body language=\"arl\"><![CDATA[\n            this.setApproved(true);\nthis.addMessage(message);\n\n            ]]></body>\n        </method>\n        <method>\n            <name>rejectData</name>\n            <parameter type=\"java.lang.String\"/>\n            <body language=\"arl\"><![CDATA[\n            this.setValidData(false);\nthis.setApproved(false);\nthis.addMessage(message);\n\n            ]]></body>\n        </method>\n        <method>\n            <name>rejectLoan</name>\n            <parameter type=\"java.lang.String\"/>\n            <body language=\"arl\"><![CDATA[\n            this.setApproved(false);\nthis.addMessage(message);\n\n            ]]></body>\n        </method>\n    </class>\n</b2x:translation>\n'), 'java', 'model_b2xa', '81640342-7aa9-4c1a-867e-ee6bc21dba20', NULL, NULL, NULL, 1),
(2, 63, 326, 2147483647, 2, 16, STRINGDECODE('<?xml version=\"1.0\" encoding=\"UTF-8\"?><b2x:translation xmlns:b2x=\"http://schemas.ilog.com/JRules/1.3/Translation\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://schemas.ilog.com/JRules/1.3/Translation ilog/rules/schemas/1_3/b2x.xsd\">\n    <id>b8f926e7-3133-4e64-9732-429d94bcea23</id>\n    <lang>ARL</lang>\n</b2x:translation>\n'), 'java', 'miniloan_b2xa', 'b8f926e7-3133-4e64-9732-429d94bcea23', NULL, NULL, NULL, 6);               
CREATE INDEX "PUBLIC"."BOM2XOMMAPPING_PRJBRANCH" ON "PUBLIC"."BOM2XOMMAPPING"("PROJECT", "BASELINE");          
CREATE UNIQUE INDEX "PUBLIC"."BOM2XOMMAPPINGUUIDUNIQUE" ON "PUBLIC"."BOM2XOMMAPPING"("UUID", "BASELINE", "ENDID");             
CREATE INDEX "PUBLIC"."FKBOM2XOMMAPPINGTYPIDX" ON "PUBLIC"."BOM2XOMMAPPING"("TYPE");           
CREATE INDEX "PUBLIC"."FKBOM2XOMMAPPINGSTRTDIDX" ON "PUBLIC"."BOM2XOMMAPPING"("STARTID");      
CREATE INDEX "PUBLIC"."FKBOM2XOMMAPPINGNDDIDX" ON "PUBLIC"."BOM2XOMMAPPING"("ENDID");          
CREATE INDEX "PUBLIC"."FKBOM2XOMMAPPINGBSLNIDX" ON "PUBLIC"."BOM2XOMMAPPING"("BASELINE");      
CREATE INDEX "PUBLIC"."FKBOM2XOMMAPPINGDIDX" ON "PUBLIC"."BOM2XOMMAPPING"("UUID");             
CREATE INDEX "PUBLIC"."FKBOM2XOMMAPPINGRLPCKGIDX" ON "PUBLIC"."BOM2XOMMAPPING"("RULEPACKAGE"); 
CREATE CACHED TABLE "PUBLIC"."BOMPATHENTRY"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "BOM" INTEGER,
    "ILRORDER" INTEGER NOT NULL,
    "URL" CLOB(52428800),
    "PROJECTNAME" VARCHAR(255),
    "CONTAINER" INTEGER NOT NULL
);         
ALTER TABLE "PUBLIC"."BOMPATHENTRY" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_F8" PRIMARY KEY("ID"); 
-- 23 +/- SELECT COUNT(*) FROM PUBLIC.BOMPATHENTRY;            
INSERT INTO "PUBLIC"."BOMPATHENTRY" VALUES
(1, 53, 1, 0, 'platform:/Loan Validation Base/bom/model.bom', NULL, 1),
(2, 52, NULL, 0, 'platform:/Loan Validation Base', 'Loan Validation Base', 4),
(3, 52, NULL, 0, 'platform:/Loan Validation Base', 'Loan Validation Base', 7),
(4, 52, NULL, 0, 'platform:/Loan Validation Base', 'Loan Validation Base', 10),
(5, 52, NULL, 0, 'platform:/Loan Validation Determination', 'Loan Validation Determination', 13),
(6, 52, NULL, 1, 'platform:/Loan Validation Check', 'Loan Validation Check', 13),
(7, 52, NULL, 2, 'platform:/Loan Validation Scoring', 'Loan Validation Scoring', 13),
(8, 53, 2, 0, 'platform:/Miniloan Service/bom/miniloan.bom', NULL, 16),
(9, 53, 2, 0, 'platform:/Miniloan Service/bom/miniloan.bom', NULL, 19),
(10, 53, 1, 0, 'platform:/Loan Validation Base/bom/model.bom', NULL, 20),
(11, 52, NULL, 0, 'platform:/Loan Validation Base', 'Loan Validation Base', 21),
(12, 52, NULL, 0, 'platform:/Loan Validation Base', 'Loan Validation Base', 22),
(13, 52, NULL, 0, 'platform:/Loan Validation Base', 'Loan Validation Base', 23),
(14, 52, NULL, 0, 'platform:/Loan Validation Determination', 'Loan Validation Determination', 24),
(15, 52, NULL, 1, 'platform:/Loan Validation Check', 'Loan Validation Check', 24),
(16, 52, NULL, 2, 'platform:/Loan Validation Scoring', 'Loan Validation Scoring', 24),
(17, 53, 1, 0, 'platform:/Loan Validation Base/bom/model.bom', NULL, 25),
(18, 52, NULL, 0, 'platform:/Loan Validation Base', 'Loan Validation Base', 26),
(19, 52, NULL, 0, 'platform:/Loan Validation Base', 'Loan Validation Base', 27),
(20, 52, NULL, 0, 'platform:/Loan Validation Base', 'Loan Validation Base', 28),
(21, 52, NULL, 0, 'platform:/Loan Validation Determination', 'Loan Validation Determination', 29),
(22, 52, NULL, 1, 'platform:/Loan Validation Check', 'Loan Validation Check', 29),
(23, 52, NULL, 2, 'platform:/Loan Validation Scoring', 'Loan Validation Scoring', 29); 
CREATE INDEX "PUBLIC"."BOMPATHENTRY_CONTAINER" ON "PUBLIC"."BOMPATHENTRY"("CONTAINER");        
CREATE INDEX "PUBLIC"."FKBOMPATHENTRYTYPIDX" ON "PUBLIC"."BOMPATHENTRY"("TYPE");               
CREATE INDEX "PUBLIC"."FKBOMPATHENTRYBMIDX" ON "PUBLIC"."BOMPATHENTRY"("BOM"); 
CREATE CACHED TABLE "PUBLIC"."DECISIONMODEL"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "BODY" BLOB,
    "SOURCE" VARCHAR(3000),
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER
);        
ALTER TABLE "PUBLIC"."DECISIONMODEL" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_9C6" PRIMARY KEY("ID");               
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.DECISIONMODEL;            
CREATE INDEX "PUBLIC"."DECISIONMODEL_PRJBRANCH" ON "PUBLIC"."DECISIONMODEL"("PROJECT", "BASELINE");            
CREATE UNIQUE INDEX "PUBLIC"."DECISIONMODELUUIDUNIQUE" ON "PUBLIC"."DECISIONMODEL"("UUID", "BASELINE", "ENDID");               
CREATE INDEX "PUBLIC"."FKDECISIONMODELTYPIDX" ON "PUBLIC"."DECISIONMODEL"("TYPE");             
CREATE INDEX "PUBLIC"."FKDECISIONMODELSTRTDIDX" ON "PUBLIC"."DECISIONMODEL"("STARTID");        
CREATE INDEX "PUBLIC"."FKDECISIONMODELNDDIDX" ON "PUBLIC"."DECISIONMODEL"("ENDID");            
CREATE INDEX "PUBLIC"."FKDECISIONMODELBSLNIDX" ON "PUBLIC"."DECISIONMODEL"("BASELINE");        
CREATE INDEX "PUBLIC"."FKDECISIONMODELDIDX" ON "PUBLIC"."DECISIONMODEL"("UUID");               
CREATE INDEX "PUBLIC"."FKDECISIONMODELRLPCKGIDX" ON "PUBLIC"."DECISIONMODEL"("RULEPACKAGE");   
CREATE CACHED TABLE "PUBLIC"."DECISIONMODELSIBLING"(
    "ID" INTEGER NOT NULL
);              
ALTER TABLE "PUBLIC"."DECISIONMODELSIBLING" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_24" PRIMARY KEY("ID");         
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.DECISIONMODELSIBLING;     
CREATE CACHED TABLE "PUBLIC"."DEPLOYMENT"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER,
    "MANAGINGXOM" BOOLEAN NOT NULL,
    "PRODUCTION" BOOLEAN NOT NULL,
    "RULEAPPNAME" VARCHAR(255),
    "RULEAPPVERSION" VARCHAR(255) NOT NULL,
    "SNAPSHOTBASENAME" VARCHAR(255),
    "SNAPSHOTCREATION" VARCHAR(30)
);            
ALTER TABLE "PUBLIC"."DEPLOYMENT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_908" PRIMARY KEY("ID");  
-- 34 +/- SELECT COUNT(*) FROM PUBLIC.DEPLOYMENT;              
INSERT INTO "PUBLIC"."DEPLOYMENT" VALUES
(1, 111, 93, 226, 1, 13, 'test deployment', '1b0002ea-1a08-4d78-a322-b9de0b255169', NULL, NULL, NULL, 5, TRUE, FALSE, 'test_deployment', '1.0', NULL, 'ALWAYS'),
(2, 111, 94, 272, 2, 13, 'production deployment', 'e97915be-0315-444e-9102-58cfa5f7bc03', NULL, NULL, NULL, 5, TRUE, TRUE, 'production_deployment', '1.0', NULL, 'ALWAYS'),
(3, 111, 226, 227, 1, 13, 'test deployment', '1b0002ea-1a08-4d78-a322-b9de0b255169', NULL, NULL, NULL, 5, TRUE, FALSE, 'test_deployment', '1.0', NULL, 'ALWAYS'),
(4, 111, 227, 228, 1, 13, 'test deployment', '1b0002ea-1a08-4d78-a322-b9de0b255169', NULL, NULL, NULL, 5, TRUE, FALSE, 'test_deployment', '1.0', NULL, 'ALWAYS'),
(5, 111, 228, 229, 1, 13, 'test deployment', '1b0002ea-1a08-4d78-a322-b9de0b255169', NULL, NULL, NULL, 5, TRUE, FALSE, 'test_deployment', '1.0', NULL, 'ALWAYS'),
(6, 111, 229, 230, 1, 13, 'test deployment', '1b0002ea-1a08-4d78-a322-b9de0b255169', NULL, NULL, NULL, 5, TRUE, FALSE, 'test_deployment', '1.0', NULL, 'ALWAYS'),
(7, 111, 230, 231, 1, 13, 'test deployment', '1b0002ea-1a08-4d78-a322-b9de0b255169', NULL, NULL, NULL, 5, TRUE, FALSE, 'test_deployment', '1.0', NULL, 'ALWAYS'),
(8, 111, 231, 232, 1, 13, 'test deployment', '1b0002ea-1a08-4d78-a322-b9de0b255169', NULL, NULL, NULL, 5, TRUE, FALSE, 'test_deployment', '1.0', NULL, 'ALWAYS'),
(9, 111, 232, 233, 1, 13, 'test deployment', '1b0002ea-1a08-4d78-a322-b9de0b255169', NULL, NULL, NULL, 5, TRUE, FALSE, 'test_deployment', '1.0', NULL, 'ALWAYS'),
(10, 111, 233, 266, 1, 13, 'test deployment', '1b0002ea-1a08-4d78-a322-b9de0b255169', NULL, NULL, NULL, 5, TRUE, FALSE, 'test_deployment', '1.0', NULL, 'ALWAYS'),
(11, 111, 266, 267, 1, 13, 'test deployment', '1b0002ea-1a08-4d78-a322-b9de0b255169', NULL, NULL, NULL, 5, TRUE, FALSE, 'test_deployment', '1.0', NULL, 'ALWAYS'),
(12, 111, 267, 268, 1, 13, 'test deployment', '1b0002ea-1a08-4d78-a322-b9de0b255169', NULL, NULL, NULL, 5, TRUE, FALSE, 'test_deployment', '1.0', NULL, 'ALWAYS'),
(13, 111, 268, 269, 1, 13, 'test deployment', '1b0002ea-1a08-4d78-a322-b9de0b255169', NULL, NULL, NULL, 5, TRUE, FALSE, 'test_deployment', '1.0', NULL, 'ALWAYS'),
(14, 111, 269, 270, 1, 13, 'test deployment', '1b0002ea-1a08-4d78-a322-b9de0b255169', NULL, NULL, NULL, 5, TRUE, FALSE, 'test_deployment', '1.0', NULL, 'ALWAYS'),
(15, 111, 270, 271, 1, 13, 'test deployment', '1b0002ea-1a08-4d78-a322-b9de0b255169', NULL, NULL, NULL, 5, TRUE, FALSE, 'test_deployment', '1.0', NULL, 'ALWAYS'),
(16, 111, 271, 2147483647, 1, 13, 'test deployment', '1b0002ea-1a08-4d78-a322-b9de0b255169', NULL, NULL, NULL, 5, TRUE, FALSE, 'test_deployment', '1.0', NULL, 'ALWAYS'),
(17, 111, 272, 273, 2, 13, 'production deployment', 'e97915be-0315-444e-9102-58cfa5f7bc03', NULL, NULL, NULL, 5, TRUE, TRUE, 'production_deployment', '1.0', NULL, 'ALWAYS'),
(18, 111, 273, 274, 2, 13, 'production deployment', 'e97915be-0315-444e-9102-58cfa5f7bc03', NULL, NULL, NULL, 5, TRUE, TRUE, 'production_deployment', '1.0', NULL, 'ALWAYS'),
(19, 111, 274, 275, 2, 13, 'production deployment', 'e97915be-0315-444e-9102-58cfa5f7bc03', NULL, NULL, NULL, 5, TRUE, TRUE, 'production_deployment', '1.0', NULL, 'ALWAYS'),
(20, 111, 275, 276, 2, 13, 'production deployment', 'e97915be-0315-444e-9102-58cfa5f7bc03', NULL, NULL, NULL, 5, TRUE, TRUE, 'production_deployment', '1.0', NULL, 'ALWAYS'),
(21, 111, 276, 277, 2, 13, 'production deployment', 'e97915be-0315-444e-9102-58cfa5f7bc03', NULL, NULL, NULL, 5, TRUE, TRUE, 'production_deployment', '1.0', NULL, 'ALWAYS'),
(22, 111, 277, 278, 2, 13, 'production deployment', 'e97915be-0315-444e-9102-58cfa5f7bc03', NULL, NULL, NULL, 5, TRUE, TRUE, 'production_deployment', '1.0', NULL, 'ALWAYS'),
(23, 111, 278, 279, 2, 13, 'production deployment', 'e97915be-0315-444e-9102-58cfa5f7bc03', NULL, NULL, NULL, 5, TRUE, TRUE, 'production_deployment', '1.0', NULL, 'ALWAYS'),
(24, 111, 279, 2147483647, 2, 13, 'production deployment', 'e97915be-0315-444e-9102-58cfa5f7bc03', NULL, NULL, NULL, 5, TRUE, TRUE, 'production_deployment', '1.0', NULL, 'ALWAYS'),
(25, 111, 333, 351, 25, 16, 'Miniloan', '44b9b9ad-f66d-408e-8ef0-61c8fe12f445', NULL, NULL, NULL, 6, TRUE, FALSE, 'mydeployment', '1.0', NULL, 'ALWAYS');               
INSERT INTO "PUBLIC"."DEPLOYMENT" VALUES
(26, 111, 351, 352, 25, 16, 'Miniloan', '44b9b9ad-f66d-408e-8ef0-61c8fe12f445', NULL, NULL, NULL, 6, TRUE, FALSE, 'mydeployment', '1.0', NULL, 'ALWAYS'),
(27, 111, 352, 353, 25, 16, 'Miniloan', '44b9b9ad-f66d-408e-8ef0-61c8fe12f445', NULL, NULL, NULL, 6, TRUE, FALSE, 'mydeployment', '1.0', NULL, 'ALWAYS'),
(28, 111, 353, 354, 25, 16, 'Miniloan', '44b9b9ad-f66d-408e-8ef0-61c8fe12f445', NULL, NULL, NULL, 6, TRUE, FALSE, 'mydeployment', '1.0', NULL, 'ALWAYS'),
(29, 111, 354, 355, 25, 16, 'Miniloan', '44b9b9ad-f66d-408e-8ef0-61c8fe12f445', NULL, NULL, NULL, 6, TRUE, FALSE, 'mydeployment', '1.0', NULL, 'ALWAYS'),
(30, 111, 355, 356, 25, 16, 'Miniloan', '44b9b9ad-f66d-408e-8ef0-61c8fe12f445', NULL, NULL, NULL, 6, TRUE, FALSE, 'mydeployment', '1.0', NULL, 'ALWAYS'),
(31, 111, 356, 357, 25, 16, 'Miniloan', '44b9b9ad-f66d-408e-8ef0-61c8fe12f445', NULL, NULL, NULL, 6, TRUE, FALSE, 'mydeployment', '1.0', NULL, 'ALWAYS'),
(32, 111, 357, 358, 25, 16, 'Miniloan', '44b9b9ad-f66d-408e-8ef0-61c8fe12f445', NULL, NULL, NULL, 6, TRUE, FALSE, 'mydeployment', '1.0', NULL, 'ALWAYS'),
(33, 111, 358, 359, 25, 16, 'Miniloan', '44b9b9ad-f66d-408e-8ef0-61c8fe12f445', NULL, NULL, NULL, 6, TRUE, FALSE, 'mydeployment', '1.0', NULL, 'ALWAYS'),
(34, 111, 359, 2147483647, 25, 16, 'Miniloan', '44b9b9ad-f66d-408e-8ef0-61c8fe12f445', NULL, NULL, NULL, 6, TRUE, FALSE, 'mydeployment', '1.0', NULL, 'ALWAYS');      
CREATE INDEX "PUBLIC"."DPLMNT_PRJBRANCH" ON "PUBLIC"."DEPLOYMENT"("PROJECT", "BASELINE");      
CREATE UNIQUE INDEX "PUBLIC"."DPLMNTUUIDUNIQUE" ON "PUBLIC"."DEPLOYMENT"("UUID", "BASELINE", "ENDID");         
CREATE INDEX "PUBLIC"."FKDPLMNTTYPIDX" ON "PUBLIC"."DEPLOYMENT"("TYPE");       
CREATE INDEX "PUBLIC"."FKDPLMNTSTRTDIDX" ON "PUBLIC"."DEPLOYMENT"("STARTID");  
CREATE INDEX "PUBLIC"."FKDPLMNTNDDIDX" ON "PUBLIC"."DEPLOYMENT"("ENDID");      
CREATE INDEX "PUBLIC"."FKDPLMNTBSLNIDX" ON "PUBLIC"."DEPLOYMENT"("BASELINE");  
CREATE INDEX "PUBLIC"."FKDPLMNTDIDX" ON "PUBLIC"."DEPLOYMENT"("UUID");         
CREATE INDEX "PUBLIC"."FKDPLMNTRLPCKGIDX" ON "PUBLIC"."DEPLOYMENT"("RULEPACKAGE");             
CREATE CACHED TABLE "PUBLIC"."DEPGROUP"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "GRP" VARCHAR(100) NOT NULL,
    "CONTAINER" INTEGER NOT NULL
);        
ALTER TABLE "PUBLIC"."DEPGROUP" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_66" PRIMARY KEY("ID");     
-- 6 +/- SELECT COUNT(*) FROM PUBLIC.DEPGROUP; 
INSERT INTO "PUBLIC"."DEPGROUP" VALUES
(1, 112, 93, 2147483647, 1, 13, 'rtsAdministrator', 1),
(2, 112, 93, 2147483647, 2, 13, 'rtsConfigManager', 1),
(3, 112, 94, 2147483647, 3, 13, 'rtsConfigManager', 2),
(4, 112, 94, 2147483647, 4, 13, 'rtsAdministrator', 2),
(5, 112, 333, 2147483647, 5, 16, 'rtsAdministrator', 25),
(6, 112, 333, 2147483647, 6, 16, 'rtsConfigManager', 25);     
CREATE INDEX "PUBLIC"."DEPGROUP_CONTAINER" ON "PUBLIC"."DEPGROUP"("CONTAINER");
CREATE INDEX "PUBLIC"."FKDEPGROUPTYPIDX" ON "PUBLIC"."DEPGROUP"("TYPE");       
CREATE INDEX "PUBLIC"."FKDEPGROUPSTRTDIDX" ON "PUBLIC"."DEPGROUP"("STARTID");  
CREATE INDEX "PUBLIC"."FKDEPGROUPNDDIDX" ON "PUBLIC"."DEPGROUP"("ENDID");      
CREATE INDEX "PUBLIC"."FKDEPGROUPBSLNIDX" ON "PUBLIC"."DEPGROUP"("BASELINE");  
CREATE CACHED TABLE "PUBLIC"."DEPPROPERTYTAG"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "VALUE" CLOB(52428800),
    "CONTAINER" INTEGER NOT NULL
);     
ALTER TABLE "PUBLIC"."DEPPROPERTYTAG" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_80" PRIMARY KEY("ID");               
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.DEPPROPERTYTAG;           
CREATE INDEX "PUBLIC"."DEPPROPTAG_CONTAINER" ON "PUBLIC"."DEPPROPERTYTAG"("CONTAINER");        
CREATE INDEX "PUBLIC"."FKDEPPROPTAGTYPIDX" ON "PUBLIC"."DEPPROPERTYTAG"("TYPE");               
CREATE INDEX "PUBLIC"."FKDEPPROPTAGSTRTDIDX" ON "PUBLIC"."DEPPROPERTYTAG"("STARTID");          
CREATE INDEX "PUBLIC"."FKDEPPROPTAGNDDIDX" ON "PUBLIC"."DEPPROPERTYTAG"("ENDID");              
CREATE INDEX "PUBLIC"."FKDEPPROPTAGBSLNIDX" ON "PUBLIC"."DEPPROPERTYTAG"("BASELINE");          
CREATE CACHED TABLE "PUBLIC"."DEPTARGET"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "ACTIVE" BOOLEAN NOT NULL,
    "NAME" VARCHAR(100),
    "CONTAINER" INTEGER NOT NULL
);
ALTER TABLE "PUBLIC"."DEPTARGET" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_7C" PRIMARY KEY("ID");    
-- 3 +/- SELECT COUNT(*) FROM PUBLIC.DEPTARGET;
INSERT INTO "PUBLIC"."DEPTARGET" VALUES
(1, 116, 93, 2147483647, 1, 13, FALSE, 'Decision Service Execution', 1),
(2, 116, 94, 2147483647, 2, 13, FALSE, 'Decision Service Execution', 2),
(3, 116, 333, 2147483647, 3, 16, FALSE, 'Decision Service Execution', 25);           
CREATE INDEX "PUBLIC"."DEPTARGET_CONTAINER" ON "PUBLIC"."DEPTARGET"("CONTAINER");              
CREATE INDEX "PUBLIC"."FKDEPTARGETTYPIDX" ON "PUBLIC"."DEPTARGET"("TYPE");     
CREATE INDEX "PUBLIC"."FKDEPTARGETSTRTDIDX" ON "PUBLIC"."DEPTARGET"("STARTID");
CREATE INDEX "PUBLIC"."FKDEPTARGETNDDIDX" ON "PUBLIC"."DEPTARGET"("ENDID");    
CREATE INDEX "PUBLIC"."FKDEPTARGETBSLNIDX" ON "PUBLIC"."DEPTARGET"("BASELINE");
CREATE CACHED TABLE "PUBLIC"."DEPVERSIONPOLICY"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "DEFAULTPOLICY" BOOLEAN,
    "DESCRIPTION" VARCHAR(255),
    "LABEL" VARCHAR(100),
    "RECURRENT" BOOLEAN,
    "RULEAPP" VARCHAR(30),
    "RULESET" VARCHAR(30),
    "CONTAINER" INTEGER NOT NULL
);           
ALTER TABLE "PUBLIC"."DEPVERSIONPOLICY" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_D1" PRIMARY KEY("ID");             
-- 9 +/- SELECT COUNT(*) FROM PUBLIC.DEPVERSIONPOLICY;         
INSERT INTO "PUBLIC"."DEPVERSIONPOLICY" VALUES
(1, 117, 93, 2147483647, 1, 13, FALSE, 'Allows you to enter your own version numbers. Used for hot fixes or updates to an earlier release.', 'The user can define the version numbers', TRUE, 'NO_CHANGE', 'MANUAL', 1),
(2, 117, 93, 2147483647, 2, 13, FALSE, 'Uses the numbers provided in the deployment configuration. Replaces the latest version of each ruleset with this release. Used for hot fixes or development.', 'Use the base version numbers', TRUE, 'NO_CHANGE', 'NO_CHANGE', 1),
(3, 117, 93, 2147483647, 3, 13, TRUE, 'Updates the minor version for each ruleset. Makes the new version available but retains previous versions.', 'Increment minor version numbers', TRUE, 'NO_CHANGE', 'INCREMENT_MINOR', 1),
(4, 117, 94, 2147483647, 4, 13, FALSE, 'Allows you to enter your own version numbers. Used for hot fixes or updates to an earlier release.', 'The user can define the version numbers', TRUE, 'NO_CHANGE', 'MANUAL', 2),
(5, 117, 94, 2147483647, 5, 13, FALSE, 'Uses the numbers provided in the deployment configuration. Replaces the latest version of each ruleset with this release. Used for hot fixes or development.', 'Use the base version numbers', TRUE, 'NO_CHANGE', 'NO_CHANGE', 2),
(6, 117, 94, 2147483647, 6, 13, TRUE, 'Updates the minor version for each ruleset. Makes the new version available but retains previous versions.', 'Increment minor version numbers', TRUE, 'NO_CHANGE', 'INCREMENT_MINOR', 2),
(7, 117, 333, 2147483647, 7, 16, TRUE, 'Updates the minor version for each ruleset. Makes the new version available but retains previous versions.', 'Increment minor version numbers', TRUE, 'NO_CHANGE', 'INCREMENT_MINOR', 25),
(8, 117, 333, 2147483647, 8, 16, FALSE, 'Uses the numbers provided in the deployment configuration. Replaces the latest version of each ruleset with this release. Used for hot fixes or development.', 'Use the base version numbers', TRUE, 'NO_CHANGE', 'NO_CHANGE', 25),
(9, 117, 333, 2147483647, 9, 16, FALSE, 'Allows you to enter your own version numbers. Used for hot fixes or updates to an earlier release.', 'The user can define the version numbers', TRUE, 'NO_CHANGE', 'MANUAL', 25);            
CREATE INDEX "PUBLIC"."DEPVERSPOLICY_CONTAINER" ON "PUBLIC"."DEPVERSIONPOLICY"("CONTAINER");   
CREATE INDEX "PUBLIC"."FKDEPVERSPOLICYTYPIDX" ON "PUBLIC"."DEPVERSIONPOLICY"("TYPE");          
CREATE INDEX "PUBLIC"."FKDEPVERSPOLICYSTRTDIDX" ON "PUBLIC"."DEPVERSIONPOLICY"("STARTID");     
CREATE INDEX "PUBLIC"."FKDEPVERSPOLICYNDDIDX" ON "PUBLIC"."DEPVERSIONPOLICY"("ENDID");         
CREATE INDEX "PUBLIC"."FKDEPVERSPOLICYBSLNIDX" ON "PUBLIC"."DEPVERSIONPOLICY"("BASELINE");     
CREATE CACHED TABLE "PUBLIC"."DSDEPLOYMENTREPORT"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CREATEDBY" VARCHAR(100),
    "CREATEDON" TIMESTAMP,
    "LASTCHANGEDBY" VARCHAR(100),
    "LASTCHANGEDON" TIMESTAMP,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER,
    "DCONFIGID" VARCHAR(255),
    "DCONFIGNAME" VARCHAR(255),
    "DEPLOYMENTSNAPSHOT" INTEGER,
    "ENDDEPLOYMENT" TIMESTAMP,
    "ORIGINALBASELINE" INTEGER NOT NULL,
    "SERVERS" CLOB(52428800),
    "STATUS" VARCHAR(30)
);        
ALTER TABLE "PUBLIC"."DSDEPLOYMENTREPORT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_AC" PRIMARY KEY("ID");           
-- 3 +/- SELECT COUNT(*) FROM PUBLIC.DSDEPLOYMENTREPORT;       
INSERT INTO "PUBLIC"."DSDEPLOYMENTREPORT" VALUES
(1, 119, 'odmAdmin', TIMESTAMP '2023-05-04 14:35:31', 'odmAdmin', TIMESTAMP '2023-05-04 14:35:48', 'Report  2023-05-04_15-35-31-891', 'ce759625-8110-4715-92c2-973863fdad33', NULL, STRINGDECODE('The resource ''miniloan-xom.zip'' was successfully deployed with version ''1.0'' on Decision Service Execution (http://localhost:9060/res).\nNo previous library matching this deployment was found on Decision Service Execution (http://localhost:9060/res): a new library will be created.\nThe library ''mydeployment_library'' was successfully deployed with version ''1.0'' on Decision Service Execution (http://localhost:9060/res).\nThe following XOM resources were successfully deployed to Decision Service Execution (http://localhost:9060/res): [reslib://mydeployment_library/1.0]. '), NULL, 6, 'dsm.Deployment:25:34', 'Miniloan', 19, TIMESTAMP '2023-05-04 14:35:48.064', 16, 'Decision Service Execution', 'COMPLETED'),
(2, 119, 'odmAdmin', TIMESTAMP '2023-05-04 14:36:05', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:14', 'Report  2023-05-04_15-36-05-831', 'c835a179-6a90-42a2-9339-eb340247d932', NULL, STRINGDECODE('The resource ''loan-validation-xom.zip'' was successfully deployed with version ''1.0'' on Decision Service Execution (http://localhost:9060/res).\nNo previous library matching this deployment was found on Decision Service Execution (http://localhost:9060/res): a new library will be created.\nThe library ''production_deployment_library'' was successfully deployed with version ''1.0'' on Decision Service Execution (http://localhost:9060/res).\nThe following XOM resources were successfully deployed to Decision Service Execution (http://localhost:9060/res): [reslib://production_deployment_library/1.0]. '), NULL, 5, 'dsm.Deployment:2:24', 'production deployment', 24, TIMESTAMP '2023-05-04 14:36:14.88', 13, 'Decision Service Execution', 'COMPLETED'),
(3, 119, 'odmAdmin', TIMESTAMP '2023-05-04 14:36:22', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:35', 'Report  2023-05-04_15-36-22-554', 'b33ecf66-d7a1-4086-b47c-37b0011735f9', NULL, STRINGDECODE('The resource ''loan-validation-xom.zip'' is already deployed with version ''1.0'' on Decision Service Execution (http://localhost:9060/res). Skipping it.\nNo previous library matching this deployment was found on Decision Service Execution (http://localhost:9060/res): a new library will be created.\nThe library ''test_deployment_library'' was successfully deployed with version ''1.0'' on Decision Service Execution (http://localhost:9060/res).\nThe following XOM resources were successfully deployed to Decision Service Execution (http://localhost:9060/res): [reslib://test_deployment_library/1.0]. '), NULL, 5, 'dsm.Deployment:1:16', 'test deployment', 29, TIMESTAMP '2023-05-04 14:36:35.043', 13, 'Decision Service Execution', 'COMPLETED');           
CREATE UNIQUE INDEX "PUBLIC"."DSDEPLOYMENTREPORTUUIDUNIQUE" ON "PUBLIC"."DSDEPLOYMENTREPORT"("UUID");          
CREATE INDEX "PUBLIC"."FKDSDEPLOYMENTREPORTTYPIDX" ON "PUBLIC"."DSDEPLOYMENTREPORT"("TYPE");   
CREATE INDEX "PUBLIC"."FKDSDEPLOYMENTREPORTRLPCKGIDX" ON "PUBLIC"."DSDEPLOYMENTREPORT"("RULEPACKAGE");         
CREATE CACHED TABLE "PUBLIC"."DEPLOYMENTERROR"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CONTAINER" INTEGER NOT NULL,
    "ARTIFACTINERROR" VARCHAR(128),
    "MESSAGE" BLOB
);            
ALTER TABLE "PUBLIC"."DEPLOYMENTERROR" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_BA9" PRIMARY KEY("ID");             
-- 3 +/- SELECT COUNT(*) FROM PUBLIC.DEPLOYMENTERROR;          
INSERT INTO "PUBLIC"."DEPLOYMENTERROR" VALUES
(1, 123, 1, NULL, X'21494e464f215468652052756c6541707020776173207375636365737366756c6c79206465706c6f79656420746f204465636973696f6e205365727669636520457865637574696f6e2028687474703a2f2f6c6f63616c686f73743a393036302f726573292e'),
(2, 123, 2, NULL, X'21494e464f215468652052756c6541707020776173207375636365737366756c6c79206465706c6f79656420746f204465636973696f6e205365727669636520457865637574696f6e2028687474703a2f2f6c6f63616c686f73743a393036302f726573292e'),
(3, 123, 3, NULL, X'21494e464f215468652052756c6541707020776173207375636365737366756c6c79206465706c6f79656420746f204465636973696f6e205365727669636520457865637574696f6e2028687474703a2f2f6c6f63616c686f73743a393036302f726573292e');      
CREATE INDEX "PUBLIC"."DEPLOYMENTERROR_CONTAINER" ON "PUBLIC"."DEPLOYMENTERROR"("CONTAINER");  
CREATE INDEX "PUBLIC"."FKDEPLOYMENTERRORTYPIDX" ON "PUBLIC"."DEPLOYMENTERROR"("TYPE");         
CREATE CACHED TABLE "PUBLIC"."EVENT"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "BODY" CLOB(52428800),
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "VALUE" CLOB(52428800),
    "VALUETYPE" VARCHAR(30),
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER
);         
ALTER TABLE "PUBLIC"."EVENT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_3F" PRIMARY KEY("ID");        
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.EVENT;    
CREATE INDEX "PUBLIC"."EVENT_PRJBRANCH" ON "PUBLIC"."EVENT"("PROJECT", "BASELINE");            
CREATE UNIQUE INDEX "PUBLIC"."EVENTUUIDUNIQUE" ON "PUBLIC"."EVENT"("UUID", "BASELINE", "ENDID");               
CREATE INDEX "PUBLIC"."FKEVENTTYPIDX" ON "PUBLIC"."EVENT"("TYPE");             
CREATE INDEX "PUBLIC"."FKEVENTSTRTDIDX" ON "PUBLIC"."EVENT"("STARTID");        
CREATE INDEX "PUBLIC"."FKEVENTNDDIDX" ON "PUBLIC"."EVENT"("ENDID");            
CREATE INDEX "PUBLIC"."FKEVENTBSLNIDX" ON "PUBLIC"."EVENT"("BASELINE");        
CREATE INDEX "PUBLIC"."FKEVENTDIDX" ON "PUBLIC"."EVENT"("UUID");               
CREATE INDEX "PUBLIC"."FKEVENTRLPCKGIDX" ON "PUBLIC"."EVENT"("RULEPACKAGE");   
CREATE CACHED TABLE "PUBLIC"."EVENTSIBLING"(
    "ID" INTEGER NOT NULL,
    "EFFECTIVEDATE" TIMESTAMP,
    "EXPIRATIONDATE" TIMESTAMP,
    "STATUS" VARCHAR(30) NOT NULL
);    
ALTER TABLE "PUBLIC"."EVENTSIBLING" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_D9" PRIMARY KEY("ID"); 
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.EVENTSIBLING;             
CREATE CACHED TABLE "PUBLIC"."EXTRACTOR"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "QUERY" INTEGER,
    "VALIDATOR" CLOB(52428800),
    "CONTAINER" INTEGER NOT NULL
);   
ALTER TABLE "PUBLIC"."EXTRACTOR" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_97" PRIMARY KEY("ID");    
-- 14 +/- SELECT COUNT(*) FROM PUBLIC.EXTRACTOR;               
INSERT INTO "PUBLIC"."EXTRACTOR" VALUES
(1, 42, 'unchecked determination_extractor', NULL, 'Default Validator', 7),
(2, 42, 'computation-test_extractor', NULL, 'Default Validator', 10),
(3, 42, 'loan validation with score and grade_extractor', NULL, 'Default Validator', 13),
(4, 42, 'validated rules operation_extractor', 26, 'Default Validator', 13),
(5, 42, 'Miniloan ServiceOperation_extractor', NULL, 'Default Validator', 16),
(6, 42, 'Miniloan ServiceOperation_extractor', NULL, 'Default Validator', 19),
(7, 42, 'unchecked determination_extractor', NULL, 'Default Validator', 22),
(8, 42, 'computation-test_extractor', NULL, 'Default Validator', 23),
(9, 42, 'loan validation with score and grade_extractor', NULL, 'Default Validator', 24),
(10, 42, 'validated rules operation_extractor', 26, 'Default Validator', 24),
(11, 42, 'unchecked determination_extractor', NULL, 'Default Validator', 27),
(12, 42, 'computation-test_extractor', NULL, 'Default Validator', 28),
(13, 42, 'loan validation with score and grade_extractor', NULL, 'Default Validator', 29),
(14, 42, 'validated rules operation_extractor', 26, 'Default Validator', 29);        
CREATE INDEX "PUBLIC"."EXTRACTOR_CONTAINER" ON "PUBLIC"."EXTRACTOR"("CONTAINER");              
CREATE UNIQUE INDEX "PUBLIC"."EXTRACTORNAMEUNIQUE" ON "PUBLIC"."EXTRACTOR"("NAME", "CONTAINER");               
CREATE INDEX "PUBLIC"."FKEXTRACTORTYPIDX" ON "PUBLIC"."EXTRACTOR"("TYPE");     
CREATE INDEX "PUBLIC"."FKEXTRACTORQRYIDX" ON "PUBLIC"."EXTRACTOR"("QUERY");    
CREATE CACHED TABLE "PUBLIC"."OPERATIONLATESTDEPLOYEDVERSION"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CONTAINER" INTEGER NOT NULL,
    "OPERATIONNAME" VARCHAR(255) NOT NULL,
    "VERSION" VARCHAR(30) NOT NULL
);      
ALTER TABLE "PUBLIC"."OPERATIONLATESTDEPLOYEDVERSION" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_679" PRIMARY KEY("ID");              
-- 4 +/- SELECT COUNT(*) FROM PUBLIC.OPERATIONLATESTDEPLOYEDVERSION;           
INSERT INTO "PUBLIC"."OPERATIONLATESTDEPLOYEDVERSION" VALUES
(1, 121, 1, 'Miniloan ServiceOperation', 'N/A'),
(2, 121, 2, 'loan validation production', 'N/A'),
(3, 121, 3, 'loan validation with score and grade', 'N/A'),
(4, 121, 3, 'loan validation production', 'N/A');  
CREATE INDEX "PUBLIC"."OPLATESTV_CONTAINER" ON "PUBLIC"."OPERATIONLATESTDEPLOYEDVERSION"("CONTAINER");         
CREATE INDEX "PUBLIC"."FKOPLATESTVTYPIDX" ON "PUBLIC"."OPERATIONLATESTDEPLOYEDVERSION"("TYPE");
CREATE CACHED TABLE "PUBLIC"."OPERATIONNEWDEPLOYEDVERSION"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CONTAINER" INTEGER NOT NULL,
    "OPERATIONNAME" VARCHAR(255) NOT NULL,
    "VERSION" VARCHAR(30) NOT NULL
);         
ALTER TABLE "PUBLIC"."OPERATIONNEWDEPLOYEDVERSION" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_DE" PRIMARY KEY("ID");  
-- 4 +/- SELECT COUNT(*) FROM PUBLIC.OPERATIONNEWDEPLOYEDVERSION;              
INSERT INTO "PUBLIC"."OPERATIONNEWDEPLOYEDVERSION" VALUES
(1, 122, 1, 'Miniloan ServiceOperation', '1.0'),
(2, 122, 2, 'loan validation production', '1.0'),
(3, 122, 3, 'loan validation with score and grade', '1.0'),
(4, 122, 3, 'loan validation production', '1.0');     
CREATE INDEX "PUBLIC"."OPNEWV_CONTAINER" ON "PUBLIC"."OPERATIONNEWDEPLOYEDVERSION"("CONTAINER");               
CREATE INDEX "PUBLIC"."FKOPNEWVTYPIDX" ON "PUBLIC"."OPERATIONNEWDEPLOYEDVERSION"("TYPE");      
CREATE CACHED TABLE "PUBLIC"."PRJRESOURCE"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER,
    "BODY" BLOB,
    "EXTENSION" VARCHAR(255)
);        
ALTER TABLE "PUBLIC"."PRJRESOURCE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_BD" PRIMARY KEY("ID");  
-- 3 +/- SELECT COUNT(*) FROM PUBLIC.PRJRESOURCE;              
INSERT INTO SYSTEM_LOB_STREAM VALUES(1, 0, NULL, '504b03041400000808000f74774d4f34fe60000300005d0600001e0000006c6f616e2f426f72726f7765722442616e6b7275707463792e636c6173738d535d4f1341143d03fda04d412c05f91610b12dc2aae02784040a24358d26808df16d5a2665713b4b76b708fe261f249198f8e08b6fbefa17fc151ad13bd32d956d313e6c67e6ce3de79e7bcff4ebd9a7cf0016b11c4507c3a0657369acd98e63bf11cef41a97af9dda81573e8e22c4d0bbcf0fb9617159319e97f645d98b22c290d251d336b6856372cb7ccb4b96a064571f8bc2714d5bbec8af33b0a70cdd395bba1e975e915b35119e9ddcf8fee5f4db2b86d02ef714aca0e96a9e6919eb14596218daaa49cfac8aa2e99a44bd2aa5ed718f485d86199d7e641c552da364ca5d839fdf1a2fabd68625aa427a44122deff1034f38a422cf107104776dc9902c347bdaf61c53562837b26c4ad35b61e84c678aa42c67ef8a383a3198400afd0c570aa614cf6ad5927076eacd260b76997ae5d4319dfd60c8db3349e270e1b2a152a99974b0df7caba24c310686eb0924d0ad769309f4e2aadadd4820893eeace15deba9e5f5f0ba16a214ef7b9c60042e9bc8ac528b6e58fa13fddae2af1561abcc974a6d59958a549916a245c9c65bcf257659a270d7f2c7df94432c538b53548b86dbbe694c5a6a926d9dd489d57151866ffedfa6ab92c5cd776768e0f94caf0a17a6a0c99ff4135309bf98d023dd9445e4ae1e42ceebac28de20969b9a09d8436d56392b477d2174608c388a28bf631fa7b75204e1fb947e71e3a4768bda2e3e4634b8c1c0dc46214a59747a7013a2dd0ca680d673fe2da89860cd1af2a01fca0d23fa938a89c4ec2084669258330e613589419a235a508b2b3a718cf8e9e62223b778aa926df0061815f947946027ea387e8fa18d3dcd93adee756bb7a736aa75aead03bd5881ac7346efa9557e846dd4574d580761642988535ff403deb9c3fe2f3d31f06b75ab846487c90ab8bb8629770d587ce9046a69daea9205782b8ba2fe1aa9bc56822b33e97716ecf078cbf3fa7525e82f5b6b5e636e6da80a782e0545bf0bc0605c113ef02e0c15670af32e98e0f561675f8afeaeec94530bdaa611d01f9794fef16f403559e2cd2775fe0011ee2911e9912f1184b88fd01504b03041400000808000f74774db9b8c1d435050000050b0000170000006c6f616e2f426f72726f7765722453534e2e636c6173738d54db721b45103da3ab25d68eec384e1c5b60c009f2cab2c8fde2c489af8962d94e22c7b940c06b792c6fb2da15bbab1078ca07f001bce625f010aa4815c829a8e203f800de79e027a882a2677625cbf2864aa95633d3d3e774cfe99ef9fddf5f7e03701a6e1c21865ec3d2ccfc8c65dbd697dc1e2d9596e38830a41e694fb4bca19995fccac6235e26e71843bfb4ea56bec46d5d33f4afb50d8393b323976bdc7674cbbc539863603718ba672dd37135d35dd38c3a8ffef97de89b3fb2cffe62486a36d796ebd50d6e33f4157743955c5b372b930c83b7eba6ab57f99aeee81462da342d577389dc61382e014ff34fab467e433737f35a6b377faf6acc1bbcca4d97481215dbaad766ad4d4a51f1526c068d5dd24ddd9d620867c6d61822c22989300614f4e160178e30200186a30a14748bd9b08294377b57412fba190e1475937b84ab9e0e7d45ab4c32681489d6be31e26eeb94f5c1e23ea129c5ae9a663b9ce60c8732fb85185b4be23832717cb4a722deae8231a80c7192803f5dd9a24899c2584100c615e430410238f50d47fa320c640a85b1fd1184fbc782e9044354b848825382e0b4c8e94d98b30acee13c096970b3e26e4b21097a1197e2a073f5ec829634775bc16511205cd54d82987e11125bbaedb8739a437056a0b67078d932373d4377c9d5ca8f97b49a2f63b7c3dde9b6b6a182bad776eb7b8096a5b61227a950d7147c8851860b01cabe8d457446a2c2dd39bda2bb54c2eecade14fa3301e2506695bd9955f666e6f12cd40d7f1dc74d86c39d3c3375ddd8f48e715bc10d2c0ad15715dc0125157f222e9428f9f1f6a379177532b0622bb8275a7bb40b0f48ec9c307caae0213ea37a68b51a37371972411db8cfe4673629525b575014a9316c285812b3156c2ae058a4d6762d0f20b6a9599785712013700d4497d3163540c9aadb65bea0cb82377d2644060cd9ffbff6d3e532771ccb5efdaac6a908512911c3d8dba09a9885c27c91de2ea5609adc9e3534c7e14e1ca2627b92a646a6b4f13e251da62f8a088e228e2e9a27e8650d21491f3d1bb4eea1758cc603d29e0ab0f5eeb3f590951e215af5d3ea16ade831c261750787d4bec33f6350fe0fc9fff42b49f21efd0f5022602a3dde5924d938522c479a4e6084f6148f8252fe40fad3b5f0e8d914858d90ed876c2ad7c0b1cbc391e7d852b3e1e106b2148aacc391f506f253e9e1e8fa73a4d52cadd3727348cda6c5de494ae33b987227dbc099e1d8fa6b5c68baec5ac44c5ac9fb2a8510eb58d373d0f38cf97e5d1d0c5d7bf0e2d06179e829a1183b81383b09859da2039fc6083b43efe5599c62e730c5ce639a5da44b3309835d86c5aee019bb8a6fd9345eb259298eea09e08b236653b22671bcc0155c25b946a8cba76916c60cedbf83f03f44cafe46ee12b9cd36b52458887e5448551c68b732a21dc0ae21caaecb80039e572b60cc6f1686b960aea14eae45e22abe812be573cd0773a53bb95688ebe61bb87a7daebe16d782cf9594ed98ddc1c22e5f0f0904769b3ab084045b6de34cb63893beb882f3bacf69908f2841bfc7299a615c543e17d0df6bc47e97d8efa187ddc741f6a0ad84fdad28fdbea26226f408c999388db8b0059cf723cff897eb88fa1306a9bd6818a2619dc6b4185fb6a28bcb09f6b0ed361df1a331f13afb7c797932202af87eec006b6de0680b5c0c040f758279207829109cee04eb81e0e5167855ca4232fe8a95fb6a03b75ea3b483bb7df71bf884969fd3d09c6b343450ee8c60b645505b1178407a0d6c7582edfde9a540fdb1ed838fd11892e01de8af3ac0aa0487e48bf048ce1ecbd75494dfa0afca61c2424df69e48e20b3848fc07504b03041400000808000f74774d7008a2d498090000e9160000130000006c6f616e2f426f72726f7765722e636c61737395576b781467157e27bb9bdd2c13020924042837694936370af5026d915c48bb3484968548a0b59d6c866460b39bcecc72b34a6fb428bd48afdc8a5ab56a8d9462492258a455a9a2bd58db7aabf55ab5fef29f3f7cece3fbcdcc5e323bcb83cf93cc7c73be73de73be73deef7cdf5ef8f0f4590057e19f419448284fa494644b5b4ad7533b543d08bf84295b95ed4a4b42490eb4aceddbaac6cd204a254cb3a45aaa25a6ea9a92d0762b7d0995ca86f5d9a3ea86964a6e887648905613b63d95344c2569f62889b41a9063e7f6771eb9fd9c84b22d9a6e98ddca106d2bbb729e62a6ae2507ae9650bb2e9d34b521b54733347a684d2653a66212db90708565b0b365e750a2a54f4bf6b728d9d9968d4389550975484d9a040925948c93409fa69b838cdf769636b5444bbb925093fd8a4e4d5f2cd62da1aa6b421a1652c8397997aae8895dd1643c2590a4a884e06e6db83dd5cfaf49715dedd7cc583ca5f3abd4184ea50d0e2a262211654a423155c36c5392dbf4f4b019df2561a6cb5d6e8efaa5d76849cd5cc1d0eaea7b24f885bb307c982fe332cc09e2231266e596729dae0ea4588164664d612cc0fc32305932a6a232883a09530b5617c6224404608384ea3a8fd5d7f7088c2619559816448b8419c5420ea319570aa825122e7343e5adcc46bc4ac62ccc1679d2926a777aa84fd5d7db4caaec4ac54924858be1b723f49b831a0b1f1a50cd36bb8ed575f5de950c19599d9a3a2f1591cd2a027515d46336312f52912ac3cb48a6b43347e6e975856cb697dc264346391963c1d8fa42be4ac614212fa5dc62a1cf10cfc90cb13d9f5be44154e8df206306aaa960b814fc7551b1b6a84704c52456663ab8260f8dfa9e306ec4ba206e62510af3282386655c0dc38c5a7b3c4e7a6ec0a782e8c9b41301bc81363236a2977bbe9fdfad4687c2ac2da8730750ef1608ef9b65dc8c5bb8dfb8d6f59ac86f55a1618f60f1ad827a2be9c4dae762825bcead4a2066d8deb83eb28c6c3153f672d919328cca4f42089c09f5397c0843c3b620b66616b846350c6540356424302421cc5c3822ee3b2f22148ac2ac684ac6306e279532f4b6c3afacf3c8c906d09b8934f9b225a50f29a68485c572e9f6b343c64e30f9a5030ed3a617105eecf9303e83cf06710737900563aa3bcdcc523b2d9f2282cf4958e6b1c4cd5dee63c32b1ac1e33b65d4a05cc475b78c7ba0daf9db6437d6106a82b82f13419e695b5a4bf48b4aecc31782f8fc8463cad690b11f0fb0d2dbc591b3768bab12c5630a632f6e0de16176f8b0181f90f1081e65b694e161329e5df0922aea0448e63cce5367debc794df304da9332fa61edf74332a6a35aacfb888ca3e06952c175f7e69d31611cc39783f8123b760e3d9a34d5015517abfb8a687fd17cd7ce249d4e17c05f93713da221cc101fdf90f14d7c8b741a548c09ed4b742f36954d42e9db324604056b3c1aa3a094d0392ee33951a65a0f9d75aa62a49242eb791927c5a2667a68b50f2ac3a6aa87f0028bdd97d7447d4306f75999a20fa4c5d1cd565fe54124d642578d74829c0f3b073067721f2c0041342b87d68433b6e493f30e6a6b325f606994e722b214f2beedf998a9c4b7ad5186ad432988317bc7e635ff4903b9d62edad77919af88ac060732ed2b6c64296ef3dde947a2853d4926181399c0156b0e259af19a8cd73368764d9af10b196f8a9a945196a94133de92f1b6a88170e0e43cb70d726d22eaddf49bf16bd14cdfe189d26f35a2603c83c1fc0b1ff4270e2be7ae53e93aed9df3ee0f326a31d30e2da33ad5dd7058d3702c95d6e36aa7260efaf2cc44b3084d42c3c5af7aadf138fb524a5fbf6b5874f780b5e725d45f8a55c6a633baaa8bd755399a4caa7a3b6f8c864afe8573acc57caec6c7ff00c2988920421c97f1f25cc2ef1271a8f37b32bf4bf9aeb0e4533c64bc8515c878ab2a90b13914c86a3cf06678e831e10532deb35cb2d994f20ec9afb9fcea839f23a02e328679913358d03b8685a77039878b7aa531d49f4223c7cd62bcf814963e6fa17e94cf6a660468a57d1b71dbe9a983345e858f512adb98f8382302c79fc032c75f0bdf622e107901979fc882955ac2ebf38c0359e3e5b8da315e41ed12a11d696088b950c296b48b366b2c846a5bcb4110233bfd12aec1b51e812c750772a367202bb0c42b90a5ee40d6d366439140ec7a48f824567a61b5bab13612abb70896cd3d89b9f7c4ea7063dd4cac5b8a604d71b03ad1e085d5e8c6ba8d584a11aceb2c5e4be214f248f6ea1157b2073d93ddc55aba0399750aabdd812469932a1288bd49f88b04dd0ed671d2b594ef2516dd45c2238dccd438d62e0f348d637d776da069149b22b581cc1ea8f58fe1d313127085b5fd0d22a539dacecdb5835b7927bdede2b6da8d85bc415d893bac9856d8deb2312d718a264622e525d6e836a6d2678dfa28f3136d2ee2646c809abc37d8b1976876ec5247e596710c76055f84afd7c784b6c67afd7c75c47a03915124c7a1c77a4b39da1e5bd3d0388edddd9cdc731ecbfdb6c128ee8a2df757de4b8c');          
INSERT INTO SYSTEM_LOB_STREAM VALUES(1, 1, NULL, '5a3fa79707ce606f2f177fff181eac7c68145fac7c8c8fda001fa37842581f3c846bb3d687c7f1940078faff00587d2c0fe0ab0ec0d72f196014cf1c42776906e0596b897e8ebe63aff98483f8dd4b456c121bde6755733bd901ec6166ef648dee423ddf11dc8dc5b89755dbcba6763f6ec07d6c09fbc8b5fdacf903943ec4e78338808779297a04a37814e7f1385ec5633c909fc0bf7008ffc661fc1747a4208e4ad5382ccdc031692e9e9216f266d786a72d76ec261b584f871da5d20a9cb2d811916612738cec582c4dc338653ec611c1f728f3339239384d5980714470c6921da0ecfb96ec3c652f5ab237293b2b64f41dc10f848cdee7e09ca5f7123dd6c0ff219241ec0be2653eff8395d6df4d0ce18719da4dd8bbadee46f98ce7defd91a77187dbf8594f63fe18728c9738c62171568ce2c76efbe379f6a1acfd3d9ecef7b88d4f7a3aff89772bdde3ee3aa3b4192bd2756a9c56ca5f5b1e8134ba0339ed19c84fb3abc8cf42e3282eb8edcf7a66e1a867ef3de8eebd2f7b3aff9977ef3de8cec279dabc52240b3f777a2f7f7d64b1ec4026891397a6fe11df48761bdae15cc80b679203f692a523894be548961a5d0ed654bb375890a378f58494dbd893ad96fa1a6f6caff37ef2461ef2d489c815143e974db737f21b85c86f11f96d22bf7371e493d9427823ff72a464c485fc3b22bf4be4df5f1c79055ddbc89b993e3fdf15d64dad6176d3187ee5712ff913f1ff6c61466cf56cb92af01b1e419235faad53cc0ac6516edd7cdf65241e9be23d37fefba4c3df8ad0c1be9b4af823a328e4e57b6e527fe0c14b1f83175a7fb1aeb3628ffd95ffefabf4f977fc83a24a4e3653f4018fe5457c57a1ec7f504b03041400000808000f74774d4199573b4803000019060000150000006c6f616e2f446174655574696c24312e636c61737385545d4f1341143d430b5bd6054a4554fcaa82d016b1a8880a880a82a2054c2a24f036b4232c2ebbcdee9688464dfc78f0c1071ffd0f3c68a2c54822effe2663bc335df9688936d99dcebd77ce3df7ccbdfbf3f7f71f00faf040430d4393e5703b7d9bfb62c637ad8e0b1ac20cd165becad316b717d3d30bcb22e76ba86388296b91c2d213be70b9efb80c077245d715b62f11e8606627465a062960955b1dc2ce9703ea864cdbf48719da1395a195fbe42c4378d4c98b7a30341aa84744470851033a9a194289e4acf41c34a0214285644c5b4c15571684fb902f58942b967172dc9ae5ae29f78131ec2f991e4373a6a26e62aa2d716f4a3cf115f6bc8e6338a1e138e5de4bccc0499c62a8e58f4804ca5f5548729ea121ebf3dce3495ef89bd656c02d8964a652db419daae830700447757422a1a18bceefa16720891411e4799271cddb4fbd8964a545c33986f88e71cac916734b639658a1eb1a7b921305df746c0de7190eef70cafaae692f8e144d2b2f5c1d3d88cad70503177189ae8f170a74970c3d89ea3a7697b607663082cb0c7adcf4e24ab4b884bc2221af5620958ffd03499e1c303088218688ef949d95ba06283aba312cbbe506c3a1fdb25083e9aef08bae1d34a72b569c55a16194a16b277cc6f68a8582e3fa223f5d907d4fb26deb17c118439b3c1f3783a19075ba82e7e38e6dade91801b5bb9e758a6e4e8c9bb2191afedeeb799984a13e6b2eda9c78906fa05ad74cf5dc0d55470d5307378dd939cbf1a8b849e12f397903939822a1cced71edffffd8ed938ea08d09db16eea8c53d4f788853cb86e8a9450d7d4b68fe80684c4e28edc2f4e838405e83fedda28810ad4da9735fd190daa03fdd5f11fb4ca61ab4d0bb51b925d45302788643b433684f47d08ac3ca47a311c04dd229e98ba5bea8a7a184b68fa80dad87d7c91ada85f89cd61788e2e52ec458801857b12c4ac6d33813407f20e6b29a1b123a932aa1fd239a537213fe86b3c4b9fbd326bae736d133b781b4b497d01beb2ba1bfcca3b7846b1bb8beb5cda3956a025ed1fb3525784355bc451bde293eade554019f5a0ce02689c714335a7fa14da3ef0f23f99a037a7d4a709276132373b1db1b18dfdad6b04e79deefaa540f90c3b8a3a2ee6242adf7705f593b91c1b48a632a9e7e7f00504b03041400000808000f74774d87c6c89441050000540a0000130000006c6f616e2f446174655574696c2e636c6173739d555d731355187e36dd246dba29a5b48542e55b68f34129d482b420a5150db680b67c15414e926dba906c60b34571bce4c671182ef4a68e1fe38c333823177a53189df107f82bfc25c5e7bcbba1a48da363da9c73f69cf7e379dfe7399b3f577ffb03c0082a71440c24cb55e50e4d29dfbee43be5384c039db7d57d3554566e69e842feb65df00dc4c61dd7f14f19681918bc6cc09cac16ed045ad066218a98814dd38e6b9f5faae46d6f4ee5cbb681aee96a41952f2bcfd1cfe1a6e92f3a356ddd90748c61ddeac7f419189c96dc4bdc95e3b10436634b1c5d3c5c3b995465db2d2acf42377a0cb4976c3fe7d67ce51698a3b72148dd54026db5b00d9b0cc4e930e75468dc5a51776c9dc840cf402e976b9abfdfc26bd84990359bad88d24e7af0c0569e0123c7ad4ad5f5176950540f38b26e03ddcd4018682b32ea446d4a1bee1d589fad69fa010b83481175ad8e7acb46470da8287574ae3fa3a72a1699919ddfb7c1b379c9872d0c4bc9f494c8da59f7796ac953be53759b85da002a97c0288ec771cc4047e39985377182dd28542b779567cf559b1695d350c62d9c049517b3ef2da9724d1335bd5ea06383f33ad5690b1338433ed4826f7b4d43ce332995e2f901e971f212ac3a7cbb7277ca5958b03d5b741427bd654787899695844bcefaaa706746dd0dd5dcea705bf9551e8dfe7b335ed9c8857e5a0fb34ec955fe92c778e7fe5790f18ddd383516c7795eb3865bb67f3881195cd417f6fdffc41e25155ba87a1545d1efff27a94ada59df73dc1285730957e2a05fb79cf9f627be189f952816aee21a5169157173edc66eabdfd8750e12f0ba850f30cb4605508488dee6e6c4cbd813255bcbe69605853c155cd297d61cc8056a2a5ab0454d799b0199bc2def78fe62a806be8582555476b5fe4b7c4acc5697bc827dd6d1ac27eb0d3da44118b072ae6b7b936555abd935ec019da03f6d5cf1ddc831cea721ce06e768ea195a7fe5228204c7986cee433b472b30e09c14f70e6c0a9d0fca09107f8ece15f4feb2cefd80b847c4a90fdb43a7ef89c3e47c8c4ee7b39d1d2d2bd891ed4c0693154ced3299dbf518dda1c7d67e3d362439c0b0408ac1d24c944117b24c7308bb59d4011ce6ce308ef0af3db4624aece22964b5872b43567bb98af0fc28ebddaf7f3bf03afd03b0f7f9ac0b4811ec743ab58283e900713a409c0e10a703c4e9067c3b25c228231f63cce3e8e4bb652b4e707f8c19c605576f109d1564389bccab31907dd67228c47093183475ddc43093d11832adecc950a6215b9754789ae304bdcf90a349c9b03bf00d33e8d511a9dc241e9d2b42eba3fcd5955cc6395a4769f5b8e5a4a687df13668a65bdf10d366775ea3e934f079fa0239b9627bd57e7abce5ec8a5f4a9cf0c0e395be19c0ce780f93e730563cb88f63fcdb64659d5c34844d3acb77b57f0d6f28bbffacde253426a9132e7d932e032615fa1caaeb2c46bd8c2dd6db8cec67e485a6fb0893759ac625979b6bbc08614f12e167011257a2ce2161c8e15d450c503dcc3675c7d015fda351294cfe605ed7a8c29ae0ce67b84b74528317c8eb32294763cc43b5c998c0e36dc5cc51e238ecdfc4ff01dd1861cced1e13de1685ab83c4563cd78e277cc5c4ba59fe1c2fa4bf3e92bba48bc84910861b4e9974ea88b33b411abe798136dceafc54ac8c997ccf65543bcbace626cd50d8977b3ce3d9e87dc8fbcd499dc50cd73966c7c94d14371d4cc983d5c0d65a9bfc232620fcd173de61a41c1ad5c668eafb9fa96ef8cefa8cd1f78f37ee4d913aafa27decb9f5f69f608a909aa1c214119d1e66112a4b599e43ba6439abd0b3da46d77d86cbe9356311cf45a93735b2abf83b25469f007453e7f03504b03041400000808000f74774d1288ad56670400009a090000160000006c6f616e2f4c6f616e526571756573742e636c6173738d546d531b55147e360909842da5a14049a9524509a16db4452d426b292f6d6878910082f5a51bb8a4db4976edee8601c7fad23fe11ff0a333ea8c8c8c33fa03fce8277f8de373ef6e024d968e93d9dcbde79ee739e73ce7dcfdebdfdfff04308e5202110ddd15dbb07205fead8aa735e17a09c4349c6958d73db392405cc3f927c69e9133ed5c5138a65131bf344a1541bcabb61bc2714ddb5acfcf6ad0164830635bae6758de8651a989b6ddfe1fbebbf3cfe0df1afaad5ab5249ce5dd45dbf21e570e568c83aab03c97b0bc8681d59ae59955b161ba26e9a72dcbf60c8fc43c7fb32033d8cfed572bb99269ede48cc6696eb35a99ab084934a9a183811d6fd6f0647a0a94abb18a9cb4f0386e546d46d1d0298b5cb355860ccfcce353a6657ab7354433a31b1a6233f68e48228a011dbde8d370b6605a624915b0e6979f2ad8dbacdea006dc07c698f7d874e559b3b68c9e7685b7749a04b14c7e74a3031a2eebd07146834eefe271353d99e6727cf7377474e39cac5c78d3aa3a69cde8484992be16543e3feb03c774f4e0bc86aeb2f00a27d5a000d4a3cb6d32c732b352988e723d8ef264e3d2e59794d5c9c3d99aa35ac59aca2fd494ca8cb6f6a8ddb38b9e635a65ce5dfdbc6258e59c6f9d6cc7049391f22631895b094cd5677651b8ae5116ae8edbf8404392c102132728d3ca14429ec03407e7d8bc5c7a22b6bd24663097005539777c94b73c51168e8e79dcd390d8932a2def4ac9f3278903b7c924f27890c0423d5959adbc603a0a58e4f8edda4ed5a0a6c3ad7d6e4d33c9fe2deb58c1871c0c1fe9899d15e16c5375556f2fbb15862b623d8135de4575e6897daf2edbbca291e9b0cb1321723d2c34eb12961aa7a2ea96e50d0839ea309c722d988c9e103eeae008b756a10ec9a25d6339f3a6fad29cb848d7248ae3fbf24fc2f4f636cbb29db5832fe450b5edf9433cfa7f5075cc7c7eae308bcbd43acaa78dbf341268e77b07bfa21124f9f0aa72dfc57d9ceb5965e77d6cb1a542fc78fd9a6c3aadfcda70d7cfdd0dae1ad7b6ec6fb8f08b82a4f92fc302d711e387fca20229270ce212570dafe0d580e0363da56f3c7bf11043cd0cef11735331f4f95e01837cf3cbd2f01a5e6fe11a3bc47033d714b96e9dc2e5cbc12b189ed74833d734b9ee9ec2950af2eac568c0f52d9b13e79a9622a9dcb2832c367b89ccd90bb143648ff9d3ca738ecadd630bef53fa3c9bb080013c50f1c619597ad5e3a583dce59b5424a2de640e51f5261b18e3f9155c0db2c9d1c76fd9afc8fed4081c57c6d5d0765d23a82e4b5411c7b3232fa4edcbf231310f4f91c59f240d6fe1ed46225a2391911f9b12298526723d143cd40c3643c1371ae07702093a25b8bbf351b75e69a6787a82a2b341314e686bfce19f9bc0fba1f1dfe538fbe0ef698d719d4cdd3cc2fb85c41fb8b315952a1ce16e712b26298f70bfb8a58a53b6b86cd611968a8b63578eb0ba74f538a43f315ff1ff1986f035357ac652bfc1049eab34b27ea8208d382bf8089b4a8e766cb165117a46d8b64d3636824f14efa7eacacb39fe8ccfe7028f60fc07504b03041400000808');          
INSERT INTO SYSTEM_LOB_STREAM VALUES(1, 2, NULL, '000f74774d31c719471e04000022070000130000006c6f616e2f4c6f616e5574696c2e636c61737375545b53535714fe766e07c2e12222a0a295166302685a4b158a20988846835023b1406f9b70080792733227272a7dee4cdffa03fad6a7be3853db0764da19673a7de84c7f46ff407f412fdfde09418166e6eccbda6bad6fadf5ad953ffef9f9158031940d0404da4bae7492592e4bbe5d321012e8da924f64b2249d6272616dcb2af80622023d5a6abbc99ce5d9b2647f29d74a1695abfa9ab7bcaaed3a4b99b480b847b729d7a9fad2f1f3b254b3c2dbbffeb9753fbdf89b40e486edd8feb440309ec80b8452eeba1545105d264cb40b74666dc77a502baf59dea33a4277d62d10401286f78630e46fda55a5fd46f89302278b963fef3afe6669e7a155913b65cbf1891a4f67d2897464260efd8be20c060c9c15e83848765efa9b26cee13c83abb84f05c2f1348d682dcb6e4db911bcb43b3ab8850d8d42594620ba63498f80d26768c2e657616c1bae5796be6fadcf36cc4fc5d389ec015ecef76ca738d98a04460c0cef17bec644923a67cbc4282e0b049672aa0c875f27a348e23d03ef0af4ea37df7ae627ebb59bd3d826aee27d8136d624a3e92830bed1f8514f8db08e38d0101f98b886eb02fd559696ec956be5394f167cf29db68bb64f1e42f14c22af74274c7cd8d495cf8eea2aa51b26a6708975ad5748a075bf541e2dff2f1472dbace8a2e51548ac2c5a066e09f41d2eeaad9a5d5ab7bcc8ccf23edf73b86be0ce1bcd5d573591011bd678a21a7561432016cf1e1e80c963688b621659d5b4f38ad8a3ef897c0b16d8091795e247261e22a73aa952b19c7581cbc7591c1135d2d0584b26f2782cd0e2bbf5478e64fc98b8984aa55e1df64c813d2a6da7bae09476f6b93a36d81555a14f4c7c8acfd82fbe9bda94deace7c91dc56d623515c51758332049c281b15222b79667a2002665d8550da26c528915a65b6d44da7d5c9c61590708aca63856395f16b6e765450fb8014e5634e7d698c89cad06be7d7fc6af284f180487945f98df191868e1de4aa203a45ac9f85fc2b583922477c13d3cfc129d3f6a95135c235a7801dd5ccdba024ea2877b2b4ea1b761fc948e95db73891ef4b913e1fe706cbbb3b33f5c18f0bfdec3e9a23b61f41b3f349d76302685c899645457b5f3313aa603bc4530e8d320dea6be3abd435990dabd18e2294c9b202ef2641034864b8d201e53aafcf6fd84f81eaecc8f867731a696f1d1d82e265f34e1bb11e27a8de6d799d33865133a845e0dd7d708c14017a67193b256cc3441d6295720f1d740c67fc1ecf268ac07a96de2ece1f64bdcef7eb08bc55d3c7a7128e929da4f13f5e66b88717cdc401c6c222e63a581f80defca3236fc3bc2c1e7c3bb58cd06a7bec7899181b13d7cfead127e15100323afbefbf7afd0736a0635de79fa035264f036dad8b55db883d3b88bb33c0fe19ec6bf50f70c0b1bdcdbf856c42671db5985215d7e5bf31e8afc8d56035b221ae0ebb6cea9f41f504b03041400000808000f74774dc119aaad31020000db030000130000006c6f616e2f4d657373616765732e636c61737385534d6f1251143d8fa10c0c832d60a185fa413ff9b04c9ab8ab7151a30b3b6814d3ad19e813a7c24098c1e8dff04f74db6aa28d0bb726fe26633cf318da34b571f3ee7df79e7beeb9f7cdfcfaf3fd0780fbb074c40432fda1e3592de9fb4e4ffa3ae2020b47ce7bc7ea3b5ecf7ade3992dd40203978dd9978877d2950b2557a12b87deba5f487937157eea9dcae40e281ebb9c14301ad5a3b10883f1a1e4a031ad226742405e66dd793cf26838e1cbf723a215dce1e769dfe813376c37b148c076f5d3f445f12477ea32783e82ab059b52f94b683b1ebf5766b57430604f2266eaafea3b11c396339a34c315730318784812594742c0b2c5d379f8932b202296a9852ebb825b07a016fb9becff0aceaf187ae1c05eed0a3eec1b4e1befc188e7c45a3803e988d15933b02ebf6ff69599569074ef75dcb19a9c5e9d8b8f47a53f224b6a2676e463dfc70d89a893a1ad371f6a2b76d5ebfd17fbfb76091d156b1276ec890996db61956a1c2fd6afcda880a974c4fa3cf4f81678a378b56d0ced5bfc138a51383c933a1826564789a53006e609e36850564a3e24f4487e4e533e43e63f127594e68eb5f51b48f9168d5edc609a169e451c00aa1217549a9b8c35b859935e6d651c40696b1a5dad51157ad6f13036635dca527988f455e915e05ab3cd788c8404b3fd5b1f21b319d5446f89d45fade44c31595b87c6ef30cd52f583c46725fd09e3299e058d9736d058e093418dd66bc891cf753c0cef91a72d4768f9da13af3f77dc1c67126b6d5e69a7f01504b0304140000080800d372774dc182766c5601000024020000180000006c6f616e2f6d657373616765732e70726f706572746965734d50c16ec2300c3d2f52ffc11297ed36b61b520f050aaa448bd46e48db05656d80686d92b9295387faef7352869643fcecbc673f67926d8a7d9c2db6cb245b87af5942280ed8c495d3b828a275bcdae669f4b2df4579c03e34a2fe1618ceaf60062b89ad05c51b0197c70136fc964d0720be82cbd3004591c1e57908d88f340b5d8910dea5290938d15dc07ac1b1ee1355ea86dede7c06d2a78e11b01245256d516aa4f7854fc0677eaa3be48eab4fec8c2dfb10e6370c5a79ce41a3f77490b5a8a0539540284fdc588a64316001ab3557e186ae19448dee94f5c2c272b4521dbd7ad921b7528f5b355ad9d3bd681fc089c06a38f3ba13e3a6c423ab39dde3069e5cf7b930bc6f84b221a46305f0af74fd0cd20aa39118b98f33d8f15a565071cbbda3c818d467dac2390ad811b9fbd1b50be32ca95af2a94aaa267f90c67c75129d8a5afc2b7b875337b8116dcb8f244a473036fb05504b03041400000808003c72774dd177818f880100005e0200001b0000006c6f616e2f6d657373616765735f64652e70726f706572746965734d91416fdb300c85cf35e0ff40a0970dd821ed6e057c48dad4c8b6b843dc65970105eb30b650990a6879831de4bf8f927aa80f9625bf477d8fbcae7ed42febeafee9615395c5af6aa35feb3cbb0ec7db755d2fcbf5e3d36ebb7c7ed92f7779f6ea44dc3f92e2bbd0c178a6ae27b983bd13c69ee0bcb840854d9736371768491dc4803d9c6f2f50bbd9a0fd4b3298a62319b91d78ecb5049cbf5ef26c36a77b77a0027ebac15b327ec6ce86a2577936118a9d36dcb85e05dfb0131ac8f09b533b074d9e3591a96ef4c602e2a2a43e428547e991df643cf9662a60c38353129e239b4a8e7fc6c5e2d848e47e25642fd87a18d907bc5bad9f67d621bf47bf83150545f4aea835ccd1f98063d2c3d631fa4ff4199201e6b187df11286415f44ab9d37782ef1dfbce4e3b3ae1a4897c91fc36340a9e8d6d43b3e45d7e1560844e4e54b722519102952981f5a625e5f0a92f5fa0a43027a36102609eb582a1c9a52ee96ec3c328c88d1eee3fcc06488e4e0e240122e6fcf87718d0cfa1a2c2f4a4bb56ed61f8912615fe0f504b03041400000808004172774d841374f9a3010000870200001b0000006c6f616e2f6d657373616765735f65732e70726f706572746965735592416bdc301085cf35f83f0ce4d25ecaa63935b0876577b318ba4e58a73915c2589a384e6d8d18c929eeb2ffbd239916ea932ccd7cf3de93aeea6fcdf3bededeefaafab0fe5e57bada97c555da3eee9b6673d8dfdd9f8e9bc7e7a7cda92c5a16e15f24eb07a11031a2f47c0b358fad109c5717d8781a86de329caf2f7047e615c1a1f90ce72f17a87f4cab558b60099a06ce3797b2f8ddfb2d5b5ac3369dbddcd8be63f0ace821e13e94c54c28c35c39c3a39655aed3c11c00dd84038554541646c8f6b1312c89841e4d6fd1a639e42c4d16c79e5ce42c307dea03dd4f997c34b336b03393044ef5a828b2ca09da9aeb3d0a66335e379582eaadc537061ac0a04fb2c9c669e064b12cca6260741a4f3ef8aa46460da81a3d4b5c12aa5c6ffa259fdd242a7571ee724423858f143ec17ffd80f08e03cb129960cc4144fa5bb38430b28bafc37c228ff3a842d7f0801aa62ec3f42f4d6da72425015e5846ba851d46cdf33db3aed3d5651ea0176e31ffa9d2b2e804d33d1d24059007f60a167446771bea2661706428a42791098f18f25d877c9839aa401d06ecb4e7a8c2f08d16d61f504b03041400000808004472774d428c924a86010000760200001b0000006c6f616e2f6d657373616765735f66722e70726f706572746965733d914d4fdc400c86cf44ca7fb0c48172415b7a6aa51c2236ac566243bb014e95903731306a32339d8f6dd315ff1d3b336a0e63cb1faf1f3be7ed5df7dcb437f7eb6dbba91edb2d7b4d599c4b78d7745dbd696eeff7bbfae1f9a9de97c5c13867fe90ab9ac9baa8034507dfe0bbfb19572bfaaacd04a7d53bb4623fb34de14f740923c1e93a470e2be8aeba2b387d792f8b7fcade98812a9017acf1014711392b8b99d08df356f766e2fc9e8ea423a0d691968ab2e81d0d2a74bd719c5f0cb0469f6938b5d0c8c7e4a87fb968433f57708b6a1c55a0858a2bace13504b81fd1fbd40dde442f05fd1b5a15dcc25f1665311ad455de18036fbf333aa04eb3d618168621891c625874d73133a52bfc8826a890e770f58bd2a87b9a4854e4288e652a78c0f8372d3af188b771de93c559aae41ad381a97d6ae2c7e7ab9c09a3236b9c54a1158721d746eb8ce0e188a31ad80a716dad33f1986104b62c5e1dca1fd98849008af59d305650fbec82a3df51f974c28575b8b8c0ff5996629689bcc7576edb2527c97d00504b03041400000808004772774d7c3bd7ac800100004f0200001b0000006c6f616e2f6d657373616765735f69742e70726f706572746965735550c14eeb30103cbf48f98795b822bd02b74a3944a5549568404d1fa727a1c55ec20ac78e6c07142afe9ddda6177cb177bcb33b3317cd7dfbbc6e560fb7db6653fd6bb6f25a97c585c2bb75dbd69bf5ddc37e571f9e9fea7d59bc8418c327c56a37e61133460e4bf0a127382ebe2fc1846e2eaea4f09803b083e3b5146ddbc0f1e6bb2cbe7858054b15acea4725fd298b8930ba69eb8d502bd893b52c4cf47e0cda5116269240ad0951feb7deb221b00cf8faca165fd871fe3f2e16b480b991bf1895087a4433faf7380ed94c15dca173dc9397f996dca969a0a87a2152c72947158d0e0c0e22c205555f1665e102faea3152ca022f81fb21c41c66d75682503dec657398cddb312a2a6ce829d15fbe84fbc3d31c81fc888f03a674f6d7079fdfdcb4a70127152721702f51cbbf94891d9d93122ee9624d49ef25dc6266f840c7b25fddd4c310c38782eaa92cba881af646aef332f649b47923689d121b2944b527886cde580ce2ec2a9ff469ccbfba64ac08114f093b19b13b3d3a3e0fff01504b03041400000808004a72774df7af9e38dc010000500300001b0000006c6f616e2f6d657373616765735f6a612e70726f706572746965734d52db8adb400c7d5e83ffc1b03f30f6d89e99853c846dba04ba5e88db3e0596b96e43133b4c6c8a1bf2ef1d69ec6efc20e4238d7474a4c7e65bfbbe699edfbe6c9b97d58f661bbc4d9a3c02fcba69dbf5cbe6ebdbee75fdfdfde77a9726aaf7beff63fd6a3f562477fb91122ef7635d94ea290b58494cb04569b22bb901');          
INSERT INTO SYSTEM_LOB_STREAM VALUES(1, 3, NULL, '200ccdae39b8ac82fccab232e433c283ad6c955d8b5bd6b64d76a5b734f97b383ff7c6ae42ba20aeda8fa5530e9ed6a149451d83b20f693259e98fd3b6d3fd099363d58a6a0b0969a2bd3587a1d5bdc7302512a95a0d5671b09aa245df29c4055ac4658103c0178696dd6f3f9e073d4131c66909948a90586b13483255689c23b8d212785f5b94a6409fcf0a44f8fe3d25a298950a4105300d30975aa5499a1c7bd9ad90b8419a48df51505ae4260f96ff575a545c81de5a2dc262cf9a81eaa21274661866537101e187331e2a73ad598094015e94b3b80b2f07142f22a0eaa9ef865fc76967cf723ad96e8068adb45df6c91d54a82df80bb30798c3db73ef87b889b803733790e64f489408389db80520b4c4959b47ac0be6401ce01cbb50c21c0e9a261f5ec6c361aa0c2598c965647de82ea3979dc620173c87ab82fea26672aefc098078422c53e7c0ff642f17f9311f92cd3f8f47a93b923c76fb07504b03041400000808004d72774d0494a66adc010000670300001b0000006c6f616e2f6d657373616765735f6b6f2e70726f7065727469657355524d8bdb30103dafc1ffc1b0d71e245bb2e5400e619b2e81ae17e2b6a785451a29dbd0c40e8a43714bfe7b3523c7dbcd4191356f46ef43f7cdd7f675dd3c3c7fde348fcbefcd26ecd669728fc74febb65d3daebf3c6f9f56df5e7facb669627aeffbdfce2f5f2ea660ece502b686b056355b64e19f177c91fde5d74ff8515522c06a25c2118b47ccda70c44528406905812094f36bd6b64dd814d734f9b33f3df4d62db1a134e1125b1815da4085d59685a2797769323aed0fe3a683fe18d17217d01a98202e2a3033c25a82a7097867f7430bbd8fe0dc21ff52d778018415146784cdf017c4eaee97bf9c061897a809e75b96dd945b2901c1a841aa0c8730b4822163d48eaa70a7e5dca95d118a4649744170850543642bd406958034499343afbb0f0e2fa89711bee4b39def8068f79cc49440bc0efd5844321a3844e7a93ddf6140b08b0c2a451648ac384aa8cad51489d70399f6a180a61efb6ef87918b7eea4c7a3eb86189aa5b9407319704c4dfe4ffe0e557a77ea3d352005244781704e72a1cc313ee0f4862a45722b767b5696178ca2c2204d7de36f44ae507d48efcdebf8868cd871b2af9e38efbbf3c5eb0ea86a657c8cb59822bdd1b1d2aa77a7e7238c0f60f680a396a33b9ff55bbc4c4b1c975b84d4c0a62bff01504b03041400000808005272774dbad44b8588010000550200001b0000006c6f616e2f6d657373616765735f6e6c2e70726f706572746965734d51cb6edb30103c5780fe81402ee9ad696e0674b013c770132b81d5f81aacc52dcd8a228525e94009fcefdd950ab43c10fbe2ecccf0aa7e6aded6f5ddf3fdb6de54aff596a375595c4979b76e9ae566fdf0bcdf2d7fbe1d96fbb23806a2f08e543da1475aa84308e4017af5f9eda296ed29e1dff4e6a20c1eb99b5043ca5cf97e51aba6569fb797b2f8b0c35dd058a9971053cb91bcff52162302b971ebdbd073f3070059df71eca55f162da1b6a9690371f751124c51b269bd1c6608bea33ca476acd40358e76c8cc8084985611a3b33a9895f180c460786d183d748ea14c2af9872275ccba22c5c002f42ad370bb5424d602684151aeb2788fb9c6952d603787d8dfeab9ae715bb40ea9d2fd126920992e8456a990b2f9d15f5c1a7931bf738c028242bb5132474f6771751b19dd91c318113ccd92386c2817dadd41e0609166a834e5b863468f08c3e4e2c3701b5c10e33e9896b591802f1bcb667843cefb73e6602df72f980f4c1e3249bce4868639afdfa578fc37ff46f844c8f317256b12764f9fb67d43f504b03041400000808005572774d22d43216dd010000190300001b0000006c6f616e2f6d657373616765735f706c2e70726f7065727469657365925d6bdb301486af67f07f10f4a685319c64a574908bd079252c4d4bd276378572226989ea58474836422afdef3b729442982f6ce97cbf8fcfd972b17ead9737f73fe7cbdbe9d3724ea7ba2cce92f9ae5eaf67b7f5affbd5ddecf1f579b62a8b0d5a8b5edae903bef4d5e88a071e1bdc28b41cd84b3fae4613a65a957ca3eb1fecbdfaf8ca3444af5c83741dd1554007acb728a2d40ac83826e343bdae17749e7c7c2b8ba8cc0d0a3965bf5130833c76e8c350ec4b590409761fe69a634b112bf2eac004f21df5acfe4ec4105716dc4aa1ba35474b51f75c6a605e810d5b147a18fd72c3156b282a5075f936a4b1f49048d08ded4dc7c3943d191029fcfb3867a57775c5221334fd9024f6304863e7719b435dc4d490598c222ad8cba4f2a22cca628fa04fe07d626b3c76909165463ddf61ab32a6c48e4770acb31e52ef73cfc8e906d8d52507bebbc834bd6b60e840710d5b3c3e0f64cbc2429768188b048464935b665e2dea6eb70f2b6920b4e49cb23fc161732afab3dde89ab0cb37e6cc41307421d7a126d2a0a5fc15a4ef519d4163c16b49d2b4cc2a23745e492b08d6613988fdd68238feb15c5269d75bd05ca6995ad85201d66f64344af2b443c772feff815d93e7138d3ac93900a5756aa573b01d76aded891674b9eb3f504b03041400000808005772774de6d5e5119e010000990200001e0000006c6f616e2f6d657373616765735f70745f42522e70726f706572746965735d52c16edb300c3d5780ff41402fdb2d6d0e4507f810246e11a071bbb8dd6940c1ca9a2bd4165d4acae605f9f75174b1437d102c93eff1bd479fd777cd7355afef37dbfab67caab7fc5615ea3c7fde554db3baad6eeef7bbd5e3f38fd5be502f4884bf2d95bb14d3cfb458d80b72f84dd738587d5c9c74832f64bddc2e4eda43306eb03ea23e5e72b1a9f571792ad45f37aeb1b5a55e570f197656a8c902f5d3d61bc6967a6f7d0b1a7c823ed70b65c8b62e360689ab0fe86302197f25e712756bf59ae472cd8d2862f2c39ac1bf511aa3994a7d03bdf480370eb41da46d0402910bf49edc0178b2476d6094d636a65ee417aa503d822fab61fc9814a21bd8fdf7043e325f26dbfa19651c0ae726d127a53989615611bed8f0557fe2cbc30fd023654f12174164d78ff007e63006f6ffda4f7b3bc294d3e51c397698275f41c68dd0c11c3c9f614ef12c3b203b22c59c700f31037e2d65831b6831e8c3bcd3dee54bb6b31a090f52ca660ad511c8de585187e43e04391fd8a6375c696c97883d586343f8ff87089718606d415a8491250ddc071d2377596837efa450ff00504b03041400000808005a72774df9fcc2f8500200007c0800001b0000006c6f616e2f6d657373616765735f72752e70726f706572746965739556d16adb30147d9ec1ff10e807ccb6a4c61de421745909ac2924dd9e064596952e2cb183e230bcd17f9f2dc9f6911d6f591e84b0a47bef39f71c2937abcf9b97c5eafee9e372f530fbb25a56b385efddd49f1f179bcdfc61f1e969fd387f7ef93a5ffb5e922b95ff946af6ed1cd0705a8f24d023d3a3a8477aa7e7b11ef98789de1bc3fa76f23b78d39f230a21041c4bba79bd3d34db43d84e2333d70bd444907abcd52385b252375a64a3619269b7919aef7713382ba14266329ac461b74c6f0140d0c1a062108898398430702c0e0390c1810882f6d09037dffbb53bdee7a99c195c5ba8690a5c412817630c7191376eeaabdbf5cef74ac9d5be5c66223f34991810ce101984bac02985021125ad33f99e5032dd151b91ab260f077218848801dd853c61bf1524d1d2ab7f959879f6439d8f85286d9614e26fe110ea6d80d82a0039074dd812d2feaa6db7408d05ad2d9a68461f048226034d581d187db64e21d104da0130ec2956bbc0f77c6f9ff36c760dc7c6c751d89564ed207ac58f9ad4511e6e32de8bbbe2533865f94283f3d6c28e23c38e098a928caed2d07be08843edb18da17da678e1980ccb7272a67d615aa8db81e59db670a40b4540ae700025c63e873c2bbeefcbb53cf2f220b362d4ab63e4c15d6819674e45a02c832aee23b7ac317b7354c4c963ae9a4a24d43c851aacc686d412f09ec3410a64275829be2b9736b50f10814e0cb38c3d25526bd5f75e156f6fdd1111b43dd5bdd965a7b3e299b087fe62a7be4efef134f0c6430db0ff7c55ae556685bb6ae8419e4efcd5016143c2ad67ff078cc8c2f7fe00504b03041400000808006072774dd836c1a855020000a10800001e0000006c6f616e2f6d657373616765735f73715f414c2e70726f70657274696573a5555d6fda30147d1e12ff21521fbabe25fe489a493ca08e21a4954ab0f585a22a04a743830499a0894ddd6f1fb11d7c92b8d3a4f16099d837f7dc73cfb9b99a7e9e3f8fa6770f1f27d3f1e0eb7472de8dfabdabeaf1fd683e1f8e479f1e66f7c32fcf8fc359bfb72aa42c7e0839588cafaf9f8e594648b5b2ac5a39b1ab7912a93dd7cf3f782a2254cf6288a06a65ea9809b5066a5deb706fb1f8e5bf2e973a3eb517fe2932a82359072b13d505525fa0d4ae441dd1f3d16f7d3fa401654f473fa0be5a358074d9effddcecef8ab5187835293481127db5a7363563cdaade4102ee4c701289dc9e26795aec304b6cc93574e8a214413cf62c08430d8268510b18422786548af5a69ca785040884425a0ec5c5d017cd2726af032e7dad7e802072225825f97779dc97e9090010e8b92e7205c2e2b6039c5914353799d5c0455e2c449c4dfd807235c975cd9ecd66503014be0704dc42bb1018b70949b31fb74e36fabd6d91e4d687295464e8307e4343646da0e71e61f5940224d01487b69a0aa306378401e1d0944620f07df11c02ab2169a2de032ff406bddfa8d283984cff09e13c858ab9c3d2b1935d9994e8b46e410ee330dff9aa5d9197dfb6a799d827a79dc84b10ef9ba5776c8c163313456788d1ccaeb6c274a9429c4a92625fc8b2532f66c301cfb4b0688766d366338e514466df1ce468021faacca089b5c1506bfcaf03a5e99e6ae63b6a7e91090e6c12b575db1ed2f046ea7ce3263f1c6592a7f856b08bf95275fcd198ccbcdbeb00e41bb74f59d3bcff97afa3eea0a51ef7c76f270e87e4457454cd010585fcd19bbcbabf7d7f00504b03041400000808006472774db2ac87d184010000820200001b0000006c6f616e2f6d657373616765735f73762e70726f706572746965736d51cb6edb30103c9780fe81407ec07d2407033e38a92218b595426a722a106cc4b54a882f2c2907aae17f2f29caeda5820e5ceeccceccf2a6deb7af65fdf0f47557579be77a174f65c16ed2f5a16cdb6d553e3e3587ed8fd7976d53b0374b64df9136fb9fe36a85b726400f846bfe98eae31d19d0869f57175e1e032ed5c70b3fe6b610fcfce9c2dbb6e6e7cf9782fd96eec10adcf0efd607336a8d94c81f0a3621909a76a6b33ab613bbbb252fcd60b50f0953b08e50c8d0769622e2db5c383bdbfa62fad943faa26730038d2e74538459338ce4e7eee28966836894ec031fc0c9802ab92c58c19405f337ea9adfa3b2cecde43600c57fe6eeafa2399d5ef020629a2b9907a9143f652409ccf90942f4de2cfc003998b626fc5253830e268d265cf3c785be61006564cce7e2f07f4acbd6e244749622a301970e6b5e4915640f5c401ecf2b2b864550a09f0314ac2748cf50511e553069fc4860ba78797d5a9f590325f9817275cabbfc1fc6c3a997c79014a2358dde431fc71d50085460d20e92d21f504b030414');          
INSERT INTO SYSTEM_LOB_STREAM VALUES(1, 4, NULL, '00000808007573774d338939d6ad010000e20200001b0000006c6f616e2f6d657373616765735f7a682e70726f706572746965735591dd8adb301085af6bf03b18f60524cbfaf1452ec2365d025d2fc46daf028bac9f6d686207c5a6b821efde19691dc88d18a44f33e79c796abeb7ef9be6f9edebb67959fd6cb6506df2ec09af5f376dbb7ed97c7bdbbdae7fbcff5aeff2ac1b4218febab0da4f9c50bf9f44c7dc7eaa5ca7f793f7144e5e115b5cc9ad80b2b6acb8522c258f3477bcb896b7a26d9be2ca6e79f6ef707e1eac5b015213ed1061004a4f059c8a506c9567b3d3e1386f7b339c22cb9dac220b14a78227ca04670f636b8610a1ca3b8a934b055049047e9024a19deeff84e93c9a1949a1580d2713204076a5891aa1d48ee0b5256851c3442954b5388a65f42915ab2221f32ccf8e83ee211f65995cf249c9d4d4829e5ad5f77c3c219892e9509a078135f74b7fc108aa77ce3e3e46654212553cce1025258b434c36e831455596e04d322593f3d3d08fbf8ff3ce9df57c72fd18fd77c6a7a6b85709b5f256251e3ab9f31012576a8e1baeeedb863f981caf549a9d525cfc595fe22759e3968c406779f611745ab8ec2a5406b1a54987fe3205dd9bcfe559fb10d6e7851075f47df7446f5fc094bb5cf447fc28ac422d44f8d4f53f504b03041400000808006772774d075d7f29c3010000ef0200001e0000006c6f616e2f6d657373616765735f7a685f54572e70726f7065727469657355524d8bdb30103dd7e0ff60d83f2059df871cc236bb04ba5e88db3d191649967643133b2836c50df9efd5c8764b7d1886f19b376fdee8a1fa56bfefaac7d7affbea79f3a3dac76c97670f507ed9d5f5f679f7f47a78d97e7f7fdb1ef2ccf421f4bf5cd8342343d837a360a56c46ea8c6e46ef718c8ca23646c3447143f722a6aa25cdc82df2c50d434130e8e4ccb1e256de8bbaae8a1bb9e7d9efe3e5b16fdd264214f20c2273b19f50d48c92330f845ff26c723a9ca67d67fb7302332728f0111e73cc19c0f2cc06d71e87daf62181a87778952b358becac443c49842faea6bb9f61bc0c76da2c3a393376d94148425377096b229b168c4c5c2b3a03e35f53dab4504cb543799667a75e77d12a690d600d71ab490ab7518d92b45d0628260d5865cd3a5c80498a29b27032840c94912cfe67e42546a041c8d9c6a087d996b254510a916236e4dc77c3e7693ab88b9eceae1b00c38df533295897262249179f2395bbf421019924186e4bffde393629184b63abe09282282ba0a2d47af9d647bfb82489ddf2b45a9e7d043d5f59180a0a5bac6785c7ee3a06ddd9f9090804675712c3f1daf8a614d77a61fe57485e98754f0cbacfee7ad51f89446a045211f7f3843f504b03041400000808000f74774d125ca078ab08000096130000110000006c6f616e2f5265706f72742e636c61737395576b781457197e67b3bbb35986db2681d228240db49b4d68d4622f845b2e05030b545282a1b6324926c9c06626ccced2062ff5122f55a9775b50eba556aabdd76609205851ab45c44bd5e2e5d17ffa437dbcf4b1ead3a7d4f79c9d6c36b313451e76ce39dff92eeff9bef77c33397bf1c46900abf06b1521057332b66eb5ec30466dc755115630570ad27cec74cd8c8aa882eabdfa01bdc5b45bba0dc7d433e641bd2f6328589095cb1ec3c99ab6b5b3ab5381b2990e3a6c2bebea96dba3677246e477d1075f7820b27dbf82589fed38f6ed86a3607e5a4669f704ad0ac242a020912e86df61eccf1959977b95071874a053777546d8ad60a16965738e6ef51b42c7748c01469d96e92ec1294413d347471dfb80d88e8d18d9ac3e646415d4a4e571723c5d4b9be3e86369b310a5db1cb27437e7d0ba3148674d4198d1ada1966ed731ada1d675b44b8c19ba9319ebb25cc321de42f80523b6e50e67c698587d6cc4b05c05d135a665baeb1454241b7b78e00e7bc088a302751a5e85575742c1151aaa502d66cb3524b050c5950aaa0290c4b1027542af51c3222c16b3260d0bb050cc566aa8c1429163d332b6e546fa0ce7e642c11269bb9ff5d25935ae3d61d81d369995b9e91222f054cb93be129517a6b127ce7012c7eb3568982b66d7699887f9e4d590e1b617ebbd30d9585671951a6959f4eaa9dd99659f63667ba60bcfacb1f45ad6704b84e1e46e91cb2a33db554e896aea0688634e71aa0d95681470949538868d8c63d996214efb060d5d20c9ab066d6744775d63e026c3e9677dc92d522bd919e081c9ed76f5fe7d5bf5519973155b4910bf1a45a5680a34e2a13be545f36f84194990c891abb8996d2b527d0eb54b5674bab5c8fd44b294d91ef1af2c13cec2f4b83e30e0f912672d57128c58815b34bc19b7123cd57d7adbfbf61afd640e2ba98e4c794a04a52c3e8d5bf8ecd3d00f513c93b74c776d726ad10cd85d9ebc55c520f7fc1edb73838386138781ba3930b14fc55e062e37d790c188a8b77187eb2784075e38b1358c822d2dca0e6358c4d51c948d32510145ab4090d5e0622dd330ac67b73198f07a4078bd5d416db263565ba137a6e120447f73ed29ee844c0137281fac435f8e29b96c368fccd6ccbe30363ad51b92010e67eb82ac57af6c84c59617dd9084fc27fac27b35d4a29a1747d4b5ac37566583a435459fa5cd5578fba086cb85b79a6c90460c87581a47b6b2383e828fa9f8e8d48b6dea2e68d8838f0bee5f4add48aa4fceb8b2052a8886f0690d6bb0368e7b7144c56176ba69a576dbce18baa5e133f82c0b7d40bc0eb70b72b269a5cbd45a85b7fb34740b6f5fc097547c51c162a9e6921f53c037cabea3e17e7c99672c74210537041ce396807b57ae15c757f0a08aa3338ed769e7587f01fcab654dadb0c7b6b843c5c3530867b0cacc0c88ab96c6a3c2c363be24ff37280fe109f132ec8de1eb7c83c7856042dc893cdf6a9778c16470a29b5410a9abab5b59279c8c89dc9ed4f00dd1bae7175b77db889db3dc186ac5f637356cc0da18bec52f81e2b784d8f8b6a04aa738cf77353c23ee5d98b14684e0fb1a9ec559d621635843eeb0ecd75d31dcc6c94896b7b25277867282cb6cbd5501f5902ccde632aca02a3a39c5de8cc7a189ff2342ee9749a5ae56c42c95a6977237ee355bb937b5e08e8af35c77db39bec3369ae2cacf297c015c2db0a29ec7afe02f8238ef9b8a18e795bcd021ae43e28d2fe77cdfcb91df1f724c7823bf65e458e3adf9a542fbcbe47c097f977bfbb5725cc419bf83a8b194ab411917589e3a8665a97913a84f554ca02175122b7a8fe1aa092453e109a484b0f909e9e56a3e9712237015c24812672391a518a989f2663460255ab8ab15fce235782d4785315fe7c5eca5970a8ef319f39a54d30456a59a2770edb4fb041d03d7f37903ddafa6fb56e9b2ae60e6b91433911a45ce4472429c5f4f9b4298168e622f927a0aab1e2f3a8f4a614709c64811e36a062a37bed66f9c0e34667b0a304e3dec33ee09345e87f59ef13a6a878476aa96899f4e4a5c4a6fa5cd6dd2c3a28256311951c90b1178432090063f90c140206dc1401afc402cdad8b30069f78074a0d3f3b545d606a816408e2096b8f128e29cd74f6293c86e45092ea70457b5e7750b7ffc334adba832f90ab6617bf184a1e209eb1ff39df0ad8127bc096f2c9eb042322a9a22d1ebfd277c0f6dc66739e10e221327ec0e4c75b33fd5770702b93938d5cd7e20f7d2e6f02c406abc54ef24af42de9ddf550628e967f0fd8180dec4ab5900d4ee0112354a36e5b17b971fd423bc998f96808a1741c549d0b7c8e07b8af53fe55df9f5c25f1e7afa240cf697a1ad4751dfdc741c6ce94f239d87b58b0bf6d1c388372f88e791f3d6475ef94d731e7788638425882bd823813c9fc7c8fb49f6c0e3eca227d8874e12c6246ff2e99296b1de0317c37524c5db086a0177df8e7710d69d5e220a7befe46c8b94845e46950a5385217ae5bb8a8cbb860844da2aabf16e9e667c9f9f75cf96e4b6b298dbf7055276dc6ffce3c0c2bc3f98b2e3fea23c4f9b0bb330a5d6a3ec070281dce507f2db40201f0a0672971fc8ef69f387ff71770e4eb123b487da51baef487c781277a723a7f089de8a541e9f9ac43dddbd61ce3e27665b9b9a27f1f96d02edbc7beec3da70418fcb493cd0bd3a9cf81aad9784a9b33a72120ff5ae9cc423c7f078e2c93c9e4a1ce36349848f3c8e0b17e3335d8c4fe2847071eaff70d170189b8a584f7b580b3d4db87afa925de571e6196c12431edfc9e37b87b13a3ce5f78c70f5834b75b572ba995aac38f04726f64f58863ff36fbbbf50fe5716ee6f6ccc7fc78d1c37e3050ce31fd88f17c9f07f911bffc421fc9b5f722fe3495cc419bc82b31ccf290a9e23132e2821bca88495b81251162baab254892a0d4a4c6953e2b2d807491896d12b7654598b73b2152c5396e387384f2aac5096e247945510478a6c3fcfdbb49924f80965116248e1a7527688b2e7a4ec1c653f93b20b94fd5cc894c594fd42c89406ca9e977ae2d62e46f82286f98e507181cf97d0fe1236f33f21fc5232f457ff01504b010214001400000808000f74774d4f34fe60000300005d0600001e00000000000000000000000000000000006c6f616e2f426f72726f7765722442616e6b7275707463792e636c617373504b010214001400000808000f74774db9b8c1d435050000050b000017000000000000000000000000003c0300006c6f616e2f426f72726f7765722453534e2e636c617373504b010214001400000808000f74774d7008a2d498090000e91600001300000000000000000000000000a60800006c6f616e2f426f72726f7765722e636c617373504b010214001400000808000f74774d4199573b480300001906000015000000000000000000000000006f1200006c6f616e2f446174655574696c24312e636c617373504b010214001400000808000f74774d87c6c89441050000540a00001300000000000000000000000000ea1500006c6f616e2f446174655574696c2e636c617373504b010214001400000808000f74774d1288ad56670400009a09000016000000000000000000000000005c1b00006c6f616e2f4c6f616e526571756573742e636c617373504b010214001400000808000f74774d31c719471e040000220700001300000000000000000000000000f71f00006c6f616e2f4c6f616e5574696c2e636c617373504b010214001400000808000f74774dc119aaad31020000db0300001300000000000000000000000000462400006c6f616e2f4d657373616765732e636c617373504b01021400140000080800d372774dc182766c56010000240200001800000000000000000000000000a82600006c6f616e2f6d657373616765732e70726f70657274696573504b010214001400000808003c72774dd177818f880100005e0200001b00000000000000000000000000342800006c6f616e2f6d657373616765735f64652e70726f70657274696573504b010214001400000808004172774d841374f9a3010000870200001b00000000000000000000000000f52900006c6f616e2f6d657373616765735f65732e70726f70657274696573504b010214001400000808004472774d428c924a86010000760200001b00000000000000000000000000d12b00006c6f616e2f6d657373616765735f66722e70726f70657274696573504b01021400140000');          
INSERT INTO SYSTEM_LOB_STREAM VALUES(1, 5, NULL, '0808004772774d7c3bd7ac800100004f0200001b00000000000000000000000000902d00006c6f616e2f6d657373616765735f69742e70726f70657274696573504b010214001400000808004a72774df7af9e38dc010000500300001b00000000000000000000000000492f00006c6f616e2f6d657373616765735f6a612e70726f70657274696573504b010214001400000808004d72774d0494a66adc010000670300001b000000000000000000000000005e3100006c6f616e2f6d657373616765735f6b6f2e70726f70657274696573504b010214001400000808005272774dbad44b8588010000550200001b00000000000000000000000000733300006c6f616e2f6d657373616765735f6e6c2e70726f70657274696573504b010214001400000808005572774d22d43216dd010000190300001b00000000000000000000000000343500006c6f616e2f6d657373616765735f706c2e70726f70657274696573504b010214001400000808005772774de6d5e5119e010000990200001e000000000000000000000000004a3700006c6f616e2f6d657373616765735f70745f42522e70726f70657274696573504b010214001400000808005a72774df9fcc2f8500200007c0800001b00000000000000000000000000243900006c6f616e2f6d657373616765735f72752e70726f70657274696573504b010214001400000808006072774dd836c1a855020000a10800001e00000000000000000000000000ad3b00006c6f616e2f6d657373616765735f73715f414c2e70726f70657274696573504b010214001400000808006472774db2ac87d184010000820200001b000000000000000000000000003e3e00006c6f616e2f6d657373616765735f73762e70726f70657274696573504b010214001400000808007573774d338939d6ad010000e20200001b00000000000000000000000000fb3f00006c6f616e2f6d657373616765735f7a682e70726f70657274696573504b010214001400000808006772774d075d7f29c3010000ef0200001e00000000000000000000000000e14100006c6f616e2f6d657373616765735f7a685f54572e70726f70657274696573504b010214001400000808000f74774d125ca078ab080000961300001100000000000000000000000000e04300006c6f616e2f5265706f72742e636c617373504b05060000000018001800a8060000ba4c00000000');          
INSERT INTO "PUBLIC"."PRJRESOURCE" VALUES
(1, 80, 18, 2147483647, 1, 1, 'loan-validation-xom', '70d9ac8b-6d1d-4ec6-8841-ccb8278cc6ed', 1, NULL, NULL, 1, SYSTEM_COMBINE_BLOB(1), '.zip'),
(2, 80, 92, 2147483647, 2, 13, 'deployment', 'd757de3a-495c-405f-8067-8b01ddfc98cd', 8, NULL, NULL, 5, X'3c3f786d6c2076657273696f6e3d22312e302220656e636f64696e673d225554462d38223f3e3c70726f6a6563742d6465706c6f796d656e7420786d6c6e733d22687474703a2f2f7777772e69626d2e636f6d2f72756c65732f72756c6570726f6a6563742f6465706c6f796d656e742220786d6c6e733a7873693d22687474703a2f2f7777772e77332e6f72672f323030312f584d4c536368656d612d696e7374616e6365223e0a202020203c636f6e666967203e0a20202020202020203c786f6d3e0a2020202020202020202020203c7572692076616c75653d227265737572693a2f2f6c6f616e2d76616c69646174696f6e2d786f6d2e7a69702f312e30222f3e0a20202020202020203c2f786f6d3e0a202020203c2f636f6e6669673e0a3c2f70726f6a6563742d6465706c6f796d656e743e', '.xml'),
(3, 80, 324, 2147483647, 3, 16, 'miniloan-xom', '9366419c-718c-450d-a9b5-b4bec89535a4', 9, NULL, NULL, 6, X'504b03041400000808002578684c9cdd64e6a1020000af050000170000006d696e696c6f616e2f426f72726f7765722e636c6173738d926d4fd35014c7cfdd23db0ae3610c795451711b424df48d822480904c172442105ff8a2eb6e66497b6b6e3b84efe40b4d2426bef003f8a18cffdb8ec1ba627cd19e736fcfc3effc7b7efff9f98b889ed2e32c25188d3996b06cd710fa962ba5fb99cb2ca5188d9e18a7866e1ba2adbf699e70d367941286c3198d37ae3e1df8d212ed3546d36f3bc2b71c7e647956d3e69b42b8bee15baef0182d050967fa9963eb4d4bb474a3f7553f76ec1d9b3b5cf8285230256f59fe81e94af4617546da3937a47d5e17a6ab5a67d6c1ea6f304a56aa4700da765b3c4f491ad548a36146c58625f85ec7697279680043c1baa6611f19d252e7ee65caff68816ba231303a20a62a83f3d5ebaadd62ff8cfb86841e3e977dc3561ba8d8d665c7e69ede749d6bc37afa56c703a0e7ed2111add2a786ddc100503b87d7ac4669ca286f5ea31ce595775ba302e51965dbdcdf0be42f55aa713f20eb5d064cc60ca0f09960348232dbd74586909079c48b5ca72ac1c44584bfeffb03452f7a933f703bd2e4bb965276f852c85585c068f9dfbf7ed334a1862b0fcf3f293daaff13dd8d4defd6771a2fe92e344a629b939450e2e194c549d921d8849271e0ae307037048b05c27b04a727b00c365dfb41c56f41ca18de7958a2154ad12a8dc3d3c2209aa012ac2a30898832fcc5248e53786e79f8de7373576e216864233e055b42a3e9daf205cdd4e62e68ae367f410b577dcba841f40c91cf51620d99ebe8f92260a885f95d06e58522282fd7252e05032ba43b815caab3de1bf13bcd7cedb50a53b763c75ba47bdde40d44abc29900392ad02be4bc0e2a94c3a81e5c86ee071d183da0a51890b92f1190fd58908754190099856c519077c839be01245c0b6c5c2cc84214e4432c482d1e64210ad2420ebf0124dcc5042d07398f82ad547bb8a2f68463d3f4bf504b03041400000808002578684c82745a30d5050000cc0c0000130000006d696e696c6f616e2f4c6f616e2e636c6173738d54db531367143f0b2131610145402d5aa9b51222125bed4d908a20351a4081a2585bfb912c71652fe95e28e9fd667de84c1fda878e7d6a9fda874ead3345b1cef40fe81fd5e9ef7c1b361016dbcc64bfdb39bff33bd7bffff9f32f223a49b713d4a0508ba95bba610b2b9bc72741318576de12cb226b08ab949d5ab8a5153c85e2c2b47d0b1b25a7d0be696c75539bd35d7dc1d0462ccbf684a7db96abd0913c2baf64574c23bba05bc5ac085fb3574de39ca1999ae50d2ab4a3e83bf25aa1f68a261ca392b33ccdd15c6f5a781a0c8d29d4163c4c6b65516135688972d9b197b52204aee1686aae2b4a1a0c7749c359dfd38deca86d18a00d70184acee8254b78be03d04ca4d050bee6f08ce7e8566970188af12144c61b56a831dd37a7506cd42e6a296aa43d2aeda68e04ed5368770d6ec4714425afbb5e8af6d29e2429b45fa536dac9bba7556aa156f893d72d6dd237173467562072703d6f178431271c9dcfd5cb98775377597a536a98513a971b632e47f3b82f651ddfd0dcec826d6e88b29b1df55dcf362f39765973bc0ad462963001db5a149ed0ed81a2b6287c03c16c5a16862fed39bc1cda9cd64bc2811a52b229bf7d4fb27cd677e1a0eb4e42713005c7651c8ea9d44471de65554a06bbe7554a51339253d2bc916a6921cc28aea45bbb89a573ecad22144ae9ee48987a4822f9ad8ba2e0d94e6500f9b539bbbb184c0a0963069c7cf0ed48f76dcd6e824e835bfdf5595f378a9a93a2d76824416736f54120a1d2591a552821e336b5a85067fa5a043c239c63d971f4433a5fdf4d83912a43749eeb2ac7a05bdffbe676d04544a2870527549aa4296eca7259b3108f63511a5baeaafe0d720d5f56699ab80b3d3b7864dccb0a35bbeb21e438c7e01ee21f77b4600a3423c06361dbb26ceda440be13eff311bd8c7ca19b3bdde8d7585ad674cc9127b6311176f5def5f46dedebfe6d9eb6e9e6764733e1d5b8639bebf0cd54a4c504c1684714904a25ba29bd67c5babcaca7928790704a7e309edab7dac68415c5e2acbdd1a8a992c5d08d78815218b570d0718bbcab924a71ee2257258f4e60c4156cb3ec7bda7cfd546c41b517962644590e90f89934c95f8a2af44182de47abd4684d08efa64a1fd247305fb6dfc314488f8d717a141dff323a6dc6f69d8236aef3284af2e419606d1e3a4f1ced2385025cb49dd94a591be441f13fa4abb24de3b973f9317a06be3682779c1a7862e094902784186b03cf8e2d7798227245a8e48a392b574c5ec8ec92fb76ac0acf6c7c3b7173115614ac9d9987d495794c7be71fd253abd49d89add281fb52e520beed14c3f714be83801b82fa69eac18d1a2883ee21ac0cfc2c0099169b3c0cede75c3a42bd2ea5a90fb787d85a067fdc34d5b6c9da362569194069c2da015a4733ddabd49fd9bf4a0399be553a5e63d525652e82551e10137077120ca624b38c64dc5165c6bb208cbc4bcab0f28e43c6945ea013d58064b1b25453e60feaff353415a8beb1c1e9a6d0e993f462557918d20c1c97946b4453f2f63a74de92085d8154482e4e2f490b0abd4cafe0ad2e80af0601aca777a09e9e1649ef147216d09bac26fbf0631a9a6780351a5ea3b187f47afb850794c74df703ba84dd039af9bd0e7b6903f6e1107b16218970fd40bdeb0ef8b8dbb8ce65ca4ecd85457912328ac46a8cc05a015665039b78c8e64a641607eac3f4716498ae466771a0defc6de87cb58d2bf3d52c5ea33743220d2191e3f7ea887c1d49e43a8a649d4863300432bd9bea3e20f22d74bedb86c8dba86b267283dec15bd0fa624b64baeb937c3792d002e5aa84c6aa915159f9e8232a34d0957a5a3fc2f44f1b68a9212d9574ba25cd2f6d8b684420fe0cc45ffe03d10e537f038d2f8b1488e51f30c910f8d6efef523b97c25d6ace60a438ab54e667ae8c4669a95506fa37da43f770be1f51ecbe94550e8282171a33317a7906f5b2950e5ab6cff3aeffce525b5b6f810d7a77d668a5645fe8c3e3d237b54a0cecad61143d82adc7d25e8fbcebadda4bd2d3a8544e630fe6c127725035d0a712e13339215af0f6394f4d8dbea02fff05504b010214001400000808002578684c9cdd64e6a1020000af0500001700000000000000000000000000000000006d696e696c6f616e2f426f72726f7765722e636c617373504b010214001400000808002578684c82745a30d5050000cc0c00001300000000000000000000000000d60200006d696e696c6f616e2f4c6f616e2e636c617373504b0506000000000200020086000000dc0800000000', '.zip');           
CREATE INDEX "PUBLIC"."PRJRESOURCE_PRJBRANCH" ON "PUBLIC"."PRJRESOURCE"("PROJECT", "BASELINE");
CREATE UNIQUE INDEX "PUBLIC"."PRJRESOURCEUUIDUNIQUE" ON "PUBLIC"."PRJRESOURCE"("UUID", "BASELINE", "ENDID");   
CREATE INDEX "PUBLIC"."FKPRJRESOURCETYPIDX" ON "PUBLIC"."PRJRESOURCE"("TYPE"); 
CREATE INDEX "PUBLIC"."FKPRJRESOURCESTRTDIDX" ON "PUBLIC"."PRJRESOURCE"("STARTID");            
CREATE INDEX "PUBLIC"."FKPRJRESOURCENDDIDX" ON "PUBLIC"."PRJRESOURCE"("ENDID");
CREATE INDEX "PUBLIC"."FKPRJRESOURCEBSLNIDX" ON "PUBLIC"."PRJRESOURCE"("BASELINE");            
CREATE INDEX "PUBLIC"."FKPRJRESOURCEDIDX" ON "PUBLIC"."PRJRESOURCE"("UUID");   
CREATE INDEX "PUBLIC"."FKPRJRESOURCERLPCKGIDX" ON "PUBLIC"."PRJRESOURCE"("RULEPACKAGE");       
CREATE CACHED TABLE "PUBLIC"."RPLFTRGT"(
    "ID" INTEGER NOT NULL,
    "LFT" INTEGER NOT NULL,
    "RGT" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL
); 
ALTER TABLE "PUBLIC"."RPLFTRGT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_53" PRIMARY KEY("ID", "BASELINE");         
-- 30 +/- SELECT COUNT(*) FROM PUBLIC.RPLFTRGT;
INSERT INTO "PUBLIC"."RPLFTRGT" VALUES
(1, 1, 2, 1),
(2, 1, 6, 4),
(3, 4, 5, 4),
(4, 2, 3, 4),
(5, 1, 2, 7),
(6, 3, 4, 7),
(7, 1, 2, 10),
(8, 1, 2, 13),
(9, 1, 2, 16),
(10, 3, 4, 16),
(11, 5, 6, 16),
(9, 1, 2, 19),
(10, 3, 4, 19),
(11, 5, 6, 19),
(1, 1, 2, 20),
(2, 1, 6, 21),
(3, 4, 5, 21),
(4, 2, 3, 21),
(5, 1, 2, 22),
(6, 3, 4, 22),
(7, 1, 2, 23),
(8, 1, 2, 24),
(1, 1, 2, 25),
(2, 1, 6, 26),
(3, 4, 5, 26),
(4, 2, 3, 26),
(5, 1, 2, 27),
(6, 3, 4, 27),
(7, 1, 2, 28),
(8, 1, 2, 29);         
CREATE INDEX "PUBLIC"."FOLDERLFTRGTIDX" ON "PUBLIC"."RPLFTRGT"("BASELINE", "LFT", "RGT");      
CREATE INDEX "PUBLIC"."FKRPLFTRGTDIDX" ON "PUBLIC"."RPLFTRGT"("ID");           
CREATE INDEX "PUBLIC"."FKRPLFTRGTBSLNIDX" ON "PUBLIC"."RPLFTRGT"("BASELINE");  
CREATE CACHED TABLE "PUBLIC"."RULEFLOW"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER,
    "BODY" CLOB(52428800),
    "DIAGRAM" CLOB(52428800),
    "FINALACTIONS" CLOB(52428800),
    "IMPORTS" CLOB(52428800),
    "INITIALACTIONS" CLOB(52428800),
    "LOCALE" VARCHAR(30),
    "MAINFLOWTASK" BOOLEAN
);     
ALTER TABLE "PUBLIC"."RULEFLOW" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_5C" PRIMARY KEY("ID");     
-- 4 +/- SELECT COUNT(*) FROM PUBLIC.RULEFLOW; 
INSERT INTO "PUBLIC"."RULEFLOW" VALUES
(1, 51, 56, 2147483647, 1, 7, 'eligibilityFlow', '966338e1-cfde-4e21-861b-3a7335ff0df2', NULL, NULL, NULL, 3, STRINGDECODE('<Ruleflow xmlns=\"http://schemas.ilog.com/Rules/7.0/Ruleflow\">\n  <Body>\n    <TaskList>\n      <StartTask Identifier=\"task_6\">\n        <Actions Language=\"bal\"><![CDATA[print \"Computing eligibility for score: \" + ''the score'';]]></Actions>\n      </StartTask>\n      <ActionTask Identifier=\"initResult\">\n        <Actions Language=\"irl\"><![CDATA[report = new loan.Report(borrower,loan);\nreport.approved = true;]]></Actions>\n      </ActionTask>\n      <RuleTask ExecutionMode=\"Fastpath\" ExitCriteria=\"None\" Identifier=\"eligibility\" Ordering=\"Default\">\n        <RuleList>\n          <Package Name=\"eligibility\"/>\n        </RuleList>\n      </RuleTask>\n      <StopTask Identifier=\"task_5\">\n        <Actions Language=\"irl\"><![CDATA[note(borrower.toString());\nnote(loan.toString());\nnote(report.toString());]]></Actions>\n      </StopTask>\n    </TaskList>\n    <NodeList>\n      <TaskNode Identifier=\"node_1\" Task=\"initResult\"/>\n      <TaskNode Identifier=\"node_6\" Task=\"task_6\"/>\n      <TaskNode Identifier=\"node_9\" Task=\"eligibility\"/>\n      <TaskNode Identifier=\"node_10\" Task=\"task_5\"/>\n    </NodeList>\n    <TransitionList>\n      <Transition Identifier=\"transition_7\" Source=\"node_6\" Target=\"node_1\"/>\n      <Transition Identifier=\"transition_3\" Source=\"node_1\" Target=\"node_9\"/>\n      <Transition Identifier=\"transition_4\" Source=\"node_9\" Target=\"node_10\"/>\n    </TransitionList>\n  </Body>\n  <Resources>\n    <ResourceSet Locale=\"en_US\">\n      <Data Name=\"node_1#x\">162.5</Data>\n      <Data Name=\"node_1#y\">110.0</Data>\n      <Data Name=\"node_10#height\">22.0</Data>\n      <Data Name=\"node_6#x\">162.5</Data>\n      <Data Name=\"node_9#height\">40.0</Data>\n      <Data Name=\"node_6#y\">20.0</Data>\n      <Data Name=\"node_10#x\">162.5</Data>\n      <Data Name=\"node_6#height\">21.0</Data>\n      <Data Name=\"node_9#x\">162.5</Data>\n      <Data Name=\"node_10#y\">281.0</Data>\n      <Data Name=\"node_10#name\">node_2</Data>\n      <Data Name=\"node_9#y\">200.0</Data>\n      <Data Name=\"node_9#name\">node_1</Data>\n      <Data Name=\"node_6#name\">node_6</Data>\n      <Data Name=\"node_1#height\">40.0</Data>\n      <Data Name=\"node_1#width\">101.0</Data>\n      <Data Name=\"node_1#name\">node_1</Data>\n      <Data Name=\"node_6#width\">21.0</Data>\n      <Data Name=\"node_10#width\">22.0</Data>\n      <Data Name=\"node_9#width\">102.0</Data>\n    </ResourceSet>\n  </Resources>\n  <Properties>\n    <imports><![CDATA[import loan.Borrower;]]>&#13;\nimport loan.LoanRequest;&#13;\nimport loan.DateUtil;&#13;\nimport java.util.Calendar;&#13;\nuse borrower;\nuse loan;\nuse report;\n</imports>\n  </Properties>\n</Ruleflow>\n'), NULL, NULL, NULL, NULL, 'en_US', FALSE),
(2, 51, 76, 2147483647, 2, 10, 'computationFlow', 'bfad24fb-ca9b-4564-80c1-8ac1fcce01c2', NULL, NULL, NULL, 4, STRINGDECODE('<Ruleflow xmlns=\"http://schemas.ilog.com/Rules/7.0/Ruleflow\">\n  <Body>\n    <TaskList>\n      <StartTask Identifier=\"task_0\"/>\n      <ActionTask Identifier=\"initResult\">\n        <Actions Language=\"irl\"><![CDATA[report = new loan.Report(borrower,loan);\nreport.approved = true;]]></Actions>\n      </ActionTask>\n      <RuleTask ExecutionMode=\"RetePlus\" ExitCriteria=\"None\" Identifier=\"computation\" Ordering=\"Default\">\n        <RuleList>\n          <Package Name=\"computation\"/>\n        </RuleList>\n      </RuleTask>\n      <StopTask Identifier=\"task_1\">\n        <Actions Language=\"bal\"><![CDATA[print \"Score: \" + ''the score'';]]></Actions>\n      </StopTask>\n    </TaskList>\n    <NodeList>\n      <TaskNode Identifier=\"node_0\" Task=\"task_0\"/>\n      <TaskNode Identifier=\"node_1\" Task=\"task_1\"/>\n      <TaskNode Identifier=\"node_2\" Task=\"initResult\"/>\n      <TaskNode Identifier=\"node_3\" Task=\"computation\"/>\n    </NodeList>\n    <TransitionList>\n      <Transition Identifier=\"transition_0\" Source=\"node_0\" Target=\"node_2\"/>\n      <Transition Identifier=\"transition_1\" Source=\"node_2\" Target=\"node_3\"/>\n      <Transition Identifier=\"transition_3\" Source=\"node_3\" Target=\"node_1\"/>\n    </TransitionList>\n  </Body>\n  <Resources>\n    <ResourceSet Locale=\"en_US\">\n      <Data Name=\"node_0#x\">53.686523</Data>\n      <Data Name=\"node_0#y\">10.5</Data>\n      <Data Name=\"node_1#x\">53.686527252197266</Data>\n      <Data Name=\"node_1#y\">261.0</Data>\n      <Data Name=\"node_2#x\">53.6865234375</Data>\n      <Data Name=\"node_3#x\">53.6865234375</Data>\n      <Data Name=\"node_2#y\">91.0</Data>\n      <Data Name=\"node_3#y\">181.0</Data>\n      <Data Name=\"node_3#height\">40.0</Data>\n      <Data Name=\"node_2#height\">40.0</Data>\n      <Data Name=\"node_0#width\">21.0</Data>\n      <Data Name=\"node_1#height\">22.0</Data>\n      <Data Name=\"node_0#height\">21.0</Data>\n      <Data Name=\"node_1#width\">22.000008</Data>\n      <Data Name=\"node_3#name\">node_3</Data>\n      <Data Name=\"node_2#width\">101.0</Data>\n      <Data Name=\"node_3#width\">107.37305</Data>\n      <Data Name=\"node_2#name\">node_1</Data>\n      <Data Name=\"node_1#name\">node_2</Data>\n      <Data Name=\"node_0#name\">node_0</Data>\n    </ResourceSet>\n  </Resources>\n  <Properties>\n    <imports><![CDATA[import loan.Borrower;]]>&#13;\nimport loan.LoanRequest;&#13;\nimport loan.DateUtil;&#13;\nimport java.util.Calendar;&#13;\nuse borrower;\nuse loan;\nuse report;\n</imports>\n  </Properties>\n</Ruleflow>\n'), NULL, NULL, NULL, NULL, 'en_US', FALSE);   
INSERT INTO SYSTEM_LOB_STREAM VALUES(2, 0, STRINGDECODE('<Ruleflow xmlns=\"http://schemas.ilog.com/Rules/7.0/Ruleflow\">\n  <Body>\n    <TaskList>\n      <StartTask Identifier=\"task_6\">\n        <Actions Language=\"irl\"><![CDATA[ /*]]>&#13;\nborrower = new Borrower(\"John\",\"Doe\",DateUtil.makeDate(1968,Calendar.MAY,12),\"123456789\");&#13;\nborrower.zipCode = \"91320\";&#13;\nborrower.creditScore = 600;&#13;\nborrower.yearlyIncome = 100000;&#13;\n&#13;\nloan = new Loan(DateUtil.makeDate(2005,Calendar.JUNE,1),72,100000,0.7d);&#13;\n*/</Actions>\n      </StartTask>\n      <RuleTask ExecutionMode=\"RetePlus\" ExitCriteria=\"None\" Identifier=\"computation\" Ordering=\"Default\">\n        <RuleList>\n          <Package Name=\"computation\"/>\n        </RuleList>\n      </RuleTask>\n      <RuleTask ExecutionMode=\"RetePlus\" ExitCriteria=\"None\" Identifier=\"insurance\" Ordering=\"Default\">\n        <RuleList>\n          <Package Name=\"insurance\"/>\n        </RuleList>\n      </RuleTask>\n      <ActionTask Identifier=\"initResult\">\n        <Actions Language=\"irl\"><![CDATA[report = new loan.Report(borrower,loan);\nreport.approved = true;]]></Actions>\n      </ActionTask>\n      <RuleTask ExecutionMode=\"RetePlus\" ExitCriteria=\"None\" Identifier=\"validation\" Ordering=\"Default\">\n        <RuleList>\n          <Package Name=\"validation\"/>\n        </RuleList>\n      </RuleTask>\n      <RuleTask ExecutionMode=\"RetePlus\" ExitCriteria=\"None\" Identifier=\"eligibility\" Ordering=\"Default\">\n        <RuleList>\n          <Package Name=\"eligibility\"/>\n        </RuleList>\n      </RuleTask>\n      <StopTask Identifier=\"task_5\">\n        <Actions Language=\"irl\"><![CDATA[note(borrower.toString());\nnote(loan.toString());\nnote(report.toString());]]></Actions>\n      </StopTask>\n    </TaskList>\n    <NodeList>\n      <TaskNode Identifier=\"node_0\" Task=\"task_5\"/>\n      <TaskNode Identifier=\"node_1\" Task=\"initResult\"/>\n      <TaskNode Identifier=\"node_2\" Task=\"validation\"/>\n      <TaskNode Identifier=\"node_3\" Task=\"computation\"/>\n      <TaskNode Identifier=\"node_4\" Task=\"eligibility\"/>\n      <TaskNode Identifier=\"node_5\" Task=\"insurance\"/>\n      <TaskNode Identifier=\"node_6\" Task=\"task_6\"/>\n    </NodeList>\n    <TransitionList>\n      <Transition Identifier=\"transition_0\" Source=\"node_1\" Target=\"node_2\"/>\n      <Transition Identifier=\"transition_1\" Source=\"node_2\" Target=\"node_3\">\n        <Conditions Language=\"bal\"><![CDATA[''the loan report'' is valid data]]></Conditions>\n      </Transition>\n      <Transition Identifier=\"transition_2\" Source=\"node_3\" Target=\"node_4\"/>\n      <Transition Identifier=\"transition_3\" Source=\"node_4\" Target=\"node_5\">\n        <Conditions Language=\"bal\"><![CDATA[''the loan report'' is approved]]></Conditions>\n      </Transition>\n      <Transition Identifier=\"transition_4\" Source=\"node_5\" Target=\"node_0\"/>\n      <Transition Identifier=\"transition_5\" Source=\"node_2\" Target=\"node_0\"/>\n      <Transition Identifier=\"transition_6\" Source=\"node_4\" Target=\"node_0\"/>\n      <Transition Identifier=\"transition_7\" Source=\"node_6\" Target=\"node_1\"/>\n    </TransitionList>\n  </Body>\n  <Resources>\n    <ResourceSet Locale=\"en_US\">\n      <Data Name=\"node_5#height\">38.0</Data>\n      <Data Name=\"node_3#height\">38.0</Data>\n      <Data Name=\"node_6#name\">node_6</Data>\n      <Data Name=\"node_1#height\">38.0</Data>\n      <Data Name=\"node_4#name\">node_4</Data>\n      <Data Name=\"node_2#name\">node_2</Data>\n      <Data Name=\"node_0#name\">node_0</Data>\n      <Data Name=\"node_0#x\">90.43652</Data>\n      <Data Name=\"node_1#x\">109.31152</Data>\n      <Data Name=\"node_0#y\">522.5</Data>\n      <Data Name=\"node_2#x\">109.31152</Data>\n      <Data Name=\"node_1#y\">90.0</Data>\n      <Data Name=\"node_2#y\">178.0</Data>\n      <Data Name=\"node_3#x\">52.686523</Data>\n      <Data Name=\"node_3#y\">266.0</Data>\n      <Data Name=\"node_4#x\">52.686523</Data>\n      <Data Name=\"node_5#x\">90.43652</Data>\n      <Data Name=\"node_4#y\">352.0</Data>\n      <Data Name=\"node_6#x\">109.31152</Data>\n      <Data Name=\"node_5#y\">442.0</Data>\n      <Data Name=\"node_6#y\">10.5</Data>\n      <Data Name=\"node_6#height\">21.0</Data>\n      <Data Name=\"node_4#height\">40.0</Data>\n      <Data Name=\"node_2#height\">38.0</Data>\n      <D'), NULL);           
INSERT INTO SYSTEM_LOB_STREAM VALUES(2, 1, STRINGDECODE('ata Name=\"node_5#name\">node_5</Data>\n      <Data Name=\"node_0#width\">23.0</Data>\n      <Data Name=\"node_1#width\">101.0</Data>\n      <Data Name=\"node_0#height\">23.0</Data>\n      <Data Name=\"transition_1#label\">data valid</Data>\n      <Data Name=\"node_2#width\">101.0</Data>\n      <Data Name=\"node_3#name\">node_3</Data>\n      <Data Name=\"node_3#width\">105.37305</Data>\n      <Data Name=\"transition_3#label\">loan approved</Data>\n      <Data Name=\"node_1#name\">node_1</Data>\n      <Data Name=\"node_4#width\">101.0</Data>\n      <Data Name=\"node_5#width\">101.0</Data>\n      <Data Name=\"node_6#width\">21.0</Data>\n    </ResourceSet>\n  </Resources>\n  <Properties>\n    <imports><![CDATA[import loan.Borrower;]]>&#13;\nimport loan.LoanRequest;&#13;\nimport loan.DateUtil;&#13;\nimport java.util.Calendar;&#13;\nuse borrower;\nuse loan;\nuse report;\n</imports>\n    <advancedProperties Identifier=\"validation\"><![CDATA[\n]]></advancedProperties>\n  </Properties>\n</Ruleflow>\n'), NULL);            
INSERT INTO "PUBLIC"."RULEFLOW" VALUES
(3, 51, 90, 2147483647, 3, 13, 'loanvalidation', 'f5dc0b49-f2a1-467d-abb0-059d6e0d5c62', NULL, NULL, NULL, 5, SYSTEM_COMBINE_CLOB(2), NULL, NULL, NULL, NULL, 'en_US', FALSE),
(4, 51, 330, 2147483647, 4, 16, 'miniloan', 'f52ba17a-2a7e-4caa-9092-fecf906fcd6d', NULL, NULL, NULL, 6, STRINGDECODE('<Ruleflow xmlns=\"http://schemas.ilog.com/Rules/7.0/Ruleflow\">\n  <Body>\n    <TaskList>\n      <StartTask Identifier=\"task_3\"/>\n      <RuleTask ExecutionMode=\"Fastpath\" ExitCriteria=\"None\" Identifier=\"validation\" Ordering=\"Default\">\n        <RuleList>\n          <Package Name=\"validation\"/>\n        </RuleList>\n      </RuleTask>\n      <RuleTask ExecutionMode=\"RetePlus\" ExitCriteria=\"None\" Identifier=\"eligibility\" Ordering=\"Default\">\n        <RuleList>\n          <Package Name=\"eligibility\"/>\n        </RuleList>\n      </RuleTask>\n      <StopTask Identifier=\"task_2\">\n        <Actions Language=\"bal\"><![CDATA[print the approval status of ''the loan'' ; ]]>&#13;\n</Actions>\n      </StopTask>\n    </TaskList>\n    <NodeList>\n      <TaskNode Identifier=\"node_0\" Task=\"task_3\"/>\n      <TaskNode Identifier=\"node_1\" Task=\"task_2\"/>\n      <TaskNode Identifier=\"node_2\" Task=\"validation\"/>\n      <TaskNode Identifier=\"node_3\" Task=\"eligibility\"/>\n    </NodeList>\n    <TransitionList>\n      <Transition Identifier=\"transition_0\" Source=\"node_0\" Target=\"node_2\"/>\n      <Transition Identifier=\"transition_1\" Source=\"node_2\" Target=\"node_3\">\n        <Conditions Language=\"bal\"><![CDATA[''the loan'' is approved ]]></Conditions>\n      </Transition>\n      <Transition Identifier=\"transition_2\" Source=\"node_3\" Target=\"node_1\"/>\n      <Transition Identifier=\"transition_3\" Source=\"node_2\" Target=\"node_1\"/>\n    </TransitionList>\n  </Body>\n  <Resources>\n    <ResourceSet Locale=\"en_US\">\n      <Data Name=\"transition_1#label\">data approved</Data>\n      <Data Name=\"node_0#height\">21.0</Data>\n      <Data Name=\"node_2#name\">node_2</Data>\n      <Data Name=\"node_3#y\">178.0</Data>\n      <Data Name=\"node_3#name\">node_3</Data>\n      <Data Name=\"node_1#name\">node_1</Data>\n      <Data Name=\"node_3#x\">67.796875</Data>\n      <Data Name=\"node_0#y\">26.0</Data>\n      <Data Name=\"node_0#x\">89.69531</Data>\n      <Data Name=\"node_1#x\">97.69531</Data>\n      <Data Name=\"node_1#y\">255.0</Data>\n      <Data Name=\"node_1#width\">23.0</Data>\n      <Data Name=\"node_1#height\">23.0</Data>\n      <Data Name=\"node_2#x\">98.6953125</Data>\n      <Data Name=\"node_2#y\">106.0</Data>\n      <Data Name=\"node_0#width\">21.0</Data>\n      <Data Name=\"node_0#name\">node_0</Data>\n    </ResourceSet>\n  </Resources>\n  <Properties>\n    <imports><![CDATA[use loan;\n]]></imports>\n  </Properties>\n</Ruleflow>\n'), NULL, NULL, NULL, NULL, 'en_US', FALSE);
CREATE INDEX "PUBLIC"."RULEFLOW_PRJBRANCH" ON "PUBLIC"."RULEFLOW"("PROJECT", "BASELINE");      
CREATE UNIQUE INDEX "PUBLIC"."RULEFLOWUUIDUNIQUE" ON "PUBLIC"."RULEFLOW"("UUID", "BASELINE", "ENDID");         
CREATE INDEX "PUBLIC"."FKRULEFLOWTYPIDX" ON "PUBLIC"."RULEFLOW"("TYPE");       
CREATE INDEX "PUBLIC"."FKRULEFLOWSTRTDIDX" ON "PUBLIC"."RULEFLOW"("STARTID");  
CREATE INDEX "PUBLIC"."FKRULEFLOWNDDIDX" ON "PUBLIC"."RULEFLOW"("ENDID");      
CREATE INDEX "PUBLIC"."FKRULEFLOWBSLNIDX" ON "PUBLIC"."RULEFLOW"("BASELINE");  
CREATE INDEX "PUBLIC"."FKRULEFLOWDIDX" ON "PUBLIC"."RULEFLOW"("UUID");         
CREATE INDEX "PUBLIC"."FKRULEFLOWRLPCKGIDX" ON "PUBLIC"."RULEFLOW"("RULEPACKAGE");             
CREATE CACHED TABLE "PUBLIC"."RULEFLOWSIBLING"(
    "ID" INTEGER NOT NULL
);   
ALTER TABLE "PUBLIC"."RULEFLOWSIBLING" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_9A" PRIMARY KEY("ID");              
-- 4 +/- SELECT COUNT(*) FROM PUBLIC.RULEFLOWSIBLING;          
INSERT INTO "PUBLIC"."RULEFLOWSIBLING" VALUES
(1),
(2),
(3),
(4);              
CREATE CACHED TABLE "PUBLIC"."OPERATION"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER,
    "ADVANCEDPROPERTIES" CLOB(52428800),
    "BUSINESSDISPLAYNAME" VARCHAR(100),
    "DESCRIPTION" VARCHAR(255),
    "ENGINECONFIGURATIONFILE" VARCHAR(255),
    "EXTRACTOR" VARCHAR(100),
    "RULEFLOW" INTEGER,
    "RULESETNAME" VARCHAR(100),
    "RULESETPROPERTIES" CLOB(52428800),
    "TARGETRULEPROJECT" INTEGER,
    "USINGEXTRACTOR" BOOLEAN,
    "USINGRULEFLOW" BOOLEAN
);  
ALTER TABLE "PUBLIC"."OPERATION" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_93" PRIMARY KEY("ID");    
-- 12 +/- SELECT COUNT(*) FROM PUBLIC.OPERATION;               
INSERT INTO "PUBLIC"."OPERATION" VALUES
(1, 108, 57, 59, 1, 7, 'eligibility', 'bfd94025-3f29-48be-81b9-9eb2676f252f', NULL, STRINGDECODE('Used for testing eligibility rules contained in the ''Loan Validation Determination'' project.\nNo rule extraction is applied.\nIt takes as inputs a borrower, a loan request, and a score.\nIt outputs the loan report and the grade.\n\n'), NULL, 3, NULL, NULL, NULL, NULL, 'unchecked determination_extractor', NULL, 'determination_test', NULL, 3, TRUE, TRUE),
(2, 108, 59, 2147483647, 1, 7, 'eligibility', 'bfd94025-3f29-48be-81b9-9eb2676f252f', NULL, STRINGDECODE('Used for testing eligibility rules contained in the ''Loan Validation Determination'' project.\nNo rule extraction is applied.\nIt takes as inputs a borrower, a loan request, and a score.\nIt outputs the loan report and the grade.\n\n'), NULL, 3, '', NULL, NULL, NULL, 'unchecked determination_extractor', 1, 'determination_test', '', 3, TRUE, TRUE),
(3, 108, 77, 79, 3, 10, 'scoring', '51e8a165-61db-4065-99fc-292399966857', NULL, STRINGDECODE('Used for testing  the scoring rules\nThe rules used are contained in the ''Loan Validation Scoring'' project, and no rule extraction is applied.\nIt takes as inputs a borrower and a loan request and outputs the loan report and the computed scoring.\n\n'), NULL, 4, NULL, NULL, NULL, NULL, 'computation-test_extractor', NULL, 'computation_test', NULL, 4, TRUE, TRUE),
(4, 108, 79, 2147483647, 3, 10, 'scoring', '51e8a165-61db-4065-99fc-292399966857', NULL, STRINGDECODE('Used for testing  the scoring rules\nThe rules used are contained in the ''Loan Validation Scoring'' project, and no rule extraction is applied.\nIt takes as inputs a borrower and a loan request and outputs the loan report and the computed scoring.\n\n'), NULL, 4, '', NULL, NULL, NULL, 'computation-test_extractor', 2, 'computation_test', '', 4, TRUE, TRUE),
(5, 108, 95, 224, 5, 13, 'loan validation with score and grade', '9017e68b-1f53-496e-998f-5d41393e1c84', NULL, STRINGDECODE('Used for testing and simulation:\n-  input a loan request and a borrower\n- output the loan report, the grade, and the score.\nRules from  projects : Check, Determination, Scoring\nwith no extraction mechanism.\n'), NULL, 5, NULL, NULL, NULL, NULL, 'loan validation with score and grade_extractor', NULL, 'loan_validation_with_score_and_grade', NULL, 5, TRUE, TRUE),
(6, 108, 96, 225, 6, 13, 'loan validation production', '7e5cbd47-fb79-4430-a17c-85ec1b2ebe6c', NULL, STRINGDECODE('Used in production\n   - input a loan request and a borrower\n   - output the loan report.\nRules from projects : Check, Determination and Scoring\nwith an extraction mechanism through a query: only rules with the validated status are used.\n'), NULL, 5, NULL, NULL, NULL, NULL, 'validated rules operation_extractor', NULL, 'loan_validation_production', NULL, 5, TRUE, TRUE),
(7, 108, 224, 2147483647, 5, 13, 'loan validation with score and grade', '9017e68b-1f53-496e-998f-5d41393e1c84', NULL, STRINGDECODE('Used for testing and simulation:\n-  input a loan request and a borrower\n- output the loan report, the grade, and the score.\nRules from  projects : Check, Determination, Scoring\nwith no extraction mechanism.\n'), NULL, 5, '', NULL, NULL, NULL, 'loan validation with score and grade_extractor', 3, 'loan_validation_with_score_and_grade', '', 5, TRUE, TRUE),
(8, 108, 225, 2147483647, 6, 13, 'loan validation production', '7e5cbd47-fb79-4430-a17c-85ec1b2ebe6c', NULL, STRINGDECODE('Used in production\n   - input a loan request and a borrower\n   - output the loan report.\nRules from projects : Check, Determination and Scoring\nwith an extraction mechanism through a query: only rules with the validated status are used.\n'), NULL, 5, '', NULL, NULL, NULL, 'validated rules operation_extractor', 3, 'loan_validation_production', '', 5, TRUE, TRUE),
(9, 108, 334, 348, 9, 16, 'Miniloan ServiceOperation', '30b58bec-77bb-430f-a9dd-2ed16dfa4426', NULL, NULL, NULL, 6, NULL, NULL, NULL, NULL, 'Miniloan ServiceOperation_extractor', NULL, 'Miniloan_ServiceRuleset', NULL, 6, TRUE, TRUE),
(10, 108, 348, 349, 9, 16, 'Miniloan ServiceOperation', '30b58bec-77bb-430f-a9dd-2ed16dfa4426', NULL, NULL, NULL, 6, '', NULL, NULL, NULL, 'Miniloan ServiceOperation_extractor', 4, 'Miniloan_ServiceRuleset', '', 6, TRUE, TRUE);            
INSERT INTO "PUBLIC"."OPERATION" VALUES
(11, 108, 349, 350, 9, 16, 'Miniloan ServiceOperation', '30b58bec-77bb-430f-a9dd-2ed16dfa4426', NULL, NULL, NULL, 6, '', NULL, NULL, NULL, 'Miniloan ServiceOperation_extractor', 4, 'Miniloan_ServiceRuleset', '', 6, TRUE, TRUE),
(12, 108, 350, 2147483647, 9, 16, 'Miniloan ServiceOperation', '30b58bec-77bb-430f-a9dd-2ed16dfa4426', NULL, NULL, NULL, 6, '', NULL, NULL, NULL, 'Miniloan ServiceOperation_extractor', 4, 'Miniloan_ServiceRuleset', '', 6, TRUE, TRUE);         
CREATE INDEX "PUBLIC"."OPERATION_PRJBRANCH" ON "PUBLIC"."OPERATION"("PROJECT", "BASELINE");    
CREATE UNIQUE INDEX "PUBLIC"."OPERATIONUUIDUNIQUE" ON "PUBLIC"."OPERATION"("UUID", "BASELINE", "ENDID");       
CREATE INDEX "PUBLIC"."FKOPERATIONTYPIDX" ON "PUBLIC"."OPERATION"("TYPE");     
CREATE INDEX "PUBLIC"."FKOPERATIONSTRTDIDX" ON "PUBLIC"."OPERATION"("STARTID");
CREATE INDEX "PUBLIC"."FKOPERATIONNDDIDX" ON "PUBLIC"."OPERATION"("ENDID");    
CREATE INDEX "PUBLIC"."FKOPERATIONBSLNIDX" ON "PUBLIC"."OPERATION"("BASELINE");
CREATE INDEX "PUBLIC"."FKOPERATIONDIDX" ON "PUBLIC"."OPERATION"("UUID");       
CREATE INDEX "PUBLIC"."FKOPERATIONRLPCKGIDX" ON "PUBLIC"."OPERATION"("RULEPACKAGE");           
CREATE INDEX "PUBLIC"."FKOPERATIONRLFLWIDX" ON "PUBLIC"."OPERATION"("RULEFLOW");               
CREATE CACHED TABLE "PUBLIC"."DEPOPERATION"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "ACTIVE" BOOLEAN NOT NULL,
    "OPERATION" INTEGER,
    "OPERATIONNAME" VARCHAR(255) NOT NULL,
    "CONTAINER" INTEGER NOT NULL
);  
ALTER TABLE "PUBLIC"."DEPOPERATION" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_8C" PRIMARY KEY("ID"); 
-- 8 +/- SELECT COUNT(*) FROM PUBLIC.DEPOPERATION;             
INSERT INTO "PUBLIC"."DEPOPERATION" VALUES
(1, 113, 93, 226, 1, 13, FALSE, NULL, 'loan validation with score and grade', 1),
(2, 113, 93, 266, 2, 13, FALSE, NULL, 'loan validation production', 1),
(3, 113, 94, 272, 3, 13, FALSE, NULL, 'loan validation production', 2),
(4, 113, 226, 2147483647, 1, 13, FALSE, 5, 'loan validation with score and grade', 1),
(5, 113, 266, 2147483647, 2, 13, FALSE, 6, 'loan validation production', 1),
(6, 113, 272, 2147483647, 3, 13, FALSE, 6, 'loan validation production', 2),
(7, 113, 333, 351, 7, 16, FALSE, NULL, 'Miniloan ServiceOperation', 25),
(8, 113, 351, 2147483647, 7, 16, FALSE, 9, 'Miniloan ServiceOperation', 25);            
CREATE INDEX "PUBLIC"."DEPOP_CONTAINER" ON "PUBLIC"."DEPOPERATION"("CONTAINER");               
CREATE INDEX "PUBLIC"."FKDEPOPTYPIDX" ON "PUBLIC"."DEPOPERATION"("TYPE");      
CREATE INDEX "PUBLIC"."FKDEPOPSTRTDIDX" ON "PUBLIC"."DEPOPERATION"("STARTID"); 
CREATE INDEX "PUBLIC"."FKDEPOPNDDIDX" ON "PUBLIC"."DEPOPERATION"("ENDID");     
CREATE INDEX "PUBLIC"."FKDEPOPBSLNIDX" ON "PUBLIC"."DEPOPERATION"("BASELINE"); 
CREATE INDEX "PUBLIC"."FKDEPOPPRTNIDX" ON "PUBLIC"."DEPOPERATION"("OPERATION");
CREATE CACHED TABLE "PUBLIC"."DEPOPERATIONPROPERTY"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "VALUE" CLOB(52428800),
    "OPERATIONREFERENCE" INTEGER,
    "CONTAINER" INTEGER NOT NULL
);             
ALTER TABLE "PUBLIC"."DEPOPERATIONPROPERTY" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_64" PRIMARY KEY("ID");         
-- 54 +/- SELECT COUNT(*) FROM PUBLIC.DEPOPERATIONPROPERTY;    
INSERT INTO "PUBLIC"."DEPOPERATIONPROPERTY" VALUES
(1, 115, 93, 227, 1, 13, 'ruleset.version', '1.0', NULL, 1),
(2, 115, 93, 228, 2, 13, 'com.ibm.rules.engine.bytecode.generation', 'true', NULL, 1),
(3, 115, 93, 229, 3, 13, 'ruleset.trace.enabled', 'false', NULL, 1),
(4, 115, 93, 230, 4, 13, 'bai.emitter.enabled', 'true', NULL, 1),
(5, 115, 93, 231, 5, 13, 'ruleset.debug.enabled', 'true', NULL, 1),
(6, 115, 93, 232, 6, 13, 'ruleset.status', 'enabled', NULL, 1),
(7, 115, 93, 233, 7, 13, 'bai.emitter.input', 'true', NULL, 1),
(8, 115, 93, 267, 8, 13, 'ruleset.version', '1.0', NULL, 1),
(9, 115, 93, 268, 9, 13, 'com.ibm.rules.engine.bytecode.generation', 'true', NULL, 1),
(10, 115, 93, 269, 10, 13, 'ruleset.trace.enabled', 'false', NULL, 1),
(11, 115, 93, 270, 11, 13, 'ruleset.debug.enabled', 'true', NULL, 1),
(12, 115, 93, 271, 12, 13, 'ruleset.status', 'enabled', NULL, 1),
(13, 115, 94, 273, 13, 13, 'ruleset.version', '1.0', NULL, 2),
(14, 115, 94, 274, 14, 13, 'com.ibm.rules.engine.bytecode.generation', 'true', NULL, 2),
(15, 115, 94, 275, 15, 13, 'ruleset.trace.enabled', 'false', NULL, 2),
(16, 115, 94, 276, 16, 13, 'bai.emitter.enabled', 'true', NULL, 2),
(17, 115, 94, 277, 17, 13, 'ruleset.debug.enabled', 'false', NULL, 2),
(18, 115, 94, 278, 18, 13, 'ruleset.status', 'enabled', NULL, 2),
(19, 115, 94, 279, 19, 13, 'bai.emitter.input', 'true', NULL, 2),
(20, 115, 227, 2147483647, 1, 13, 'ruleset.version', '1.0', 5, 1),
(21, 115, 228, 2147483647, 2, 13, 'com.ibm.rules.engine.bytecode.generation', 'true', 5, 1),
(22, 115, 229, 2147483647, 3, 13, 'ruleset.trace.enabled', 'false', 5, 1),
(23, 115, 230, 2147483647, 4, 13, 'bai.emitter.enabled', 'true', 5, 1),
(24, 115, 231, 2147483647, 5, 13, 'ruleset.debug.enabled', 'true', 5, 1),
(25, 115, 232, 2147483647, 6, 13, 'ruleset.status', 'enabled', 5, 1),
(26, 115, 233, 2147483647, 7, 13, 'bai.emitter.input', 'true', 5, 1),
(27, 115, 267, 2147483647, 8, 13, 'ruleset.version', '1.0', 6, 1),
(28, 115, 268, 2147483647, 9, 13, 'com.ibm.rules.engine.bytecode.generation', 'true', 6, 1),
(29, 115, 269, 2147483647, 10, 13, 'ruleset.trace.enabled', 'false', 6, 1),
(30, 115, 270, 2147483647, 11, 13, 'ruleset.debug.enabled', 'true', 6, 1),
(31, 115, 271, 2147483647, 12, 13, 'ruleset.status', 'enabled', 6, 1),
(32, 115, 273, 2147483647, 13, 13, 'ruleset.version', '1.0', 6, 2),
(33, 115, 274, 2147483647, 14, 13, 'com.ibm.rules.engine.bytecode.generation', 'true', 6, 2),
(34, 115, 275, 2147483647, 15, 13, 'ruleset.trace.enabled', 'false', 6, 2),
(35, 115, 276, 2147483647, 16, 13, 'bai.emitter.enabled', 'true', 6, 2),
(36, 115, 277, 2147483647, 17, 13, 'ruleset.debug.enabled', 'false', 6, 2),
(37, 115, 278, 2147483647, 18, 13, 'ruleset.status', 'enabled', 6, 2),
(38, 115, 279, 2147483647, 19, 13, 'bai.emitter.input', 'true', 6, 2),
(39, 115, 333, 352, 39, 16, 'ruleset.bom.enabled', 'true', NULL, 25),
(40, 115, 333, 353, 40, 16, 'ruleset.version', '1.0', NULL, 25),
(41, 115, 333, 354, 41, 16, 'com.ibm.rules.engine.bytecode.generation', 'true', NULL, 25),
(42, 115, 333, 355, 42, 16, 'ruleset.trace.enabled', 'false', NULL, 25),
(43, 115, 333, 356, 43, 16, 'ruleset.debug.enabled', 'false', NULL, 25),
(44, 115, 333, 357, 44, 16, 'ruleset.status', 'enabled', NULL, 25),
(45, 115, 333, 358, 45, 16, 'monitoring.enabled', 'true', NULL, 25),
(46, 115, 333, 359, 46, 16, 'ruleset.sequential.trace.enabled', 'true', NULL, 25),
(47, 115, 352, 2147483647, 39, 16, 'ruleset.bom.enabled', 'true', 9, 25),
(48, 115, 353, 2147483647, 40, 16, 'ruleset.version', '1.0', 9, 25),
(49, 115, 354, 2147483647, 41, 16, 'com.ibm.rules.engine.bytecode.generation', 'true', 9, 25),
(50, 115, 355, 2147483647, 42, 16, 'ruleset.trace.enabled', 'false', 9, 25),
(51, 115, 356, 2147483647, 43, 16, 'ruleset.debug.enabled', 'false', 9, 25),
(52, 115, 357, 2147483647, 44, 16, 'ruleset.status', 'enabled', 9, 25),
(53, 115, 358, 2147483647, 45, 16, 'monitoring.enabled', 'true', 9, 25),
(54, 115, 359, 2147483647, 46, 16, 'ruleset.sequential.trace.enabled', 'true', 9, 25);     
CREATE INDEX "PUBLIC"."DEPOPPROP_CONTAINER" ON "PUBLIC"."DEPOPERATIONPROPERTY"("CONTAINER");   
CREATE INDEX "PUBLIC"."FKDEPOPPROPTYPIDX" ON "PUBLIC"."DEPOPERATIONPROPERTY"("TYPE");          
CREATE INDEX "PUBLIC"."FKDEPOPPROPSTRTDIDX" ON "PUBLIC"."DEPOPERATIONPROPERTY"("STARTID");     
CREATE INDEX "PUBLIC"."FKDEPOPPROPNDDIDX" ON "PUBLIC"."DEPOPERATIONPROPERTY"("ENDID");         
CREATE INDEX "PUBLIC"."FKDEPOPPROPBSLNIDX" ON "PUBLIC"."DEPOPERATIONPROPERTY"("BASELINE");     
CREATE INDEX "PUBLIC"."FKDEPOPPROPPRTNRFRNCIDX" ON "PUBLIC"."DEPOPERATIONPROPERTY"("OPERATIONREFERENCE");      
CREATE CACHED TABLE "PUBLIC"."OPERATIONTAG"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "VALUE" CLOB(52428800),
    "CONTAINER" INTEGER NOT NULL
);       
ALTER TABLE "PUBLIC"."OPERATIONTAG" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_79" PRIMARY KEY("ID"); 
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.OPERATIONTAG;             
CREATE INDEX "PUBLIC"."OPTAG_CONTAINER" ON "PUBLIC"."OPERATIONTAG"("CONTAINER");               
CREATE INDEX "PUBLIC"."FKOPTAGTYPIDX" ON "PUBLIC"."OPERATIONTAG"("TYPE");      
CREATE INDEX "PUBLIC"."FKOPTAGSTRTDIDX" ON "PUBLIC"."OPERATIONTAG"("STARTID"); 
CREATE INDEX "PUBLIC"."FKOPTAGNDDIDX" ON "PUBLIC"."OPERATIONTAG"("ENDID");     
CREATE INDEX "PUBLIC"."FKOPTAGBSLNIDX" ON "PUBLIC"."OPERATIONTAG"("BASELINE"); 
CREATE CACHED TABLE "PUBLIC"."RULEFLOWTAG"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "CONTAINER" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "VALUE" CLOB(52428800)
);        
ALTER TABLE "PUBLIC"."RULEFLOWTAG" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_CE" PRIMARY KEY("ID");  
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.RULEFLOWTAG;              
CREATE INDEX "PUBLIC"."RULEFLOWTAG_CONTAINER" ON "PUBLIC"."RULEFLOWTAG"("CONTAINER");          
CREATE UNIQUE INDEX "PUBLIC"."RULEFLOWTAGNAMEUNIQUE" ON "PUBLIC"."RULEFLOWTAG"("CONTAINER", "ENDID", "NAME", "BASELINE");      
CREATE INDEX "PUBLIC"."FKRULEFLOWTAGTYPIDX" ON "PUBLIC"."RULEFLOWTAG"("TYPE"); 
CREATE INDEX "PUBLIC"."FKRULEFLOWTAGSTRTDIDX" ON "PUBLIC"."RULEFLOWTAG"("STARTID");            
CREATE INDEX "PUBLIC"."FKRULEFLOWTAGNDDIDX" ON "PUBLIC"."RULEFLOWTAG"("ENDID");
CREATE INDEX "PUBLIC"."FKRULEFLOWTAGBSLNIDX" ON "PUBLIC"."RULEFLOWTAG"("BASELINE");            
CREATE CACHED TABLE "PUBLIC"."SCENARIOSUITE"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER,
    "ENTRYPOINT" CLOB(52428800),
    "FORMAT" VARCHAR(255),
    "TESTBASELINE" VARCHAR(255),
    "TESTEXTRACTOR" VARCHAR(255)
);      
ALTER TABLE "PUBLIC"."SCENARIOSUITE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_74" PRIMARY KEY("ID");
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.SCENARIOSUITE;            
CREATE INDEX "PUBLIC"."SCSUITE_PRJBRANCH" ON "PUBLIC"."SCENARIOSUITE"("PROJECT", "BASELINE");  
CREATE UNIQUE INDEX "PUBLIC"."SCSUITEUUIDUNIQUE" ON "PUBLIC"."SCENARIOSUITE"("UUID", "BASELINE", "ENDID");     
CREATE INDEX "PUBLIC"."FKSCSUITETYPIDX" ON "PUBLIC"."SCENARIOSUITE"("TYPE");   
CREATE INDEX "PUBLIC"."FKSCSUITESTRTDIDX" ON "PUBLIC"."SCENARIOSUITE"("STARTID");              
CREATE INDEX "PUBLIC"."FKSCSUITENDDIDX" ON "PUBLIC"."SCENARIOSUITE"("ENDID");  
CREATE INDEX "PUBLIC"."FKSCSUITEBSLNIDX" ON "PUBLIC"."SCENARIOSUITE"("BASELINE");              
CREATE INDEX "PUBLIC"."FKSCSUITEDIDX" ON "PUBLIC"."SCENARIOSUITE"("UUID");     
CREATE INDEX "PUBLIC"."FKSCSUITERLPCKGIDX" ON "PUBLIC"."SCENARIOSUITE"("RULEPACKAGE");         
CREATE CACHED TABLE "PUBLIC"."SCENARIOSUITERESOURCE"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "CONTAINER" INTEGER NOT NULL,
    "ILRKEY" VARCHAR(255) NOT NULL,
    "VALUE" BLOB
);      
ALTER TABLE "PUBLIC"."SCENARIOSUITERESOURCE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_A7" PRIMARY KEY("ID");        
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.SCENARIOSUITERESOURCE;    
CREATE INDEX "PUBLIC"."SCSUITERS_CONTAINER" ON "PUBLIC"."SCENARIOSUITERESOURCE"("CONTAINER");  
CREATE UNIQUE INDEX "PUBLIC"."SCSUITERSNAMEUNIQUE" ON "PUBLIC"."SCENARIOSUITERESOURCE"("CONTAINER", "ENDID", "ILRKEY", "BASELINE");            
CREATE INDEX "PUBLIC"."FKSCSUITERSTYPIDX" ON "PUBLIC"."SCENARIOSUITERESOURCE"("TYPE");         
CREATE INDEX "PUBLIC"."FKSCSUITERSSTRTDIDX" ON "PUBLIC"."SCENARIOSUITERESOURCE"("STARTID");    
CREATE INDEX "PUBLIC"."FKSCSUITERSNDDIDX" ON "PUBLIC"."SCENARIOSUITERESOURCE"("ENDID");        
CREATE INDEX "PUBLIC"."FKSCSUITERSBSLNIDX" ON "PUBLIC"."SCENARIOSUITERESOURCE"("BASELINE");    
CREATE CACHED TABLE "PUBLIC"."TASK"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "DEFINITION" CLOB(52428800),
    "ADVANCEDPROPERTIES" CLOB(52428800),
    "ALGORITHM" VARCHAR(30),
    "DYNAMIC" BOOLEAN,
    "EXITCRITERIA" VARCHAR(30),
    "ORDERING" VARCHAR(30),
    "ILRSELECT" CLOB(52428800),
    "CONTAINER" INTEGER NOT NULL,
    "DOCUMENTATION" CLOB(52428800),
    "FINALACTIONS" CLOB(52428800),
    "INITIALACTIONS" CLOB(52428800),
    "NAME" VARCHAR(255) NOT NULL
);     
ALTER TABLE "PUBLIC"."TASK" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_27" PRIMARY KEY("ID");         
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.TASK;     
CREATE INDEX "PUBLIC"."TASK_CONTAINER" ON "PUBLIC"."TASK"("CONTAINER");        
CREATE INDEX "PUBLIC"."FKTASKTYPIDX" ON "PUBLIC"."TASK"("TYPE");               
CREATE INDEX "PUBLIC"."FKTASKSTRTDIDX" ON "PUBLIC"."TASK"("STARTID");          
CREATE INDEX "PUBLIC"."FKTASKNDDIDX" ON "PUBLIC"."TASK"("ENDID");              
CREATE INDEX "PUBLIC"."FKTASKBSLNIDX" ON "PUBLIC"."TASK"("BASELINE");          
CREATE CACHED TABLE "PUBLIC"."TEMPLATE"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER,
    "DEFINITION" CLOB(52428800),
    "DEFINITIONINFO" CLOB(52428800),
    "LOCALE" VARCHAR(30),
    "RULETYPE" VARCHAR(255)
);             
ALTER TABLE "PUBLIC"."TEMPLATE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_DF" PRIMARY KEY("ID");     
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.TEMPLATE; 
CREATE INDEX "PUBLIC"."TEMPLATE_PRJBRANCH" ON "PUBLIC"."TEMPLATE"("PROJECT", "BASELINE");      
CREATE UNIQUE INDEX "PUBLIC"."TEMPLATEUUIDUNIQUE" ON "PUBLIC"."TEMPLATE"("UUID", "BASELINE", "ENDID");         
CREATE INDEX "PUBLIC"."FKTEMPLATETYPIDX" ON "PUBLIC"."TEMPLATE"("TYPE");       
CREATE INDEX "PUBLIC"."FKTEMPLATESTRTDIDX" ON "PUBLIC"."TEMPLATE"("STARTID");  
CREATE INDEX "PUBLIC"."FKTEMPLATENDDIDX" ON "PUBLIC"."TEMPLATE"("ENDID");      
CREATE INDEX "PUBLIC"."FKTEMPLATEBSLNIDX" ON "PUBLIC"."TEMPLATE"("BASELINE");  
CREATE INDEX "PUBLIC"."FKTEMPLATEDIDX" ON "PUBLIC"."TEMPLATE"("UUID");         
CREATE INDEX "PUBLIC"."FKTEMPLATERLPCKGIDX" ON "PUBLIC"."TEMPLATE"("RULEPACKAGE");             
CREATE CACHED TABLE "PUBLIC"."INITIALVALUE"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "NAME" VARCHAR(255),
    "VALUE" CLOB(52428800),
    "CONTAINER" INTEGER NOT NULL
);
ALTER TABLE "PUBLIC"."INITIALVALUE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_72" PRIMARY KEY("ID"); 
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.INITIALVALUE;             
CREATE INDEX "PUBLIC"."INITIALVALUE_CONTAINER" ON "PUBLIC"."INITIALVALUE"("CONTAINER");        
CREATE INDEX "PUBLIC"."FKINITIALVALUETYPIDX" ON "PUBLIC"."INITIALVALUE"("TYPE");               
CREATE INDEX "PUBLIC"."FKINITIALVALUESTRTDIDX" ON "PUBLIC"."INITIALVALUE"("STARTID");          
CREATE INDEX "PUBLIC"."FKINITIALVALUENDDIDX" ON "PUBLIC"."INITIALVALUE"("ENDID");              
CREATE INDEX "PUBLIC"."FKINITIALVALUEBSLNIDX" ON "PUBLIC"."INITIALVALUE"("BASELINE");          
CREATE CACHED TABLE "PUBLIC"."RULEARTIFACT"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "CATEGORIES" CLOB(52428800),
    "LOCALE" VARCHAR(30),
    "TEMPLATE" INTEGER,
    "RETURNTYPE" CLOB(52428800),
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER,
    "PRIORITY" VARCHAR(15),
    "ACTIVE" BOOLEAN,
    "IMPORTS" CLOB(52428800)
);  
ALTER TABLE "PUBLIC"."RULEARTIFACT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_487" PRIMARY KEY("ID");
-- 23 +/- SELECT COUNT(*) FROM PUBLIC.RULEARTIFACT;            
INSERT INTO "PUBLIC"."RULEARTIFACT" VALUES
(1, 56, 32, 2147483647, 1, 4, '', 'en_US', NULL, NULL, 'checkAmount', 'e9c4e688-8ece-4347-bc80-59347e408398', 3, NULL, NULL, 2, NULL, TRUE, NULL),
(2, 56, 33, 2147483647, 2, 4, '', 'en_US', NULL, NULL, 'checkSSNdigits', '85980264-7328-45e2-bc8b-fc8dbbf429c9', 4, NULL, NULL, 2, NULL, TRUE, NULL),
(3, 56, 34, 2147483647, 3, 4, '', 'en_US', NULL, NULL, 'checkSSNareanumber', '3d0baca6-b708-4be4-893a-fa988452dfb9', 4, NULL, NULL, 2, NULL, TRUE, NULL),
(4, 56, 35, 2147483647, 4, 4, '', 'en_US', NULL, NULL, 'checkZipcode', 'f7871a3e-5f1e-4d7d-b235-4e6129919c57', 4, NULL, NULL, 2, NULL, TRUE, NULL),
(5, 56, 36, 2147483647, 5, 4, '', 'en_US', NULL, NULL, 'checkAge', 'b0361335-f157-4660-a3dc-146c8e301ddb', 4, 'Ensure the age of the borrower is correct', NULL, 2, NULL, TRUE, NULL),
(6, 56, 37, 2147483647, 6, 4, '', 'en_US', NULL, NULL, 'checkName', 'c5b9e0ce-c668-4a77-9f0a-8ea444e459e0', 4, NULL, NULL, 2, NULL, TRUE, NULL),
(7, 28, 49, 2147483647, 7, 7, '', 'en_US', NULL, NULL, 'grade', '48827069-467c-4c12-8d23-06eb9d0ba48f', 5, NULL, NULL, 3, 'high', TRUE, NULL),
(8, 56, 50, 2147483647, 8, 7, '', 'en_US', NULL, NULL, 'checkIncome', 'c7be44d1-ca4c-4108-92e2-3816134e66a2', 5, NULL, NULL, 3, NULL, TRUE, NULL),
(9, 56, 51, 2147483647, 9, 7, '', 'en_US', NULL, NULL, 'approval', '350b2987-2b8e-4a0c-99fe-d06ab0af90ba', 5, NULL, NULL, 3, 'low', TRUE, NULL),
(10, 56, 52, 2147483647, 10, 7, '', 'en_US', NULL, NULL, 'checkCreditScore', 'c8dafd02-cb18-4a33-ba0c-ec0dfd12e8b8', 5, NULL, NULL, 3, NULL, TRUE, NULL),
(11, 56, 53, 2147483647, 11, 7, '', 'en_US', NULL, NULL, 'defaultInsurance', '842c35bf-47f4-41f5-a6f8-f43dfe302609', 6, NULL, NULL, 3, 'low', TRUE, NULL),
(12, 56, 54, 2147483647, 12, 7, '', 'en_US', NULL, NULL, 'unvalidated action rule', '67bf4528-7e1c-4ef0-8089-3407e1d0c224', 6, NULL, NULL, 3, NULL, TRUE, NULL),
(13, 28, 55, 2147483647, 13, 7, '', 'en_US', NULL, NULL, 'insurance', '639203c5-bd7d-4696-bb7e-eee46e008cb0', 6, NULL, NULL, 3, NULL, TRUE, NULL),
(14, 28, 70, 2147483647, 14, 10, '', 'en_US', NULL, NULL, 'rate', '7c47ee41-f999-4157-b91a-be48d7e4facf', 7, NULL, NULL, 4, NULL, TRUE, NULL),
(15, 56, 71, 2147483647, 15, 10, '', 'en_US', NULL, NULL, 'initialCorporateScore', 'f8ebe74d-bf29-48fd-a9f4-a4b7cd124d14', 7, NULL, NULL, 4, 'high', TRUE, NULL),
(16, 56, 72, 2147483647, 16, 10, '', 'en_US', NULL, NULL, 'repayment', 'b1ade762-dc28-4abc-8033-e300be183560', 7, NULL, NULL, 4, 'low', TRUE, NULL),
(17, 28, 73, 2147483647, 17, 10, '', 'en_US', NULL, NULL, 'salary2score', '59352b03-2138-4986-9347-52e771a8bb16', 7, NULL, NULL, 4, NULL, TRUE, NULL),
(18, 56, 74, 2147483647, 18, 10, '', 'en_US', NULL, NULL, 'neverBankruptcy', '2ee02474-d7ae-4410-beba-d3b55a6df36f', 7, NULL, NULL, 4, NULL, TRUE, NULL),
(19, 28, 75, 2147483647, 19, 10, '', 'en_US', NULL, NULL, 'bankruptcyScore', '1e28b410-f5bd-44b4-9cb6-8f9784895282', 7, 'calculate the bankruptcy score.', NULL, 4, NULL, TRUE, NULL),
(20, 28, 327, 2147483647, 20, 16, '', 'en_US', NULL, NULL, 'repayment and score', '91025540-61cb-4392-9731-d5c155081a58', 10, NULL, NULL, 6, NULL, TRUE, NULL),
(21, 56, 328, 2147483647, 21, 16, '', 'en_US', NULL, NULL, 'minimum income', 'f5ad9c90-3892-433d-88ad-12de47e9d6ae', 10, NULL, NULL, 6, NULL, TRUE, NULL),
(22, 56, 329, 2147483647, 22, 16, '', 'en_US', NULL, NULL, 'minimum credit score', '9bc888e9-e5d9-4cd1-948b-2c435648e0d9', 10, NULL, NULL, 6, NULL, TRUE, NULL),
(23, 56, 331, 2147483647, 23, 16, '', 'en_US', NULL, NULL, 'maximum amount', '50dc8154-1da8-4263-8666-d33e4e8b6c79', 11, NULL, NULL, 6, NULL, TRUE, NULL);     
CREATE INDEX "PUBLIC"."RULEARTIFACT_PRJBRANCH" ON "PUBLIC"."RULEARTIFACT"("PROJECT", "BASELINE");              
CREATE UNIQUE INDEX "PUBLIC"."RULEARTIFACTUUIDUNIQUE" ON "PUBLIC"."RULEARTIFACT"("UUID", "BASELINE", "ENDID"); 
CREATE UNIQUE INDEX "PUBLIC"."RULEARTIFVERSION" ON "PUBLIC"."RULEARTIFACT"("ORIGINALID", "TYPE", "STARTID", "ENDID", "RULEPACKAGE");           
CREATE INDEX "PUBLIC"."FKRULEARTIFACTTYPIDX" ON "PUBLIC"."RULEARTIFACT"("TYPE");               
CREATE INDEX "PUBLIC"."FKRULEARTIFACTSTRTDIDX" ON "PUBLIC"."RULEARTIFACT"("STARTID");          
CREATE INDEX "PUBLIC"."FKRULEARTIFACTNDDIDX" ON "PUBLIC"."RULEARTIFACT"("ENDID");              
CREATE INDEX "PUBLIC"."FKRULEARTIFACTBSLNIDX" ON "PUBLIC"."RULEARTIFACT"("BASELINE");          
CREATE INDEX "PUBLIC"."FKRULEARTIFACTDIDX" ON "PUBLIC"."RULEARTIFACT"("UUID"); 
CREATE INDEX "PUBLIC"."FKRULEARTIFACTTMPLTIDX" ON "PUBLIC"."RULEARTIFACT"("TEMPLATE");         
CREATE INDEX "PUBLIC"."FKRULEARTIFACTRLPCKGIDX" ON "PUBLIC"."RULEARTIFACT"("RULEPACKAGE");     
CREATE CACHED TABLE "PUBLIC"."RULEARTIFACTSIBLING"(
    "ID" INTEGER NOT NULL,
    "EFFECTIVEDATE" TIMESTAMP,
    "EXPIRATIONDATE" TIMESTAMP,
    "STATUS" VARCHAR(30) NOT NULL
);             
ALTER TABLE "PUBLIC"."RULEARTIFACTSIBLING" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_CA" PRIMARY KEY("ID");          
-- 23 +/- SELECT COUNT(*) FROM PUBLIC.RULEARTIFACTSIBLING;     
INSERT INTO "PUBLIC"."RULEARTIFACTSIBLING" VALUES
(1, NULL, NULL, 'new'),
(2, NULL, NULL, 'new'),
(3, NULL, NULL, 'new'),
(4, NULL, NULL, 'new'),
(5, NULL, NULL, 'new'),
(6, NULL, NULL, 'new'),
(7, NULL, NULL, 'new'),
(8, NULL, NULL, 'new'),
(9, NULL, NULL, 'new'),
(10, NULL, NULL, 'new'),
(11, NULL, NULL, 'validated'),
(12, NULL, NULL, 'new'),
(13, NULL, NULL, 'validated'),
(14, NULL, NULL, 'new'),
(15, NULL, NULL, 'new'),
(16, NULL, NULL, 'deployable'),
(17, NULL, NULL, 'new'),
(18, NULL, NULL, 'new'),
(19, NULL, NULL, 'new'),
(20, NULL, NULL, 'new'),
(21, NULL, NULL, 'new'),
(22, NULL, NULL, 'new'),
(23, NULL, NULL, 'new');     
CREATE CACHED TABLE "PUBLIC"."ACTIVITYCOMMENT"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "BASELINE" INTEGER,
    "SOURCEARTIFACT" INTEGER,
    "SOURCEARTIFACTID" INTEGER,
    "SOURCEARTIFACTTYPE" INTEGER,
    "SOURCERULEARTIFACT" INTEGER,
    "SOURCERULEARTIFACTID" INTEGER,
    "ADDITIONALDETAILS" VARCHAR(255),
    "FORUSER" VARCHAR(100),
    "MAJORVERSION" INTEGER,
    "MINORVERSION" INTEGER,
    "NEWDATE" TIMESTAMP,
    "NEWDESC" CLOB(52428800),
    "NEWPROPERTY" VARCHAR(255),
    "OLDDATE" TIMESTAMP,
    "OLDDESC" CLOB(52428800),
    "OLDNAME" VARCHAR(1000),
    "OLDPROPERTY" VARCHAR(255),
    "SOURCEBRANCH" INTEGER,
    "SOURCERULEPROJECT" INTEGER,
    "UPDATETYPE" VARCHAR(30),
    "VERSIONCOMMENT" CLOB(5242880),
    "PARENT" INTEGER,
    "TEXT" CLOB(5242880),
    "CREATEDBY" VARCHAR(100),
    "CREATEDON" TIMESTAMP,
    "LASTCHANGEDBY" VARCHAR(100),
    "LASTCHANGEDON" TIMESTAMP
);          
ALTER TABLE "PUBLIC"."ACTIVITYCOMMENT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_37" PRIMARY KEY("ID");              
-- 140 +/- SELECT COUNT(*) FROM PUBLIC.ACTIVITYCOMMENT;        
INSERT INTO "PUBLIC"."ACTIVITYCOMMENT" VALUES
(1, 103, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:19', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:19'),
(2, 103, 1, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'BranchCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:19', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:19'),
(3, 103, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39'),
(4, 103, 4, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 'BranchCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39'),
(5, 103, 4, NULL, 0, NULL, 1, 1, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39'),
(6, 103, 4, NULL, 0, NULL, 2, 2, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39'),
(7, 103, 4, NULL, 0, NULL, 3, 3, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39'),
(8, 103, 4, NULL, 0, NULL, 4, 4, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39'),
(9, 103, 4, NULL, 0, NULL, 5, 5, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39'),
(10, 103, 4, NULL, 0, NULL, 6, 6, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39'),
(11, 103, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39'),
(12, 103, 7, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 'BranchCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:39'),
(13, 103, 7, NULL, 0, NULL, 7, 7, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40'),
(14, 103, 7, NULL, 0, NULL, 8, 8, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40'),
(15, 103, 7, NULL, 0, NULL, 9, 9, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40'),
(16, 103, 7, NULL, 0, NULL, 10, 10, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40'),
(17, 103, 7, NULL, 0, NULL, 11, 11, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40'),
(18, 103, 7, NULL, 0, NULL, 12, 12, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40');        
INSERT INTO "PUBLIC"."ACTIVITYCOMMENT" VALUES
(19, 103, 7, NULL, 0, NULL, 13, 13, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40'),
(20, 103, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40'),
(21, 103, 10, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, 'BranchCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40'),
(22, 103, 10, NULL, 0, NULL, 14, 14, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40'),
(23, 103, 10, NULL, 0, NULL, 15, 15, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40'),
(24, 103, 10, NULL, 0, NULL, 16, 16, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40'),
(25, 103, 10, NULL, 0, NULL, 17, 17, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40'),
(26, 103, 10, NULL, 0, NULL, 18, 18, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40'),
(27, 103, 10, NULL, 0, NULL, 19, 19, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:40'),
(28, 103, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5, 'DecisionServiceCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41'),
(29, 103, 13, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5, 'BranchCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41'),
(30, 103, 13, 1, 1, 132, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41'),
(31, 103, 13, 1, 1, 129, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41'),
(32, 103, 13, 1, 1, 126, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41'),
(33, 103, 13, 1, 1, 127, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41'),
(34, 103, 13, 1, 1, 124, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41'),
(35, 103, 13, 2, 2, 124, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41'),
(36, 103, 13, 3, 3, 124, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41');          
INSERT INTO "PUBLIC"."ACTIVITYCOMMENT" VALUES
(37, 103, 13, 4, 4, 124, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41'),
(38, 103, 13, 5, 5, 124, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41'),
(39, 103, 13, 6, 6, 124, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41'),
(40, 103, 13, 7, 7, 124, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41'),
(41, 103, 13, 8, 8, 124, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41'),
(42, 103, 13, 9, 9, 124, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41'),
(43, 103, 13, 10, 10, 124, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:41'),
(44, 103, 13, 11, 11, 124, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42'),
(45, 103, 13, 1, 1, 125, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42'),
(46, 103, 13, 2, 2, 125, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42'),
(47, 103, 13, 3, 3, 125, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42'),
(48, 103, 13, 4, 4, 125, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42'),
(49, 103, 13, 5, 5, 125, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42'),
(50, 103, 13, 6, 6, 125, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42'),
(51, 103, 13, 7, 7, 125, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42'),
(52, 103, 13, 8, 8, 125, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42'),
(53, 103, 13, 9, 9, 125, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42'),
(54, 103, 13, 10, 10, 125, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42');        
INSERT INTO "PUBLIC"."ACTIVITYCOMMENT" VALUES
(55, 103, 13, 11, 11, 125, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42'),
(56, 103, 13, 12, 12, 125, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42'),
(57, 103, 13, 13, 13, 125, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42'),
(58, 103, 13, 14, 14, 125, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42'),
(59, 103, 13, 15, 15, 125, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42'),
(60, 103, 13, 16, 16, 125, NULL, 0, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:42'),
(61, 103, 13, 1, 2, 132, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43'),
(62, 103, 13, 1, 2, 129, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43'),
(63, 103, 13, 1, 2, 126, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43'),
(64, 103, 13, 1, 3, 126, NULL, 0, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43'),
(65, 103, 13, 1, 2, 127, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43'),
(66, 103, 13, 1, 12, 124, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43'),
(67, 103, 13, 2, 13, 124, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43'),
(68, 103, 13, 3, 14, 124, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43'),
(69, 103, 13, 4, 15, 124, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43'),
(70, 103, 13, 5, 16, 124, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43'),
(71, 103, 13, 6, 17, 124, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43');    
INSERT INTO "PUBLIC"."ACTIVITYCOMMENT" VALUES
(72, 103, 13, 7, 18, 124, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43'),
(73, 103, 13, 8, 19, 124, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43'),
(74, 103, 13, 9, 20, 124, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43'),
(75, 103, 13, 10, 21, 124, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43'),
(76, 103, 13, 11, 22, 124, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43'),
(77, 103, 13, 1, 17, 125, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43'),
(78, 103, 13, 2, 18, 125, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43'),
(79, 103, 13, 3, 19, 125, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43'),
(80, 103, 13, 4, 20, 125, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43'),
(81, 103, 13, 5, 21, 125, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:43'),
(82, 103, 13, 6, 22, 125, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:44', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:44'),
(83, 103, 13, 7, 23, 125, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:44', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:44'),
(84, 103, 13, 8, 24, 125, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:44', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:44'),
(85, 103, 13, 9, 25, 125, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:44', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:44'),
(86, 103, 13, 10, 26, 125, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:44', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:44'),
(87, 103, 13, 11, 27, 125, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:44', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:44'),
(88, 103, 13, 12, 28, 125, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:44', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:44');            
INSERT INTO "PUBLIC"."ACTIVITYCOMMENT" VALUES
(89, 103, 13, 13, 29, 125, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:44', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:44'),
(90, 103, 13, 14, 30, 125, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:44', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:44'),
(91, 103, 13, 15, 31, 125, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:44', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:44'),
(92, 103, 13, 16, 32, 125, NULL, 0, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:44', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:44'),
(93, 103, 13, 1, 3, 129, NULL, 0, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45'),
(94, 103, 13, 1, 4, 129, NULL, 0, NULL, NULL, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45'),
(95, 103, 13, 14, 33, 125, NULL, 0, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45'),
(96, 103, 13, 16, 34, 125, NULL, 0, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45'),
(97, 103, 13, 1, 35, 125, NULL, 0, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45'),
(98, 103, 13, 2, 36, 125, NULL, 0, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45'),
(99, 103, 13, 3, 37, 125, NULL, 0, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45'),
(100, 103, 13, 4, 38, 125, NULL, 0, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45'),
(101, 103, 13, 7, 39, 125, NULL, 0, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45'),
(102, 103, 13, 8, 40, 125, NULL, 0, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45'),
(103, 103, 13, 5, 41, 125, NULL, 0, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45'),
(104, 103, 13, 6, 42, 125, NULL, 0, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45'),
(105, 103, 13, 7, 43, 125, NULL, 0, NULL, NULL, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45');       
INSERT INTO "PUBLIC"."ACTIVITYCOMMENT" VALUES
(106, 103, 13, 8, 44, 125, NULL, 0, NULL, NULL, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45'),
(107, 103, 13, 9, 45, 125, NULL, 0, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45'),
(108, 103, 13, 10, 46, 125, NULL, 0, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45'),
(109, 103, 13, 11, 47, 125, NULL, 0, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:45'),
(110, 103, 13, 12, 48, 125, NULL, 0, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46'),
(111, 103, 13, 13, 49, 125, NULL, 0, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46'),
(112, 103, 13, 14, 50, 125, NULL, 0, NULL, NULL, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46'),
(113, 103, 13, 15, 51, 125, NULL, 0, NULL, NULL, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46'),
(114, 103, 13, 16, 52, 125, NULL, 0, NULL, NULL, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46'),
(115, 103, 13, 1, 4, 126, NULL, 0, NULL, NULL, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46'),
(116, 103, 13, 1, 5, 126, NULL, 0, NULL, NULL, 1, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46'),
(117, 103, 13, 1, 6, 126, NULL, 0, NULL, NULL, 1, 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46'),
(118, 103, 13, 1, 7, 126, NULL, 0, NULL, NULL, 1, 6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46'),
(119, 103, 13, 1, 8, 126, NULL, 0, NULL, NULL, 1, 7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46'),
(120, 103, 13, 1, 9, 126, NULL, 0, NULL, NULL, 1, 8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46'),
(121, 103, 13, 1, 10, 126, NULL, 0, NULL, NULL, 1, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46'),
(122, 103, 13, 1, 11, 126, NULL, 0, NULL, NULL, 1, 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46');              
INSERT INTO "PUBLIC"."ACTIVITYCOMMENT" VALUES
(123, 103, 13, 1, 12, 126, NULL, 0, NULL, NULL, 1, 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'TestSuiteUpdateSingle', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46', 'odmAdmin', TIMESTAMP '2023-05-04 14:34:46'),
(124, 103, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 'DecisionServiceCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:35:15', 'odmAdmin', TIMESTAMP '2023-05-04 14:35:15'),
(125, 103, 16, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, 'BranchCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:35:15', 'odmAdmin', TIMESTAMP '2023-05-04 14:35:15'),
(126, 103, 16, NULL, 0, NULL, 20, 20, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:35:15', 'odmAdmin', TIMESTAMP '2023-05-04 14:35:15'),
(127, 103, 16, NULL, 0, NULL, 21, 21, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:35:15', 'odmAdmin', TIMESTAMP '2023-05-04 14:35:15'),
(128, 103, 16, NULL, 0, NULL, 22, 22, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:35:15', 'odmAdmin', TIMESTAMP '2023-05-04 14:35:15'),
(129, 103, 16, NULL, 0, NULL, 23, 23, NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:35:15', 'odmAdmin', TIMESTAMP '2023-05-04 14:35:15'),
(130, 103, 19, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 16, NULL, 'SnapshotCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:35:31', 'odmAdmin', TIMESTAMP '2023-05-04 14:35:31'),
(131, 103, 20, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 'SnapshotCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:36:05', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:05'),
(132, 103, 21, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, 'SnapshotCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:36:05', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:05'),
(133, 103, 22, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 7, NULL, 'SnapshotCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:36:06', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:06'),
(134, 103, 23, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, NULL, 'SnapshotCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:36:06', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:06'),
(135, 103, 24, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 13, NULL, 'SnapshotCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:36:06', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:06'),
(136, 103, 25, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 'SnapshotCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:36:22', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:22'),
(137, 103, 26, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, NULL, 'SnapshotCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:36:22', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:22'),
(138, 103, 27, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 7, NULL, 'SnapshotCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:36:22', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:22'),
(139, 103, 28, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, NULL, 'SnapshotCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:36:22', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:22'),
(140, 103, 29, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 13, NULL, 'SnapshotCreate', NULL, NULL, NULL, 'odmAdmin', TIMESTAMP '2023-05-04 14:36:22', 'odmAdmin', TIMESTAMP '2023-05-04 14:36:22');
CREATE INDEX "PUBLIC"."ACTIVITYCOMMENTDATEIDX" ON "PUBLIC"."ACTIVITYCOMMENT"("TYPE", "CREATEDON");             
CREATE INDEX "PUBLIC"."FKACOMMENTTYPIDX" ON "PUBLIC"."ACTIVITYCOMMENT"("TYPE");
CREATE INDEX "PUBLIC"."FKACOMMENTBSLNIDX" ON "PUBLIC"."ACTIVITYCOMMENT"("BASELINE");           
CREATE INDEX "PUBLIC"."FKACOMMENTSRCRLRTFCTIDX" ON "PUBLIC"."ACTIVITYCOMMENT"("SOURCERULEARTIFACT");           
CREATE INDEX "PUBLIC"."FKACOMMENTSRCBRNCHIDX" ON "PUBLIC"."ACTIVITYCOMMENT"("SOURCEBRANCH");   
CREATE INDEX "PUBLIC"."FKACOMMENTSRCRLPRJCTIDX" ON "PUBLIC"."ACTIVITYCOMMENT"("SOURCERULEPROJECT");            
CREATE CACHED TABLE "PUBLIC"."ACTIVITYCOMMENTACCESS"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "BRANCH" INTEGER,
    "PROJECT" INTEGER,
    "CONTAINER" INTEGER NOT NULL
); 
ALTER TABLE "PUBLIC"."ACTIVITYCOMMENTACCESS" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_43C" PRIMARY KEY("ID");       
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.ACTIVITYCOMMENTACCESS;    
CREATE INDEX "PUBLIC"."ACMTACCES_CONTAINER" ON "PUBLIC"."ACTIVITYCOMMENTACCESS"("CONTAINER");  
CREATE INDEX "PUBLIC"."FKACMTACCESTYPIDX" ON "PUBLIC"."ACTIVITYCOMMENTACCESS"("TYPE");         
CREATE CACHED TABLE "PUBLIC"."ACTIVITYCOMMENTATTACHMENT"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CONTENTTYPE" VARCHAR(750),
    "DATA" BLOB,
    "NAME" VARCHAR(1000),
    "CONTAINER" INTEGER NOT NULL
);               
ALTER TABLE "PUBLIC"."ACTIVITYCOMMENTATTACHMENT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_27C" PRIMARY KEY("ID");   
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.ACTIVITYCOMMENTATTACHMENT;
CREATE INDEX "PUBLIC"."ACMTATCHMT_CONTAINER" ON "PUBLIC"."ACTIVITYCOMMENTATTACHMENT"("CONTAINER");             
CREATE INDEX "PUBLIC"."FKACMTATCHMTTYPIDX" ON "PUBLIC"."ACTIVITYCOMMENTATTACHMENT"("TYPE");    
CREATE CACHED TABLE "PUBLIC"."ACTIVITYCOMMENTLINK"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "URL" CLOB(5242880),
    "CONTAINER" INTEGER NOT NULL
);       
ALTER TABLE "PUBLIC"."ACTIVITYCOMMENTLINK" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_FA" PRIMARY KEY("ID");          
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.ACTIVITYCOMMENTLINK;      
CREATE INDEX "PUBLIC"."ACMTLINK_CONTAINER" ON "PUBLIC"."ACTIVITYCOMMENTLINK"("CONTAINER");     
CREATE INDEX "PUBLIC"."FKACMTLINKTYPIDX" ON "PUBLIC"."ACTIVITYCOMMENTLINK"("TYPE");            
CREATE CACHED TABLE "PUBLIC"."ACTIVITYSUBSCRIPTION"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "SOURCEARTIFACT" INTEGER,
    "SOURCEARTIFACTTYPE" INTEGER,
    "SRCBRANCH" INTEGER,
    "SRCRULE" INTEGER,
    "SRCPROJECT" INTEGER,
    "USERNAME" VARCHAR(100)
);          
ALTER TABLE "PUBLIC"."ACTIVITYSUBSCRIPTION" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_31" PRIMARY KEY("ID");         
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.ACTIVITYSUBSCRIPTION;     
CREATE INDEX "PUBLIC"."FKACMTSUBSCRTYPIDX" ON "PUBLIC"."ACTIVITYSUBSCRIPTION"("TYPE");         
CREATE INDEX "PUBLIC"."FKACMTSUBSCRSRCRLIDX" ON "PUBLIC"."ACTIVITYSUBSCRIPTION"("SRCRULE");    
CREATE CACHED TABLE "PUBLIC"."ARGUMENT"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "ARGUMENTTYPE" CLOB(52428800) NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "ILRORDER" INTEGER NOT NULL,
    "CONTAINER" INTEGER NOT NULL
);          
ALTER TABLE "PUBLIC"."ARGUMENT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_CFE" PRIMARY KEY("ID");    
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.ARGUMENT; 
CREATE INDEX "PUBLIC"."ARGUMENT_CONTAINER" ON "PUBLIC"."ARGUMENT"("CONTAINER");
CREATE INDEX "PUBLIC"."FKARGUMENTTYPIDX" ON "PUBLIC"."ARGUMENT"("TYPE");       
CREATE INDEX "PUBLIC"."FKARGUMENTSTRTDIDX" ON "PUBLIC"."ARGUMENT"("STARTID");  
CREATE INDEX "PUBLIC"."FKARGUMENTNDDIDX" ON "PUBLIC"."ARGUMENT"("ENDID");      
CREATE INDEX "PUBLIC"."FKARGUMENTBSLNIDX" ON "PUBLIC"."ARGUMENT"("BASELINE");  
CREATE CACHED TABLE "PUBLIC"."DEFINITION"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "BODY" CLOB(52428800),
    "INFO" CLOB(52428800),
    "CONTAINER" INTEGER NOT NULL
); 
ALTER TABLE "PUBLIC"."DEFINITION" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_E0" PRIMARY KEY("ID");   
-- 23 +/- SELECT COUNT(*) FROM PUBLIC.DEFINITION;              
INSERT INTO SYSTEM_LOB_STREAM VALUES(3, 0, STRINGDECODE('<DT xmlns=\"http://schemas.ilog.com/Rules/7.0/DecisionTable\">\n    <Body xmlns=\"http://schemas.ilog.com/Rules/7.0/DecisionTable\">\n    <Properties>\n      <Property Name=\"Lock.ApplyLocking\" Type=\"xs:boolean\"><![CDATA[false]]></Property>\n      <Property Name=\"UI.ShowInvisibleColumns\" Type=\"xs:boolean\"><![CDATA[true]]></Property>\n      <Property Name=\"UI.ShowRuleView\" Type=\"xs:boolean\"><![CDATA[false]]></Property>\n    </Properties>\n    <Structure>\n      <ConditionDefinitions>\n        <ConditionDefinition Id=\"C0\">\n          <ExpressionDefinition>\n            <Text><![CDATA[the yearly repayment of ''the loan report'' is at least <min> and less than <max>]]></Text>\n          </ExpressionDefinition>\n        </ConditionDefinition>\n        <ConditionDefinition Id=\"C1\">\n          <ExpressionDefinition>\n            <Text><![CDATA[''the score'' is at least <min> and less than <max>]]></Text>\n          </ExpressionDefinition>\n        </ConditionDefinition>\n      </ConditionDefinitions>\n      <ActionDefinitions>\n        <ActionDefinition Id=\"A0\">\n          <ExpressionDefinition>\n            <Text><![CDATA[set ''the grade'' to <a string>]]></Text>\n          </ExpressionDefinition>\n        </ActionDefinition>\n        <ActionDefinition Id=\"A1\">\n          <ExpressionDefinition>\n            <Text><![CDATA[in ''the loan report'' , add the message <a string>]]></Text>\n          </ExpressionDefinition>\n        </ActionDefinition>\n      </ActionDefinitions>\n    </Structure>\n    <Contents>\n      <Partition DefId=\"C0\">\n        <Condition>\n          <Expression>\n            <Param><![CDATA[0]]></Param>\n            <Param><![CDATA[10000]]></Param>\n          </Expression>\n          <Partition DefId=\"C1\">\n            <Condition>\n              <Expression>\n                <Text><![CDATA[<a number> is at least <a number>]]></Text>\n                <Param><![CDATA[900]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[\"A\"]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[\"Very low risk loan\"]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[600]]></Param>\n                <Param><![CDATA[900]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[\"A\"]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[\"Very low risk loan\"]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[300]]></Param>\n                <Param><![CDATA[600]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[\"B\"]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[\"Low risk loan\"]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n          </Partition>\n        </Condition>\n        <Condition>\n          <Expression>\n            <Param><![CDATA[10000]]></Param>\n            <Param><![CDATA[30000]]></Param>\n          </Expression>\n          <Partition DefId=\"C1\">\n            <Condition>\n              <Expression>\n                <Text><![CDATA[<a number> is at least <a number>]]></Text>\n                <Param><![CDATA[900]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Ex'), NULL);              
INSERT INTO SYSTEM_LOB_STREAM VALUES(3, 1, STRINGDECODE('pression>\n                    <Param><![CDATA[\"A\"]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[\"Very low risk loan\"]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[600]]></Param>\n                <Param><![CDATA[900]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[\"B\"]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[\"Low risk loan\"]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[300]]></Param>\n                <Param><![CDATA[600]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[\"C\"]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[\"Average risk loan\"]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n          </Partition>\n        </Condition>\n        <Condition>\n          <Expression>\n            <Param><![CDATA[30000]]></Param>\n            <Param><![CDATA[60000]]></Param>\n          </Expression>\n          <Partition DefId=\"C1\">\n            <Condition>\n              <Expression>\n                <Text><![CDATA[<a number> is at least <a number>]]></Text>\n                <Param><![CDATA[900]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[\"B\"]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[\"Low risk loan\"]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[600]]></Param>\n                <Param><![CDATA[900]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[\"C\"]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[\"Average risk loan\"]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[300]]></Param>\n                <Param><![CDATA[600]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[\"D\"]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[\"Risky loan\"]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n          </Partition>\n        </Condition>\n        <Condition>\n          <Expression>\n            <Text><![CDATA[<a number> is at least <a number>]]></Text>\n            <Param><![CDATA[60000]]></Param>\n          </Expression>\n          <Partition DefId=\"C1\">\n            <Condition>\n              <Expression>\n                <Text><![CDATA[<a number> is at least <a number>]]></Text>\n    '), NULL);  
INSERT INTO SYSTEM_LOB_STREAM VALUES(3, 2, STRINGDECODE('            <Param><![CDATA[900]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[\"C\"]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[\"Average risk loan\"]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[600]]></Param>\n                <Param><![CDATA[900]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[\"D\"]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[\"Risky loan\"]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[300]]></Param>\n                <Param><![CDATA[600]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[\"E\"]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[\"Very risky loan\"]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n          </Partition>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <E'), NULL); 
INSERT INTO SYSTEM_LOB_STREAM VALUES(3, 3, STRINGDECODE('xpression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n      </Partition>\n    </Contents>\n  </Body>\n    <Resources DefaultLocale=\"en_US\" xmlns=\"http://schemas.ilog.com/Rules/7.0/DecisionTable\">\n    <ResourceSet Locale=\"en_US\">\n      <Data Name=\"Definitions(A0)#HeaderText\"><![CDATA[Grade]]></Data>\n      <Data Name=\"Definitions(A0)#Width\"><![CDATA[259]]></Data>\n      <Data Name=\"Definitions(A1)#HeaderText\"><![CDATA[Message]]></Data>\n      <Data Name=\"Definitions(A1)#Width\"><![CDATA[257]]></Data>\n      <Data Name=\"Definitions(C0)#HeaderText\"><![CDATA[Yearly repayment]]></Data>\n      <Data Name=\"Definitions(C0)#Width\"><![CDATA[408]]></Data>\n      <Data Name=\"Definitions(C0)[0]#HeaderText\"><![CDATA[Min]]></Data>\n      <Data Name=\"Definitions(C0)[1]#HeaderText\"><![CDATA[Max]]></Data>\n      <Data Name=\"Definitions(C1)#HeaderText\"><![CDATA[Corporate score]]></Data>\n      <Data Name=\"Definitions(C1)#Width\"><![CDATA[398]]></Data>\n      <Data Name=\"Definitions(C1)[0]#HeaderText\"><![CDATA[Min]]></Data>\n      <Data Name=\"Definitions(C1)[1]#HeaderText\"><![CDATA[Max]]></Data>\n    </ResourceSet>\n  </Resources>\n</DT>\n'), NULL);        
INSERT INTO "PUBLIC"."DEFINITION" VALUES
(1, 30, 32, 2147483647, 1, 4, STRINGDECODE('definitions \n    set maxAmount to 1,000,000;\nif \n    the amount of ''the loan'' is at least  maxAmount \nthen \n    in ''the loan report'', reject the data with the message \"The loan cannot exceed \" + maxAmount;'), NULL, 1),
(2, 30, 33, 2147483647, 2, 4, STRINGDECODE('definitions \n    set ''digits'' to 9;\n    set ''areanumber'' to 3; \n    set ''groupcode'' to 2;\n    set ''serialnumber'' to 4;\nif \n    the number of digits of the SSN of ''the borrower'' does not equal digits \n    or the length of the area number of the SSN of ''the borrower'' does not equal areanumber \n    or it is not true that the area number of the SSN of ''the borrower'' contains only digits \n    or the length of the group code of the SSN of ''the borrower'' does not equal groupcode \n    or it is not true that the group code of the SSN of ''the borrower'' contains only digits \n    or the length of the serial number of the SSN of ''the borrower'' does not equal serialnumber \n    or it is not true that the serial number of the SSN of ''the borrower'' contains only digits \nthen \n    in ''the loan report'' , reject the data with the message \"The borrower''s SSN should be formatted with 3-2-4 digits\";\n    print \"rejected with message The borrower''s SSN should be formatted with 3-2-4 digits\"; \nelse \n\tprint \"The borrower''s SSN is well formatted.\";\n'), NULL, 2),
(3, 30, 34, 2147483647, 3, 4, STRINGDECODE('if \n    the area number of the SSN of ''the borrower'' is one of { \"000\" , \"666\" } \nthen \n    in ''the loan report'' , reject the data with the message \"The borrower''s SSN area number cannot be \" + the area number of the SSN of ''the borrower'';\n    print \"rejected with The borrower''s SSN area number cannot be \" + the area number of the SSN of ''the borrower'';\nelse \n    print \"The borrower''s SSN area number belongs to an authorized area.\"; \n\n'), NULL, 3),
(4, 30, 35, 2147483647, 4, 4, STRINGDECODE('definitions \n    set ''zip length'' to 5;\nif\n    the zip code of the address of ''the borrower'' is null or\n    the length of the zip code of the address of ''the borrower'' does not equal ''zip length''\nthen \n    in ''the loan report'' , reject the data with the message \"The borrower''s Zip Code should have \" + ''zip length'' + \" digits\";\n    print \"rejected with message The borrower''s Zip Code should have \" + ''zip length'' + \" digits\";\nelse\n    print \"The borrower''s Zip Code is valid.\"; \n\n'), NULL, 4),
(5, 30, 36, 2147483647, 5, 4, STRINGDECODE('definitions\n  set ''minAge'' to 0; \n  set ''maxAge'' to 150;\n\nif \n  it is not true that the age of ''the borrower'' is between minAge and maxAge\nthen\n  in ''the loan report'' , reject the data with the message \"The borrower''s age is not valid.\";\n  print \"rejected with message The borrower''s age is not valid.\";\nelse\n  print \"The borrower''s age is valid.\";\n  '), NULL, 5),
(6, 30, 37, 2147483647, 6, 4, STRINGDECODE('if \n  the last name of ''the borrower'' is empty \nthen\n  in ''the loan report'' , reject the data with the message \"The borrower''s name is empty\";\n  print \"rejected with message The borrower''s name is empty\";\nelse \n  print \"The borrower''s name is not empty.\";'), NULL, 6),
(7, 30, 49, 2147483647, 7, 7, SYSTEM_COMBINE_CLOB(3), NULL, 7),
(8, 30, 50, 2147483647, 8, 7, STRINGDECODE('definitions \n    set ''minimum income'' to 0.37 * the yearly income of ''the borrower'';\nif \n    the yearly repayment of ''the loan report'' is at least ''minimum income''\nthen \n    in ''the loan report'', refuse the loan with the message \"Too big Debt/Income ratio: \" + (formatted amount) the yearly repayment of ''the loan report'' / the yearly income of ''the borrower''; \n\n'), NULL, 8),
(9, 30, 51, 2147483647, 9, 7, STRINGDECODE('if \n    ''the loan report'' is approved and\n    ''the grade'' is one of { \"A\" , \"B\" , \"C\" } \nthen \n    in ''the loan report'', accept the loan with the message \"Congratulations! Your loan has been approved\" ;\nelse \n    in ''the loan report'', refuse the loan with the message \"We are sorry. Your loan has not been approved\" ;\n'), NULL, 9);            
INSERT INTO SYSTEM_LOB_STREAM VALUES(4, 0, STRINGDECODE('<DT xmlns=\"http://schemas.ilog.com/Rules/7.0/DecisionTable\">\n    <Body xmlns=\"http://schemas.ilog.com/Rules/7.0/DecisionTable\">\n    <Properties>\n      <Property Name=\"Check.Overlap.ErrorLevel\">Error</Property>\n      <Property Name=\"Lock.ApplyLocking\" Type=\"xs:boolean\"><![CDATA[false]]></Property>\n      <Property Name=\"UI.ShowInvisibleColumns\" Type=\"xs:boolean\"><![CDATA[true]]></Property>\n      <Property Name=\"UI.ShowLockIcon\" Type=\"xs:boolean\"><![CDATA[false]]></Property>\n      <Property Name=\"UI.ShowRuleView\" Type=\"xs:boolean\"><![CDATA[false]]></Property>\n    </Properties>\n    <Preconditions>\n      <Text><![CDATA[if\n\t''the grade'' is not empty]]></Text>\n    </Preconditions>\n    <Structure>\n      <ConditionDefinitions>\n        <ConditionDefinition Id=\"C0\">\n          <Properties>\n            <Property Name=\"Check.Gap\" Type=\"xs:boolean\"><![CDATA[false]]></Property>\n          </Properties>\n          <ExpressionDefinition>\n            <Text><![CDATA[''the grade'' is <a string>]]></Text>\n          </ExpressionDefinition>\n        </ConditionDefinition>\n        <ConditionDefinition Id=\"C1\">\n          <ExpressionDefinition>\n            <Properties>\n              <Property Name=\"context\" Type=\"ilog.rules.dt.model.check.IlrDTExpressionChecker$IntervalContext\">\n                <intervalContext direction=\"asc\" enabled=\"false\"/>\n              </Property>\n            </Properties>\n            <Text><![CDATA[the amount of ''the loan'' is at least <min> and less than <max>]]></Text>\n          </ExpressionDefinition>\n        </ConditionDefinition>\n      </ConditionDefinitions>\n      <ActionDefinitions>\n        <ActionDefinition Id=\"A0\">\n          <ExpressionDefinition>\n            <Text><![CDATA[set insurance required in ''the loan report'' to <a boolean>]]></Text>\n          </ExpressionDefinition>\n        </ActionDefinition>\n        <ActionDefinition Id=\"A1\">\n          <ExpressionDefinition>\n            <Text><![CDATA[set the insurance rate in ''the loan report'' to <a number>]]></Text>\n          </ExpressionDefinition>\n        </ActionDefinition>\n      </ActionDefinitions>\n    </Structure>\n    <Contents>\n      <Partition DefId=\"C0\">\n        <Condition>\n          <Expression>\n            <Param><![CDATA[\"A\"]]></Param>\n          </Expression>\n          <Partition DefId=\"C1\">\n            <Condition>\n              <Expression>\n                <Text><![CDATA[<a number> is less than <a number>]]></Text>\n                <Param><![CDATA[100000]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[false]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\" Enabled=\"false\">\n                  <Expression/>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[100000]]></Param>\n                <Param><![CDATA[300000]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[true]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[0.001]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[300000]]></Param>\n                <Param><![CDATA[600000]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[true]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[0.003]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            '), NULL);         
INSERT INTO SYSTEM_LOB_STREAM VALUES(4, 1, STRINGDECODE('<Condition>\n              <Expression>\n                <Text><![CDATA[<a number> is at least <a number>]]></Text>\n                <Param><![CDATA[600000]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[true]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[0.005]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n          </Partition>\n        </Condition>\n        <Condition>\n          <Expression>\n            <Param><![CDATA[\"B\"]]></Param>\n          </Expression>\n          <Partition DefId=\"C1\">\n            <Condition>\n              <Expression>\n                <Text><![CDATA[<a number> is less than <a number>]]></Text>\n                <Param><![CDATA[100000]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[false]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\" Enabled=\"false\">\n                  <Expression/>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[100000]]></Param>\n                <Param><![CDATA[300000]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[true]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[0.0025]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[300000]]></Param>\n                <Param><![CDATA[600000]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[true]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[0.005]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Text><![CDATA[<a number> is at least <a number>]]></Text>\n                <Param><![CDATA[600000]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[true]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[0.0075]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n          </Partition>\n        </Condition>\n        <Condition>\n          <Expression>\n            <Param><![CDATA[\"C\"]]></Param>\n          </Expression>\n          <Partition DefId=\"C1\">\n            <Condition>\n              <Expression>\n                <Text><![CDATA[<a number> is less than <a number>]]></Text>\n                <Param><![CDATA[100000]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[true]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[0.0035]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n'), NULL); 
INSERT INTO SYSTEM_LOB_STREAM VALUES(4, 2, STRINGDECODE('              <Expression>\n                <Param><![CDATA[100000]]></Param>\n                <Param><![CDATA[300000]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[true]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[0.006]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[300000]]></Param>\n                <Param><![CDATA[600000]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[true]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[0.0085]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Text><![CDATA[<a number> is at least <a number>]]></Text>\n                <Param><![CDATA[600000]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[true]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[0.0145]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n          </Partition>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n '), NULL);
INSERT INTO SYSTEM_LOB_STREAM VALUES(4, 3, STRINGDECODE('         <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n            <Action DefId=\"A1\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n      </Partition>\n    </Contents>\n  </Body>\n    <Resources DefaultLocale=\"en_US\" xmlns=\"http://schemas.ilog.com/Rules/7.0/DecisionTable\">\n    <ResourceSet Locale=\"en_US\">\n      <Data Name=\"Definitions(A0)#HeaderText\"><![CDATA[Insurance required]]></Data>\n      <Data Name=\"Definitions(A0)#Width\"><![CDATA[315]]></Data>\n      <Data Name=\"Definitions(A1)#HeaderText\"><![CDATA[Insurance rate]]></Data>\n      <Data Name=\"Definitions(A1)#Width\"><![CDATA[314]]></Data>\n      <Data Name=\"Definitions(C0)#HeaderText\"><![CDATA[Grade]]></Data>\n      <Data Name=\"Definitions(C0)#Width\"><![CDATA[305]]></Data>\n      <Data Name=\"Definitions(C1)#HeaderText\"><![CDATA[Amount of loan]]></Data>\n      <Data Name=\"Definitions(C1)#Width\"><![CDATA[388]]></Data>\n      <Data Name=\"Definitions(C1)[0]#HeaderText\"><![CDATA[Min]]></Data>\n      <Data Name=\"Definitions(C1)[1]#HeaderText\"><![CDATA[Max]]></Data>\n    </ResourceSet>\n  </Resources>\n</DT>\n'), NULL);              
INSERT INTO SYSTEM_LOB_STREAM VALUES(5, 0, STRINGDECODE('<DT xmlns=\"http://schemas.ilog.com/Rules/7.0/DecisionTable\">\n    <Body xmlns=\"http://schemas.ilog.com/Rules/7.0/DecisionTable\">\n    <Properties>\n      <Property Name=\"Check.Overlap\" Type=\"xs:boolean\"><![CDATA[false]]></Property>\n      <Property Name=\"Check.Overlap.ErrorLevel\">Error</Property>\n      <Property Name=\"Lock.ApplyLocking\" Type=\"xs:boolean\"><![CDATA[false]]></Property>\n      <Property Name=\"UI.ShowInvisibleColumns\" Type=\"xs:boolean\"><![CDATA[true]]></Property>\n      <Property Name=\"UI.ShowRuleView\" Type=\"xs:boolean\"><![CDATA[false]]></Property>\n    </Properties>\n    <Structure>\n      <ConditionDefinitions>\n        <ConditionDefinition Id=\"C0\">\n          <ExpressionDefinition>\n            <Properties>\n              <Property Name=\"context\" Type=\"ilog.rules.dt.model.check.IlrDTExpressionChecker$IntervalContext\">\n                <intervalContext direction=\"asc\" enabled=\"false\"/>\n              </Property>\n            </Properties>\n            <Text><![CDATA[the duration (in years) of ''the loan'' is between <min> and <max>]]></Text>\n          </ExpressionDefinition>\n        </ConditionDefinition>\n        <ConditionDefinition Id=\"C1\">\n          <ExpressionDefinition>\n            <Properties>\n              <Property Name=\"context\" Type=\"ilog.rules.dt.model.check.IlrDTExpressionChecker$IntervalContext\">\n                <intervalContext direction=\"asc\" enabled=\"false\"/>\n              </Property>\n            </Properties>\n            <Text><![CDATA[the Loan to Value of ''the loan'' is at least <min> and less than <max>]]></Text>\n          </ExpressionDefinition>\n        </ConditionDefinition>\n      </ConditionDefinitions>\n      <ActionDefinitions>\n        <ActionDefinition Id=\"A0\">\n          <ExpressionDefinition>\n            <Text><![CDATA[set the yearly interest rate of ''the loan report'' to <a number>]]></Text>\n          </ExpressionDefinition>\n        </ActionDefinition>\n      </ActionDefinitions>\n    </Structure>\n    <Contents>\n      <Partition DefId=\"C0\">\n        <Condition>\n          <Expression>\n            <Text><![CDATA[<a number> is less than <a number>]]></Text>\n            <Param><![CDATA[5]]></Param>\n          </Expression>\n          <Partition DefId=\"C1\">\n            <Condition>\n              <Expression>\n                <Param><![CDATA[0]]></Param>\n                <Param><![CDATA[0.7]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.05]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[0.7]]></Param>\n                <Param><![CDATA[0.8]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.052]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[0.8]]></Param>\n                <Param><![CDATA[0.9]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.053]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Text><![CDATA[<a number> is at least <a number>]]></Text>\n                <Param><![CDATA[0.9]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.055]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n          </Partition>\n        </Condition>\n        <Condition>\n          <Expression>\n            <Param><![CDATA[5]]></Param>\n            <Param><!['), NULL);     
INSERT INTO SYSTEM_LOB_STREAM VALUES(5, 1, STRINGDECODE('CDATA[8]]></Param>\n          </Expression>\n          <Partition DefId=\"C1\">\n            <Condition>\n              <Expression>\n                <Param><![CDATA[0]]></Param>\n                <Param><![CDATA[0.7]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.056]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[0.7]]></Param>\n                <Param><![CDATA[0.8]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.057]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[0.8]]></Param>\n                <Param><![CDATA[0.9]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.058]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Text><![CDATA[<a number> is at least <a number>]]></Text>\n                <Param><![CDATA[0.9]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.059]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n          </Partition>\n        </Condition>\n        <Condition>\n          <Expression>\n            <Param><![CDATA[9]]></Param>\n            <Param><![CDATA[12]]></Param>\n          </Expression>\n          <Partition DefId=\"C1\">\n            <Condition>\n              <Expression>\n                <Param><![CDATA[0]]></Param>\n                <Param><![CDATA[0.7]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.06]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[0.7]]></Param>\n                <Param><![CDATA[0.8]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.061]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[0.8]]></Param>\n                <Param><![CDATA[0.9]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.062]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Text><![CDATA[<a number> is at least <a number>]]></Text>\n                <Param><![CDATA[0.9]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.063]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n          </Partition>\n        </Condition>\n        <Condition>\n          <Expression>\n            <Param><![CDATA[13]]></Param>\n            <Param><![CDATA[17]]></Param>\n          </Expression>\n          <Partition DefId=\"C1\">\n            <Condition>\n              <Expression>\n                <Param><![CDATA'), NULL);         
INSERT INTO SYSTEM_LOB_STREAM VALUES(5, 2, STRINGDECODE('[0]]></Param>\n                <Param><![CDATA[0.7]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.064]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[0.7]]></Param>\n                <Param><![CDATA[0.8]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.065]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[0.8]]></Param>\n                <Param><![CDATA[0.9]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.066]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Text><![CDATA[<a number> is at least <a number>]]></Text>\n                <Param><![CDATA[0.9]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.067]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n          </Partition>\n        </Condition>\n        <Condition>\n          <Expression>\n            <Param><![CDATA[18]]></Param>\n            <Param><![CDATA[25]]></Param>\n          </Expression>\n          <Partition DefId=\"C1\">\n            <Condition>\n              <Expression>\n                <Param><![CDATA[0]]></Param>\n                <Param><![CDATA[0.7]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.068]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[0.7]]></Param>\n                <Param><![CDATA[0.8]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.069]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[0.8]]></Param>\n                <Param><![CDATA[0.9]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.07]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Text><![CDATA[<a number> is at least <a number>]]></Text>\n                <Param><![CDATA[0.9]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.08]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n          </Partition>\n        </Condition>\n        <Condition>\n          <Expression>\n            <Text><![CDATA[<a number> is at least <a number>]]></Text>\n            <Param><![CDATA[26]]></Param>\n          </Expression>\n          <Partition DefId=\"C1\">\n            <Condition>\n              <Expression>\n                <Param><![CDATA[0]]></Param>\n                <Param><![CDATA[0.7]]></Param>\n              </Expression>\n              <ActionSet>\n              '), NULL);            
INSERT INTO SYSTEM_LOB_STREAM VALUES(5, 3, STRINGDECODE('  <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.081]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[0.7]]></Param>\n                <Param><![CDATA[0.8]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.082]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[0.8]]></Param>\n                <Param><![CDATA[0.9]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.083]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Text><![CDATA[<a number> is at least <a number>]]></Text>\n                <Param><![CDATA[0.9]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[0.085]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n          </Partition>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <Partition DefId=\"C1\">\n            <Condition>\n              <Expression>\n                <Param/>\n                <Param/>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression/>\n                </Action>\n              </ActionSet>\n            </Condition>\n          </Partition>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        '), NULL);   
INSERT INTO SYSTEM_LOB_STREAM VALUES(5, 4, STRINGDECODE('</Condition>\n      </Partition>\n    </Contents>\n  </Body>\n    <Resources DefaultLocale=\"en_US\" xmlns=\"http://schemas.ilog.com/Rules/7.0/DecisionTable\">\n    <ResourceSet Locale=\"en_US\">\n      <Data Name=\"Definitions(A0)#HeaderText\"><![CDATA[Yearly interest rate]]></Data>\n      <Data Name=\"Definitions(A0)#Width\"><![CDATA[440]]></Data>\n      <Data Name=\"Definitions(C0)#HeaderText\"><![CDATA[Loan duration (y)]]></Data>\n      <Data Name=\"Definitions(C0)#Width\"><![CDATA[441]]></Data>\n      <Data Name=\"Definitions(C0)[0]#HeaderText\"><![CDATA[Min]]></Data>\n      <Data Name=\"Definitions(C0)[1]#HeaderText\"><![CDATA[Max]]></Data>\n      <Data Name=\"Definitions(C1)#HeaderText\"><![CDATA[Loan to Value]]></Data>\n      <Data Name=\"Definitions(C1)#Width\"><![CDATA[441]]></Data>\n      <Data Name=\"Definitions(C1)[0]#HeaderText\"><![CDATA[Min]]></Data>\n      <Data Name=\"Definitions(C1)[1]#HeaderText\"><![CDATA[Max]]></Data>\n    </ResourceSet>\n  </Resources>\n</DT>\n'), NULL);      
INSERT INTO SYSTEM_LOB_STREAM VALUES(6, 0, STRINGDECODE('<DT xmlns=\"http://schemas.ilog.com/Rules/7.0/DecisionTable\">\n    <Body xmlns=\"http://schemas.ilog.com/Rules/7.0/DecisionTable\">\n    <Properties>\n      <Property Name=\"Check.Overlap.ErrorLevel\">Error</Property>\n      <Property Name=\"Lock.ApplyLocking\" Type=\"xs:boolean\"><![CDATA[false]]></Property>\n      <Property Name=\"UI.ShowInvisibleColumns\" Type=\"xs:boolean\"><![CDATA[true]]></Property>\n      <Property Name=\"UI.ShowRuleView\" Type=\"xs:boolean\"><![CDATA[false]]></Property>\n    </Properties>\n    <Structure>\n      <ConditionDefinitions>\n        <ConditionDefinition Id=\"C0\">\n          <ExpressionDefinition>\n            <Properties>\n              <Property Name=\"context\" Type=\"ilog.rules.dt.model.check.IlrDTExpressionChecker$IntervalContext\">\n                <intervalContext direction=\"asc\" enabled=\"false\"/>\n              </Property>\n            </Properties>\n            <Text><![CDATA[the yearly income of ''the borrower'' is at least <min> and less than <max>]]></Text>\n          </ExpressionDefinition>\n        </ConditionDefinition>\n      </ConditionDefinitions>\n      <ActionDefinitions>\n        <ActionDefinition Id=\"A0\">\n          <ExpressionDefinition>\n            <Text><![CDATA[set ''the score'' to ''the score'' + <a number>]]></Text>\n          </ExpressionDefinition>\n        </ActionDefinition>\n      </ActionDefinitions>\n    </Structure>\n    <Contents>\n      <Partition DefId=\"C0\">\n        <Condition>\n          <Expression>\n            <Text><![CDATA[<a number> is less than <a number>]]></Text>\n            <Param><![CDATA[10000]]></Param>\n          </Expression>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression>\n                <Param><![CDATA[21]]></Param>\n              </Expression>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression>\n            <Param><![CDATA[10000]]></Param>\n            <Param><![CDATA[20000]]></Param>\n          </Expression>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression>\n                <Param><![CDATA[50]]></Param>\n              </Expression>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression>\n            <Param><![CDATA[20000]]></Param>\n            <Param><![CDATA[30000]]></Param>\n          </Expression>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression>\n                <Param><![CDATA[80]]></Param>\n              </Expression>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression>\n            <Param><![CDATA[30000]]></Param>\n            <Param><![CDATA[50000]]></Param>\n          </Expression>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression>\n                <Param><![CDATA[120]]></Param>\n              </Expression>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression>\n            <Param><![CDATA[50000]]></Param>\n            <Param><![CDATA[80000]]></Param>\n          </Expression>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression>\n                <Param><![CDATA[150]]></Param>\n              </Expression>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression>\n            <Param><![CDATA[80000]]></Param>\n            <Param><![CDATA[120000]]></Param>\n          </Expression>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression>\n                <Param><![CDATA[200]]></Param>\n              </Expression>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression>\n            <Param><![CDATA[120000]]></Param>\n            <Param><![CDATA[200000]]></Param>\n          </Expression>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression>\n                <Param><![CDATA[250]]></Param>\n              </Expression>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition'), NULL);              
INSERT INTO SYSTEM_LOB_STREAM VALUES(6, 1, STRINGDECODE('>\n          <Expression>\n            <Text><![CDATA[<a number> is at least <a number>]]></Text>\n            <Param><![CDATA[200000]]></Param>\n          </Expression>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression>\n                <Param><![CDATA[300]]></Param>\n              </Expression>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n      </Partition>\n    </Contents>\n  </Body>\n    <Resources DefaultLocale=\"en_US\" xmlns=\"http://schemas.ilog.com/Rules/7.0/DecisionTable\">\n    <ResourceSet Locale=\"en_US\">\n      <Data Name=\"/0/A#Comment\"><![CDATA[low salary]]></Data>\n      <Data Name=\"Definitions(A0)#HeaderText\"><![CDATA[Add to corporate score]]></Data>\n      <Data Name=\"Definitions(A0)#Width\"><![CDATA[661]]></Data>\n      <Data Name=\"Definitions(C0)#HeaderText\"><![CDATA[Yearly income]]></Data>\n      <Data Name=\"Definitions(C0)#Width\"><![CDATA[661]]></Data>\n      <Data Name=\"Definitions(C0)[0]#HeaderText\"><![CDATA[Min]]></Data>\n      <Data Name=\"Definitions(C0)[1]#HeaderText\"><![CDATA[Max]]></Data>\n    </ResourceSet>\n  </Resources>\n</DT>\n'), NULL);     
INSERT INTO SYSTEM_LOB_STREAM VALUES(7, 0, STRINGDECODE('<DT xmlns=\"http://schemas.ilog.com/Rules/7.0/DecisionTable\">\n    <Body xmlns=\"http://schemas.ilog.com/Rules/7.0/DecisionTable\">\n    <Properties>\n      <Property Name=\"Check.Overlap.ErrorLevel\">Error</Property>\n      <Property Name=\"Lock.ApplyLocking\" Type=\"xs:boolean\"><![CDATA[false]]></Property>\n      <Property Name=\"UI.ShowCellTooltip\" Type=\"xs:boolean\"><![CDATA[false]]></Property>\n      <Property Name=\"UI.ShowInvisibleColumns\" Type=\"xs:boolean\"><![CDATA[true]]></Property>\n      <Property Name=\"UI.ShowRuleView\" Type=\"xs:boolean\"><![CDATA[false]]></Property>\n    </Properties>\n    <Preconditions>\n      <Text><![CDATA[if\n\t''the borrower'' has filed a bankruptcy]]></Text>\n    </Preconditions>\n    <Structure>\n      <ConditionDefinitions>\n        <ConditionDefinition Id=\"C0\">\n          <ExpressionDefinition>\n            <Properties>\n              <Property Name=\"context\" Type=\"ilog.rules.dt.model.check.IlrDTExpressionChecker$IntervalContext\">\n                <intervalContext direction=\"asc\" enabled=\"false\"/>\n              </Property>\n            </Properties>\n            <Text><![CDATA[the age of the latest bankruptcy of ''the borrower'' is between <min> and <max>]]></Text>\n          </ExpressionDefinition>\n        </ConditionDefinition>\n      </ConditionDefinitions>\n      <ActionDefinitions>\n        <ActionDefinition Id=\"A0\">\n          <ExpressionDefinition>\n            <Text><![CDATA[set ''the score'' to ''the score'' + <a number>]]></Text>\n          </ExpressionDefinition>\n        </ActionDefinition>\n      </ActionDefinitions>\n    </Structure>\n    <Contents>\n      <Partition DefId=\"C0\">\n        <Condition>\n          <Expression>\n            <Param><![CDATA[0]]></Param>\n            <Param><![CDATA[1]]></Param>\n          </Expression>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression>\n                <Param><![CDATA[-200]]></Param>\n              </Expression>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression>\n            <Param><![CDATA[2]]></Param>\n            <Param><![CDATA[5]]></Param>\n          </Expression>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression>\n                <Param><![CDATA[-100]]></Param>\n              </Expression>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression>\n            <Param><![CDATA[6]]></Param>\n            <Param><![CDATA[8]]></Param>\n          </Expression>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression>\n                <Param><![CDATA[-50]]></Param>\n              </Expression>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression>\n            <Otherwise/>\n          </Expression>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression>\n                <Param><![CDATA[-10]]></Param>\n              </Expression>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n    '), NULL);        
INSERT INTO SYSTEM_LOB_STREAM VALUES(7, 1, STRINGDECODE('          <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n        <Condition>\n          <Expression/>\n          <ActionSet>\n            <Action DefId=\"A0\">\n              <Expression/>\n            </Action>\n          </ActionSet>\n        </Condition>\n      </Partition>\n    </Contents>\n  </Body>\n    <Resources DefaultLocale=\"en_US\" xmlns=\"http://schemas.ilog.com/Rules/7.0/DecisionTable\">\n    <ResourceSet Locale=\"en_US\">\n      <Data Name=\"Definitions(A0)#HeaderText\"><![CDATA[Add to corporate score]]></Data>\n      <Data Name=\"Definitions(A0)#Width\"><![CDATA[661]]></Data>\n      <Data Name=\"Definitions(C0)#HeaderText\"><![CDATA[Age of latest bankruptcy]]></Data>\n      <Data Name=\"Definitions(C0)#Width\"><![CDATA[661]]></Data>\n      <Data Name=\"Definitions(C0)[0]#HeaderText\"><![CDATA[Min]]></Data>\n      <Data Name=\"Definitions(C0)[1]#HeaderText\"><![CDATA[Max]]></Data>\n    </ResourceSet>\n  </Resources>\n</DT>\n'), NULL);    
INSERT INTO SYSTEM_LOB_STREAM VALUES(8, 0, STRINGDECODE('<DT xmlns=\"http://schemas.ilog.com/Rules/7.0/DecisionTable\">\n    <Body xmlns=\"http://schemas.ilog.com/Rules/7.0/DecisionTable\">\n    <Properties>\n      <Property Name=\"Lock.ApplyLocking\" Type=\"xs:boolean\"><![CDATA[false]]></Property>\n      <Property Name=\"UI.RenderBoolean\" Type=\"xs:boolean\"><![CDATA[true]]></Property>\n      <Property Name=\"UI.ShowLockIcon\" Type=\"xs:boolean\"><![CDATA[false]]></Property>\n      <Property Name=\"UI.ShowRuleView\" Type=\"xs:boolean\"><![CDATA[false]]></Property>\n    </Properties>\n    <Preconditions>\n      <Text><![CDATA[if the yearly income of ''the borrower'' is more than 0\n\t ]]></Text>\n    </Preconditions>\n    <Structure>\n      <ConditionDefinitions>\n        <ConditionDefinition Id=\"C0\">\n          <ExpressionDefinition>\n            <Text><![CDATA[the yearly repayment of ''the loan'' * 100 / the yearly income of ''the borrower'' is at least <min> and less than <max>]]></Text>\n          </ExpressionDefinition>\n        </ConditionDefinition>\n        <ConditionDefinition Id=\"C1\">\n          <ExpressionDefinition>\n            <Text><![CDATA[the credit score of ''the borrower'' is at least <min> and less than <max>]]></Text>\n          </ExpressionDefinition>\n        </ConditionDefinition>\n      </ConditionDefinitions>\n      <ActionDefinitions>\n        <ActionDefinition Id=\"A0\">\n          <ExpressionDefinition>\n            <Text><![CDATA[add <a string> to the messages of ''the loan'']]></Text>\n          </ExpressionDefinition>\n        </ActionDefinition>\n        <ActionDefinition Id=\"A1\">\n          <ExpressionDefinition>\n            <Text><![CDATA[make it <a boolean> that ''the loan''  is approved]]></Text>\n          </ExpressionDefinition>\n        </ActionDefinition>\n      </ActionDefinitions>\n    </Structure>\n    <Contents>\n      <Partition DefId=\"C0\">\n        <Condition>\n          <Expression>\n            <Param><![CDATA[0]]></Param>\n            <Param><![CDATA[30]]></Param>\n          </Expression>\n          <Partition DefId=\"C1\">\n            <Condition>\n              <Expression>\n                <Param><![CDATA[0]]></Param>\n                <Param><![CDATA[200]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[\"debt-to-income too high compared to credit score\"]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[false]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[200]]></Param>\n                <Param><![CDATA[800]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\" Enabled=\"false\">\n                  <Expression/>\n                </Action>\n                <Action DefId=\"A1\" Enabled=\"false\">\n                  <Expression>\n                    <Param><![CDATA[true]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n          </Partition>\n        </Condition>\n        <Condition>\n          <Expression>\n            <Param><![CDATA[30]]></Param>\n            <Param><![CDATA[45]]></Param>\n          </Expression>\n          <Partition DefId=\"C1\">\n            <Condition>\n              <Expression>\n                <Param><![CDATA[0]]></Param>\n                <Param><![CDATA[400]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[\"debt-to-income too high compared to credit score\"]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[false]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <E'), NULL);              
INSERT INTO SYSTEM_LOB_STREAM VALUES(8, 1, STRINGDECODE('xpression>\n                <Param><![CDATA[400]]></Param>\n                <Param><![CDATA[800]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\" Enabled=\"false\">\n                  <Expression/>\n                </Action>\n                <Action DefId=\"A1\" Enabled=\"false\">\n                  <Expression>\n                    <Param><![CDATA[true]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n          </Partition>\n        </Condition>\n        <Condition>\n          <Expression>\n            <Param><![CDATA[45]]></Param>\n            <Param><![CDATA[50]]></Param>\n          </Expression>\n          <Partition DefId=\"C1\">\n            <Condition>\n              <Expression>\n                <Param><![CDATA[0]]></Param>\n                <Param><![CDATA[600]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[\"debt-to-income too high compared to credit score\"]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[false]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n            <Condition>\n              <Expression>\n                <Param><![CDATA[600]]></Param>\n                <Param><![CDATA[800]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\" Enabled=\"false\">\n                  <Expression/>\n                </Action>\n                <Action DefId=\"A1\" Enabled=\"false\">\n                  <Expression>\n                    <Param><![CDATA[true]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n          </Partition>\n        </Condition>\n        <Condition>\n          <Expression>\n            <Text><![CDATA[<a number> is at least <a number>]]></Text>\n            <Param><![CDATA[50]]></Param>\n          </Expression>\n          <Partition DefId=\"C1\">\n            <Condition>\n              <Expression>\n                <Param><![CDATA[0]]></Param>\n                <Param><![CDATA[800]]></Param>\n              </Expression>\n              <ActionSet>\n                <Action DefId=\"A0\">\n                  <Expression>\n                    <Param><![CDATA[\"debt-to-income too high compared to credit score\"]]></Param>\n                  </Expression>\n                </Action>\n                <Action DefId=\"A1\">\n                  <Expression>\n                    <Param><![CDATA[false]]></Param>\n                  </Expression>\n                </Action>\n              </ActionSet>\n            </Condition>\n          </Partition>\n        </Condition>\n      </Partition>\n    </Contents>\n  </Body>\n    <Resources DefaultLocale=\"en_US\" xmlns=\"http://schemas.ilog.com/Rules/7.0/DecisionTable\">\n    <ResourceSet Locale=\"en_US\">\n      <Data Name=\"/0/0/A#Height\"><![CDATA[19]]></Data>\n      <Data Name=\"/0/1/A#Height\"><![CDATA[19]]></Data>\n      <Data Name=\"/0[]#Format\"><![CDATA[{0,number,#0.##} %]]></Data>\n      <Data Name=\"/1/1/A#Height\"><![CDATA[20]]></Data>\n      <Data Name=\"/1[]#Format\"><![CDATA[{0,number,#0.##} %]]></Data>\n      <Data Name=\"/2[]#Format\"><![CDATA[{0,number,#0.##} %]]></Data>\n      <Data Name=\"/3[]#Format\"><![CDATA[\u2265 {0} %]]></Data>\n      <Data Name=\"Definitions(A0)#HeaderText\"><![CDATA[message]]></Data>\n      <Data Name=\"Definitions(A0)#Width\"><![CDATA[262]]></Data>\n      <Data Name=\"Definitions(A1)#HeaderText\"><![CDATA[ loan approved]]></Data>\n      <Data Name=\"Definitions(A1)#Width\"><![CDATA[261]]></Data>\n      <Data Name=\"Definitions(C0)#HeaderText\"><![CDATA[debt to income]]></Data>\n      <Data Name=\"Definitions(C0)#Width\"><![CDATA[301]]></Data>\n      <Data Name=\"Definitions(C0)[0]#HeaderText\"><![CDATA[min]]></Data>\n      <Data Name=\"Definitions(C0)[1]#HeaderText\"><![CDATA[max]]></Data>\n      <Data Name=\"Definition'), NULL);         
INSERT INTO SYSTEM_LOB_STREAM VALUES(8, 2, STRINGDECODE('s(C1)#HeaderText\"><![CDATA[credit score]]></Data>\n      <Data Name=\"Definitions(C1)#Width\"><![CDATA[319]]></Data>\n      <Data Name=\"Definitions(C1)[0]#HeaderText\"><![CDATA[min]]></Data>\n      <Data Name=\"Definitions(C1)[1]#HeaderText\"><![CDATA[max]]></Data>\n    </ResourceSet>\n  </Resources>\n</DT>\n'), NULL);    
INSERT INTO "PUBLIC"."DEFINITION" VALUES
(10, 30, 52, 2147483647, 10, 7, STRINGDECODE('definitions \n    set ''minimum score'' to 200 ;\nif \n    the credit score of ''the borrower'' is less than ''minimum score'' \nthen \n    in ''the loan report'', refuse the loan with the message \"Credit score below \" + ''minimum score'' ;\n'), NULL, 10),
(11, 30, 53, 2147483647, 11, 7, STRINGDECODE('then \n    set insurance required in ''the loan report'' to true ;\n    set the insurance rate in ''the loan report'' to 0.02 ;\n'), NULL, 11),
(12, 30, 54, 2147483647, 12, 7, 'then print "unvalidated rule called"; ', NULL, 12),
(13, 30, 55, 2147483647, 13, 7, SYSTEM_COMBINE_CLOB(4), NULL, 13),
(14, 30, 70, 2147483647, 14, 10, SYSTEM_COMBINE_CLOB(5), NULL, 14),
(15, 30, 71, 2147483647, 15, 10, STRINGDECODE('then \n    set ''the score'' to the credit score of ''the borrower''; \n\n'), NULL, 15),
(16, 30, 72, 2147483647, 16, 10, STRINGDECODE('definitions \n    set amount to the amount of ''the loan''; \n    set duration to the number of monthly payments of ''the loan'';\n    set rate to the yearly interest rate of ''the loan report'';\n\nthen \n    set the monthly repayment of ''the loan report'' to \n        the computed monthly repayment for a loan of amount during duration with a yearly rate of rate ;\n    print \"monthly repayment calculated.\";\n\n'), NULL, 16),
(17, 30, 73, 2147483647, 17, 10, SYSTEM_COMBINE_CLOB(6), NULL, 17),
(18, 30, 74, 2147483647, 18, 10, STRINGDECODE('if \n    it is not true that ''the borrower'' has filed a bankruptcy \nthen \n    set ''the score'' to ''the score'' + 20;\n'), NULL, 18),
(19, 30, 75, 2147483647, 19, 10, SYSTEM_COMBINE_CLOB(7), NULL, 19),
(20, 30, 327, 2147483647, 20, 16, SYSTEM_COMBINE_CLOB(8), NULL, 20),
(21, 30, 328, 2147483647, 21, 16, STRINGDECODE('if \n  the yearly repayment of ''the loan'' is more than the yearly income of ''the borrower'' * 0.3\nthen \n  add \"Too big Debt-To-Income ratio\" to the messages of ''the loan'' ;\n  reject ''the loan'' ;'), NULL, 21),
(22, 30, 329, 2147483647, 22, 16, STRINGDECODE('if\n    the credit score of ''the borrower'' is less than 200\nthen\n    add \"Credit score below 200\" to the messages of ''the loan'' ;\n    reject ''the loan'';'), NULL, 22),
(23, 30, 331, 2147483647, 23, 16, STRINGDECODE('if \n  the amount of ''the loan'' is more than 1,000,000 \nthen\n  add \"The loan cannot exceed 1,000,000\" to the messages of ''the loan'' ;\n  reject ''the loan'' ;\n  '), NULL, 23);     
CREATE UNIQUE INDEX "PUBLIC"."DEFINITIONCONTAINERUNIQUE" ON "PUBLIC"."DEFINITION"("CONTAINER", "ENDID", "BASELINE");           
CREATE INDEX "PUBLIC"."FKDEFINITIONTYPIDX" ON "PUBLIC"."DEFINITION"("TYPE");   
CREATE INDEX "PUBLIC"."FKDEFINITIONSTRTDIDX" ON "PUBLIC"."DEFINITION"("STARTID");              
CREATE INDEX "PUBLIC"."FKDEFINITIONNDDIDX" ON "PUBLIC"."DEFINITION"("ENDID");  
CREATE INDEX "PUBLIC"."FKDEFINITIONBSLNIDX" ON "PUBLIC"."DEFINITION"("BASELINE");              
CREATE CACHED TABLE "PUBLIC"."OVERRIDDENRULE"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "ILRRULE" INTEGER,
    "CONTAINER" INTEGER NOT NULL
);            
ALTER TABLE "PUBLIC"."OVERRIDDENRULE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_3D" PRIMARY KEY("ID");               
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.OVERRIDDENRULE;           
CREATE INDEX "PUBLIC"."OVERRIDDENRULE_CONTAINER" ON "PUBLIC"."OVERRIDDENRULE"("CONTAINER");    
CREATE INDEX "PUBLIC"."FKOVERRIDDENRULETYPIDX" ON "PUBLIC"."OVERRIDDENRULE"("TYPE");           
CREATE INDEX "PUBLIC"."FKOVERRIDDENRULESTRTDIDX" ON "PUBLIC"."OVERRIDDENRULE"("STARTID");      
CREATE INDEX "PUBLIC"."FKOVERRIDDENRULENDDIDX" ON "PUBLIC"."OVERRIDDENRULE"("ENDID");          
CREATE INDEX "PUBLIC"."FKOVERRIDDENRULEBSLNIDX" ON "PUBLIC"."OVERRIDDENRULE"("BASELINE");      
CREATE INDEX "PUBLIC"."FKOVERRIDDENRULELRRLIDX" ON "PUBLIC"."OVERRIDDENRULE"("ILRRULE");       
CREATE CACHED TABLE "PUBLIC"."RULEARTIFACTTAG"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "CONTAINER" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "VALUE" CLOB(52428800)
);    
ALTER TABLE "PUBLIC"."RULEARTIFACTTAG" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_E5" PRIMARY KEY("ID");              
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.RULEARTIFACTTAG;          
CREATE INDEX "PUBLIC"."RULARTTAG_CONTAINER" ON "PUBLIC"."RULEARTIFACTTAG"("CONTAINER");        
CREATE UNIQUE INDEX "PUBLIC"."RULARTTAGNAMEUNIQUE" ON "PUBLIC"."RULEARTIFACTTAG"("CONTAINER", "ENDID", "NAME", "BASELINE");    
CREATE INDEX "PUBLIC"."FKRULARTTAGTYPIDX" ON "PUBLIC"."RULEARTIFACTTAG"("TYPE");               
CREATE INDEX "PUBLIC"."FKRULARTTAGSTRTDIDX" ON "PUBLIC"."RULEARTIFACTTAG"("STARTID");          
CREATE INDEX "PUBLIC"."FKRULARTTAGNDDIDX" ON "PUBLIC"."RULEARTIFACTTAG"("ENDID");              
CREATE INDEX "PUBLIC"."FKRULARTTAGBSLNIDX" ON "PUBLIC"."RULEARTIFACTTAG"("BASELINE");          
CREATE CACHED TABLE "PUBLIC"."SCOPEELEMENT"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "CONTAINER" INTEGER NOT NULL,
    "ILRORDER" INTEGER,
    "ILRRULE" INTEGER,
    "RULEPACKAGE" INTEGER,
    "RULETASKNAME" VARCHAR(255)
);          
ALTER TABLE "PUBLIC"."SCOPEELEMENT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_F5" PRIMARY KEY("ID"); 
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.SCOPEELEMENT;             
CREATE INDEX "PUBLIC"."SCOPEELEMENT_CONTAINER" ON "PUBLIC"."SCOPEELEMENT"("CONTAINER");        
CREATE INDEX "PUBLIC"."FKSCOPEELEMENTTYPIDX" ON "PUBLIC"."SCOPEELEMENT"("TYPE");               
CREATE INDEX "PUBLIC"."FKSCOPEELEMENTSTRTDIDX" ON "PUBLIC"."SCOPEELEMENT"("STARTID");          
CREATE INDEX "PUBLIC"."FKSCOPEELEMENTNDDIDX" ON "PUBLIC"."SCOPEELEMENT"("ENDID");              
CREATE INDEX "PUBLIC"."FKSCOPEELEMENTBSLNIDX" ON "PUBLIC"."SCOPEELEMENT"("BASELINE");          
CREATE INDEX "PUBLIC"."FKSCOPEELEMENTLRRLIDX" ON "PUBLIC"."SCOPEELEMENT"("ILRRULE");           
CREATE INDEX "PUBLIC"."FKSCOPEELEMENTRLPCKGIDX" ON "PUBLIC"."SCOPEELEMENT"("RULEPACKAGE");     
CREATE CACHED TABLE "PUBLIC"."VARIABLESET"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER
);       
ALTER TABLE "PUBLIC"."VARIABLESET" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_BFF" PRIMARY KEY("ID"); 
-- 3 +/- SELECT COUNT(*) FROM PUBLIC.VARIABLESET;              
INSERT INTO "PUBLIC"."VARIABLESET" VALUES
(1, 41, 14, 2147483647, 1, 1, 'ruleset variables', '66f69a65-d7fa-4596-b8ad-08e837c89800', NULL, '', NULL, 1),
(2, 41, 15, 2147483647, 2, 1, 'parameters', '3abc737a-ba41-4dcf-a7d1-012b9484f9f8', NULL, NULL, NULL, 1),
(3, 41, 332, 2147483647, 3, 16, 'Miniloan ServiceParameters', '92d289c8-4db8-4669-bb9f-4a48010ba78c', NULL, NULL, NULL, 6); 
CREATE INDEX "PUBLIC"."VARIABLESET_PRJBRANCH" ON "PUBLIC"."VARIABLESET"("PROJECT", "BASELINE");
CREATE UNIQUE INDEX "PUBLIC"."VARIABLESETUUIDUNIQUE" ON "PUBLIC"."VARIABLESET"("UUID", "BASELINE", "ENDID");   
CREATE INDEX "PUBLIC"."FKVARIABLESETTYPIDX" ON "PUBLIC"."VARIABLESET"("TYPE"); 
CREATE INDEX "PUBLIC"."FKVARIABLESETSTRTDIDX" ON "PUBLIC"."VARIABLESET"("STARTID");            
CREATE INDEX "PUBLIC"."FKVARIABLESETNDDIDX" ON "PUBLIC"."VARIABLESET"("ENDID");
CREATE INDEX "PUBLIC"."FKVARIABLESETBSLNIDX" ON "PUBLIC"."VARIABLESET"("BASELINE");            
CREATE INDEX "PUBLIC"."FKVARIABLESETDIDX" ON "PUBLIC"."VARIABLESET"("UUID");   
CREATE INDEX "PUBLIC"."FKVARIABLESETRLPCKGIDX" ON "PUBLIC"."VARIABLESET"("RULEPACKAGE");       
CREATE CACHED TABLE "PUBLIC"."OPERATIONVARIABLE"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "CONTAINER" INTEGER NOT NULL,
    "DIRECTION" VARCHAR(30),
    "VARIABLENAME" VARCHAR(255),
    "VARIABLESET" INTEGER
);       
ALTER TABLE "PUBLIC"."OPERATIONVARIABLE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_F1" PRIMARY KEY("ID");            
-- 21 +/- SELECT COUNT(*) FROM PUBLIC.OPERATIONVARIABLE;       
INSERT INTO "PUBLIC"."OPERATIONVARIABLE" VALUES
(1, 110, 57, 2147483647, 1, 7, 1, 'OUT', 'grade', 1),
(2, 110, 57, 2147483647, 2, 7, 1, 'IN', 'score', 1),
(3, 110, 57, 2147483647, 3, 7, 1, 'OUT', 'report', 2),
(4, 110, 57, 2147483647, 4, 7, 1, 'IN', 'loan', 2),
(5, 110, 57, 2147483647, 5, 7, 1, 'IN', 'borrower', 2),
(6, 110, 77, 2147483647, 6, 10, 3, 'OUT', 'score', 1),
(7, 110, 77, 2147483647, 7, 10, 3, 'OUT', 'report', 2),
(8, 110, 77, 2147483647, 8, 10, 3, 'IN', 'loan', 2),
(9, 110, 77, 2147483647, 9, 10, 3, 'IN', 'borrower', 2),
(10, 110, 95, 2147483647, 10, 13, 5, 'OUT', 'grade', 1),
(11, 110, 95, 2147483647, 11, 13, 5, 'OUT', 'score', 1),
(12, 110, 95, 2147483647, 12, 13, 5, 'OUT', 'report', 2),
(13, 110, 95, 2147483647, 13, 13, 5, 'IN', 'loan', 2),
(14, 110, 95, 2147483647, 14, 13, 5, 'IN', 'borrower', 2),
(15, 110, 96, 2147483647, 15, 13, 6, 'OUT', 'report', 2),
(16, 110, 96, 2147483647, 16, 13, 6, 'IN', 'loan', 2),
(17, 110, 96, 2147483647, 17, 13, 6, 'IN', 'borrower', 2),
(18, 110, 334, 349, 18, 16, 9, 'IN', 'borrower', NULL),
(19, 110, 334, 350, 19, 16, 9, 'INOUT', 'loan', NULL),
(20, 110, 349, 2147483647, 18, 16, 9, 'IN', 'borrower', 3),
(21, 110, 350, 2147483647, 19, 16, 9, 'INOUT', 'loan', 3);     
CREATE INDEX "PUBLIC"."OPVARIABLE_CONTAINER" ON "PUBLIC"."OPERATIONVARIABLE"("CONTAINER");     
CREATE INDEX "PUBLIC"."FKOPVARIABLETYPIDX" ON "PUBLIC"."OPERATIONVARIABLE"("TYPE");            
CREATE INDEX "PUBLIC"."FKOPVARIABLESTRTDIDX" ON "PUBLIC"."OPERATIONVARIABLE"("STARTID");       
CREATE INDEX "PUBLIC"."FKOPVARIABLENDDIDX" ON "PUBLIC"."OPERATIONVARIABLE"("ENDID");           
CREATE INDEX "PUBLIC"."FKOPVARIABLEBSLNIDX" ON "PUBLIC"."OPERATIONVARIABLE"("BASELINE");       
CREATE INDEX "PUBLIC"."FKOPVARIABLEVRBLSTIDX" ON "PUBLIC"."OPERATIONVARIABLE"("VARIABLESET");  
CREATE CACHED TABLE "PUBLIC"."VARIABLE"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "BOMTYPE" CLOB(52428800) NOT NULL,
    "INITIALVALUE" CLOB(52428800),
    "NAME" VARCHAR(255) NOT NULL,
    "VERBALIZATION" CLOB(52428800),
    "CONTAINER" INTEGER NOT NULL
);         
ALTER TABLE "PUBLIC"."VARIABLE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_E4" PRIMARY KEY("ID");     
-- 7 +/- SELECT COUNT(*) FROM PUBLIC.VARIABLE; 
INSERT INTO "PUBLIC"."VARIABLE" VALUES
(1, 39, 14, 2147483647, 1, 1, 'java.lang.Integer', '0', 'score', 'the score', 1),
(2, 39, 14, 2147483647, 2, 1, 'java.lang.String', '""', 'grade', 'the grade', 1),
(3, 39, 15, 2147483647, 3, 1, 'loan.LoanRequest', '', 'loan', 'the loan', 2),
(4, 39, 15, 2147483647, 4, 1, 'loan.Report', '', 'report', 'the loan report', 2),
(5, 39, 15, 2147483647, 5, 1, 'loan.Borrower', '', 'borrower', 'the borrower', 2),
(6, 39, 332, 2147483647, 6, 16, 'miniloan.Borrower', '', 'borrower', 'the borrower', 3),
(7, 39, 332, 2147483647, 7, 16, 'miniloan.Loan', '', 'loan', 'the loan', 3);            
CREATE INDEX "PUBLIC"."VARIABLE_CONTAINER" ON "PUBLIC"."VARIABLE"("CONTAINER");
CREATE INDEX "PUBLIC"."FKVARIABLETYPIDX" ON "PUBLIC"."VARIABLE"("TYPE");       
CREATE INDEX "PUBLIC"."FKVARIABLESTRTDIDX" ON "PUBLIC"."VARIABLE"("STARTID");  
CREATE INDEX "PUBLIC"."FKVARIABLENDDIDX" ON "PUBLIC"."VARIABLE"("ENDID");      
CREATE INDEX "PUBLIC"."FKVARIABLEBSLNIDX" ON "PUBLIC"."VARIABLE"("BASELINE");  
CREATE CACHED TABLE "PUBLIC"."VOCABULARY"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER,
    "BODY" CLOB(52428800),
    "LOCALE" VARCHAR(30)
);   
ALTER TABLE "PUBLIC"."VOCABULARY" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_E59" PRIMARY KEY("ID");  
-- 2 +/- SELECT COUNT(*) FROM PUBLIC.VOCABULARY;               
INSERT INTO SYSTEM_LOB_STREAM VALUES(9, 0, STRINGDECODE('# Vocabulary Properties\nfile = /loanvalidation-rules/bom/model_en.voc\nuuid = 298ef717-efd8-4b46-9bfc-28f2f82612b0\n\n# Term: age of the latest bankruptcy\n@age\\ of\\ the\\ latest\\ bankruptcy#plural = ages of latest bankruptcies\n\n# Term: number of digits\n@number\\ of\\ digits#plural = numbers of digits\n\n# loan.Borrower\nloan.Borrower#concept.label = borrower\n\n# loan.Borrower.Bankruptcy\nloan.Borrower.Bankruptcy#concept.label = bankruptcy\nloan.Borrower.Bankruptcy.chapter#phrase.navigation = {chapter} of {this}\nloan.Borrower.Bankruptcy.date#phrase.navigation = {date} of {this}\nloan.Borrower.Bankruptcy.reason#phrase.navigation = {reason} of {this}\n\n# loan.Borrower.SSN\nloan.Borrower.SSN#concept.label = SSN\nloan.Borrower.SSN.areaNumber#phrase.navigation = {area number} of {this}\nloan.Borrower.SSN.digits#phrase.navigation = {number of digits} of {this}\nloan.Borrower.SSN.fullNumber#phrase.navigation = {full number} of {this}\nloan.Borrower.SSN.groupCode#phrase.navigation = {group code} of {this}\nloan.Borrower.SSN.serialNumber#phrase.navigation = {serial number} of {this}\nloan.Borrower.SSNCode#phrase.navigation = {SSNCode} of {this}\nloan.Borrower.age#phrase.navigation = {age} of {this}\nloan.Borrower.birthDate#phrase.navigation = {birth date} of {this}\nloan.Borrower.creditScore#phrase.action = set the credit score of {this} to {credit score}\nloan.Borrower.creditScore#phrase.navigation = {credit score} of {this}\nloan.Borrower.firstName#phrase.navigation = {first name} of {this}\nloan.Borrower.getBankruptcyAge()#phrase.navigation = {age of the latest bankruptcy} of {this}\nloan.Borrower.hasLatestBankrupcy()#phrase.navigation = {this} has filed a bankruptcy\nloan.Borrower.lastName#phrase.navigation = {last name} of {this}\nloan.Borrower.latestBankruptcyChapter#phrase.navigation = {latest bankruptcy chapter} of {this}\nloan.Borrower.latestBankruptcyDate#phrase.navigation = {latest bankruptcy date} of {this}\nloan.Borrower.latestBankruptcyReason#phrase.navigation = {latest bankruptcy reason} of {this}\nloan.Borrower.spouse#phrase.action = set the spouse of {this} to {spouse}\nloan.Borrower.spouse#phrase.navigation = {spouse} of {this}\nloan.Borrower.ssn#phrase.navigation = {SSN} of {this}\nloan.Borrower.yearlyIncome#phrase.action = set the yearly income of {this} to {yearly income}\nloan.Borrower.yearlyIncome#phrase.navigation = {yearly income} of {this}\nloan.Borrower.zipCode#phrase.action = set the zip code of the address of {this} to {zip code}\nloan.Borrower.zipCode#phrase.navigation = {zip code} of the address of {this}\n\n# loan.LoanRequest\nloan.LoanRequest#concept.label = loan\nloan.LoanRequest.amount#phrase.navigation = {amount} of {this}\nloan.LoanRequest.duration#phrase.navigation = {duration} (in years) of {this}\nloan.LoanRequest.loanToValue#phrase.action = set the Loan to Value of {this} to {Loan to Value}\nloan.LoanRequest.loanToValue#phrase.navigation = {Loan to Value} of {this}\nloan.LoanRequest.numberOfMonthlyPayments#phrase.navigation = {number of monthly payments} of {this}\nloan.LoanRequest.startDate#phrase.navigation = {start date} of {this}\n\n# loan.LoanUtil\nloan.LoanUtil#concept.label = loan util\nloan.LoanUtil.containsOnlyDigits(java.lang.String)#phrase.navigation = {0} contains only digits\nloan.LoanUtil.formattedAmount(double)#phrase.navigation = (formatted amount) {0}\nloan.LoanUtil.formattedPercentage(double)#phrase.navigation = (formatted percentage) {0}\nloan.LoanUtil.getMonthlyRepayment(double,int,double)#phrase.navigation = the computed monthly repayment for a loan of {0, <amount>} during {1, <months>} with a yearly rate of {2, <rate>}\n\n# loan.Report\nloan.Report#concept.label = report\nloan.Report.addMessage(java.lang.String)#phrase.action = in {this}, add the message {0}\nloan.Report.approveLoan(java.lang.String)#phrase.action = in {this}, accept the loan with the message {0}\nloan.Report.approved#phrase.action = set the approved of {this} to {approved}\nloan.Report.approved#phrase.navigation = {this} is approved\nloan.Report.borrower#phrase.navigation = {borrower} of {this}\nloan.Report.insurance#phrase.navigation = {insurance} of {this}\nloan.'), NULL);
INSERT INTO SYSTEM_LOB_STREAM VALUES(9, 1, STRINGDECODE('Report.insuranceRate#phrase.action = set the insurance rate in {this} to {insurance rate}\nloan.Report.insuranceRate#phrase.navigation = {insurance rate} of {this}\nloan.Report.insuranceRequired#phrase.action = set insurance required in {this} to {insurance required}\nloan.Report.insuranceRequired#phrase.navigation = {this} is insurance required\nloan.Report.loan#phrase.navigation = {loan} of {this}\nloan.Report.message#phrase.navigation = {message} of {this}\nloan.Report.messages#phrase.navigation = {message} of {this}\nloan.Report.monthlyRepayment#phrase.action = set the monthly repayment of {this} to {monthly repayment}\nloan.Report.monthlyRepayment#phrase.navigation = {monthly repayment} of {this}\nloan.Report.rejectData(java.lang.String)#phrase.action = in {this}, reject the data with the message {0}\nloan.Report.rejectLoan(java.lang.String)#phrase.action = in {this}, refuse the loan with the message {0}\nloan.Report.validData#phrase.action = set the valid data of {this} to {valid data}\nloan.Report.validData#phrase.navigation = {this} is valid data\nloan.Report.yearlyInterestRate#phrase.action = set the yearly interest rate of {this} to {yearly interest rate}\nloan.Report.yearlyInterestRate#phrase.navigation = {yearly interest rate} of {this}\nloan.Report.yearlyRepayment#phrase.navigation = {yearly repayment} of {this}\n'), NULL);        
INSERT INTO "PUBLIC"."VOCABULARY" VALUES
(1, 34, 17, 2147483647, 1, 1, 'model', '298ef717-efd8-4b46-9bfc-28f2f82612b0', NULL, NULL, NULL, 1, SYSTEM_COMBINE_CLOB(9), 'en'),
(2, 34, 325, 2147483647, 2, 16, 'miniloan', 'cbb8ced6-1bcf-452d-962f-12938c8e7da6', NULL, NULL, NULL, 6, STRINGDECODE('# Vocabulary Properties\nuuid = cbb8ced6-1bcf-452d-962f-12938c8e7da6\n\n# miniloan.Borrower\nminiloan.Borrower#concept.label = borrower\nminiloan.Borrower.creditScore#phrase.action = set the credit score of {this} to {credit score}\nminiloan.Borrower.creditScore#phrase.navigation = {credit score} of {this}\nminiloan.Borrower.name#phrase.navigation = {name} of {this}\nminiloan.Borrower.yearlyIncome#phrase.action = set the yearly income of {this} to {yearly income}\nminiloan.Borrower.yearlyIncome#phrase.navigation = {yearly income} of {this}\n\n# miniloan.Loan\nminiloan.Loan#concept.label = loan\nminiloan.Loan.addToMessages(java.lang.String)#phrase.action = add {0} to the messages of {this}\nminiloan.Loan.amount#phrase.navigation = {amount} of {this}\nminiloan.Loan.approvalStatus#phrase.navigation = {approval status} of {this}\nminiloan.Loan.approved#phrase.action = make it {approved} that {this} is approved\nminiloan.Loan.approved#phrase.navigation = {this} is approved\nminiloan.Loan.duration#phrase.navigation = {duration} of {this}\nminiloan.Loan.messages#phrase.navigation = {message} of {this}\nminiloan.Loan.reject()#phrase.action = reject {this}\nminiloan.Loan.removeFromMessages(java.lang.String)#phrase.action = remove {0} from the messages of {this}\nminiloan.Loan.yearlyInterestRate#phrase.navigation = {yearly interest rate} of {this}\nminiloan.Loan.yearlyRepayment#phrase.navigation = {yearly repayment} of {this}\n'), 'en'); 
CREATE INDEX "PUBLIC"."VOCABULARY_PRJBRANCH" ON "PUBLIC"."VOCABULARY"("PROJECT", "BASELINE");  
CREATE UNIQUE INDEX "PUBLIC"."VOCABULARYUUIDUNIQUE" ON "PUBLIC"."VOCABULARY"("UUID", "BASELINE", "ENDID");     
CREATE INDEX "PUBLIC"."FKVOCABULARYTYPIDX" ON "PUBLIC"."VOCABULARY"("TYPE");   
CREATE INDEX "PUBLIC"."FKVOCABULARYSTRTDIDX" ON "PUBLIC"."VOCABULARY"("STARTID");              
CREATE INDEX "PUBLIC"."FKVOCABULARYNDDIDX" ON "PUBLIC"."VOCABULARY"("ENDID");  
CREATE INDEX "PUBLIC"."FKVOCABULARYBSLNIDX" ON "PUBLIC"."VOCABULARY"("BASELINE");              
CREATE INDEX "PUBLIC"."FKVOCABULARYDIDX" ON "PUBLIC"."VOCABULARY"("UUID");     
CREATE INDEX "PUBLIC"."FKVOCABULARYRLPCKGIDX" ON "PUBLIC"."VOCABULARY"("RULEPACKAGE");         
CREATE CACHED TABLE "PUBLIC"."VSINPUTDATA"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER,
    "CONTENT" BLOB,
    "FILENAME" VARCHAR(255),
    "INPUTTYPE" VARCHAR(30),
    "ENABLED" BOOLEAN NOT NULL,
    "OPERATION" INTEGER
);
ALTER TABLE "PUBLIC"."VSINPUTDATA" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_44" PRIMARY KEY("ID");  
-- 2 +/- SELECT COUNT(*) FROM PUBLIC.VSINPUTDATA;              
INSERT INTO SYSTEM_LOB_STREAM VALUES(10, 0, NULL, '504b03041400060008000000210084fc57bfae01000097070000130008025b436f6e74656e745f54797065735d2e786d6c20a2040228a000020000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c4554b4f023110be9bf81f36bd1ab6e8c118c3e2c1c75149c41f50db816dd83ed22908ffdee92e1024c84a96c4cb76b7edf798d9ce74f0b03455b68080dad9825de77d9681954e693b2dd8c7f8a577c7328cc22a51390b055b01b287e1e5c560bcf28019a12d16ac8cd1df738eb2042330771e2cad4c5c3022d26798722fe44c4c81dff4fbb75c3a1bc1c65e4c1c6c387882899857317b5ed274e3c4db29cb1e9b7d49aa60da247c9ae70711012adc8308ef2b2d45a4d8f8c2aa3d5fbdb5a79c90f51e2cb5c72b32fe8b425af9e96957e077dce228ee803137996809cac9b9a134e5847f0ae28b7e4932f6467f2b6805d94884f82a0ca5862f2bfee5c2ecd3b9597edc65bb1afa00426109104d95d7636e84b69bc41cd1af3723af87eb331b49f1d5c427fab8f9271f914a0178fdec9e8a9aa625708cab0af0ccd136a46dcaa508a0de63a0137a7603bbdc2d3e545324c8d72fddf3be266ad195cea43ac5ee7a3f6b6fc3db22bf1f76f713ff87b0a9398d82f348bd3cc0e9876ed37a13bae7890842d4b06dbe877acc56919aeee9827b2d15d24da3409daa2de7189de92cdfd01c10e7f5b53afc060000ffff0300504b030414000600080000002100135ebe6505010000df0200000b0008025f72656c732f2e72656c7320a2040228a000020000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ac92cf4ec3300cc6ef48bc4394fbea6e2084d0d25d26a4dd102a0f6012f78fdac6519241f7f60424049546bb03c7d89f3ffffc29dbdd38f4e28d7c68d92ab9ce7229c86a36adad957c291f57f7528488d660cf96943c5190bbe2fa6afb4c3dc634149ad605915c6c50b289d13d0004ddd08021634736752af603c6f4f43538d41dd6049b3cbf03ffdb4316134f71304afa83b991a23cb9b479d99babaad5b4677d1cc8c6332b80c648d69059399fd87c6cd335a2445f5354d2b07e4ae500e85c96b0259c27da5c4ef4f7b5305044831141b3a7799e4fc51cd0fa72a0e588a68a9f74c61eded977afccdd1ccbed7fb2e863883c2c84f3a5f94682c9b72c3e000000ffff0300504b0304140006000800000021004aa9a661fa000000470300001a000801786c2f5f72656c732f776f726b626f6f6b2e786d6c2e72656c7320a2040128a0000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000bc92cd6ac4300c84ef85be83d1bd7192fe50ca3a7b2985bdb6db0730b112874d6c63a93f79fb9a94ee36b0a497d0a32434f331cc66fb39f4e21d2375de2928b21c04bada9bceb50a5ef74f57f72088b533baf70e158c48b0ad2e2f36cfd86b4e4f64bb4022a938526099c38394545b1c34653ea04b97c6c741731a632b83ae0fba4559e6f99d8cbf35a09a698a9d511077e61ac47e0cc9f96f6ddf345d8d8fbe7e1bd0f1190bc9890b93a08e2db28269fc5e16590205799ea15c93e1c3c70359443e711c5724a74bb90453fc33cc6232b76bc290d511cd0bc7543e3aa5335b2f2573b32a0c8f7deafab12b34cd3ff67256ffea0b0000ffff0300504b030414000600080000002100b4e4b6a8590100003f0200000f000000786c2f776f726b626f6f6b2e786d6c8c91cb4ec3301045f748fc83e53d8d933e80aa492544512b21844469d7269e34561d3bb21dd2fe3de3442d61c7ca9e87cfccbd5e2c4f9522df609d343aa5f18851023a3742ea434a3fb72f770f9438cfb5e0ca6848e9191c5d66b7378bd6d8e39731478200ed525a7a5fcfa3c8e52554dc8d4c0d1a2b85b115f718da43e46a0b5cb812c0572a4a189b4515979af684b9fd0fc31485cce1d9e44d05daf7100b8a7b5cdf95b276345b1452c1ae5744785dbff10af73e294a14777e25a40791d22986a6853f09dbd44f8d54587d1cb3318db2abc8774b0414bc517e8bf22e74f42b9924c92c74062b76125af7fb2884e4b4975a9836a5b3315a7bbe46312ed076a5bd14be4c691233861d7d6e0df2507adc72723f0df46880ef0cc431dd4974a7ee2307cdad340e3f2bf8bb410d3125762ef16237220e90e183f5eaf57dd09b0c7a936ee0654ace558eeac311a0ac2b5efe3efb010000ffff0300504b030414000600080000002100cff7167b1a050000862200000d000000786c2f7374796c65732e786d6cd45adf6fe238107e3fe9fe8728ef3484022d2861b5b4cb69a5bdd54ae5a47b358903561d3b724c17f6b4fffb8ded84841f81b02da1fbd226c6f9e69bf1cc783c89f7611553eb058b9470e6dbee4ddbb6300b7848d8dcb7ff994e5af7b6954ac4424439c3bebdc6a9fd61f4e71f5e2ad7143f2d30961640b0d4b717522643c74983058e517ac313cce097888b1849b81573274d044661aa1e8aa9d369b7fb4e8c08b30dc2300eea80c4483c2f9356c0e30449322394c8b5c6b2ad38187e9e332ed08c02d595db45418ead6ff6e06312089ef248de009cc3a38804789fe5c019388034f222ce646a057cc924d80a2ca35187cf8c7f6713f51b8c66d3465efac37a4114465cdb197901a75c588485788543dfbe57630cc5d8cc794094cc045183118a095d9be18e1ad0f6cce6c504b453838ea2620815927640a768c1635439db6dab9f8ef3fa2808a27b0833c52ad7ee10ca403d526877182547d0ac77689c057050915a082715d9b1e86145ca288794a90572cc1acd021c34672d0ae4945f746eeb38c6f2148cabe3a2ae7f750e79687f076222107ba684597f71b9208135e6fc59713d18676e5ffdb4e3b2af43ecbe15e26ccf7875ed64d6bd7ab636450a398750ba49820395ee6060e441329658b009dc58d9f5749d401a66b06f1853ea792766cf055abb9d5efd0734fcc89bcd1fb6336c5f9bd429d152ab598742ca2909955ebb90c67d9b90d4d37b4613923a3a109a90d4d78bda84249dfbdf74e535e239d4b5a741b0ccb808a1b8ca6b863b702b3334f2288e2404ab20f385fa2f79027f675c4aa844465e48d09c3344e1d2c99fc8ffbfee4928e7a072f36dc8730ce8eca63113364ac416b75a4f810e67a8500b728fc839467aa5845a8f9b153bbd60b5c04adad69aaf9d47fb4eade9a5f5a935bfae6eb02687dcf8d53232cf87380a30a54fca6fff8d36c1a44aed5564b1653c89e56728aae1eca2cae2fc12727d766902c7dca8802aa319ec12ec6def9770ad55b41150c5aa030433567059b072e124913d6da124a1ebafcb7886c5441f9dd499c28caa2346e90e908abbb14e34ea1e14ac927f5bc887cb423e90b9aa7c20d388fc6e85fe30de88fc5e85fca6ec5f25bf29fbdf15fa83c90bff035e8dd81f4eec79fc6dc96f4aff2af94df9dfa042ff6bdbbfa9fc5765ff7e43fe07ada08d035e65038093f37509a82d3adb012119141900c6b733c024dbdd8eec662e846d0e062b5b8035e54e70626e8080d9fb3f523267313605c0c8837ea1b9b5be0b944cf14a1706aab65945d5fb7f33848f2d1964baab2e5923fe7fa115bb4ec628f9f8e508bca1c54a2b7cb9a47082ef820bf2038a75d5fe57473a5b37fe4dec9e8a51d88b2e1f2117e4ef968acccb2dc0b11cf31e3c76df03ca79fa0c7728a7ecabc5dfbe36ea45d6d9febc5573bf69cd79c29fe1fda624818a46e880e8d6f2de2ed955b571d63c80fefe2606816651585c9ab351e39be01207d2bc90dd3bce6f112d1da87e1ba260dcf76551571525f9d2972cfaee88aac47636cf7a4da3030174ae3396d2ee7bb09c6ef2415bafd43bdcea1c6e7a80967ae5e5db5f55b38d968e21b325a192b04d53afe81a0266b82afa90fafda254df1ce80ee5460a1824c4115a5239ddfce8dbc5f5df3824cb18927a36eb1b79e15243f87671fd45bd1f306f1ca1caff92425b1efe5b4b417cfbbf4fe3bbc1e3a749a775df1edfb7bab7b8d71af4c68fad5ef761fcf83819b43bed879fa093fa4063081f2bbce20308fda1061c2ddcee30a5f09984');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(10, 1, NULL, 'c894cdc83f1563be5dba31f475ce05da703ec99570d2cd0724a3ff010000ffff0300504b030414000600080000002100fb62a56d94060000a71b000013000000786c2f7468656d652f7468656d65312e786d6cec594f6fdb3614bf0fd87720746f6d27b61b07758ad8b19bad4d1bc46e871e6999965853a240d2497d1bdae38001c3ba619701bbed306c2bd002bb749f265b87ad03fa15f6484ab218cb4bd2061bd6d58744227f7cffdfe32375f5da8388a1432224e571dbab5dae7a88c43e1fd338687b7786fd4b1b1e920ac763cc784cdade9c48efdad6fbef5dc59b2a241141b03e969bb8ed854a259b958af46118cbcb3c2131cc4db888b082571154c6021f01dd8855d6aad56625c234f6508c23207b7b32a13e41434dd2dbca88f718bcc64aea019f8981264d9c15063b9ed63442ce659709748859db033e637e34240f948718960a26da5ed5fcbccad6d50ade4c1731b5626d615ddffcd275e982f174cdf014c128675aebd75b577672fa06c0d432aed7eb757bb59c9e0160df074dad2c459af5fe46ad93d12c80ece332ed6eb551adbbf802fdf525995b9d4ea7d14a65b1440dc83ed697f01bd5667d7bcdc11b90c53796f0f5ce76b7db74f00664f1cd257cff4aab5977f10614321a4f97d0daa1fd7e4a3d874c38db2d856f007ca39ac2172888863cba348b098fd5aa588bf07d2efa00d04086158d919a2764827d88e22e8e468262cd006f125c98b143be5c1ad2bc90f4054d54dbfb30c190110b7aaf9e7fffeaf953f4eaf993e387cf8e1ffe74fce8d1f1c31f2d2d67e12e8e83e2c297df7ef6e7d71fa33f9e7ef3f2f117e57859c4fffac327bffcfc793910326821d18b2f9ffcf6ecc98baf3efdfdbbc725f06d814745f8904644a25be4081df0087433867125272371be15c3105367050e817609e99e0a1de0ad396665b80e718d775740f128035e9fdd77641d8462a66809e71b61e400f738671d2e4a0d7043f32a5878388b8372e66256c41d607c58c6bb8b63c7b5bd590255330b4ac7f6dd903862ee331c2b1c909828a4e7f8949012edee51ead8758ffa824b3e51e81e451d4c4b4d32a4232790168b7669047e9997e90cae766cb3771775382bd37a871cba484808cc4a841f12e698f13a9e291c95911ce288150d7e13abb04cc8c15cf8455c4f2af074401847bd3191b26ccd6d01fa169c7e0343bd2a75fb1e9b472e52283a2da37913735e44eef06937c45152861dd0382c623f905308518cf6b92a83ef713743f43bf801c72bdd7d9712c7dda717823b3470445a04889e9989125f5e27dc89dfc19c4d303155064aba53a9231aff5dd96614eab6e5f0ae6cb7bd6dd8c4ca9267f744b15e85fb0f96e81d3c8bf70964c5f216f5ae42bfabd0de5b5fa157e5f2c5d7e54529862aad1b12db6b9bce3b5ad9784f2863033567e4a634bdb7840d68dc8741bdce1c3a497e104b4278d4990c0c1c5c20b0598304571f51150e429c40df5ef3349140a6a40389122ee1bc68864b696b3cf4feca9e361bfa1c622b87c46a8f8fedf0ba1ece8e1b3919235560ceb419a3754de0acccd6afa44441b7d76156d3429d995bcd88668aa2c32d57599bd89ccbc1e4b96a30985b133a1b04fd1058b909c77ecd1ace3b9891b1b6bbf551e616e3858b74910cf198a43ed27a2ffba8669c94c5ca92225a0f1b0cfaec788ad50adc5a9aec1b703b8b938aecea2bd865de7b132f6511bcf012503b998e2c2e26278bd151db6b35d61a1ef271d2f626705486c72801af4bdd4c6216c07d93af840dfb5393d964f9c29bad4c3137096a70fb61edbea4b053071221d50e96a10d0d339586008b35272bff5a03cc7a510a9454a3b349b1be01c1f0af490176745d4b2613e2aba2b30b23da76f6352da57ca6881884e3233462337180c1fd3a54419f319570e3612a827e81eb396d6d33e516e734e98a97620667c7314b429c965b9da259265bb82948b90ce6ad201ee8562abb51eefcaa9894bf20558a61fc3f5345ef277005b13ed61ef0e1765860a433a5ed71a1420e552809a9df17d03898da01d10257bc300d410577d4e6bf2087fabfcd394bc3a4359c24d5010d90a0b01fa95010b20f65c944df29c46ae9de6549b2949089a882b832b1628fc82161435d039b7a6ff75008a16eaa495a060cee64fcb9ef69068d02dde414f3cda964f9de6b73e09fee7c6c3283526e1d360d4d66ff5cc4bc3d58ecaa76bd599eedbd4545f4c4a2cdaa675901cc0a5b412b4dfbd714e19c5badad584b1aaf3532e1c08bcb1ac360de1025709184f41fd8ffa8f099fde0a137d4213f80da8ae0fb8526066103517dc9361e4817483b3882c6c90eda60d2a4ac69d3d6495b2ddbac2fb8d3cdf99e30b696ec2cfe3ea7b1f3e6cc65e7e4e2451a3bb5b0636b3bb6d2d4e0d993290a4393ec20631c63be94153f66f1d17d70f40e7c369831254d30c1a72a81a1871e983c80e4b71ccdd2adbf000000ffff0300504b0304140006000800000021004bcce67ec0030000540e000018000000786c2f776f726b7368656574732f7368656574322e786d6c94574d6fa33010bdafb4ff01712f848fa44d1452b5aaaacd61a5d56abb7b76c009a88091ed34cdbfdf1903c1109c269706eaf17b7ecf3363b37cfc2c72eb837291b132b23d67625bb48c599295bbc87efbf37af7605b42923221392b69641fa9b01f57dfbf2d0f8cbf8b945269014229223b95b25ab8ae88535a10e1b08a9630b265bc20125ef9ce1515a72451938adcf52793995b90acb46b8405bf06836db7594c5f58bc2f68296b104e732261fd22cd2ad1a215f1357005e1effbea2e664505109b2ccfe45181da56112fd6bb9271b2c941f7a71792b8c5562f67f045167326d8563a00e7d60b3dd73c77e72e20ad9649060ad0768bd36d643ff98bf5db7462bbaba572e86f460f427bb6d0f00d63ef38b04e225b85ba67b1afcaf05fdc4ae896ec73f99b1d7ed06c974ad8dd2908401d8be4f842450c06028ce34f91346639d0c15fabc83013c000f2a97e0f5922d3c80e1d2f9ccc2018f2e18896205cbc179215ffea08afc1a911fc06017e1b04cf9f39fec3d49bde8012b42853606b702047b525a4599250b56250e1d632942b2f4492d592b383059905ab1015c13cf516f08c76f8f7a3768453d89c18e73c4120c40978ff584d96ee07e23763cf080860332d24f04f312ed09eb8c33ef7f816b49c106ce44420e084759f4282609c13d675a617dc3766404bafeb194a46cc217d384e8f5d43b3fbb264083ee91972221070ea21c1749cd3c3bcd048d51e431e8f9007dd1ee32c23bb8204fab91613cc0cf46329768de5dea534c34130c0d75719dc1b567053a27997320d079116ec1b31a797dd3e94e899edd7e8c68923e0aaf49e152a2c40f7267818d7ad7a92b6f1231b0e216d8663b4991606cff26d6ea0853ad4857f41ab57ed30cbb115a1ddba236117d4f7fba6daf2f5cae9101b93ebeaead176317d5628811bc4ea05d32136ac083514eb8d7b1c0c6afab2c7186ddc5a0535a0ed96d6131b40da5f2f16a3cdac0835600d0de74430e8205f88d54ba313527baca006b45d4c5feca07ebf60d553b4436c58116ac01a1a0ea8e0a66685d1668f9b66351ed3178bf5adb50a752d9a3be3c7a2764ac0e305feba69f41a4b683818839b9a06469b65374d434fbfd070360683f25567e3354d1a279a57d054b27e69080dc76378534d61b4915641419a8dc7f4f63b1c344bd48d922e2739ce32b3374db327da7022c37dbe976e976931da48aba040b49e11e1f040ac3f07ea8b6f4576f427e1bbac14564eb7003c716032afbf05d4b36495fa2fe4ef8649b8c8b76f297ca751b8014f1ca8e82d63b27d812b76c2c901be0e2dbec892c8e6eb445dfbddd3f7e0ea3f000000ffff0300504b03041400060008000000210042343a0be30000004602000023000000786c2f776f726b7368656574732f5f72656c732f7368656574312e786d6c2e72656c73ac91cb6ac3301045f785fe83987d243b81524ae46c4221db927ec0208d1fc47aa051f3f8fbaa34a435b874939d34179d7b18ad3767378a23251e82d750cb0a047913ece03b0deffbd7c53308cee82d8ec193860b316c9ac787f51b8d98cb23ee87c8a2503c6be8738e2f4ab1e9c921cb10c997a40dc9612ed7d4a988e6801da965553da9f49b01cd8429765643dad91588fd2596e6ffd9a16d0743db603e1cf93c53a14c705f111726a68eb206296fc35a165750f31acb7b6a1cddb84d782a3b9e88d8ef19ab9fbc96e5fc97537d4fa76bf9bcd035bc6d484d7ebff9040000ffff0300504b0304140006000800000021003d06b464bd0000002b01000023000000786c2f776f726b7368656574732f5f72656c732f7368656574322e786d6c2e72656c73848fcd0ac2301084ef82ef10f66e527b1091a6bd88e055ea032cc9f607db2464e3dfdb9b8ba02078dbd965bf99a99ac73c891b451ebdd3b096050872c6dbd1f51aceed61b505c1099dc5c93bd2f02486a65e2eaa134d98f2130f636091298e350c29859d526c069a91a50fe4f2a5f371c69465ec554073c19e5459141b153f19507f31c5d16a8847bb06d13e4376fecff65d371ada7b739dc9a51f16ca46bce7661989b1a7a441caf78edf432973645075a5be2ad62f000000ffff0300504b03041400060008000000210056c4669cc7000000ab01000023000000786c2f64726177696e67732f5f72656c732f64726177696e67322e786d6c2e72656c73bc90c14a04310c86ef82ef5072b7999983886c672fb2b057591f20b4994e719a96b62beedb5b10c185056f1e93f07fff4776fbcfb8a90f2e35243130ea01148b4d2e8837f0763a3c3c81aa8dc4d196840d5cb8c27ebebfdbbdf246ad87ea1a72559d22d5c0da5a7e46ac76e54855a7ccd22f4b2a915a1f8bc74cf69d3ce3340c8f587e3360be62aaa333508e6e0275bae4defc373b2d4bb0fc92ec39b2b41b151862efee402a9e9b01ad31b20bf4bd9f74160f785b63fc378df14703af5e3c7f010000ffff0300504b03040a0000000000000021000077278cb5140000b514000013000000786c2f6d656469612f696d616765322e706e6789504e470d0a1a0a0000000d49484452000001280000007b080200000048088aa30000002b744558744372656174696f6e2054696d650057656420332044656320323030382031353a34363a3136202b3031303069fd92ff0000000774494d4507d80c030e2f0cf4c82f41000000097048597300000ec300000ec301c76fa8640000000467414d410000b18f0bfc61050000140d4944415478daed9dfd6b1b499ac79f0efe030626c7782761d3c2c3c57b1826c126e3908148383f4871200c18ecfdc173071299f5e5c23020453066608e90058d0443980bda0912ecae614938c3dd40bcd20f315260433c212613ceec3a90a0f6e2cdfab809f327e8eaaddfa496d4adb76ab59f0f4e6895aa5af574d7d3f554777dab957abd0ede79befbfafdc977bb28e85b8264d1a8db32eaf57763e011d9754090c3083a1e8248001d0f4124808e87201240c7431009a0e3218804c69eefbeeea2d8a95f1c935d7304196194ee9ee3298a527f2abbee08329a2833186a22880cd0f11044027d76bcd40c28d740eba2e401c448d95bb28f07820c857e381ef119741804f142cf8e47bcee1294659b8120a3c5588fe58b3799d7ad81b20615fd3ee7ca8c70c5e4b7909d1689240acdf1ad65a87f');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(10, 2, NULL, 'da7a87d720f1986e14ee437cbc3111ce42ed1b504177f86548aed1dd56ee43c6faf129849d4af114feadf61d846e40f40b285dd6aba76773a8aafde74e9dfaa71f7ef8b3ec73d71f4efd233cfb83ec4a1c3e7a75bcf82aacb316c91be806f9f71816ee43699cb5f24f609eb572b359b316ac400bdf5b03b80ff5719a3f71092658d9ea2dea2ddc0f497ae89aee7b2c3fd97f16a86364ac1f5b949abb40abb7b10de169d0349aadfc00b4cba06e53778a5ed0bdae5555d7844312afabd7f7649fbbfea028276457e1303280bb9a67618ef55413efd1ff5f1d00589a358c437a99b6e0aa63d965d1cbcd2feb658947add9d31fc3e681f95baafda7c5c716a5d40f200ab0b34f1337d620c9d235d2fbb194850f3a57b5f614f00126d23bbdf6786ee0cdba7c03941b662271aaf078cb22aa4affdffd1b009b2113559dd3e13dbbe3d93f3a949a8685b39020bddc07b00390fe94fa15a9c9ab07e27aa17def5cd5c825b6b56cffb9a0a0ccd0fff182324c86e178ea71fabf319a72038f0327f5796965cd39bd3d8ea568b4790336bf87f259c893c4b3b0fe3d4c3da6d553c9d74e5525edb27e1fef2121fda4e750731ca63ae69986241f4db14fed9ef5ad41918591240e1421ab1eef35a677aa55ab523cda4cdc10dd23f143d2bfe5789ce958d5191a5e22487fe9438f474650397657b370bf659e2c69bb331062218d7967b219e22d3741e1773557459ef0a7507849efb524da97b5d3b2d4388d36cb8f21f921fdc47b63c32d69e766ad2a1bd4b9f93904f1044e92b6dba58f768407b6ce16bcbb9a813ca1fe042749db5066cc0d6c85c84041c71b0831e58462fe7d5cd49c32697763b1bb9ab71d2301618c048ddd9534fa8740d2ab75d14cadb4a4cab662a826235e18fbf2cb2fbb28464a8d7c30666f678e979f56367a6ea3a4735b8185a97482cd7c4956f6b2e1fde24aba5c8690928e161e95e6fe140ba5d9e38af385daefe360e4bf52a9af8687723c649ed0a67331f2adab93818738d46c716aeb4fcdbfee29a74346a8c9e3c9727a777eaf5edfab57aee43224e5783c9f89928eb1be578aefa742afd275f66dede2fa8a35ff90bc4e3201733317061e62c783c6c3d1abb359611e55e77f3ce68c66ae86d957ea44b421b3a6edc09d08f752d2ef955f69d6fc878443e67b87dbf1c037e7dbeaa887a4976bc627e762280606caf19499c63faf8763d8f0ce4d55a7cae9db5579d5f00f87c6f7fae078da77a29517d946f1c075c90148d7eb16c0fd5d10ebf9def6688523d6315eabc709ea523a4923cc58f178b696d989d8c784b2295e6307819c2336bf2fd5dd8a1e5dd05fdfd3ebdf7d86c1183876e11d78f0bf00ef5cf8b75f1ddd7d74f4dcb9b749ea9b47bff90f9aea8acd07a66034ee7a1a347011ed7bc3b47878949ae6b5c4c3fa96ba542a89cd7076afcee583b054aa2fd9f650025f300ea56f68ebdc915d91c11a38748e9cfbd5d2fb62fbe424fce7bf13fefbc5dbe722efbb2b2f54de6b6cdeb3a5af48cdd0de2cc67ac2aaa557247fa9eda682c6eed81e52b7f4ccfa57d58614b63292355bf156cbce8da4c7beebf2e8549b6ac20d0930c2e46bb0cb3fb30e217593ce6e0dd97b067206f9c1310fef8138e3fca483e5bc8b3c7c6fd79a5ac5ad96953177be2db235976a4cb1ff0a61d3693f669d895d2cf84a3554c68d39b7c47120addad80017a61d790147ffe11dbefd66f77f582f77f0e31bd7e729fe0d14ceb21eaf69ee72f925e4d97dc2f001acb04516c876651972bfa5e7af4dc11cbfc1f82d55a9dedea6472af29229508d144b36ca6348acb5ab24d5d775e12dcdbfab1b12486863324c5e859dc7e6575757216a9f9e4e1ad6fa05711f78ea867eb5bd44171f2029b52f20724b1cae8a3d0f399293ab7aab782084c535d5f9e2185ea41aae2adb2efe96cd6b6f2e6549491aaa65e357d8a7b9e6fd34c3962fb0eec49539a4e1add21692fb44dff89353259b18fbf1cddb47c76956801fffcf6d74e90aa1e306210848307569f2db760bae70c4713906e2b6fb34d48fd16b4fd9311b1bd739eec79aae10bccec06cfe5ddd904052d6e805d150df134bdba07e007089c98597f5a34ac2d1b370956baf2e033df4db744d101e32cf2fc306972feb4210ed7bd68b1a17c465a79f61d5a04b751c837580fc3475f8c65297a1b46a9ea6c903e66c0ddab1a6fd38a02f5f307996a9b4c19b395163e325545d9876e4e8db6f7eecf146820b48ff46af25402f0c46c7ed12da6bf36bcf7d887a29d8238ebfcb0d09241d2f8836c8d0e8293b326b667ce5151e0489bf16bf1eff17da87d09501f4eb7863a96d7a9ad24f45036b45f37e064a47d38e9cec7747e7008b9549879be5611b5f4cc5355c3f3ec1d66518a606dce1777543fab177dfcd902676a9c77511f001ac3f6e97995e956e09f72391185dc6669c0af9c57238db6c547c8cba6595256cac35ae1b40fb4c3dfcb38de51a98a6b11f89dcd2975b975a66bddcb6be369c8bfd74c6a3395e4d1b7bf49bbbcf7b3d659d6dc87f41d7d2e30b99908b41dc580d895c2f5f76d0b692409f181c99a1c737c9972a1acaab8a1c7e775a181248f86a17b57d16239d85a435d464add0babe1b89be0ad7f491331bfe11b26c818c044bab3001313d5c2c0f1962c4c588c6dca7f12d8d575bfbc355924d13319e63a9e4275487cd4f93b91e4ffbfdb8c09b39565c98a68cfa24e986bb260de3ba86cc1db4adae2dea8310964d9bcefb40c1e043216cc3b9285ea3f72de21dd7fbe844bff6d31703477ee68a7f9a8b959872b32a36b7526c5b2b7eecf03cdd1a701adb64a3c593f7e69d98293e0b5cfb037bbc9478af676fe9d77efac7c83b1e400731417fd4061e4927ef6c54d9567533979c0b93d82cfe7b3115b37232717bab75d12d07a5824ee34eb4bb2b8993159652997aa541e0986e77df45c27efa47977a3c181ddda4fb7af6d1a2f0fc95c8c656363c5bdd7851b8ba4a93483f26147764983ba1b52ac9940a39e58efef90ac9a99adfda77a2aa53908e2840357bd9d5a11da821e0abca0c82b16ab5da45b17038dcdd2a490345613424baac275dbec9b5459d65fbe17f2e647e5705d8d8b97855e50ef3c785da5e4915a3bb76b452af3bec64365bdfcbd268f644047a95ccfae7847a3a17a308313008a1a6819fced6f1b985171ba9cd9d850f559e10bd38c7b6b4cd3fda1e8a94458828d2db2b151a76a2dd4d15f799fb3d2a445f0431d60c2c81723cb0ab130c8d8214d4b98b3b3948c7d9c29dea527a4ae81556764f9ad300d4a57ce145c4963edb52a9d0bc135585c43996f3dcfac2afe3aa2c5b11cff4cff1b4624c4955bbfbd677d0ea9a74577175a96489fda81081dd052965574b2492a41a051a4f1af74b44ba286857afb7da090b35450af7705f601ebd98e506ae9e683d9a8e897eaab5876a7b33d0c9f10e36ae87f3cf641f07895453a1c45445ef326b859d881f1ac6a8408f1e146aecc84162853762e3905692b9887e301d1325d69a9f735aeb90a88dfb6a7b353068a1663fa86ee4a20573c113359e2f4473e2e900d20976f4f22cec55e3a57a896d9987347cd538988e8992d05eed40729ed685d43a9d841d3660765f6dcf061e61fd9b807573cff24bd92770efb3f0f50d3e23c6cca0a77436c3b1d7a657005bbfcbe2cfa29e37e6acd31e3eea64b49cb0dedfa00d281bb65458760d7d0c6dc153136aeb4475628a376bc74459a8730b8667507f59a037b1dc57dbbb8147889b85beae52eea66a9f11d73bbd7237750616bfae7e354f1ff3133f7c78fe2ecbf07528bbc47cf360a3ad119648ad3265f4da00b9c8c67cbdb1dfcdad439e27da1bbb44889fd12ab618e0d10acbaea18fd176cbd149f0d1d0cd25e4a4d72633acd299c95a69e037aa8edc3b93fae834db1c9fffaaba72bae1fb675bf7ce9c9fe6136d4e7f943a736feb191c6c3f6cb74b4baf0de1f9a4e9e87afc467a143337bfb634244a279c15033cdd03cd16a4571869453991d12fa6b9886fe2980e90602cb4bec046a60beba1c15f315c8cf19e649744a84963d0ceb06b9e2a3ed0b06d57e3db4d1148cb44ffc03cb04602f48cde80dc55d8abeac77f2aa1eed187786c64639c7d7fc37a8bb41899a693838f7b5d38de99148f3439b63ed1f12181d5d7ec5e381ad081a8dd283a00189106241ddbd937122d231c63e4e398e82bdc57dbbb8147169f64ff8b3f3aa037518cdb27b5d77ce3f4ece29387db22f1599e65189f3e6fa99918926a9bebc2c52c89749ceac303da1e76072a627b02b5928082a7759dd97b11e8c3ee5871bf496d406778d174e0420492b86fcb3fd2d0fe420f0faab713653ee820430e318437d39c1365559bde5ce1d5d68a19bdd1baafb67703abf4568a6091df65d19316bfb67eb266a0fb320641fa9749e3c9178dcd4462943dd0e1297a0663db315112609ff552b1ae22a01b61549265de6bf75713ef45a8d7ef25e92c4a7b22d9a0898f0ad1f3855a43fe61ff1956f6ef589aa7df72468d236a3dcb8e89f5be56a68b5a1be7db53b5bd19a8046992742f789d24dd41086be85cad7a028a98caac153f0e251ed2f704f11927f274b1a610d63727f4304c92eec33bd0910e38a90dd48993000fbbda1d120470e6cac068f75e84ad54042af57b5389cfcda1a42e536003bf9b5557bf818c2a632468ecae64d7af92f52dfdb488be17e14444b94383c95a26163a21764d7b3ff5b6b20895bd3089d82b9b4ae8e604093eadf9e746dffc6055662006e2184f1c88fe8ef146071ce3493110434d0491003a1e82480085b02dabdbab10f6f08242d8ce06628fe7000a617b0185b02884ed0e1f0b6147602e350a61dd0961af5fcfe7afeb22d806cdab6d0d08fd03cbd3c98cc32e848d99ef61267f87e9a11c0a615d0a61e1c93df825571d3c3345b15cf33a3e7d9e09f028548497fae8b4d0c5b6350285b0ec799d391fb2a7e52e470c14c2ba83849a677efe33b679f0ba068bb35cf5737a76910a144ccfa37e777e7adcaa8b6d050a619d0f8ba151601d200b1a8b29f6916edf4cc5e8b7a9ea7e516cb478b302ffe4e79728a010d605c4f142ef7247fafb5f9fe83e08f0b39f9f79f2d7bf5305d019aa10127e47bf61bad876bb44212ca12c16c0d43d6d2b154a4f556807582bbc88a4b6789edd79bd3f2cbf98ccefd52b577291cf816f64daf98faf5fa280425817586eae085fe3e85e383effcbd0c3ed67a6df715dac5e5d14c2b6a021d4d4b49d6846f4f77317a3b9cd2acb63dec1e14b44ab135163a3fdfe8dfe3372077634f612853b11d69786b352235b14c2ba14c29a9be3ef86401fd1919052ef094fcf86b29f6585dfd974b128849584fe120521e4a3497c65dbb90de9f7725008ebce40ab2c88ae2f765dc491a45ffb4a2cf240c77b303b3faee7794df2e845c2d94a528928ec15b8c94a5d4418d95a2116e2b35ca3855a49e601edea24c44bf50912f22b0991408de86db44d350a8bb7ab4bd9307bed41f25f4ba065dc1464920555bc2ce1a2996e7b89c245fa1285cd0fb371fa1285c9d8e7a44cb8a7eaf60439fdaf62e2e09136111689464331d29c1325411f1aad8778b5c9f9ce7aadb657037192b47e20fa3a493a16bbdba86a3515b14c0b6b55be5a55b3f60d607a5992259abc023b13f93cacb0742d7522c2ae76229d291ef81bc04d71ad5b5b7092b40403d1f1cc6381ea04d97531aa147cc7c3992b08228180cb0d0747f07a3c64988c75d7');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(10, 3, NULL, 'a73fdf7dfdfee4bbb22bdf4f3c5914487db47fa2bbe0b5ae660331d4441009a0e3218804d0f14690111007211d40c7431009a0e30d8446f580558b00d0f43605a398914d17284093ac0102f4a285430c3ade4068540f80558bb0950abd4a8bb7295c5c5fb1078d229b21506896351c8fe7c58b163ccd50417c053ade6068500f80458ba0693b5449c0be0d91becb2e4031b2718182a3ac01197dd0f10642937ac0cea1d5a7233ae87883c1a61eb0e3fc36851658323359c35c98a79765ab5d91de40c71b08e929a1405fd93dd9d4e3cd666b999dc809772b35989943899395ec2c4da32f5aa0c12ade5c195dba9c061ebc493d5ea78c056fae264e191ba681d8e3218804d0f1104402e878082201743c049180f2c35ffe26bb0ea3c7a95f1c0bdecd156c09c304ef6a7663912fee6a5a974bea01bcab29c5400c35114402e87803c1f62683e65720585e9660794d823d05dabe6ea141a3d04aee80f81574bc81d0f94d06fc65095c8510617ed598d2fe750b568dc27e3bb903e24bd0f10642e73719e89339213c978417d43b1b52aa9d5eb760d05eee80f81274bc8130ec3719a0dc61d440c71b08293a7d99bec9a01065bd99de0b398815aa9b39a3afb3a6845be812acf0dd7a923b20fe001d6f3024ceb15b1de7d6177e1d0f2fe5c920ad41ac60bc402f0215fe48a031c5499760c5d4281cf72277407c013ec7ebc6a25e9fe3353f82ebd343b92ec0e778520cc41e0f412430d6fb2e10cfa84ba552a71424d0608f87201240c7431009a0e30d185c6e1d71021d0f4124808e872012187bbefbbabb925d17f42dfdb4884498a1b498a412cdc8b66ce8e607ab328360acbb2795c17bc4d95f8bb8b0a014164fc64702ff9cd0e0b5ae6603f139de40c81af35af0011de2048ef1104402e878082201743c0491003a1e8248006fae74c35b6fbd65a86910a40bd0f1bae1a79f7ee21b8aa2c8ae0b329260a8892012c01eaf27fca3dab612f807d001007b3c0491003a1e8248001d0f4124f0ff5426dc331dfd721c0000000049454e44ae426082504b030414000600080000002100a33fddfb2f0a0000dc37000018000000786c2f776f726b7368656574732f7368656574312e786d6cac9b5b73ea381280dfb76aff83d72ff33480cd3554c8d40eb9104838537b7d76c0095400b3b6939cfcfb69592de356b765a8daa93a03419fbbdbfa24d928f1f56f3ff73bef334eb36d7298f841abe37bf16195acb787b789ffef7fddff3af2bd2c8f0eeb68971ce289ff1d67fe6f377ffdcbf55792be679b38ce3d8870c826fe26cf8fe3763b5b6de27d94b592637c8096d724dd4739fc98beb5b3631a47ebe2a0fdae1d763a83f63eda1e7c1d619c9e1323797dddaee2db64f5b18f0fb90e92c6bb2887fab3cdf69899683fd767c55ba7d1179caba9a752e2ad6e29e3053d56df7ebb4a932c79cd5bab64dfd6a5f1b3bc6a5f91f3dcaf5820a1b3f651fafe71fc15021fe1e45eb6bb6dfe5d9caeefed57e3c7b74392462f3b30f233e845ab4a95110f7f7e9d10e9e67abd85be5503c24be3d789ff7b385e8623bf7d735da8fbcf36feca2aefbd3c7af967bc8b5779bc8611e47b6a64bc24c9bb021fe1a30e84cc0a40858c56f9f6339ec6bbddc4ff0174f6bf22c98f60fc23e8f446fde140656a97a9aaef4ddafb6250fd917aebf835fad8e5ff48be66f1f66d9343febeef251ff96e7b889fe2cf78074d4551452f8dd7dfb771b682810355b5c2becab44a761016feefedb76a0640f7463ff5796cd7f966e2777d6ff591e5c9febffae7008fd27c883cbc7e617bd80a7a9d0144771d07518b3cf06a8eebb48641e7aa3b741fd8c303e1150f1cb5fac34e37684808518b84f05a1e178efa41bfa9d2011e38ac1c78c609c2ba51e48357cc77754ebf5ce161f07a59bf04b0726973f0060f1db446fd7e6f306ae8d2a094ae46afb6383aa7d8c0d8576ff0c0b0db3aab5b033302d49bb2de7346406086807a83470641ab17f687a39a51d0d6a3bc9854b7511edd5ca7c997070b24d49d1d23b57c8763154e9e26303f14fcbba2616a40c130813298d69f37ddce75fb13e6e80afe41cc323030170456340486024e810339308cdf0b022bba98cc65dc53bdc5394d1b895b4dc00a782aae57d65604b913102bcf7d33f2d08ccc9a91c76664de8c2c0424b44ee949602ce4b919593a1132a66025ba40bda28b015eaa3f8d28ad5e1390bf24bad4ebad2660e52b893e25ee3831a2c43d2702ab971e0424a451661a518b5c594a608dc2478919d0387389b12a5ef07242abeb9e04c4aae65940ac62960272aa85a8070544fd66bb5ec7fa725dbdda1753ddbd86a948c545bdec47cbc65413505b1d71ab89ea82609dd95d2371df483c3412334da8cb5759aa55c86333326f4616bc94d01aa04fcdc87333b27422644440efff9f46848a34f1abd71eebdca69cb0170a4dc04d4b29624827de1d27ae2871cf89c09a760f02625532d388ba21294b09ac45eb5162ac7ae7126355bce0e58456394f026255f32c2056314b0139d54286052820c3026e7c76d131c3af26eea5411d0b578caac5de298dbe6668a65b5d87adf5e31691eaacec5bcc9dc458b2ef91098bfbacb01f0cad5e799082584377864cb70832e858753c92e6a0a3fea3a3722e25b1242f90d19576afae0696e227926668d5f84c5afbbc862501e06b52592251af2e8ec4bddb76815bbafbd6456c8a90d3b7619cc245c8366ea07ae58620b9acfe9c19a84e3a6d17ad1ba4ba2af62dab0b03d57b3784ae8489a7cd23c13c25ead5437f5ca25ee1b67aebca3955975575a7e09aea86213aac197427424c3d6673a84782e462ea11aa554fda65f5521e7bc69b7372a82799b87ad22c15b23439f4b9745aa7e147a7fd65df61d59591b93fad287a9547c8ed5e07eac28994575ab6ce9b400462ee3192c3bd948bb947a8d63d6997ba7c6eca25d3fe744b5e74cec2400ef72413774f9a61cb825d75962687717f1244dd5fb6cda0762e987bfb0a8f90dbbd0ed4e05e82987b841ceea530cc3d42babf94dbf21a59487b346775026c646e90aafc8115676120877c520a974f9a03e9726f7234c987422f59f4156e2dfa034bc7546d41352efac890396df5d39d0944202bdbbd811cf2a55c4c3e42babff84d9e49e3728f21e0a55ccc06569e8589e3704f2ae1ee49733094263e41ea2ff86ad7e8fc8d4bf55b01e6debaa64d11724f7c1da861e24b10738f90c3bd14c672323345d7bac7202ef78810f7d68df0c2e471b82799b87bd20cbffc636bd4d2e4d0b5d6bb57db4617b8d7bb4ce46b9dfd05651a68c8ed1e1932a5d9bc9720e61e21877b290c738f50ad7bd22e5ff0a53cd6c45898ce71b82799b87bd2dc15dd13a4debdda20bac0bdde4fa2eed98dbe86dcee9171bb9720e61e21877b290c738f50ad7bd22ebb47a43aeffbec660f21877b9289bb27cd3dd13d41eaddab5da00bdceb4d23eafe741f8937fa1a72bb47c6ed5e82987b841ceea530cc3d42b5ee49bbec1e91aa7b7eaf8790c33dc9c4dd93e6e256cf5a2f970141eaddab2da00bdceb1d23eade1adad300b7959c5ff09171bb9720e61e21877b290c738f50ad7bd22ebb97f2b0351f21877b9289bb27cde26d3e216ad587976deb15b87d9b6f7fc743c839ed0de3542f42b67a03d5ab3704c965ab37509d7ada2eaa374875dab36d3d03d5ab3784ae84a9a7cdd2b61e25ead5437f5c30eb43855bea87d6823345c8ad5e0772dfe59b40c419538f911ceaa55c4c3d42b5ea49bb74733d17cbb567bd811cea4926ae9e344b63706972e873a977af3689ce5ff143bda74456fca165638a90db3d6e4ec18994df84d9b69e0944202bdbbd811ceea55ccc3d42babfe006cadad9316974bbd4e5738390696f5d0e170672b8279570f7a459dcd633399adcab3da20bdceb2d25eadeeac66988fb4eaeabbd618856abbfef4488b9c76c0ef748905c56d133934bf717dfd9a1edb27bcc5375cfeef44c1c877b0ca32be1ee49b3b8ab677218f7a71d06b2a51b42a197b857b8bde65bcbdab488d9f0ab1cc3101fccbdce462f0ccc3d420ef75218e61ea15af7a45d768f08bc946b19dbd53327ee704f3271f7a459dcd533398cfbd3d730ea5eed115d30eff596129df7a761a5bfe1a93f8b6ddad1358cdb3d062210738f90c3bd1486b947a8d63d6997dd2342dc5b9db33027ee704f3271f7a459baf1589a1c4deed506d005eef57e11757ffa0d21bac74d25e79a8f0cd1cae6bd0431f70839dc4b61987b846add9376d9bd94c75a141721420ef72413774f9ac55d3d93a3c9bdda00bac0bdde2fa2eeed5dbd1037959cee9171bb9720e61e21877b290c738f50ad7bd22e4db7b939efeabc67bb7a0672b82799b87bd22ceeea991c4deed506d005eef57e11757fba9ce0bcc74d25a77b64dcee2588b947c8e15e0ac3dc2354eb9eb4cbf31e91aa7b7eaf8790c33dc9c4dd936671574ffdb1bcbae8d6b9d78ff7e82711f671fa563c0f9479abe4433d9aa32a2b3fd5cf20ddf6c7f057ebf0b88ef5f9a23f863f20570f0c950df034cfe6fb18a7f008d07bf53d3ecc0437aabb64553c2f36f17f99dd3dfdf1cbdffe0e8360bdcd8ebbe87be24f77dbd5bbb789d3d8cb13785c69156799976f62f86877f48a47288a84d524c7e82d7e8ed2b7ed21f376f12b9c037caff5bd543f9354bccf9363f1295c305f921c1e27323f6de099b8189eaee8b4a0b4d724c9cd0f7056f8749a978eb7eb899f3eae8b878f76f15bb4fac6e7d34e6d615156f95cdecd9f000000ffff0300504b03040a0000000000000021004bd08478c5360000c536000013000000786c2f6d656469612f696d616765312e706e6789504e470d0a1a0a0000000d4948445200000291000000900802000000df8aa7100000002c744558744372656174696f6e2054696d65005475652032312041707220323030392031303a34383a3531202b3031303099dee18b0000000774494d4507d9041508332734d067c9000000097048597300000ec300000ec301c76fa8640000000467414d410000b18f0bfc61050000361c4944415478daed9d0b7c54c5bdf867093eea0329494c00950d5093546c8c40841ba91b493569ac044b4ca80d5724f72f5c8980cd4aabd594daea85e42f20f809fc9ba8353e922657c03625d8d0ac8df9a38994e6824da2600222249744afdaaae4b57766ce9cd7ee9cddb39bcdee399bdfb7349e9d9dc7ef37e7f19bdf6f66cf2004000000008019b0e0ffd756edfe7cd2fc00567a635c4ca8f50200000080b0e286c4e91385a3db52120355e91b2ded4909d3fc2eded6716634c50153130667df5c2a984bdaf0933f2c1534a3cc26927c42a8050000000000401760b301000000c01c4cd495ab674f61e1aebfd3c31f3c72607d727065ec6fdeb5b3a157384eca2bce8e1f5d759d7bf7a2ecd15662323af76e6a4f1c75cf0100000021458fcd6edd56b86bd623077660537d64dbad4f3e3863c7334b63832520b636553de96b8b5747b24f9bf68eca6c77eeadea895e1b2ce98d427c7631d86b000000b3a323367ea4f9f5d9ab7305df3af9eec2d99d27cf064b3aec6157b525e5ad4e8d6409f1d979496ded9da3a8b1af07c54645fa5f010000000084081d7e76f2fa3fcbc1f08f4f1e0f9e70fd1d477bb1c5567988a2c748a3bd79a8aaaa2d267dedeaa8a64d556df47b45f09cb8e842224b1583ec559b10fd2c67e084dc71e61a94c3860b526c592e429aa55f');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(10, 4, NULL, '2ae3ceca7c0af15215830485548aafdc6455a52993da13d74637523564a139a59502a4c7369c4b94925de5d712090000003018fae6b345ced655629ffbe520cd6753939dc68fe9127fb9adad3dafb8385b0a9f635b43acf2ae666276888b8e2d73b168a8f612a3959a937e74e7b9346abeb8a5142d4446c5f6b6f7e1ff12f3ddd8939ea36a881cefdc1b856bc292c4442f92a4128e95e2a920a1795683544514194ac432594559c828c45d295a6d0d4e2e260ad634f7c76b68aa140067384aa5e2cacf150902e900000006c48775e367eb1ebce785999b9f5a3a3578e2c54447f1bfe83bd78b5d42625bb041c5ae648e606f2353d3927acff591c3841ca5e96115e16249898269e4975210151dd3d3d78f0f3a9b1a62d3886d6c54c4e9e3139310fd1a572905dba563593c1770b1de869d9bf692f07e7c7631b5994d0dbd497962dec8d4d5c5ab53115f3ca15a4104b95d9ea64a01584e0df97922010000004644af9f4d0d362adcb13e90ef4bf30e35550aef570c58f7b5b725a515d32fb04542bdbd3b3735489992c8fb61fa9a76ee6c930b26e55137b2bd8df9c41aa594888e36692b11bbcb9dd80cba0f21e42a156e76a72c9e2bd42a6235366daa12e2d8c423768b26f0c5c35993d2b223d56d7135550a20e6ece3cacf1329a8a718000000d08b2e9bcd3cec9a201b6c6c34d151ec0ac64bc60fbba4e8fab5d865ec90e3d188371bad8cf792806f23355674015a62a4662917a8a3ddd97c94c6c5298ad56bc45663518824d72f62c6b1e328ba3e2752694f918b545810e22613673a95cc3877620954a6946589e289d7df7c1445e7b00fc4794e8cd4d054258098b38f273f572430da0000008644476cbc67cf9321f0b009346a5bd3dc2f7c22f3b63d42bc58198fc696b5ad91e5213f05db25e66760a3d686e48835338fde4a11e898a191c6c5dd8b5461939710491d62b19d9d0d72649cbb361dd7d0dbd0c456bd63a3292979b443ae368934c7154f592db5ca2e4eb3aca94b4e613a802b3f5724000000c09078f7b35bf791b7a9fcbdf0f69d624af05eab129f5d9cb777931822c69ea7b0865ce546620731ef9c9847cc12b928bd71a790169394a4d8b1a4b761e72e44fc4a5e2957a2a2512f1e25c4eb6a28293d3d260645216d379bd550b5495eb81d4f95cc6b57544b9d6b5e5bcae082e4d2a3788ea6aa65711da273ce57992b92e47d7b3806000000820ddbd76b41fa8a40d5f8464bfbca4cff4dba91ded28e3dfba6a8d530bf1b3c8c74f6c7850ae69236fce40f4b05cd28b35924b7582cf0be714dfa9b6b8e5ebf080c3600000060107cfb7df6b881be6584448a210a0c0000001805161bff7c52205798dd181733fa4a000000000090b821713af3b36f4b491c5d55326fb4b48f664ac0f8330a00e001735dc0e69236fce40f4b05cd28b3892487f96c00000000300760b301000000c01ce8b3d947b62dceb91dffbb35e7c13d3dc115b01b655a9085fecbac50253a9407da651dde2af79461dce25fcfb897529f298bdb3f87565bbcfc7ae581d30a004098a2eb3d68854f7eb876c781833507fefcc8cc1d85db5a83269d0359e2d0b22ee474927f730a14665bc08af63b912db85de61d93da8cb117bbd1c94ea5f4cfa63b7f57394acbc43286433f000000f8870e9b1dbb7447cd334b63e97172ea9de8c3d3c172b52b36a3a246b4caca3e9634a2fa0278988e53acab50513d3ad81d6a3900000042876ff3d974ffecb405b14111ad1bd5d6a32c9b22c5e6e699295d224534d5ee70abac829f4e70b895525455d12da664227ba62a9cabcaa0c01e87ea114a5396d5ceac1480fcb37364e00ae6495a515f979cdc444db175f64ca8d1544aa7f06e899c7e0000003006ba6d76cf9ec29cdbc9769ceb82b57f7637aacf4056ddd9f1a3764e238da376a163696a77dc81e20a48a0b5c4c6299856474b35a252b1945d0ac837a28238b12afc20dfc8060dfc0c22255d2883c6758508812c182f33c99046c2094206542a5b0e7775b4125d85e9466b0ac4c0b2a41737515b6c1f7ac6a53f9593d0d4fef1bf520e50f45c0e15a834032d76b920b495d229bc7ba27b3f0000001804ddef412311f2a5e8c8b65b0bb75d15ec4d3975e0200ff42e1b3da693dccaaf2c69e4116cd3285afe002b95a1acca4a8f6da83c03d539908d7e4cb06a67d0aabd1b1dc3b6dec632172174a29bd5265122494b3368aae32191272d6b88062724b8895ae8ea1937c5555d8dbdd8388daf74906671add9cacbc6554a97f048b3f70000000c888fbff50ae67c367edad6eb5d73d47d42f3abb4cda8b11c6daed0cc30cbea96548fe2445fb0a09e975323034f3255b4202103757473f248e1d9526d7534757417065bf42e541ba75e6fcf4df488fe9e19231abd2e58d3564aaff0c1d5080000603418f8f7d956b48cfa3d32d4b6716719adb334ab69dc8f6cabc89a731fa627b1efa530159c88bad70c0a2d94238f8e7ad159572aa5581b5fa4ad8ea68e5c61a8232e44d191a43b37d127f42b1e34f42bc515de801a01000068a0c3661fd9766b8ef8fbae9ed32782b6060da1551bc964a4f414268b838a3466196d6451f1b30e7acc33ed0f94a38235fabc769b6a7db2dd7d94e03503e584906845739038f2701037dad5ffeb2633be42a2c3cefc6cbe3ada89aec2b8fd5a89d4cf4dd412dbbf9e093efa94d2145e5b234ffd000000102274d8ece4f52fdffbe14f8577aa149e5cf154b0d6a0213a43495706b1b87111729668e62da1cbb284754f731a5d4dbbf04ba1353a02c2425552b815357246095e32d00801165b58b12c0b9686cabbdc02bc741a55589cb539811c0bc173ae3a5a89aec2585159b9b8e08be6b4218d446db1fdeb19cfb8ae41532cea567ea5276e2fc9ec45296fc2737bcf6b3f0000008404b6afd782f41581aaf18d96f69599c97e1737c55bda01400b735dc0e69236fce40f4b05cd28b35924b7582cc6dd3fdb62197d1d00302af4acae070000081ac6b5d9f0b80400000000252c36fef9a440fee2fac6b89850eb050000000061c50d89d3999f7d5b4a62a02a7da3a57d345302c69f511853407db3ab6f2e15cc256df8c91f960a9a516613496ee0df670300000000a0006c360000000098035f6c36d92624889b670300000000a0c0079bddba6fd77ba1161700000000c62dba6df6916d1bbbe3af0bb5b800000000306ed169b3cfecf91ddabc2e2dd4d202000000c0f84597cd3e5bf71f7fbef96ec3ed990d00000000e3093d36bbb5faadb447b28cfeab3500000000086fbcbfbbb475f7cfd1dd0782b7971700000000003cbcdaecd6e606f4fb86db7f2f7efe69cefe1f3c7260bdff1b770100000000e00f5e6df6fcf53507d60b873d7b0a0b4faea8590f13db00000000107ce03d6800000000600e7cd98b3376e98e9a50cb0b00000000e315f0b301000000c01c80cd060000000073c062e393aa6f09548dcbc82ea47b4653435bc799d0764a6819cfeadf90383dd422000000181766b32fb7e506aac62f1cd5a3d936dc14bb8e8f1de35c7d8cf3dd504b000086c1320fee0840065f0f101b07000000007300361b00000000cc813e9b7dee831faddd9740ffc5977cf051a88506c61bf679c85288bafd28d9833271d9eda1560000028aff770442158524c4ea08b50a807fe8fb7df67f7f7178e14d9df7c4865a5a603c81cd6d35dabf2ed462008041803b02d0e96737ffeda3b9532f0bb5a8c078023f9eee40f5a19602008c02dc1100458fcdfe47f7992bb2ae079b0d048f8a5fd3c753a52a88b7661ef988ffd90fcb39ed62a2e700b8100fc4ff2a7a38897298518ca50bd53a5c3e6a9452061bbbf791e3cc7d0af1c46c1c5179f503803b01bf23e49addef02245e99f35cef1ae17aaed8ced2a5eb1c081aba6cf6f193a8ee053a99bdd6f1f2b9508b0c8c03563d8a32f07ff2c90f5d6c42d221b4ec0fe463f942547a3f7b6ce12748e942d4f52e72fe0165546a3fa42a117a94942d42a8e00e56d6b11d151c42e5b4cea243284ef9c0aa4459ef2a9a567ce4965a9c4e72d5d1e76637ada5be81d67618952294918eac9e4575690e00dc08f01d21a27517d8b14f4fdb6277cdaf1577c721847259bbf54fc04033d8e8b0d9e7bee84428ebde251d3b9774ee4c38bee9afcda1161a188f2c448be9828a59b3c9df133d2a8b8862d1c67c62fc1cdcb2f968152d9b952f96ed419b2bd5e987d0c11eb92dabba69f651a394f526f23c3d769a24d655a2229ade8ded374d59769337515d9a03003d8ce68e10d0be0b4ab0b55ec75c705ca7703d6bb60b04111d363bfa5bafecb4dd132d7dfebc1b5c6dc0000816118ff485305d5a25f9e8f90962b592bf1d1fb38f19567e3a9aad36a2ea8f9c52b168d942ea5bf7a063f8d9b78eb8265892830dec01e745d4d960b38100e0c71d8134ee0221c05e9bcefc6cc038f8b2af17001809eb55e46fc66368ff12bd4584c07582f882d4fa6e7eba67b8a54878fc0974f01d54bf1095e1c485a8f61d34e71011cf8abfd612157c142070f8714720eef54cfdf5a2dda864ae980942418641879ffdde5fe3d78af1f0735f74ce98fedd68ef85006054c4a2395ef3cc251e009b39f6fc8bd54ab688a6ae528cec899143d7746f52699512c2e3054f30a7199b70ecee940a81719f4405002e81bd23c43a3ddc05a56f91bfddfbdc62e34048d1e1675f7763c35d8eefad250b049de8eae776de7875a88506c60359f9a8b412592ac902192d4ade45681e8a9b473f2c445d3b34bc01fc60fa35b21c2287e58fb23cb675a8fc38599256e0b9ac1acd524278fc102aba997c123c1ee51350afa800a04120ef0811fef53c1735e693d0ba8546d7cb1f2383d1133dc8066fe8300016fcffdaaadd3fbcfe1f81aaf10b47f5e5fffe8edfc5c7f92619e35c7d8bc5023b22008004ec110228813d4200000000c03480cd060000000073c0e6b3bf705407b0d2b68e337e97bd2151dfe25d204cb1cc0bb504006024e08e0094309bfd79ee9b81aaf18d96f695a39b91fdc52f7e11d23e092ac56a652de34c7d17b0eee69bbd533f52f11934b40ae69236fce40f4b05cd28b3592477931062e32166d338b6d06182d16ef2709236fce40f4b05cd28b359247793106c76e801b36d7a8c7fe79b57daf0933f2c1534a3cc66915c2da1cef7a09dd9f3b3953b8f93a36fdffbfc8eac60fe182929af383b9e1d77eedd54d516c4b62931e96b57a746ea6f9a0adcdfbc6b6743af4a784f1a60b35decc1721311a29a02abbbfe3ac7a2f5f0e35dd72896a13197b4e1277f582a684699cd22b942425d7e76ebee953bd0ea976a0e1cdcb11abdf01f7b82f7c2456c2eb0cdc3860eb3b713c567af4d8f09458f8d0a417cccaee6fef8ece2bc246eae607bdbbd0d3b3d9861dcf192a09e730212c61fb09b57daf0933f2c1534a3cc66915c94508fcd6e6d6e882f5cb7742a3e8c5dbaa3e699a5c17b1b4e6c5424b679edd460b45561b3479cd720434cd6a68018adde86a64e84e217698d3b2048ae44d8889aecddbbcf75df6b2ff4a04c7d3b07071ee59d7fd847b1832f79809e531585544d2c3c7d53a63d68af650dec735694dfff0c4153906e6eaddc33db1f65852bcd8fabd43f998386df37912f9207ef22779350476cbce7f409343335846fad8b4f4c426d6e265311769603ceda89fdcdcd7da9a9f43b16b74662d89b552826b3587867677c3c75f11ba355b1714519b922bdb4b57766c7c747e1ced4534cd4a6');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(10, 5, NULL, 'bfb3534e94dbe7eb21ebad486589382527aa0fc5c7637576f52d1222de34f4ddd11c954af3d29c4979b46076f1da68dc0452c4c6dd5b5717f7bd4b34219b62e5930d0131ab7cd9f3a0e2d7a87e7640440836e6959c108bf6ef204fcc63a116646c150c0be42b6daef1564a074ab5b123a417b90e3ffbecc9f766cf40750f2eceb91dffdb762498e2b555ed259e69767171b12a2a4e63e6d83ea842e6e24432370a1d99801a852f50646a1afd825a2616b8c6b544a6e6289a8847ed9b38ee352d23361c99badaaf587d54b48e4244c528dad0a626142f0e2c70fb091dbb0491fb5257530d63d27352fb58fc7d6f677c769ea41d4bddd51c952df645643c6a72d72b3e35aa49cc89556aab22fd84bbc6c5fe2aea945aa7c51350cd26d6256949280060d7ade010d9bd806c72a07005ecf3c8203a93fadf0e852f6e11dd0e5541a93a5a837dbb9859fccae19222b82f8ac40af138739faa2ad7446f38dc9a36a2e43dac6385be15dc4a7ba15b576f572b55883aa4e238ffafc94bd7e3d45e88b00db3aa5d97b614f5b33cde5a77ef6195a6dbd59d2c96724d51b78239c8ab4796b9906cb78aaf40bb8b307ad4d9cefa019f6ee900e9504d42aeb35a21a1e4702b9c6f97dbc4e56ad1bab9945708ab53e3f2d3cf282f5495182e6af264e3df447ee0f1f2ab505ce4fa4f5fa0d0359f6d39beeb45f4d38335070e3e92f9fa930f06713e9b45c489e1c606125b6ec14cc45c9f1089fa3b8ef62245c83c2911fba42c9145a11365fb217e71ae0f89469396acea495f8beba5fe6c64941c4de8efe3681993be08e7eb6ca2960cfbcc642870fdd84cb013155943a8ad115b500ad6912922a44a1a8ac300a213b5c7246773a360995513d25cc5c4aca4dfb4558a898e12272aa8f6d2d84394a9a7af3f40eaafda81ca17523fdb6d9383fae3a8ec5de21cd87ad09a27c8ce83f8b8311f95be406e210f054be98f2f9dbbc92645cfd27b3eed38ea52a628b2753d46126badecb8fe09d18cdd4ff62824f5fc816cbea92b3ee9de902125b7df8196fd81954a131e408750c2a3625737d016f1b756fa78956478141d3b2457f2c0a32843bd35057ea809db30e37f739e10c75e2e6dd10e6954e7f1d4ba1bb65ca294831e57bc40776a712fa54829aa6499e556e8a7c5eef5b85389b2d495e852a712a147c9292bbd5f3c788b27a4f65514f7043b831bf15de0eda2936f13b7ab857fa5d12b44b8260521edeaebcae562d385bf172a570c2e2eb279b8897c8677f909677c957491eb3f7d8143d7ba71e7ecd58f086bc593ef2e9cbdf2e45912260a26d812b50961593219dcd640a7b95dcc03312882654f95d2a851d18cd4b2d033f19a1b625d1778f79dd32a27193d62a1e223f506ba75d5ad01196944b163b58624688e4df22eb4564c15a2d3b437fa7437ae4f22dcedb2c5c7da53dd7bfc51683464a4abb6d22a7802598467d93a2f05d9f3773ad93493301739a793317b3d2f9bb031d79cabe4f4133dc8fa0ec95c7f3fdd9d50e034a9c70bee0d1950f21e746c217a40d857740972d214695fb2ee77a86321adadcd27830c7622a82e1eb0de84d01d4453f2247d57a3adc3a83e1feda75f66e5a3ba8f89b21e5ae740c5a83b8c6cd3512d426573c958c1b5d412b4ff51b9df127aa89d76d983d5ad1e0ee266d2090be96e57c8377532a483e3c8a147354af7695a1b95070f50322abd5c33f26da271b5b8d64faf90c625ac4811dd8bb3e466f9ba922f3ffdf87ba172c5e0e2bf6c5e912e8c58de6523759abed3174074d8eca933ae3b7e125f305383218f077a8f76f4a7a60a7682632da9071de9c37c2af5cbc5d95f7a72b82ea81b52bbc2c8415719559bba8b48430e613c22c0d59078d20de4800c6c72d28fee6cc0bd91a05f2ecf831b11d14cd38c2a031e2af0b07a158d0496526bd4f8ae7c3b79053fd3b1e352fe07f26ccdbc839f2781f7225d5c64952f63566e43a6905c09767df62b561574eb7729f023ef5dea3fdd41f676c4639412df5f4fecd23a9755f722cb5be8012b42d45c75bb973a8c2cf793aede4f7b5e673d638d1ed546839eab25844d2718ff5dd51e2f9bb13e7deee8888dc72e5d91beffc53afa0af123bfdb713c33353958d2614f588a870b017121364bccb718fa26bf4aa293ddaa58352da963b259ac63916b6c9c8b6ae1b73216af0f5568dd0b444569e23d4d5c6086759443d75847aaa1f2775904eaf5929ce2dc32c9e0b92fc4ac44424925b76977322c12a3f144fba0bad71ce8cc56e63eb26730098ed171ba7ebabbc9df59b1ccc3d0037619f170be40984dd4bde096d39001258f45730ea183d2bca67a3a90f8ca62c4589839c64e527d039ba1ac3de4a96932e1b79d59eeaec7d0b1d3bcb6a613c751a8bfaed2f539eede3a9fb92474b9a6016d5ca25d2a9f8e8d0e2be20ddeeaf18e8feaf8a39ae895d6d140b1a35a3cefd4bf3c465d70ad8b41e7d5225c219bf7312d4a91c6bc802ff87da1ba8aa143cdb145e3b2d17ffa0288aed8f8fcfb9f3ffdb3958b5f20c7773e72607ed07aaaad6a1759b49d5d5c9c4d3f631fb38acdbbeedc1b559ccdbec0ce323183bd559b505e71360b127bf5b8dbaaf6261667c70b75743637a3d454ef8bc39844421b3a9dfa78497e5fde0ac3542445fb3b3bc58900a17d1606677aa3869a669cc6dac0896d8a9c422acba9a95d6773df22555f221ad4585d1c85e5951feeca3a89f221fed1762c2a7b8c0ce449dc950e78052772d66cba08e5b86a56d51d21c098368fdc9045c213c1eb901f1b9edd64d06da19149ec32ea715b390dcd35a2e4257f20ce50013dc65e85b547559c082c3819f9c8498d59d7699ab210152d54e59c4397e7482a5897a0f24271a30b3a0bc8690bc9f533d9bcb5cee5019cad9b05a5b9a58a841ea0fdd6f1b166bfa9ead1816feaa8cf8b4ed5f03583473c71342a93912f868263d1c67c94462f2439510df7f293afb47bddae902798d8257389951a0da3ba50956220ef6a4ae8bc897c60aedb653357bec8f59ebec061c1ffafaddabd207d45a06a247b8464faef895b2c9671be4946b0d537d26bce4cb947881a6c9c4ca482b9a4f52a7f452159dee577fc3fe0f5045c4153604699cd22399650e7bb4b0100000c0c9d7424bece280d6da0ea0180b1016c360000e62750ef0609bb778c0061068b8d7f3e299093d437c6f9ff9be51b128dbf8e100000000042c098f8d94909a3daf8cbe17084a42f8c80cd661be7ea3b9dce504b312a2c168b89543097b4e1277f582a684699cd22399690d9ecdb52120355e91b2deda1d60b00000000c2105def2e050000000020e4e8b3d93d7b0ae90621b7fe6ccfd9e0c976a4cce6c2c375e26b43eb1ec61fcb74ef5742ab924a9b02a2a27e054d2880cefabb2b322d76877fdf861e229f8c7e49b97a195d593f90fb27b3a2db2d51a92c37d14852fb20b6e115f4a4b29b7c01bc2c95b78bdcb563d1b1c6ee6dcdae20e8da3f7b5be12e74eff3076b0ebc7c73e33dbb5b832a7aee5607636b2e6a29c90ba9191b57c4666d71acf1ed87f6211f67180c873dae604ea393d1557e2c4def23c2ba6abfb3c486c2d24eabfb079577d1be41056b842793d4698d45a569a2eadcc4104a2d9c5522751c9346bfd88657d093ca543e950d713c5b10b017937577d41789f7cbfe55d631eb5863f7b6665708e8b0d964ffeccc15748f90a959f977365406755f2f99e405b9f86fd719d23ab1270e5f2d0a000415475d6946f90336f1a37555597946699d23d4621906da3f65f47944c628c29349ee34db03527771134344f78963a8288bc882a5de58848e9de8f6496cc32be88ef24226f2d577744b5fd9d38e65046a7f0ed24e8255abedc075acb17b5bb32b18269acf3ef276354229b7cc25ef3a70898d4b51f4b2329f83e04255ead0bb3a59f1058bb1d795714a0409593045e3ca6904a157a8cb5b27e6e5c889333c5c562675a37bb54aa799dba8a28b68be236579252da87a83aa064d511fde73ca67ddf93149f2e050c5b9a86f5a21e655670d26d6848cfa82671d8a0495f75ca108cfb986ea987b4dfc817a549aa654c24559f3428cdf9c5956ed44ebac398245e426860aebe265d2639e3c59972db6fa22b6f11574c756a270f5b003287dd15db11935962d0b5033b81784de54a705bc630ddedb5a5d21a2678f90ab66a1fdcdf4e17db6aef2f7a8f36410e7b48909606ca84629f687b2dc5e4f842d03fe4a88a12f40d5be554fed4c8abd8ac6de5b4af29871a1c92c2c4f63f24f2b8c5ecb9b68294eafb2a7e02ff60437144c048b6372c589330547ca3654cbc256bf2aca5afd267ac8c134e3c9d9528d960be10a5ced9bb754b954ab6cd4fd5b852455f6ae0d3831790de9122cc8167a9278a5c8b9eaa2bded588eaa5b7cd35d19a09b23c52411366975594ed73857692d2a1312d566339860134d64d298069425c459d648c79b95430c5b495779062a6a941f995c65cd097ef8672420a3cf2bba834f6b57c2662af4e6842e75dc32ecc1565af2b9bb2bd6d42e93e348a3af1b8f066ad7847aa46d083c75851e3f7bfefa1dab4f3c49d6a03d89f2d7ce0eaef0f27c363608d8a8bacd97f61c7e133ffb7317d038b9103fd74d4fddabd8c6e72ea73686966d79f3303178c96b882d9b4afdc40d6418d0724a1ea8305f3f765a1c1263f5c1a2e74c97a82a9557689d48bb464e7415144dbd26855f5dca35c206ab47deae16f3a2e4a5f694eab7959dccfd9624da970a8d7267be79a5c8b962bd4dd37cd25d119344b6ac2279742c3e42b05b2be71647a9aac4e0833d14a7340da8364d4a0915c78ab8230faeb2a6a5be60b33c7031cb63da61b7c4d52ea3b3f0cb6ae34c34d81835dd159964d8cc86298e676b97950570c4426e70b4ac4cb85f3676c48da38ef5a92bf4bd532576e98e9aa5f4a875db0bf13342b393766cd6f2dc92966a62a6dce6b145e3a36d9eb45197a5c639f6481935d5c401df7256383604674fb5a45cf31092e415a4a5fe2b894b3385ecec206e9a9777262b3290e15089f445ee727546b76fc9e0015de3455acf7592318f2fe171ea9695b10fa271b3e263b7f82ad24a0c21c478979067dee68a076cab5c25d42fadd1f41a1de274369d578c134fa8b1a163c78d6c167e6351c1663c76b4855aa860e84d0c362aef2a119475d8d3d046a735800d9099a3558acfc7c649c7eaed0a2bfbe0e37c36598f36f32ae3bd3d5f7283b1511b5d596ac1e9d4b914e42548863db488665a94978a450cb6188526c171bf10e607445cbd66b76f8520833f754a81096af6f970174bab7c506ac0ad41ec793f2013cf6a2dc854a8173f7a1cc10d2a28e717a579476ea2a1d02fb63915641eb63c47e3a82b456cda872db9189b80c35874ace17bdb33fa7eeb95f3a0b056bc75dfaef7d25383b77fb61ae5223499d8b9b760f75888e60ab16efd10d71d8913c0aed5abaa54c6c64308319562e09ac84b1d6532d6601e3399d9f6a3dae405b96c5280d6e1b2648dfb2d491427c9c95a33a988689379a5c8b9124b1dd953a239bc2237155be6d37db096596745227d6218fe4ea36b52d354bf3b5e831d15df27000db8462610102f559cbe273f1812263e6c59e20a04398d9f182ab1c91a34416c32b9cbae43fd621b5e4177840b57f4b029d2a40ff9c51b5d72e1547eed0fca31aebc066b2c3ad6d8bdadd9150c3db1f1f9eb1f695e5c78fb4e849cb357bffc54704d76f5069bc20ae56edde2b6082d366bcbd653b60d');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(10, 6, NULL, '345f6e6e2e5959c5471daac54e20ae8bac9beaca635f0849884c106fcdaddec09aceb5db5149090dc9073bc0a0529e4a47e47d38cf66131388ef4a6686f3849c29f6adf6940d647ce15b5800577be661b17772b73a482ff478fc1629259112b14d2ec19d796a2bf6aab9a5847345644dc9cdd59ec6b095341659d22ca5e4183f0e58fcb4a4ab3c33ce42b6b54119e55dfb6d413e1b3e43225cb3ec96384b014b2052fb3801482c4441419ca5a3d159e25b491380cfe8894cd63df834db58a274eea5347e628820bfd9ab8d13c4ce902c997eb10dafa02bc22fb0ebe5eb9888385a0bed8ef2fea62d58c7ac638ddcdb1eba4280edebb5207d45a09a7ba3a57d65a6ff3f9cb6582ca3d924834e444bb6d77c18688f1012723fb53cb83f82873d4240da71257f582a684699cd223996d044bfcfd642f8c1af109ba573a46ee173000000000803c6642fcee0c202d962e01b3bd926f5b10d045b879ebb754ba8250100000024586cfcf349819ca5be312ec6efb237244e0f759f0000000080111993fdb39312a68da606a34ce8860203cd6787487d83cf2779c5f85362e69536fce40f4b05cd28b359240f8ff96c00000000181780cd060000000073a0672fce3d8539db149b669fd9f333f2eef15b55896387fb9655a344b92798cbfe60ea4643b069978b98e3692f6aaa2f27ddf306d246df5e5ab973bd2f6f8ae2ea657465fd80bb535b376fdf906e036d26c2df5f4ebfd88657d093ca6ef28df565c96d5a7963c927215c7a5b534182579bddbaad70d77bcacfbb57eeb0feea60cd81cde9fb37ee1e6babaddcb38b6c59b521b47614007c41b113197d5fd4b134bd8f08f5ae9dfaca980fd23fa89ceeb6518e0ad6b057a2899da6dcba8c9b1842a985b34aa416f76fd02fb6e115f4a4b2fb6e2ec21b5782dd7477477d91786789ef290a97ded65450c093cd3e5bf7e0e29c9f9f48cfbc4e4e6b6d6e882f5c421699cf5fb2faba86e63136daf415e0e29e5d64af2db3be2b05188790dd9515af2a25efcf92765e0658ff94b1dd36f6b32793dc69f4ddaf427771134384627f39f2f655f66659fd621b5e4177941732914ff19a78873ded58c6186e31a7d1344976dd6f205c7a5b52466343058f7ef6b4fc976a0eec5832434e51ee1142f6d5fef07410dc5ef5ce90540c21a45d47ff2304cde510ba1c50ee91be0f60a45b51a9b24a7e5b2cc65e57163821e4861495b94f20d050b3d441fc76bd952a935f27ce4b7cb8ac4c9a5970914a15d8173f7894fce13d3af6f8e2c72485d7f32ae25cd437ad10f3866e8b47b209866af36eb5f75ca108cfb986ea987b4dfc01ba018342091765cd0b777b0665a2b49703373154d0f78dcbefbd17de05ad5f6ce32be88ead44e1ea91ad9d45ba2b36a3c6b265416fdaed1ddc288c7a5b4b41114f367b6af2fc506f6645de97425fbbcd333bd5a7a66da1db6a931caf5e5325ecb18d8f056b71a42cafa4856dbf8d6b6929793a00569b562aec57b535b7a5248f49e5b1ad9637d152269bb4adc668da8f63edc495e4899a6ea8961b675b9e900e7a133de46092eee1ccd96b942a39b55cd8afbc4b9e8ae025b654a3e5c27e5d6e5291cd40c4a156cfe137917d6932ce236e3e26494ea63eba84cdbf96a36a6f3bb229a364730ae43d654bd3eab29cae71aed25a716366b5d90c26d8448bdb66736cac2c21ceb2463adeac1c6290f70ed30d18a4e71657597342f76643469f5774079fd6ae84cd54e8cd093ebf40dee4906d5144c7b7bb624ded32dfb7bc0940d3c478d7ae09f5987c2c75f5a0a0e1d78dd3883831dc64870ff5723121662eec0ac9795f292db9662a75ee3604666f2e6193afdce5c226190b8854c2d6551edb62b209824a5b51fa27c0992e71aa80b62fd4465a5f2327ba36acb1a9b866296c60c97fc9a667d2ce5cfc44b64129472ad96813938de538f276b5748ec8a626e44bfc550beb4c9ae65977454c926ccc238f8ec54708766be5dce2285595187ca4ed8f44e32d9b26a5848a632f7b757295352df5059be5818b591ebe0ebb25ae76199d855f561b67a2c1c6a8613b72b2618ae3d9da6565c11ab1a89a268f02b4ac4cb8b33676c485dd29f0a8a0e16d36859a44c1a17e55b7b32c445d05e7cedf5da579485b6953532818e7b16acb1571cb6cb17d716820879d957b71b20d3a35f1a194c7449e54c46893110533d9e41b61d4453b8ab30da7d71db9555b662b8d1b77534ea3edd4498d37769a653f5a29a17e698da6d7e810a7b35d67498d0c1d3b6e64b3f01b8b8c18591d1bbd89d59477e474d8d3d0c620596c97a615ab1f04c2ee147854d0479bad9cc356ce6d070361a36cddce32dd0e3b77ab62d59a6c57468524015d20472b1db3b65c519869d9549297838b6167fd2306cd52dc4880c7f000572aec91c7bd79f8886cb29130a520c25c7ca962babd0b83bb585ae583aa0cb841516e82cb5458bccc2c96290870830acaf94569de919b6828f48b6d4e05999b2b1b12b2833d9bf6614b2ec62ae0e0d6b40661d4db9ef1d5cf9e9f9adeb9631f592ddeba6fd77be9a963bb99b6e0be9649f3a2f222729db0f02c0d690720364e22c392af4f0db522261fe0b6f8026067549c2726ed534f978c1d98cb4be6a87556a5594a9cfb269a48ea71133d4a45c2e471251b4a98c94e5e20c7d4c9792593e2641426567c648fc2f72637155be6d37db096596745227d6218fe4ea36b52d354bf3b5e83bd05df2700c3ce8d10205eaa1876203f1812263e6c59e20a04398d9f182ab1c91a34416c32c3caae43fd621b5e4177840bb74bb965b634e943a34764c9c518eca8cd6f5a3d1a96576b854b6f6b2ac8f0795faff9f7ffeace9c9f2f6e404e94b9b9666c4d364a5e5365efca2bd9606326057b6abab77366db7d096573ed765452427cba64fd81811671ab30b16dec463389842fa47dba47df169f6a4973b135d2fec379369b98407a834c05e7093953ec5bed291bc878c1ab9baf592ad77ecdab36db0644230744bd1ead44d57972950ab169f2052cf680f39c7958ec505609cadab2f5948d0a91929b4ba228ac42c59ef4e471c0e2a78a8de033cabbf6db46d9bb630e8970cdb25be22c052c8148ed63389158888282384b87cbc6f761013ea3273259f7e0d36c6389d2b997d2f8892182fc66af364e103b433227fac536bc82ae08bfc0ae97af6322e2985868bd4d2b9e0434c14a8fc2a3b705f9b80a0ab07dbd16a4af0854736fb4b4afccf4c5175663b158c6f92619a1549f04cc4f2d77a80746dcc43153dfe0efe8f78af1b71930afb4e1277f582a684699cd2239ec110200000000a6016c36000000009803161bff7c522067a66f8c8bf1bbec0d89d343dd27000000006044d81ab4db52120355e31b2ded4909d3fc2efeb7f68f4753dcecb4759c01f5432dc53852c15cd2869ffc61a9a01965368be4309f0d00000000a6016c360000000098031d36bb674f61ceb6563d8900000000008c195e6d76ebb6c25defe94a0400000000600cf164b3cfd63db838e7e727d233aff3960800000000c058e3d1cf9e96ff52cd811d4b66784f0400000000608cf1f4bef1a9c9f37526020000000030d69077aa3cf3f2a1c0565af8a305a1d62b64ec78e5ed508b10022e9e1c156a110060bc3330381c6a11009fb9f08208fd99ff4fd6b7889fbdf2ae94004af0fc6b2da3afc4a460831dd8ce340baf3575875a04000000f371d105befde29ad8ec8fff27c0a3b37f7c3d72e945e3e897df4323cef3834e3c58b9edd6b901ef4cbfb9e442cb372f9980a5ba39f54665faf06fe222fead2b204d4cfac6849849a48949d157865a5d0018eff8faf4078c80affb884df4a7900e460cbda15920191e710e0c51839d36772c7ad23f2eb98819ecf937259f1f62624d7c7e26faf63df820bae3573d4d15432b3f1c4d13932f65067bf0a22bfa3f3f1f6a8d8131e7fce048a845007c060c7998416cf6a21f6fffcb4bebf4e4feae3ae777b50b8e78da85f4d3170b9ffb5927fb607126befaa7ef2f1a7b554fbdf6e2c25de72c99d9a737cc0a549dc34e34440df6f7d2e6ba2adcfb6ee143fdf7be7cfb5c978fe4a0b9cd2267b4d87ef0e60f3e516566f959368b33e169e557de900c76d2dce48121397d42c28f26fcfde579f65fbe5bf278eca255afbdd38e138786860606cf9f3ffff5f9afbfc67ff1714eee0fbd361179d984ab2647e026265cfacd8b02789200000828174d049b1d56b075e3d8fabef9d2837a0ab8e4746ab896da7ef689c76fdbfb028a7ef28515f9d3103ad392736fd38196efa78efd6af4ab96aef868a967d97c03d7333c4c0c76baed46ce4ee934c5297d217d2407094f57dea6b4c1cede7e5566969f653b5bffcaf2c75a5ffde5bca93aa4baf4a20953a8c14ebc21696058768c26bf321bffc5067be4f295f3ec089bed7f4115dfdad835383c323834323444fe7efecf811dcfbda62cc525faf2881991c460c3d2330030383e2d71028c8ffc5baf5b7efc8ca35297d956e6d472a735ed626be7f31664b936e1bb53699ea929d5cfa3ca8fe971eb1f673cd62ee4b25cbba8e99994abcfb4dcbdb2e91dc1d7ccc8ee5e3f0bd19496f8c47f45ed2fbc4fd26fbaffbedf2dfd2652e494136985a4606aa7f5e7e8a55fa17b848fb81e74a2f8f6bd2f302f36fa89e7e90002a1b7b6fddf7bea5925624e3e58f1911162b0176383addd574ef5cc83f4d1c99b91704f14526293affdce4b9f7c8c0fbc9d1a62b02f25067be69cef48217181debb3f886cfb3936d582c18eb9f9becb531f1b181e1e1a7412b33d38323034747e70786060c0a5a00bb15744cc8a9e889bb802e6b001c0f0406c3ccc50fd3edb96ffcc734fffbb9e6252ce0fcf0d71336886c669baf3fda69b339ab051ec5a370b9bed1f4f45ce963f5a1f6fc7a6fa2fdb53ae46277eb1aedff971cbddf735b5646677af9bf5d1de1717edde7bf78cfbaa8545d99d7db39ffb49f7b413bfc8d8fbdb5d879ab2bf7f33ae96e6c4c69826febe3265c58f05193e6cbe7bff398412259170cdb9b8e6f8454da4ad4f5f5af7dc632b5f44cfadb8a5e5456cb0b1bdafce268380dc1a4d2d8829a5067bf6f5df39d9cfef01f4e9c85768a4b77fe8a4cb4797746e6697146e11376226455c338518ec5973bec33fd99dd51f45de894a1ebf327565ef5bcf5d74d323827b4dfe0d0e0b7f07ce7f65f1d0c41511f13117088bce0c33770f040978fa9b11b84fc30c95cdaedcfe80ce6252ce0b22f84ff8112d477b6e66e5ededf907c8a1b37eafb59eb8b99b2af2e39a8987bde29ef9d3479c2368e6e35b67363ff334f69bff75e14c5cd5f46951089d6be9ee1b994f2fc16b1316c53a474626cfbc16a1f7fb3efcd8f92f53e7bf5a28343a7371067ae1c0b90f4e3b5984d799b0e58ff957e38377f7d38f2327dfeec035a7dc328bb63579d12dd1cef7cfbdfe76ff8c53d8b4a3963f7f70f2cef957c74a15f2c176ebdb372479eaa3088b05bdbf65fdfb5282055d3b31c272a15bfaedab1fb8f74a9c88c8b7aae22ce5e8c1b73f58f8fde4080fc694c4ab6752f7f7daef684ad59f77fca3ffeabcbafff5cb531fbf78c1a324244edc6b6cb3b1c11ec60703f8e3c0f98809fc86ae9c14f1ad2b491393a2ae8427c138c469197d1d40d0815b35bc906d76d54ebd065b99536baec4c39cf1c2c2878e172274a6f547ffd6d462c10f8273c5bf3bfe5bfa1509384bde303df86df1d3bf954a7ef8e9a911f95b79d2758494faffcf3cbde2');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(10, 7, NULL, '0db9153943dc37a70bc76254da291e086d4d9f4e0604ad273f59b86c514a7d53cb074db76435e1f494827b5fc99ee2223c36a4166ab06f987783976e8ac0ff8b2f2efb1ef379fffbf0638f7f72c1446cb3d5e9ec5b9c6821dfaa8abfff642131ed96190b9ffde9cc0bb59b9a72d9841953267a1f462034343c34e327c7bf1a181c1c943d6c62b689f11efef2fcd0279ff471d7ac486382cba3c0c31ea758e0c49b1038696106b3d9ff59b6566701979c5a7eb6d60b794eefdbff564a66de548462e6fff6f5f9a7f7557eefb973d8189f8823df8e8cc8058549d51f3ffed0a3cac55a675be9522e926d902edb46e4d756e82fdb9fbeef4f68fe7df7beb864caa19de498542514718a758e881fe981536cebf4a93efc77de55530663666391f0b15043abe344d70fa65ca5683c62029a6821063b658137834dbb16774dc44474a1cb4797746e669612ffcbdf7c2fd95b3b932f99307d32b1a6df999be42d2f1a1e62d67a605870b249487c8004c6696c1cff1dfc7aa2db382cf2b2086b2469e2b2c868a7131e02e3150b38dae6036ed83083d8ecdfffa650676e979c1e0a7ef6157fedf11783e736ad7efaef1bd7ff84d8a24fffe420e1e8653f9c9b89fa36fda9fde597deb9ebdbf3a7a14f5ffb7fc7172c494d7ea3594c41a8b775cdbe29654b46c8ecf1c8c8175f8d7c869cb411e757e747fe49adaf357af2675ff5779c20c7e7cfe30c94612713e63cfb78f96d0b722a7e5febf8a0fd36d21696c1e28c4a4b9adcb0fdc58f96fcf8ae18f4ed3b48d37fbb66f2e55f89952074f1059649175bb0dd5a7957ca07bd83de3b2b8298e10ba570b7f4d1259d9b999bc283bed5244290ea6f1f79ff91f4d0d0a060a789e51e1e1e181cd9f5e2eb03035f0f9cff7a60e07c6fcfc7834383116a3f7bcaa511d74c61065be775028425f0f4078090436cf658fc166064c4c935dbdfb065ac6d7a69e7e66d35f42336966b9f5a9e1533fc294adfbf6e24737bf35d79cd24ddbaf0b9cbe63df9d488fd672c85242ecafaf49f2383b4f6cffe39fc0d34fc256de1cb7f0ecf4e5f38e7e0a19acddb6a9d51d75197fdfcd7b84efaf5e0c8a78249ff5afa38f3bee7b2cedf57c7da72463df0d4f2b4cb868f0cf66d59b76d8bd056dcc2e7eeb1b282085df18d09932e9e20bd96f59b9745fce36b6fef9788b04c40968889960b5c3e9283ce9fded72965b4dc72c7c13b54891667c296d229aae23c2ebb7842d4a5b254519747fccf3fbd4895766b4a794de3f23b6e1226b077bff87ad49449d75ebbe0eb8191babaff7c7afb5697fc932f9d701575e22f9d120d4fec710eb8d966046edb3083dc85ffa5c33fd38fe32f7f15deb9fde1b9a1735f18e5459ea3419acabd644af4979f9c13b4fb9f2f47be1c08e56ba12eb970c264fa3b6ca554673e1bfaec4bef52bdf2f2bef303e731ab57e79796ec18a0c79b7ef9a84bb62b2e9930ed0aa6780835050c02986c3302263b9c28c89c1d6a110000000000d0c7ff0213f3f4dc3864a0220000000049454e44ae426082504b03041400060008000000210092ccdd862c020000c406000018000000786c2f64726177696e67732f64726177696e67322e786d6cdc95db6adc301086ef0b7d07a1fbc6a73d45ac1d429694426897d03e8022cb6b515b3292b2bb79fb8e0e5e27610b692037bd594633f2fcbf469fd8f5d5b1efd09e6b23942c71769162c42553b590bb12fffa79fb658591b154d6b4539297f8891b7c557dfeb43ed69a1ccc462368200d8165895b6b07922486b5bca7e6420d5c42b551baa716967a97d49a1ea075df25799a2e1233684e6bd3726e37a182633ffa8e6e3d151257de993da81bde75d792b54a8754a3551f22a6ba2a5b27ee042ef41f40f0a369aaf494762b5fd1ea506545c8bb784c3edb0e69bfddb79c74ac3af5fe9bde6259ac66b3d579d53c9a7cad3a5f66f368f485f2a837081684e57e2bd8369e9f7ddf6f35127589738c24ede132a16a1f3547194635370c6e306670129dc337a103258360778afd3648aa9b96ca1dbf36036716a071bbc3344fdbfdf285fc4327865bd1c1b8297171bce73751a39a4630be51ecb1e7d2067434efa805684d2b06839126bc7fe07038fdadf68628315673cb5a27d880f03d9875469f15bccbc99803c20c6e5e941c1b0db45002d2e8586278164fee171a50c28f1631482e0ab887e51c2306b5ac5865593ef7b3983e1fb4b15fb9ea910bc01c78004229a1fb3b13dd8c5be20c8301ef0c261eafa11370ee0db5749cf419becfa42614ff1df9d944583011519bd2ef44bec8f3c5e56c711ef931ff1a79186e7a4ef9adc817ff39f27920f3c391cf57b3e5e509f90c904ffda3805735be9891e70f46debf10f70754fd010000ffff0300504b030414000600080000002100dde46a54f70100000b04000018000000786c2f64726177696e67732f64726177696e67312e786d6c9c534d6fd43010bd23f11f2cdf69d2854525daa42abb2c97d2562a9c5753dbd958f547649b4dfaef19dbc9121007208768e6cdf8bdf9b037d7a356e4249c97d6d4f4f2a2a4441866b934c79a7efbba7f7345890f6038286b444d5f84a7d7cdeb579b91bb6af03b4790c0f80add9a7621f4555178d6090dfec2f6c260b4b54e4340d71d0bee60406aad8a5559be2f7cef0470df0911763942273ef80f360dd2d026551606bb154add18d65997a1d6599d2d6655536e8ad84134d30134eedb7601472f459c1d66389a33b6c846386527c69f32c19ea99bcb77ffa4b75ee5f4bf119c657c4f3430676b4a49106350d23ca39d6b30a7c7fe611a04bb3b3d382239aebb7c8beb35a071b187d1fbf6c070680766b5162650d249ce45bc16b4985ab94b3c248c1fed18f1660395ef6f2d7bf6c4d847a1040b114767db81398a1b873d7471c9134d1e7be6697297cbe23c96499e862f96634df03dd82431b60e7707956d5b82ba78495fe21fab820a5b250cc10febd5ba2c31c430363b985140351fef9d0f9f85d5241a3575586ca287d3ad0f39754e498d5925f95e2abc22d8a53b3e6d9523275035dda72fea23bb5fa62943862c9f67b38cfd4281a5c66aff40a165108e28a96b7a754e822a0ef193e17800aa0052651bf59599e618677736a78529899bdc418028146ffc6f2f2361f11d373f000000ffff0300504b03041400060008000000210048a698f87f0600007811000014000000786c2f736861726564537472696e67732e786d6c94586b4f1c3714fd5ea9ffc1dacfb00f088fac8088005153a5340a345285a2ca3b7377c7cd8c3db53dc0f6d7f75c7b6660c72c6aa44861fcb88f73cf3dd770f2eeb12ac53d59a78c3e1dcdc6d391209d995ce9d5e9e88fdb0fbbc723e1bcd4b92c8da6d3d19adce8ddd9cf3f9d38e705ee6a773a2abcafe79389cb0aaaa41b9b9a347696c656d2e3d3ae26aeb624735710f9aa9cec4da787934a2a3d129969b43f1dededc16fa3d53f0d5dc495a3e3d1d9895367277e727632e11fc2c7d94d465a5a65c4c7cb9389dfd8faab800fb2c3e59c5c6655ed91e070cb172416c65af3905e5b2a8b0cb5ac6878abbb31bf2b8dd4e3f7ad816ff38fd7c3a3c1c8356ccceffe96f7725c4abd1adf780b74bfcd97b27489f1526ef1ca1b3f6469a1ac2f442e7de223ec5c62a38daaf1aa1cf3f796986e6eae2f4c9e986997ff776a99a55c79e13263135b71ef86b7e6774afb6f736f9be4d49aa42dd74281a06959e2e6c7b0f78a8d7f550dd6a5d9609d937c299b974261ea70f9871547af58ff22ea7cbaa5cc27fcf8854076874453d6041b3f501fdd540bb2c22c4565b42f80502dd71569ef86d1c593bf2f7f8be73eb7c75ab85e24a4acb8218786e2ea6bf73847e18df82acbb4908cc5ad095bf3bbdc348b721bf72e201c9ec4da3416cc89bdefc6e3f130a08b5265df454196d8a9cc32724e70910a2a6b11946778e516bb578f1995bd61b1546542badb42b9cd13020b8da39c3d0165402fcb3238eb23149a380269d77ce85e968a1b31a6619b92dc8e80a6f686a443c9c01b943064eac10ce11a85ff8541e2aa6a4ac90ae692c4cfe1ba731be277a0b7f6505721c54d875844402c1a2f2ab9ee4f182004f3accbb816a0cec543415aac4893854bbdda482c78109eaa1af1d08e80c80b7a94f8642c6bca3c60f942ae29619033ec17af1e2983d0182d2e09d1956e2c02b2bf5c7dfa1cadd6d6dc2ba835fa3bce0e3e8c7f5cc536c45c39385ec307d2f3496112703e56b5b1985e7e2eae09530e0d92ab256a029399299b4a63b8d926f30d7803f09f5c25a606500ec8c4a370ee6a99614462d639b2f734ea87951396c2aaf6f849965cd3a5cabc021e4de092c8a443e6be909e19c0f4da200e07b6a042de2b5ced581288341657322b046658c48492a2f7bec1250d285b4e4406560d98d613a6a5f113799f97c242b114343c143dd0340410ba201497b8a484edb2340fcc9c8e19ae300f48eec1f4cedd5c0c103cbb361848e04ede64f0817c1c32f60f04323e2b579cf1915bbc1cc77497539fc9f3b803a8ccfa0531aecb06bd6a440e3e9478aa5810f14f208e189b3247df324dc2a0827954810349c8f08169cfb0778ed1090ae0055612f73bb41d0f1a3c479e058fa85d8b8e9b0fd3eff885878dd80d38f2db2390216a0c5a437bb55430bce13ab4592823e717de5049bccfde40307e2e969668d7d3234a4f081b1d0ffe33ef3288762b699a07ed53230614594c5d38182dc26358ef60481c2f1aa7749062b29583efaba0972d40ac1e5cc4ee3a4af1dea008b135a3f4358bee4b22c68a5fa2ded875e229d2872bc939288d1644b3a1783bc2af6b9541a28316cb3c17b9c91a9e8f4152773668b6758e049d0a32244aa5bf07d49f08c8ed17a99904f655b9062d2f559e8ce3db8d6eb97f3a18a7562888616ded46470f54429f73080b0692557861428b5b227a530bab5645982c1c6d2b7a815a4ae78085478cc47ac580c46ad22344160886da00bc208d6dc9d039287aa008e58096054b31c620d38e88ef0b7cf2b4e3553ce2264b7ee746b57106123416bf186e32a4c782cc520795470c818a0a8f56b9990c776b14fe10511b6b02f439bcdaef62056e43325e40a2a4256b9dc564ebc43ef8e4f98e07a55715b0781a3170eb9ad58a47b1648ef0a08ffd10c662475e3631161f5811e220dc112a8cf1ae911815b2ccc0280c5c1c19000b29efb48f90071690ce217c475731634686fd0d2c6d4a975a693c9ff902106d0df1932108b4763ce298021d87846db007382ca6769936d439a2e45f8d042a1cee85976d3b245fe65160039f6dc9d20e177870b5c163005981399625cce1adc0621626b9148ef0fee117d2a5f49245020fa7d06c49956fdaf1359d0d15f45753e8e1daa549de73b3bdfddd3707bb8747c76f87a7dfcef6f7a6c3c5dee1de7067865f64876bfde9fdad3b6f863bc7fb47af183a181e9f1e1e1c6ef77b383c7e743c7dc5fa5172fc603a4d5cf6591d0f8ff73b0998ddce6c6bacb3a484fd9d04eb7e672baeb304d7feced67c66095afd9d04987e672b06b3ad183c67d5047f3939fb0f0000ffff0300504b0304140006000800000021007949e1e6e2030000452100001b000000786c2f64726177696e67732f766d6c44726177696e67312e766d6cec9a5f6fa33810c0df4fbaef60b10f7d691a0c2424de1069d5d3beddad7477d23d56049ce0adc1117652ba9ffec6366d5389a05dd5f044943fd8630f9ef14f');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(10, 8, NULL, '33d8cea62939824f25c939f14e75456456d03295b39265b59062af669928c9b9e4deefbfb52d455f4bb1dfb38c12fbf3d6a7f9893eb4c928f7b6709f8d20b2488f94a7cfe2a4d099d046251ecd9932622d6779991edf49509eaa34f1b037372ae6ef746c3767ab523d1f296279e23d3452ee1fe08efc012c2c69a53c045d8e56e6c3eba1c47eb8d236a04c883a97ec074dbc002f7dffd67cdb0e30b2c00f3c744c559178e52db7c2da36e4f6a7a1edc86118aa168f147d17ac92ea9983ca92295adb612318a756840e759a331894f183784c3c33bc4c5415cd943622f16ab87a31f6c2ba57535b338d2912fbc1c243b6e3a72edbed586e8e4232c54445d29d14fca4e8676d7f99d60756cd38dd2b12afef1647f5b9ad52e248625d7e62b92a088ea23b532c283b148ae0c007d98f19ab72da106c949d99643bc6997a2605cb735adda03de33c135cd489f7690f2f8ab56fc141549522075bd393126f1e2cd25c3c215119af589b24ab0e9c7a305346cb8ea7d923e8d8c9ec545398eed653affe15e49d2f2b51d1b71950c0db4e34a8f54929c52c67dadde09859ca15d1c3b9d19821b4c9d9f9a5a1ee077276a88876d5cd763307a969b7999f49abd6961b72cff504ff01d4a26fbbefa0fd5f33ad7f09d5c282360df9539ce97f4c15f700aa3464c32d1bf20fb0d851fda5ca0a51db81a1e016f9b76871f18d7561336fc8653bd0f605ccf90a53b0fd9a72494d83971a6b6343fe164fdb8596e88b97ca7b20a4acb658d7b7d75a648aafc6e9d6da7a43f25538976ee0c42bdff27705cf600d3876b2194c6c02f263b1195d50199beb81d80c1db019bb613308a2bba0277486a109ac9d7486139d23d27919335743d21939a073e588ce65dc93d5b5ac13cc6802734430971761733d249826d57f30a5afdd8019faebde941ef936aa76e2b998f01c114f9bc96df4c4f0ec09ef81d2faf2e38133f41df1b9887bf90c75caef847339c139229c3691b770e221e18c1dc0090b60178bf5084757b37ae0e36b64c6139923926933794ba65db50f1436570ec884ad2e27642ef4ce50f7323df0fb72fa6a82734438db3cded2190e1937d70ee80c1dd1b90efa927a80e3eb6bf5f5c4e7987cda54def269f795068a9ed8ec9d7e6c5514466e005de29e9da4a87d22ed7ceac4fec4e7987c5e6ec36b30610d3f149f0e36e24347a744cb459bc2bb333c1ca25d0fa0783a27d2c74f63edc5639bd4db080a780e4868e020c53b3a2a8a713fa1d1aa87d0e9b46854422f8f8b30ec320d48e82f1d18cde1bf13dbff010000ffff0300504b030414000600080000002100b1dcf1ad480100006002000011000801646f6350726f70732f636f72652e786d6c20a2040128a00001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008c925f4bc33014c5df05bf43c97b9ba6635243dbe11f0682c38113c5b790dc6dc1260d49b4dbb737edb6daa10f3ee69e737ff7dc4b8ad94ed5d11758271b5d2292a42802cd1b21f5a6442fab799ca3c879a605ab1b0d25da8343b3eaf2a2e086f2c6c2d23606ac97e0a240d28e7253a2adf78662ecf81614734970e820ae1bab980f4fbbc186f10fb6019ca5e91556e099609ee10e189b81888e48c107a4f9b4750f101c430d0ab477982404ff783d58e5fe6ce895915349bf3761a763dc315bf08338b8774e0ec6b66d9376d2c708f9097e5b3c3ef7abc65277b7e280aa4270ca2d30dfd8ea266cbb8568f9f450e051b93b61cd9c5f846baf2588db7da5d6b55405fe2d045c9ffec00411853cf490fea4bc4eeeee577354652999c6e9754cf2559a5342683679efe69ef577f90e05759cfe7f624ea7d9887802547deef33f517d030000ffff0300504b0304140006000800000021006622820efb0100008e0b000010000000786c2f636f6d6d656e7473312e786d6cd456c18ed33010bd23f10f239fe0405d38ac5628c94ab05be85256885db8cf3a93c6526c077b5cb6fbf54c9a96030704a2918a14459ef168f2f2c6cf33c5c583eb604331d9e04bf572365740de84dafa75a9bedc2d5e9c2b488cbec62e782ad59692baa89e3e294c708e3c2790043e95aa65ee5f6b9d4c4b0ed32cf4e465a709d1218b19d73af591b04e2d11bb4ebf9acfcfb443eb555560e636c4745854d79f7347a9d0a3bf3a2c2460ffd5954dfcd380484da9de9c2918e39775a9e69295e94182a23c9fe4951e61835da9ce9516cf22781eed3b6c83c3c1a977715c5d79a60808d9db6f99607909f21740685a48863c461b668596d45ad2eaf12b7a0fec1750974706c52d0da805d500a9b13131787404986000328385109e3b313112f8c09072df87c854ff29e6ab49310bb4e3435e4c0af9de466ea146ded18ce3ead978b2c150d7c1772b010826270e6edcdf6fdb06869a991ca38805444260d3ae2e26f80d793b78c987bc6e9f1fa378ef2665e2f6f6e66da88f7adade4f0ad844aaad68c00451c3200af0d9dd8bba7f53be7dc4bf17f0af95b79c948b2d61ecb660e5761f2f8cd326e37a52321e6d0fd2e58e7a943f4c8a589a70e4ffe4165a4dcac45ea0a101275dbc9533dde3769c454e5ee21f2765065dc8d24f4e9e859b49595805f4c001beee06a55324e3302d8e63ecc14ad50f000000ffff0300504b0304140006000800000021003f9ac49e860100001a03000010000801646f6350726f70732f6170702e786d6c20a2040128a00001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009c92414fe3301085ef2bf11f22dfa94317a155e5b85a15500faca8d40267af33692c5c3bf20c51cbaf6792a8345d0e487b9b99f7f4f2653c6abedff9ac85842e86425c4d729141b0b174615b88a7cdfde52f912199501a1f0314e20028e6fae2875aa5d8402207987144c042d444cd4c4ab435ec0c4e580eac5431ed0c719bb6325695b3701beddb0e02c9699edf48d8138412cacbe633500c89b396fe37b48cb6e3c3e7cda16160ad7e378d77d610ffa5fee36c8a182bcaeef616bc92635131dd1aec5b7274d0b992e356adadf1b0e0605d198fa0e469a09660baa5ad8c4ba8554bb3162cc594a17be7b54d45f6d720743885684d7226106375b6a1e96bdf2025fd12d32bd600844ab26118f6e5d83baeddb59ef6062ece8d5dc000c2c239e2c691077cac5626d177c43dc3c03be0ac2d04068f67889fb0cbbb87d517f67e1d4cf1cf771f5c78c5a766136f0dc171afe743b5ae4d82929fe2a89f066ac92b4dbe0b59d4266ca13c7abe0add153c0fa7aeafae27f9cf9c1f783453f274d4fa030000ffff0300504b03041400060008000000210063d96af9ad010000f204000013000801646f6350726f70732f637573746f6d2e786d6c20a2040128a0000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000b494514fdb3010c7df27ed3b587e5e9c3450a05152349af2ca048517c483675fdb6c8e6dd9e7d20aedbbcf6dc946410869531e4ff7bfbb9fefce579eaf5b4556e07c637445072ca304b430b2d18b8adece2e93334a3c722db9321a2aba014fcfc79f3f95df9cb1e0b0014f620aed2bba44b4459a7ab184967b16dd3a7ae6c6b51ca3e916a999cf1b01b511a1058d699e6527a9081e4d9bd83fe9e83e5fb1c27f4d298dd8d2f9bbd9c646dc71f99c7c43e62d36b2a24ff57052d7c36c98e4d3d1241964838b6474343a4db2b32ccb2ff2c9e5e8ebf41725762bce29d1bc8d4f87b505812019ac41048c0d63129037ca33bf0440b695c56a2b2c947df4e8c6d3e70832ed2248bd8f28d3bfaa32edf8fe93f4a8237541818f402620b3dc452c8c133e4073608dc3e25e19aed9f5ce7828ae6e675f168e4b28ee7ff015678aeb05bb41179761e7ec85fab8a356467075d840d0bd941c7625bd00cd5d63de9de04d27e885e3a4e380b5504102fb1e3bfe930950ea705ae802f44270da1148f0c23576b7d5c2a8d0eab7ebfc42d30b4c3c35af7e9a031f543c1e1ffdafebbdee3daa747b0ef6c76afc1b0000ffff0300504b01022d001400060008000000210084fc57bfae010000970700001300000000000000000000000000000000005b436f6e74656e745f54797065735d2e786d6c504b01022d0014000600080000002100135ebe6505010000df0200000b00000000000000000000000000e70300005f72656c732f2e72656c73504b01022d00140006000800000021004aa9a661fa000000470300001a000000000000000000000000001d070000786c2f5f72656c732f776f726b626f6f6b2e786d6c2e72656c73504b01022d0014000600080000002100b4e4b6a8590100003f0200000f0000000000000000000000000057090000786c2f776f726b626f6f6b2e786d6c504b01022d0014000600080000002100cff7167b1a050000862200000d00000000000000000000000000dd0a0000786c2f7374796c65732e786d6c504b01022d0014000600080000002100fb62a56d94060000a71b0000130000000000000000000000000022100000786c2f7468656d652f7468656d65312e786d6c504b01022d00140006000800000021004bcce67ec0030000540e00001800000000000000000000000000e7160000786c2f776f726b7368656574732f7368656574322e786d6c504b01022d001400060008000000210042343a0be3000000460200002300000000000000000000000000dd1a0000786c2f776f726b7368656574732f5f72656c732f7368656574312e786d6c2e72656c7350');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(10, 9, NULL, '4b01022d00140006000800000021003d06b464bd0000002b0100002300000000000000000000000000011c0000786c2f776f726b7368656574732f5f72656c732f7368656574322e786d6c2e72656c73504b01022d001400060008000000210056c4669cc7000000ab0100002300000000000000000000000000ff1c0000786c2f64726177696e67732f5f72656c732f64726177696e67322e786d6c2e72656c73504b01022d000a0000000000000021000077278cb5140000b51400001300000000000000000000000000071e0000786c2f6d656469612f696d616765322e706e67504b01022d0014000600080000002100a33fddfb2f0a0000dc3700001800000000000000000000000000ed320000786c2f776f726b7368656574732f7368656574312e786d6c504b01022d000a0000000000000021004bd08478c5360000c53600001300000000000000000000000000523d0000786c2f6d656469612f696d616765312e706e67504b01022d001400060008000000210092ccdd862c020000c4060000180000000000000000000000000048740000786c2f64726177696e67732f64726177696e67322e786d6c504b01022d0014000600080000002100dde46a54f70100000b0400001800000000000000000000000000aa760000786c2f64726177696e67732f64726177696e67312e786d6c504b01022d001400060008000000210048a698f87f060000781100001400000000000000000000000000d7780000786c2f736861726564537472696e67732e786d6c504b01022d00140006000800000021007949e1e6e2030000452100001b00000000000000000000000000887f0000786c2f64726177696e67732f766d6c44726177696e67312e766d6c504b01022d0014000600080000002100b1dcf1ad48010000600200001100000000000000000000000000a3830000646f6350726f70732f636f72652e786d6c504b01022d00140006000800000021006622820efb0100008e0b0000100000000000000000000000000022860000786c2f636f6d6d656e7473312e786d6c504b01022d00140006000800000021003f9ac49e860100001a03000010000000000000000000000000004b880000646f6350726f70732f6170702e786d6c504b01022d001400060008000000210063d96af9ad010000f20400001300000000000000000000000000078b0000646f6350726f70732f637573746f6d2e786d6c504b050600000000150015008f050000ed8d00000000');     
INSERT INTO SYSTEM_LOB_STREAM VALUES(11, 0, NULL, '504b03041400060008000000210084fc57bfae01000097070000130008025b436f6e74656e745f54797065735d2e786d6c20a2040228a000020000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000c4554b4f023110be9bf81f36bd1ab6e8c118c3e2c1c75149c41f50db816dd83ed22908ffdee92e1024c84a96c4cb76b7edf798d9ce74f0b03455b68080dad9825de77d9681954e693b2dd8c7f8a577c7328cc22a51390b055b01b287e1e5c560bcf28019a12d16ac8cd1df738eb2042330771e2cad4c5c3022d26798722fe44c4c81dff4fbb75c3a1bc1c65e4c1c6c387882899857317b5ed274e3c4db29cb1e9b7d49aa60da247c9ae70711012adc8308ef2b2d45a4d8f8c2aa3d5fbdb5a79c90f51e2cb5c72b32fe8b425af9e96957e077dce228ee803137996809cac9b9a134e5847f0ae28b7e4932f6467f2b6805d94884f82a0ca5862f2bfee5c2ecd3b9597edc65bb1afa00426109104d95d7636e84b69bc41cd1af3723af87eb331b49f1d5c427fab8f9271f914a0178fdec9e8a9aa625708cab0af0ccd136a46dcaa508a0de63a0137a7603bbdc2d3e545324c8d72fddf3be266ad195cea43ac5ee7a3f6b6fc3db22bf1f76f713ff87b0a9398d82f348bd3cc0e9876ed37a13bae7890842d4b06dbe877acc56919aeee9827b2d15d24da3409daa2de7189de92cdfd01c10e7f5b53afc060000ffff0300504b030414000600080000002100135ebe6505010000df0200000b0008025f72656c732f2e72656c7320a2040228a000020000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ac92cf4ec3300cc6ef48bc4394fbea6e2084d0d25d26a4dd102a0f6012f78fdac6519241f7f60424049546bb03c7d89f3ffffc29dbdd38f4e28d7c68d92ab9ce7229c86a36adad957c291f57f7528488d660cf96943c5190bbe2fa6afb4c3dc634149ad605915c6c50b289d13d0004ddd08021634736752af603c6f4f43538d41dd6049b3cbf03ffdb4316134f71304afa83b991a23cb9b479d99babaad5b4677d1cc8c6332b80c648d69059399fd87c6cd335a2445f5354d2b07e4ae500e85c96b0259c27da5c4ef4f7b5305044831141b3a7799e4fc51cd0fa72a0e588a68a9f74c61eded977afccdd1ccbed7fb2e863883c2c84f3a5f94682c9b72c3e000000ffff0300504b0304140006000800000021004aa9a661fa000000470300001a000801786c2f5f72656c732f776f726b626f6f6b2e786d6c2e72656c7320a2040128a0000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000bc92cd6ac4300c84ef85be83d1bd7192fe50ca3a7b2985bdb6db0730b112874d6c63a93f79fb9a94ee36b0a497d0a32434f331cc66fb39f4e21d2375de2928b21c04bada9bceb50a5ef74f57f72088b533baf70e158c48b0ad2e2f36cfd86b4e4f64bb4022a938526099c38394545b1c34653ea04b97c6c741731a632b83ae0fba4559e6f99d8cbf35a09a698a9d511077e61ac47e0cc9f96f6ddf345d8d8fbe7e1bd0f1190bc9890b93a08e2db28269fc5e16590205799ea15c93e1c3c70359443e711c5724a74bb90453fc33cc6232b76bc290d511cd0bc7543e3aa5335b2f2573b32a0c8f7deafab12b34cd3ff67256ffea0b0000ffff0300504b030414000600080000002100b4e4b6a8590100003f0200000f000000786c2f776f726b626f6f6b2e786d6c8c91cb4ec3301045f748fc83e53d8d933e80aa492544512b21844469d7269e34561d3bb21dd2fe3de3442d61c7ca9e87cfccbd5e2c4f9522df609d343aa5f18851023a3742ea434a3fb72f770f9438cfb5e0ca6848e9191c5d66b7378bd6d8e39731478200ed525a7a5fcfa3c8e52554dc8d4c0d1a2b85b115f718da43e46a0b5cb812c0572a4a189b4515979af684b9fd0fc31485cce1d9e44d05daf7100b8a7b5cdf95b276345b1452c1ae5744785dbff10af73e294a14777e25a40791d22986a6853f09dbd44f8d54587d1cb3318db2abc8774b0414bc517e8bf22e74f42b9924c92c74062b76125af7fb2884e4b4975a9836a5b3315a7bbe46312ed076a5bd14be4c691233861d7d6e0df2507adc72723f0df46880ef0cc431dd4974a7ee2307cdad340e3f2bf8bb410d3125762ef16237220e90e183f5eaf57dd09b0c7a936ee0654ace558eeac311a0ac2b5efe3efb010000ffff0300504b030414000600080000002100cff7167b1a050000862200000d000000786c2f7374796c65732e786d6cd45adf6fe238107e3fe9fe8728ef3484022d2861b5b4cb69a5bdd54ae5a47b358903561d3b724c17f6b4fffb8ded84841f81b02da1fbd226c6f9e69bf1cc783c89f7611553eb058b9470e6dbee4ddbb6300b7848d8dcb7ff994e5af7b6954ac4424439c3bebdc6a9fd61f4e71f5e2ad7143f2d30961640b0d4b717522643c74983058e517ac313cce097888b1849b81573274d044661aa1e8aa9d369b7fb4e8c08b30dc2300eea80c4483c2f9356c0e30449322394c8b5c6b2ad38187e9e332ed08c02d595db45418ead6ff6e06312089ef248de009cc3a38804789fe5c019388034f222ce646a057cc924d80a2ca35187cf8c7f6713f51b8c66d3465efac37a4114465cdb197901a75c588485788543dfbe57630cc5d8cc794094cc045183118a095d9be18e1ad0f6cce6c504b453838ea2620815927640a768c1635439db6dab9f8ef3fa2808a27b0833c52ad7ee10ca403d526877182547d0ac77689c057050915a082715d9b1e86145ca288794a90572cc1acd021c34672d0ae4945f746eeb38c6f2148cabe3a2ae7f750e79687f076222107ba684597f71b9208135e6fc59713d18676e5ffdb4e3b2af43ecbe15e26ccf7875ed64d6bd7ab636450a398750ba49820395ee6060e441329658b009dc58d9f5749d401a66b06f1853ea792766cf055abb9d5efd0734fcc89bcd1fb6336c5f9bd429d152ab598742ca2909955ebb90c67d9b90d4d37b4613923a3a109a90d4d78bda84249dfbdf74e535e239d4b5a741b0ccb808a1b8ca6b863b702b3334f2288e2404ab20f385fa2f79027f675c4aa844465e48d09c3344e1d2c99fc8ffbfee4928e7a072f36dc8730ce8eca63113364ac416b75a4f810e67a8500b728fc839467aa5845a8f9b153bbd60b5c04adad69aaf9d47fb4eade9a5f5a935bfae6eb02687dcf8d53232cf87380a30a54fca6fff8d36c1a44aed5564b1653c89e56728aae1eca2cae2fc12727d766902c7dca8802aa319ec12ec6def9770ad55b41150c5aa030433567059b072e124913d6da124a1ebafcb7886c5441f9dd499c28caa2346e90e908abbb14e34ea1e14ac927f5bc887cb423e90b9aa7c20d388fc6e85fe30de88fc5e85fca6ec5f25bf29fbdf15fa83c90bff035e8dd81f4eec79fc6dc96f4aff2af94df9dfa042ff6bdbbfa9fc5765ff7e43fe07ada08d035e65038093f37509a82d3adb012119141900c6b733c024dbdd8eec662e846d0e062b5b8035e54e70626e8080d9fb3f523267313605c0c8837ea1b9b5be0b944cf14a1706aab65945d5fb7f33848f2d1964baab2e5923fe7fa115bb4ec628f9f8e508bca1c54a2b7cb9a47082ef820bf2038a75d5fe57473a5b37fe4dec9e8a51d88b2e1f2117e4ef968acccb2dc0b11cf31e3c76df03ca79fa0c7728a7ecabc5dfbe36ea45d6d9febc5573bf69cd79c29fe1fda624818a46e880e8d6f2de2ed955b571d63c80fefe2606816651585c9ab351e39be01207d2bc90dd3bce6f112d1da87e1ba260dcf76551571525f9d2972cfaee88aac47636cf7a4da3030174ae3396d2ee7bb09c6ef2415bafd43bdcea1c6e7a80967ae5e5db5f55b38d968e21b325a192b04d53afe81a0266b82afa90fafda254df1ce80ee5460a1824c4115a5239ddfce8dbc5f5df3824cb18927a36eb1b79e15243f87671fd45bd1f306f1ca1caff92425b1efe5b4b417cfbbf4fe3bbc1e3a749a775df1edfb7bab7b8d71af4c68fad5ef761fcf83819b43bed879fa093fa4063081f2bbce20308fda1061c2ddcee30a5f09984');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(11, 1, NULL, 'c894cdc83f1563be5dba31f475ce05da703ec99570d2cd0724a3ff010000ffff0300504b030414000600080000002100fb62a56d94060000a71b000013000000786c2f7468656d652f7468656d65312e786d6cec594f6fdb3614bf0fd87720746f6d27b61b07758ad8b19bad4d1bc46e871e6999965853a240d2497d1bdae38001c3ba619701bbed306c2bd002bb749f265b87ad03fa15f6484ab218cb4bd2061bd6d58744227f7cffdfe32375f5da8388a1432224e571dbab5dae7a88c43e1fd338687b7786fd4b1b1e920ac763cc784cdade9c48efdad6fbef5dc59b2a241141b03e969bb8ed854a259b958af46118cbcb3c2131cc4db888b082571154c6021f01dd8855d6aad56625c234f6508c23207b7b32a13e41434dd2dbca88f718bcc64aea019f8981264d9c15063b9ed63442ce659709748859db033e637e34240f948718960a26da5ed5fcbccad6d50ade4c1731b5626d615ddffcd275e982f174cdf014c128675aebd75b577672fa06c0d432aed7eb757bb59c9e0160df074dad2c459af5fe46ad93d12c80ece332ed6eb551adbbf802fdf525995b9d4ea7d14a65b1440dc83ed697f01bd5667d7bcdc11b90c53796f0f5ce76b7db74f00664f1cd257cff4aab5977f10614321a4f97d0daa1fd7e4a3d874c38db2d856f007ca39ac2172888863cba348b098fd5aa588bf07d2efa00d04086158d919a2764827d88e22e8e468262cd006f125c98b143be5c1ad2bc90f4054d54dbfb30c190110b7aaf9e7fffeaf953f4eaf993e387cf8e1ffe74fce8d1f1c31f2d2d67e12e8e83e2c297df7ef6e7d71fa33f9e7ef3f2f117e57859c4fffac327bffcfc793910326821d18b2f9ffcf6ecc98baf3efdfdbbc725f06d814745f8904644a25be4081df0087433867125272371be15c3105367050e817609e99e0a1de0ad396665b80e718d775740f128035e9fdd77641d8462a66809e71b61e400f738671d2e4a0d7043f32a5878388b8372e66256c41d607c58c6bb8b63c7b5bd590255330b4ac7f6dd903862ee331c2b1c909828a4e7f8949012edee51ead8758ffa824b3e51e81e451d4c4b4d32a4232790168b7669047e9997e90cae766cb3771775382bd37a871cba484808cc4a841f12e698f13a9e291c95911ce288150d7e13abb04cc8c15cf8455c4f2af074401847bd3191b26ccd6d01fa169c7e0343bd2a75fb1e9b472e52283a2da37913735e44eef06937c45152861dd0382c623f905308518cf6b92a83ef713743f43bf801c72bdd7d9712c7dda717823b3470445a04889e9989125f5e27dc89dfc19c4d303155064aba53a9231aff5dd96614eab6e5f0ae6cb7bd6dd8c4ca9267f744b15e85fb0f96e81d3c8bf70964c5f216f5ae42bfabd0de5b5fa157e5f2c5d7e54529862aad1b12db6b9bce3b5ad9784f2863033567e4a634bdb7840d68dc8741bdce1c3a497e104b4278d4990c0c1c5c20b0598304571f51150e429c40df5ef3349140a6a40389122ee1bc68864b696b3cf4feca9e361bfa1c622b87c46a8f8fedf0ba1ece8e1b3919235560ceb419a3754de0acccd6afa44441b7d76156d3429d995bcd88668aa2c32d57599bd89ccbc1e4b96a30985b133a1b04fd1058b909c77ecd1ace3b9891b1b6bbf551e616e3858b74910cf198a43ed27a2ffba8669c94c5ca92225a0f1b0cfaec788ad50adc5a9aec1b703b8b938aecea2bd865de7b132f6511bcf012503b998e2c2e26278bd151db6b35d61a1ef271d2f626705486c72801af4bdd4c6216c07d93af840dfb5393d964f9c29bad4c3137096a70fb61edbea4b053071221d50e96a10d0d339586008b35272bff5a03cc7a510a9454a3b349b1be01c1f0af490176745d4b2613e2aba2b30b23da76f6352da57ca6881884e3233462337180c1fd3a54419f319570e3612a827e81eb396d6d33e516e734e98a97620667c7314b429c965b9da259265bb82948b90ce6ad201ee8562abb51eefcaa9894bf20558a61fc3f5345ef277005b13ed61ef0e1765860a433a5ed71a1420e552809a9df17d03898da01d10257bc300d410577d4e6bf2087fabfcd394bc3a4359c24d5010d90a0b01fa95010b20f65c944df29c46ae9de6549b2949089a882b832b1628fc82161435d039b7a6ff75008a16eaa495a060cee64fcb9ef69068d02dde414f3cda964f9de6b73e09fee7c6c3283526e1d360d4d66ff5cc4bc3d58ecaa76bd599eedbd4545f4c4a2cdaa675901cc0a5b412b4dfbd714e19c5badad584b1aaf3532e1c08bcb1ac360de1025709184f41fd8ffa8f099fde0a137d4213f80da8ae0fb8526066103517dc9361e4817483b3882c6c90eda60d2a4ac69d3d6495b2ddbac2fb8d3cdf99e30b696ec2cfe3ea7b1f3e6cc65e7e4e2451a3bb5b0636b3bb6d2d4e0d993290a4393ec20631c63be94153f66f1d17d70f40e7c369831254d30c1a72a81a1871e983c80e4b71ccdd2adbf000000ffff0300504b0304140006000800000021004bcce67ec0030000540e000018000000786c2f776f726b7368656574732f7368656574322e786d6c94574d6fa33010bdafb4ff01712f848fa44d1452b5aaaacd61a5d56abb7b76c009a88091ed34cdbfdf1903c1109c269706eaf17b7ecf3363b37cfc2c72eb837291b132b23d67625bb48c599295bbc87efbf37af7605b42923221392b69641fa9b01f57dfbf2d0f8cbf8b945269014229223b95b25ab8ae88535a10e1b08a9630b265bc20125ef9ce1515a72451938adcf52793995b90acb46b8405bf06836db7594c5f58bc2f68296b104e732261fd22cd2ad1a215f1357005e1effbea2e664505109b2ccfe45181da56112fd6bb9271b2c941f7a71792b8c5562f67f045167326d8563a00e7d60b3dd73c77e72e20ad9649060ad0768bd36d643ff98bf5db7462bbaba572e86f460f427bb6d0f00d63ef38b04e225b85ba67b1afcaf05fdc4ae896ec73f99b1d7ed06c974ad8dd2908401d8be4f842450c06028ce34f91346639d0c15fabc83013c000f2a97e0f5922d3c80e1d2f9ccc2018f2e18896205cbc179215ffea08afc1a911fc06017e1b04cf9f39fec3d49bde8012b42853606b702047b525a4599250b56250e1d632942b2f4492d592b383059905ab1015c13cf516f08c76f8f7a3768453d89c18e73c4120c40978ff584d96ee07e23763cf080860332d24f04f312ed09eb8c33ef7f816b49c106ce44420e084759f4282609c13d675a617dc3766404bafeb194a46cc217d384e8f5d43b3fbb264083ee91972221070ea21c1749cd3c3bcd048d51e431e8f9007dd1ee32c23bb8204fab91613cc0cf46329768de5dea534c34130c0d75719dc1b567053a27997320d079116ec1b31a797dd3e94e899edd7e8c68923e0aaf49e152a2c40f7267818d7ad7a92b6f1231b0e216d8663b4991606cff26d6ea0853ad4857f41ab57ed30cbb115a1ddba236117d4f7fba6daf2f5cae9101b93ebeaead176317d5628811bc4ea05d32136ac083514eb8d7b1c0c6afab2c7186ddc5a0535a0ed96d6131b40da5f2f16a3cdac0835600d0de74430e8205f88d54ba313527baca006b45d4c5feca07ebf60d553b4436c58116ac01a1a0ea8e0a66685d1668f9b66351ed3178bf5adb50a752d9a3be3c7a2764ac0e305feba69f41a4b683818839b9a06469b65374d434fbfd070360683f25567e3354d1a279a57d054b27e69080dc76378534d61b4915641419a8dc7f4f63b1c344bd48d922e2739ce32b3374db327da7022c37dbe976e976931da48aba040b49e11e1f040ac3f07ea8b6f4576f427e1bbac14564eb7003c716032afbf05d4b36495fa2fe4ef8649b8c8b76f297ca751b8014f1ca8e82d63b27d812b76c2c901be0e2dbec892c8e6eb445dfbddd3f7e0ea3f000000ffff0300504b03041400060008000000210042343a0be30000004602000023000000786c2f776f726b7368656574732f5f72656c732f7368656574312e786d6c2e72656c73ac91cb6ac3301045f785fe83987d243b81524ae46c4221db927ec0208d1fc47aa051f3f8fbaa34a435b874939d34179d7b18ad3767378a23251e82d750cb0a047913ece03b0deffbd7c53308cee82d8ec193860b316c9ac787f51b8d98cb23ee87c8a2503c6be8738e2f4ab1e9c921cb10c997a40dc9612ed7d4a988e6801da965553da9f49b01cd8429765643dad91588fd2596e6ffd9a16d0743db603e1cf93c53a14c705f111726a68eb206296fc35a165750f31acb7b6a1cddb84d782a3b9e88d8ef19ab9fbc96e5fc97537d4fa76bf9bcd035bc6d484d7ebff9040000ffff0300504b0304140006000800000021003d06b464bd0000002b01000023000000786c2f776f726b7368656574732f5f72656c732f7368656574322e786d6c2e72656c73848fcd0ac2301084ef82ef10f66e527b1091a6bd88e055ea032cc9f607db2464e3dfdb9b8ba02078dbd965bf99a99ac73c891b451ebdd3b096050872c6dbd1f51aceed61b505c1099dc5c93bd2f02486a65e2eaa134d98f2130f636091298e350c29859d526c069a91a50fe4f2a5f371c69465ec554073c19e5459141b153f19507f31c5d16a8847bb06d13e4376fecff65d371ada7b739dc9a51f16ca46bce7661989b1a7a441caf78edf432973645075a5be2ad62f000000ffff0300504b03041400060008000000210056c4669cc7000000ab01000023000000786c2f64726177696e67732f5f72656c732f64726177696e67322e786d6c2e72656c73bc90c14a04310c86ef82ef5072b7999983886c672fb2b057591f20b4994e719a96b62beedb5b10c185056f1e93f07fff4776fbcfb8a90f2e35243130ea01148b4d2e8837f0763a3c3c81aa8dc4d196840d5cb8c27ebebfdbbdf246ad87ea1a72559d22d5c0da5a7e46ac76e54855a7ccd22f4b2a915a1f8bc74cf69d3ce3340c8f587e3360be62aaa333508e6e0275bae4defc373b2d4bb0fc92ec39b2b41b151862efee402a9e9b01ad31b20bf4bd9f74160f785b63fc378df14703af5e3c7f010000ffff0300504b03040a0000000000000021000077278cb5140000b514000013000000786c2f6d656469612f696d616765322e706e6789504e470d0a1a0a0000000d49484452000001280000007b080200000048088aa30000002b744558744372656174696f6e2054696d650057656420332044656320323030382031353a34363a3136202b3031303069fd92ff0000000774494d4507d80c030e2f0cf4c82f41000000097048597300000ec300000ec301c76fa8640000000467414d410000b18f0bfc61050000140d4944415478daed9dfd6b1b499ac79f0efe030626c7782761d3c2c3c57b1826c126e3908148383f4871200c18ecfdc173071299f5e5c23020453066608e90058d0443980bda0912ecae614938c3dd40bcd20f315260433c212613ceec3a90a0f6e2cdfab809f327e8eaaddfa496d4adb76ab59f0f4e6895aa5af574d7d3f554777dab957abd0ede79befbfafdc977bb28e85b8264d1a8db32eaf57763e011d9754090c3083a1e8248001d0f4124808e87201240c7431009a0e3218804c69eefbeeea2d8a95f1c935d7304196194ee9ee3298a527f2abbee08329a2833186a22880cd0f11044027d76bcd40c28d740eba2e401c448d95bb28f07820c857e381ef119741804f142cf8e47bcee1294659b8120a3c5588fe58b3799d7ad81b20615fd3ee7ca8c70c5e4b7909d1689240acdf1ad65a87f');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(11, 2, NULL, 'da7a87d720f1986e14ee437cbc3111ce42ed1b504177f86548aed1dd56ee43c6faf129849d4af114feadf61d846e40f40b285dd6aba76773a8aafde74e9dfaa71f7ef8b3ec73d71f4efd233cfb83ec4a1c3e7a75bcf82aacb316c91be806f9f71816ee43699cb5f24f609eb572b359b316ac400bdf5b03b80ff5719a3f71092658d9ea2dea2ddc0f497ae89aee7b2c3fd97f16a86364ac1f5b949abb40abb7b10de169d0349aadfc00b4cba06e53778a5ed0bdae5555d7844312afabd7f7649fbbfea028276457e1303280bb9a67618ef55413efd1ff5f1d00589a358c437a99b6e0aa63d965d1cbcd2feb658947add9d31fc3e681f95baafda7c5c716a5d40f200ab0b34f1337d620c9d235d2fbb194850f3a57b5f614f00126d23bbdf6786ee0cdba7c03941b662271aaf078cb22aa4affdffd1b009b2113559dd3e13dbbe3d93f3a949a8685b39020bddc07b00390fe94fa15a9c9ab07e27aa17def5cd5c825b6b56cffb9a0a0ccd0fff182324c86e178ea71fabf319a72038f0327f5796965cd39bd3d8ea568b4790336bf87f259c893c4b3b0fe3d4c3da6d553c9d74e5525edb27e1fef2121fda4e750731ca63ae69986241f4db14fed9ef5ad41918591240e1421ab1eef35a677aa55ab523cda4cdc10dd23f143d2bfe5789ce958d5191a5e22487fe9438f474650397657b370bf659e2c69bb331062218d7967b219e22d3741e1773557459ef0a7507849efb524da97b5d3b2d4388d36cb8f21f921fdc47b63c32d69e766ad2a1bd4b9f93904f1044e92b6dba58f768407b6ce16bcbb9a813ca1fe042749db5066cc0d6c85c84041c71b0831e58462fe7d5cd49c32697763b1bb9ab71d2301618c048ddd9534fa8740d2ab75d14cadb4a4cab662a826235e18fbf2cb2fbb28464a8d7c30666f678e979f56367a6ea3a4735b8185a97482cd7c4956f6b2e1fde24aba5c8690928e161e95e6fe140ba5d9e38af385daefe360e4bf52a9af8687723c649ed0a67331f2adab93818738d46c716aeb4fcdbfee29a74346a8c9e3c9727a777eaf5edfab57aee43224e5783c9f89928eb1be578aefa742afd275f66dede2fa8a35ff90bc4e3201733317061e62c783c6c3d1abb359611e55e77f3ce68c66ae86d957ea44b421b3a6edc09d08f752d2ef955f69d6fc878443e67b87dbf1c037e7dbeaa887a4976bc627e762280606caf19499c63faf8763d8f0ce4d55a7cae9db5579d5f00f87c6f7fae078da77a29517d946f1c075c90148d7eb16c0fd5d10ebf9def6688523d6315eabc709ea523a4923cc58f178b696d989d8c784b2295e6307819c2336bf2fd5dd8a1e5dd05fdfd3ebdf7d86c1183876e11d78f0bf00ef5cf8b75f1ddd7d74f4dcb9b749ea9b47bff90f9aea8acd07a66034ee7a1a347011ed7bc3b47878949ae6b5c4c3fa96ba542a89cd7076afcee583b054aa2fd9f650025f300ea56f68ebdc915d91c11a38748e9cfbd5d2fb62fbe424fce7bf13fefbc5dbe722efbb2b2f54de6b6cdeb3a5af48cdd0de2cc67ac2aaa557247fa9eda682c6eed81e52b7f4ccfa57d58614b63292355bf156cbce8da4c7beebf2e8549b6ac20d0930c2e46bb0cb3fb30e217593ce6e0dd97b067206f9c1310fef8138e3fca483e5bc8b3c7c6fd79a5ac5ad96953177be2db235976a4cb1ff0a61d3693f669d895d2cf84a3554c68d39b7c47120addad80017a61d790147ffe11dbefd66f77f582f77f0e31bd7e729fe0d14ceb21eaf69ee72f925e4d97dc2f001acb04516c876651972bfa5e7af4dc11cbfc1f82d55a9dedea6472af29229508d144b36ca6348acb5ab24d5d775e12dcdbfab1b12486863324c5e859dc7e6575757216a9f9e4e1ad6fa05711f78ea867eb5bd44171f2029b52f20724b1cae8a3d0f399293ab7aab782084c535d5f9e2185ea41aae2adb2efe96cd6b6f2e6549491aaa65e357d8a7b9e6fd34c3962fb0eec49539a4e1add21692fb44dff89353259b18fbf1cddb47c76956801fffcf6d74e90aa1e306210848307569f2db760bae70c4713906e2b6fb34d48fd16b4fd9311b1bd739eec79aae10bccec06cfe5ddd904052d6e805d150df134bdba07e007089c98597f5a34ac2d1b370956baf2e033df4db744d101e32cf2fc306972feb4210ed7bd68b1a17c465a79f61d5a04b751c837580fc3475f8c65297a1b46a9ea6c903e66c0ddab1a6fd38a02f5f307996a9b4c19b395163e325545d9876e4e8db6f7eecf146820b48ff46af25402f0c46c7ed12da6bf36bcf7d887a29d8238ebfcb0d09241d2f8836c8d0e8293b326b667ce5151e0489bf16bf1eff17da87d09501f4eb7863a96d7a9ad24f45036b45f37e064a47d38e9cec7747e7008b9549879be5611b5f4cc5355c3f3ec1d66518a606dce1777543fab177dfcd902676a9c77511f001ac3f6e97995e956e09f72391185dc6669c0af9c57238db6c547c8cba6595256cac35ae1b40fb4c3dfcb38de51a98a6b11f89dcd2975b975a66bddcb6be369c8bfd74c6a3395e4d1b7bf49bbbcf7b3d659d6dc87f41d7d2e30b99908b41dc580d895c2f5f76d0b692409f181c99a1c737c9972a1acaab8a1c7e775a181248f86a17b57d16239d85a435d464add0babe1b89be0ad7f491331bfe11b26c818c044bab3001313d5c2c0f1962c4c588c6dca7f12d8d575bfbc355924d13319e63a9e4275487cd4f93b91e4ffbfdb8c09b39565c98a68cfa24e986bb260de3ba86cc1db4adae2dea8310964d9bcefb40c1e043216cc3b9285ea3f72de21dd7fbe844bff6d31703477ee68a7f9a8b959872b32a36b7526c5b2b7eecf03cdd1a701adb64a3c593f7e69d98293e0b5cfb037bbc9478af676fe9d77efac7c83b1e400731417fd4061e4927ef6c54d9567533979c0b93d82cfe7b3115b37232717bab75d12d07a5824ee34eb4bb2b8993159652997aa541e0986e77df45c27efa47977a3c181ddda4fb7af6d1a2f0fc95c8c656363c5bdd7851b8ba4a93483f26147764983ba1b52ac9940a39e58efef90ac9a99adfda77a2aa53908e2840357bd9d5a11da821e0abca0c82b16ab5da45b17038dcdd2a490345613424baac275dbec9b5459d65fbe17f2e647e5705d8d8b97855e50ef3c785da5e4915a3bb76b452af3bec64365bdfcbd268f644047a95ccfae7847a3a17a308313008a1a6819fced6f1b985171ba9cd9d850f559e10bd38c7b6b4cd3fda1e8a94458828d2db2b151a76a2dd4d15f799fb3d2a445f0431d60c2c81723cb0ab130c8d8214d4b98b3b3948c7d9c29dea527a4ae81556764f9ad300d4a57ce145c4963edb52a9d0bc135585c43996f3dcfac2afe3aa2c5b11cff4cff1b4624c4955bbfbd677d0ea9a74577175a96489fda81081dd052965574b2492a41a051a4f1af74b44ba286857afb7da090b35450af7705f601ebd98e506ae9e683d9a8e897eaab5876a7b33d0c9f10e36ae87f3cf641f07895453a1c45445ef326b859d881f1ac6a8408f1e146aecc84162853762e3905692b9887e301d1325d69a9f735aeb90a88dfb6a7b353068a1663fa86ee4a20573c113359e2f4473e2e900d20976f4f22cec55e3a57a896d9987347cd538988e8992d05eed40729ed685d43a9d841d3660765f6dcf061e61fd9b807573cff24bd92770efb3f0f50d3e23c6cca0a77436c3b1d7a657005bbfcbe2cfa29e37e6acd31e3eea64b49cb0dedfa00d281bb65458760d7d0c6dc153136aeb4475628a376bc74459a8730b8667507f59a037b1dc57dbbb8147889b85beae52eea66a9f11d73bbd7237750616bfae7e354f1ff3133f7c78fe2ecbf07528bbc47cf360a3ad119648ad3265f4da00b9c8c67cbdb1dfcdad439e27da1bbb44889fd12ab618e0d10acbaea18fd176cbd149f0d1d0cd25e4a4d72633acd299c95a69e037aa8edc3b93fae834db1c9fffaaba72bae1fb675bf7ce9c9fe6136d4e7f943a736feb191c6c3f6cb74b4baf0de1f9a4e9e87afc467a143337bfb634244a279c15033cdd03cd16a4571869453991d12fa6b9886fe2980e90602cb4bec046a60beba1c15f315c8cf19e649744a84963d0ceb06b9e2a3ed0b06d57e3db4d1148cb44ffc03cb04602f48cde80dc55d8abeac77f2aa1eed187786c64639c7d7fc37a8bb41899a693838f7b5d38de99148f3439b63ed1f12181d5d7ec5e381ad081a8dd283a00189106241ddbd937122d231c63e4e398e82bdc57dbbb8147169f64ff8b3f3aa037518cdb27b5d77ce3f4ece29387db22f1599e65189f3e6fa99918926a9bebc2c52c89749ceac303da1e76072a627b02b5928082a7759dd97b11e8c3ee5871bf496d406778d174e0420492b86fcb3fd2d0fe420f0faab713653ee820430e318437d39c1365559bde5ce1d5d68a19bdd1baafb67703abf4568a6091df65d19316bfb67eb266a0fb320641fa9749e3c9178dcd4462943dd0e1297a0663db315112609ff552b1ae22a01b61549265de6bf75713ef45a8d7ef25e92c4a7b22d9a0898f0ad1f3855a43fe61ff1956f6ef589aa7df72468d236a3dcb8e89f5be56a68b5a1be7db53b5bd19a8046992742f789d24dd41086be85cad7a028a98caac153f0e251ed2f704f11927f274b1a610d63727f4304c92eec33bd0910e38a90dd48993000fbbda1d120470e6cac068f75e84ad54042af57b5389cfcda1a42e536003bf9b5557bf818c2a632468ecae64d7af92f52dfdb488be17e14444b94383c95a26163a21764d7b3ff5b6b20895bd3089d82b9b4ae8e604093eadf9e746dffc6055662006e2184f1c88fe8ef146071ce3493110434d0491003a1e82480085b02dabdbab10f6f08242d8ce06628fe7000a617b0185b02884ed0e1f0b6147602e350a61dd0961af5fcfe7afeb22d806cdab6d0d08fd03cbd3c98cc32e848d99ef61267f87e9a11c0a615d0a61e1c93df825571d3c3345b15cf33a3e7d9e09f028548497fae8b4d0c5b6350285b0ec799d391fb2a7e52e470c14c2ba83849a677efe33b679f0ba068bb35cf5737a76910a144ccfa37e777e7adcaa8b6d050a619d0f8ba151601d200b1a8b29f6916edf4cc5e8b7a9ea7e516cb478b302ffe4e79728a010d605c4f142ef7247fafb5f9fe83e08f0b39f9f79f2d7bf5305d019aa10127e47bf61bad876bb44212ca12c16c0d43d6d2b154a4f556807582bbc88a4b6789edd79bd3f2cbf98ccefd52b577291cf816f64daf98faf5fa280425817586eae085fe3e85e383effcbd0c3ed67a6df715dac5e5d14c2b6a021d4d4b49d6846f4f77317a3b9cd2acb63dec1e14b44ab135163a3fdfe8dfe3372077634f612853b11d69786b352235b14c2ba14c29a9be3ef86401fd1919052ef094fcf86b29f6585dfd974b128849584fe120521e4a3497c65dbb90de9f7725008ebce40ab2c88ae2f765dc491a45ffb4a2cf240c77b303b3faee7794df2e845c2d94a528928ec15b8c94a5d4418d95a2116e2b35ca3855a49e601edea24c44bf50912f22b0991408de86db44d350a8bb7ab4bd9307bed41f25f4ba065dc1464920555bc2ce1a2996e7b89c245fa1285cd0fb371fa1285c9d8e7a44cb8a7eaf60439fdaf62e2e09136111689464331d29c1325411f1aad8778b5c9f9ce7aadb657037192b47e20fa3a493a16bbdba86a3515b14c0b6b55be5a55b3f60d607a5992259abc023b13f93cacb0742d7522c2ae76229d291ef81bc04d71ad5b5b7092b40403d1f1cc6381ea04d97531aa147cc7c3992b08228180cb0d0747f07a3c64988c75d7');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(11, 3, NULL, 'a73fdf7dfdfee4bbb22bdf4f3c5914487db47fa2bbe0b5ae660331d4441009a0e3218804d0f14690111007211d40c7431009a0e30d8446f580558b00d0f43605a398914d17284093ac0102f4a285430c3ade4068540f80558bb0950abd4a8bb7295c5c5fb1078d229b21506896351c8fe7c58b163ccd50417c053ade6068500f80458ba0693b5449c0be0d91becb2e4031b2718182a3ac01197dd0f10642937ac0cea1d5a7233ae87883c1a61eb0e3fc36851658323359c35c98a79765ab5d91de40c71b08e929a1405fd93dd9d4e3cd666b999dc809772b35989943899395ec2c4da32f5aa0c12ade5c195dba9c061ebc493d5ea78c056fae264e191ba681d8e3218804d0f1104402e878082201743c049180f2c35ffe26bb0ea3c7a95f1c0bdecd156c09c304ef6a7663912fee6a5a974bea01bcab29c5400c35114402e87803c1f62683e65720585e9660794d823d05dabe6ea141a3d04aee80f81574bc81d0f94d06fc65095c8510617ed598d2fe750b568dc27e3bb903e24bd0f10642e73719e89339213c978417d43b1b52aa9d5eb760d05eee80f81274bc8130ec3719a0dc61d440c71b08293a7d99bec9a01065bd99de0b398815aa9b39a3afb3a6845be812acf0dd7a923b20fe001d6f3024ceb15b1de7d6177e1d0f2fe5c920ad41ac60bc402f0215fe48a031c5499760c5d4281cf72277407c013ec7ebc6a25e9fe3353f82ebd343b92ec0e778520cc41e0f412430d6fb2e10cfa84ba552a71424d0608f87201240c7431009a0e30d185c6e1d71021d0f4124808e872012187bbefbbabb925d17f42dfdb4884498a1b498a412cdc8b66ce8e607ab328360acbb2795c17bc4d95f8bb8b0a014164fc64702ff9cd0e0b5ae6603f139de40c81af35af0011de2048ef1104402e878082201743c0491003a1e8248006fae74c35b6fbd65a86910a40bd0f1bae1a79f7ee21b8aa2c8ae0b329260a8892012c01eaf27fca3dab612f807d001007b3c0491003a1e8248001d0f4124f0ff5426dc331dfd721c0000000049454e44ae426082504b030414000600080000002100a33fddfb2f0a0000dc37000018000000786c2f776f726b7368656574732f7368656574312e786d6cac9b5b73ea381280dfb76aff83d72ff33480cd3554c8d40eb9104838537b7d76c0095400b3b6939cfcfb69592de356b765a8daa93a03419fbbdbfa24d928f1f56f3ff73bef334eb36d7298f841abe37bf16195acb787b789ffef7fddff3af2bd2c8f0eeb68971ce289ff1d67fe6f377ffdcbf55792be679b38ce3d8870c826fe26cf8fe3763b5b6de27d94b592637c8096d724dd4739fc98beb5b3631a47ebe2a0fdae1d763a83f63eda1e7c1d619c9e1323797dddaee2db64f5b18f0fb90e92c6bb2887fab3cdf69899683fd767c55ba7d1179caba9a752e2ad6e29e3053d56df7ebb4a932c79cd5bab64dfd6a5f1b3bc6a5f91f3dcaf5820a1b3f651fafe71fc15021fe1e45eb6bb6dfe5d9caeefed57e3c7b74392462f3b30f233e845ab4a95110f7f7e9d10e9e67abd85be5503c24be3d789ff7b385e8623bf7d735da8fbcf36feca2aefbd3c7af967bc8b5779bc8611e47b6a64bc24c9bb021fe1a30e84cc0a40858c56f9f6339ec6bbddc4ff0174f6bf22c98f60fc23e8f446fde140656a97a9aaef4ddafb6250fd917aebf835fad8e5ff48be66f1f66d9343febeef251ff96e7b889fe2cf78074d4551452f8dd7dfb771b682810355b5c2becab44a761016feefedb76a0640f7463ff5796cd7f966e2777d6ff591e5c9febffae7008fd27c883cbc7e617bd80a7a9d0144771d07518b3cf06a8eebb48641e7aa3b741fd8c303e1150f1cb5fac34e37684808518b84f05a1e178efa41bfa9d2011e38ac1c78c609c2ba51e48357cc77754ebf5ce161f07a59bf04b0726973f0060f1db446fd7e6f306ae8d2a094ae46afb6383aa7d8c0d8576ff0c0b0db3aab5b033302d49bb2de7346406086807a83470641ab17f687a39a51d0d6a3bc9854b7511edd5ca7c997070b24d49d1d23b57c8763154e9e26303f14fcbba2616a40c130813298d69f37ddce75fb13e6e80afe41cc323030170456340486024e810339308cdf0b022bba98cc65dc53bdc5394d1b895b4dc00a782aae57d65604b913102bcf7d33f2d08ccc9a91c76664de8c2c0424b44ee949602ce4b919593a1132a66025ba40bda28b015eaa3f8d28ad5e1390bf24bad4ebad2660e52b893e25ee3831a2c43d2702ab971e0424a451661a518b5c594a608dc2478919d0387389b12a5ef07242abeb9e04c4aae65940ac62960272aa85a8070544fd66bb5ec7fa725dbdda1753ddbd86a948c545bdec47cbc65413505b1d71ab89ea82609dd95d2371df483c3412334da8cb5759aa55c86333326f4616bc94d01aa04fcdc87333b27422644440efff9f46848a34f1abd71eebdca69cb0170a4dc04d4b29624827de1d27ae2871cf89c09a760f02625532d388ba21294b09ac45eb5162ac7ae7126355bce0e58456394f026255f32c2056314b0139d54286052820c3026e7c76d131c3af26eea5411d0b578caac5de298dbe6668a65b5d87adf5e31691eaacec5bcc9dc458b2ef91098bfbacb01f0cad5e799082584377864cb70832e858753c92e6a0a3fea3a3722e25b1242f90d19576afae0696e227926668d5f84c5afbbc862501e06b52592251af2e8ec4bddb76815bbafbd6456c8a90d3b7619cc245c8366ea07ae58620b9acfe9c19a84e3a6d17ad1ba4ba2af62dab0b03d57b3784ae8489a7cd23c13c25ead5437f5ca25ee1b67aebca3955975575a7e09aea86213aac197427424c3d6673a84782e462ea11aa554fda65f5521e7bc69b7372a82799b87ad22c15b23439f4b9745aa7e147a7fd65df61d59591b93fad287a9547c8ed5e07eac28994575ab6ce9b400462ee3192c3bd948bb947a8d63d6997ba7c6eca25d3fe744b5e74cec2400ef72413774f9a61cb825d75962687717f1244dd5fb6cda0762e987bfb0a8f90dbbd0ed4e05e82987b841ceea530cc3d42babf94dbf21a59487b346775026c646e90aafc8115676120877c520a974f9a03e9726f7234c987422f59f4156e2dfa034bc7546d41352efac890396df5d39d0944202bdbbd811cf2a55c4c3e42babff84d9e49e3728f21e0a55ccc06569e8589e3704f2ae1ee49733094263e41ea2ff86ad7e8fc8d4bf55b01e6debaa64d11724f7c1da861e24b10738f90c3bd14c672323345d7bac7202ef78810f7d68df0c2e471b82799b87bd20cbffc636bd4d2e4d0b5d6bb57db4617b8d7bb4ce46b9dfd05651a68c8ed1e1932a5d9bc9720e61e21877b290c738f50ad7bd22e5ff0a53cd6c45898ce71b82799b87bd2dc15dd13a4debdda20bac0bdde4fa2eed98dbe86dcee9171bb9720e61e21877b290c738f50ad7bd22ebb47a43aeffbec660f21877b9289bb27cd3dd13d41eaddab5da00bdceb4d23eafe741f8937fa1a72bb47c6ed5e82987b841ceea530cc3d42b5ee49bbec1e91aa7b7eaf8790c33dc9c4dd93e6e256cf5a2f970141eaddab2da00bdceb1d23eade1adad300b7959c5ff09171bb9720e61e21877b290c738f50ad7bd22ebb97f2b0351f21877b9289bb27cde26d3e216ad587976deb15b87d9b6f7fc743c839ed0de3542f42b67a03d5ab3704c965ab37509d7ada2eaa374875dab36d3d03d5ab3784ae84a9a7cdd2b61e25ead5437f5c30eb43855bea87d6823345c8ad5e0772dfe59b40c419538f911ceaa55c4c3d42b5ea49bb74733d17cbb567bd811cea4926ae9e344b63706972e873a977af3689ce5ff143bda74456fca165638a90db3d6e4ec18994df84d9b69e0944202bdbbd811ceea55ccc3d42babfe006cadad9316974bbd4e5738390696f5d0e170672b8279570f7a459dcd633399adcab3da20bdceb2d25eadeeac66988fb4eaeabbd618856abbfef4488b9c76c0ef748905c56d133934bf717dfd9a1edb27bcc5375cfeef44c1c877b0ca32be1ee49b3b8ab677218f7a71d06b2a51b42a197b857b8bde65bcbdab488d9f0ab1cc3101fccbdce462f0ccc3d420ef75218e61ea15af7a45d768f08bc946b19dbd53327ee704f3271f7a459dcd533398cfbd3d730ea5eed115d30eff596129df7a761a5bfe1a93f8b6ddad1358cdb3d062210738f90c3bd1486b947a8d63d6997dd2342dc5b9db33027ee704f3271f7a459baf1589a1c4deed506d005eef57e11757ffa0d21bac74d25e79a8f0cd1cae6bd0431f70839dc4b61987b846add9376d9bd94c75a141721420ef72413774f9ac55d3d93a3c9bdda00bac0bdde2fa2eeed5dbd1037959cee9171bb9720e61e21877b290c738f50ad7bd22e4db7b939efeabc67bb7a0672b82799b87bd22ceeea991c4deed506d005eef57e11757fba9ce0bcc74d25a77b64dcee2588b947c8e15e0ac3dc2354eb9eb4cbf31e91aa7b7eaf8790c33dc9c4dd936671574ffdb1bcbae8d6b9d78ff7e82711f671fa563c0f9479abe4433d9aa32a2b3fd5cf20ddf6c7f057ebf0b88ef5f9a23f863f20570f0c950df034cfe6fb18a7f008d07bf53d3ecc0437aabb64553c2f36f17f99dd3dfdf1cbdffe0e8360bdcd8ebbe87be24f77dbd5bbb789d3d8cb13785c69156799976f62f86877f48a47288a84d524c7e82d7e8ed2b7ed21f376f12b9c037caff5bd543f9354bccf9363f1295c305f921c1e27323f6de099b8189eaee8b4a0b4d724c9cd0f7056f8749a978eb7eb899f3eae8b878f76f15bb4fac6e7d34e6d615156f95cdecd9f000000ffff0300504b03040a0000000000000021004bd08478c5360000c536000013000000786c2f6d656469612f696d616765312e706e6789504e470d0a1a0a0000000d4948445200000291000000900802000000df8aa7100000002c744558744372656174696f6e2054696d65005475652032312041707220323030392031303a34383a3531202b3031303099dee18b0000000774494d4507d9041508332734d067c9000000097048597300000ec300000ec301c76fa8640000000467414d410000b18f0bfc61050000361c4944415478daed9d0b7c54c5bdf867093eea0329494c00950d5093546c8c40841ba91b493569ac044b4ca80d5724f72f5c8980cd4aabd594daea85e42f20f809fc9ba8353e922657c03625d8d0ac8df9a38994e6824da2600222249744afdaaae4b57766ce9cd7ee9cddb39bcdee399bdfb7349e9d9dc7ef37e7f19bdf6f66cf2004000000008019b0e0ffd756edfe7cd2fc00567a635c4ca8f50200000080b0e286c4e91385a3db52120355e91b2ded4909d3fc2eded6716634c50153130667df5c2a984bdaf0933f2c1534a3cc26927c42a8050000000000401760b301000000c01c4cd495ab674f61e1aebfd3c31f3c72607d727065ec6fdeb5b3a157384eca2bce8e1f5d759d7bf7a2ecd15662323af76e6a4f1c75cf0100000021458fcd6edd56b86bd623077660537d64dbad4f3e3863c7334b63832520b636553de96b8b5747b24f9bf68eca6c77eeadea895e1b2ce98d427c7631d86b000000b3a323367ea4f9f5d9ab7305df3af9eec2d99d27cf064b3aec6157b525e5ad4e8d6409f1d979496ded9da3a8b1af07c54645fa5f010000000084081d7e76f2fa3fcbc1f08f4f1e0f9e70fd1d477bb1c5567988a2c748a3bd79a8aaaa2d267dedeaa8a64d556df47b45f09cb8e842224b1583ec559b10fd2c67e084dc71e61a94c3860b526c592e429aa55f');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(11, 4, NULL, '2ae3ceca7c0af15215830485548aafdc6455a52993da13d74637523564a139a59502a4c7369c4b94925de5d712090000003018fae6b345ced655629ffbe520cd6753939dc68fe9127fb9adad3dafb8385b0a9f635b43acf2ae666276888b8e2d73b168a8f612a3959a937e74e7b9346abeb8a5142d4446c5f6b6f7e1ff12f3ddd8939ea36a881cefdc1b856bc292c4442f92a4128e95e2a920a1795683544514194ac432594559c828c45d295a6d0d4e2e260ad634f7c76b68aa140067384aa5e2cacf150902e900000006c48775e367eb1ebce785999b9f5a3a3578e2c54447f1bfe83bd78b5d42625bb041c5ae648e606f2353d3927acff591c3841ca5e96115e16249898269e4975210151dd3d3d78f0f3a9b1a62d3886d6c54c4e9e3139310fd1a572905dba563593c1770b1de869d9bf692f07e7c7631b5994d0dbd497962dec8d4d5c5ab53115f3ca15a4104b95d9ea64a01584e0df97922010000004644af9f4d0d362adcb13e90ef4bf30e35550aef570c58f7b5b725a515d32fb04542bdbd3b3735489992c8fb61fa9a76ee6c930b26e55137b2bd8df9c41aa594888e36692b11bbcb9dd80cba0f21e42a156e76a72c9e2bd42a6235366daa12e2d8c423768b26f0c5c35993d2b223d56d7135550a20e6ece3cacf1329a8a718000000d08b2e9bcd3cec9a201b6c6c34d151ec0ac64bc60fbba4e8fab5d865ec90e3d188371bad8cf792806f23355674015a62a4662917a8a3ddd97c94c6c5298ad56bc45663518824d72f62c6b1e328ba3e2752694f918b545810e22613673a95cc3877620954a6946589e289d7df7c1445e7b00fc4794e8cd4d054258098b38f273f572430da0000008644476cbc67cf9321f0b009346a5bd3dc2f7c22f3b63d42bc58198fc696b5ad91e5213f05db25e66760a3d686e48835338fde4a11e898a191c6c5dd8b5461939710491d62b19d9d0d72649cbb361dd7d0dbd0c456bd63a3292979b443ae368934c7154f592db5ca2e4eb3aca94b4e613a802b3f5724000000c09078f7b35bf791b7a9fcbdf0f69d624af05eab129f5d9cb777931822c69ea7b0865ce546620731ef9c9847cc12b928bd71a790169394a4d8b1a4b761e72e44fc4a5e2957a2a2512f1e25c4eb6a28293d3d260645216d379bd550b5495eb81d4f95cc6b57544b9d6b5e5bcae082e4d2a3788ea6aa65711da273ce57992b92e47d7b3806000000820ddbd76b41fa8a40d5f8464bfbca4cff4dba91ded28e3dfba6a8d530bf1b3c8c74f6c7850ae69236fce40f4b05cd28b35924b7582cf0be714dfa9b6b8e5ebf080c3600000060107cfb7df6b881be6584448a210a0c0000001805161bff7c52205798dd181733fa4a000000000090b821713af3b36f4b491c5d55326fb4b48f664ac0f8330a00e001735dc0e69236fce40f4b05cd28b3892487f96c00000000300760b301000000c01ce8b3d947b62dceb91dffbb35e7c13d3dc115b01b655a9085fecbac50253a9407da651dde2af79461dce25fcfb897529f298bdb3f87565bbcfc7ae581d30a004098a2eb3d68854f7eb876c781833507fefcc8cc1d85db5a83269d0359e2d0b22ee474927f730a14665bc08af63b912db85de61d93da8cb117bbd1c94ea5f4cfa63b7f57394acbc43286433f000000f8870e9b1dbb7447cd334b63e97172ea9de8c3d3c172b52b36a3a246b4caca3e9634a2fa0278988e53acab50513d3ad81d6a3900000042876ff3d974ffecb405b14111ad1bd5d6a32c9b22c5e6e699295d224534d5ee70abac829f4e70b895525455d12da664227ba62a9cabcaa0c01e87ea114a5396d5ceac1480fcb37364e00ae6495a515f979cdc444db175f64ca8d1544aa7f06e899c7e0000003006ba6d76cf9ec29cdbc9769ceb82b57f7637aacf4056ddd9f1a3764e238da376a163696a77dc81e20a48a0b5c4c6299856474b35a252b1945d0ac837a28238b12afc20dfc8060dfc0c22255d2883c6758508812c182f33c99046c2094206542a5b0e7775b4125d85e9466b0ac4c0b2a41737515b6c1f7ac6a53f9593d0d4fef1bf520e50f45c0e15a834032d76b920b495d229bc7ba27b3f0000001804ddef412311f2a5e8c8b65b0bb75d15ec4d3975e0200ff42e1b3da693dccaaf2c69e4116cd3285afe002b95a1acca4a8f6da83c03d539908d7e4cb06a67d0aabd1b1dc3b6dec632172174a29bd5265122494b3368aae32191272d6b88062724b8895ae8ea1937c5555d8dbdd8388daf74906671add9cacbc6554a97f048b3f70000000c888fbff50ae67c367edad6eb5d73d47d42f3abb4cda8b11c6daed0cc30cbea96548fe2445fb0a09e975323034f3255b4202103757473f248e1d9526d7534757417065bf42e541ba75e6fcf4df488fe9e19231abd2e58d3564aaff0c1d5080000603418f8f7d956b48cfa3d32d4b6716719adb334ab69dc8f6cabc89a731fa627b1efa530159c88bad70c0a2d94238f8e7ad159572aa5581b5fa4ad8ea68e5c61a8232e44d191a43b37d127f42b1e34f42bc515de801a01000068a0c3661fd9766b8ef8fbae9ed32782b6060da1551bc964a4f414268b838a3466196d6451f1b30e7acc33ed0f94a38235fabc769b6a7db2dd7d94e03503e584906845739038f2701037dad5ffeb2633be42a2c3cefc6cbe3ada89aec2b8fd5a89d4cf4dd412dbbf9e093efa94d2145e5b234ffd000000102274d8ece4f52fdffbe14f8577aa149e5cf154b0d6a0213a43495706b1b87111729668e62da1cbb284754f731a5d4dbbf04ba1353a02c2425552b815357246095e32d00801165b58b12c0b9686cabbdc02bc741a55589cb539811c0bc173ae3a5a89aec2585159b9b8e08be6b4218d446db1fdeb19cfb8ae41532cea567ea5276e2fc9ec45296fc2737bcf6b3f0000008404b6afd782f41581aaf18d96f69599c97e1737c55bda01400b735dc0e69236fce40f4b05cd28b35924b7582cc6dd3fdb62197d1d00302af4acae070000081ac6b5d9f0b80400000000252c36fef9a440fee2fac6b89850eb050000000061c50d89d3999f7d5b4a62a02a7da3a57d345302c69f511853407db3ab6f2e15cc256df8c91f960a9a516613496ee0df670300000000a0006c360000000098035f6c36d92624889b670300000000a0c0079bddba6fd77ba1161700000000c62dba6df6916d1bbbe3af0bb5b800000000306ed169b3cfecf91ddabc2e2dd4d202000000c0f84597cd3e5bf71f7fbef96ec3ed990d00000000e3093d36bbb5faadb447b28cfeab3500000000086fbcbfbbb475f7cfd1dd0782b7971700000000003cbcdaecd6e606f4fb86db7f2f7efe69cefe1f3c7260bdff1b770100000000e00f5e6df6fcf53507d60b873d7b0a0b4faea8590f13db00000000107ce03d6800000000600e7cd98b3376e98e9a50cb0b00000000e315f0b301000000c01c80cd060000000073c062e393aa6f09548dcbc82ea47b4653435bc799d0764a6819cfeadf90383dd422000000181766b32fb7e506aac62f1cd5a3d936dc14bb8e8f1de35c7d8cf3dd504b000086c1320fee0840065f0f101b07000000007300361b00000000cc813e9b7dee831faddd9740ffc5977cf051a88506c61bf679c85288bafd28d9833271d9eda1560000028aff770442158524c4ea08b50a807fe8fb7df67f7f7178e14d9df7c4865a5a603c81cd6d35dabf2ed462008041803b02d0e96737ffeda3b9532f0bb5a8c078023f9eee40f5a19602008c02dc1100458fcdfe47f7992bb2ae079b0d048f8a5fd3c753a52a88b7661ef988ffd90fcb39ed62a2e700b8100fc4ff2a7a38897298518ca50bd53a5c3e6a9452061bbbf791e3cc7d0af1c46c1c5179f503803b01bf23e49addef02245e99f35cef1ae17aaed8ced2a5eb1c081aba6cf6f193a8ee053a99bdd6f1f2b9508b0c8c03563d8a32f07ff2c90f5d6c42d221b4ec0fe463f942547a3f7b6ce12748e942d4f52e72fe0165546a3fa42a117a94942d42a8e00e56d6b11d151c42e5b4cea243284ef9c0aa4459ef2a9a567ce4965a9c4e72d5d1e76637ada5be81d67618952294918eac9e4575690e00dc08f01d21a27517d8b14f4fdb6277cdaf1577c721847259bbf54fc04033d8e8b0d9e7bee84428ebde251d3b9774ee4c38bee9afcda1161a188f2c448be9828a59b3c9df133d2a8b8862d1c67c62fc1cdcb2f968152d9b952f96ed419b2bd5e987d0c11eb92dabba69f651a394f526f23c3d769a24d655a2229ade8ded374d59769337515d9a03003d8ce68e10d0be0b4ab0b55ec75c705ca7703d6bb60b04111d363bfa5bafecb4dd132d7dfebc1b5c6dc0000816118ff485305d5a25f9e8f90962b592bf1d1fb38f19567e3a9aad36a2ea8f9c52b168d942ea5bf7a063f8d9b78eb8265892830dec01e745d4d960b38100e0c71d8134ee0221c05e9bcefc6cc038f8b2af17001809eb55e46fc66368ff12bd4584c07582f882d4fa6e7eba67b8a54878fc0974f01d54bf1095e1c485a8f61d34e71011cf8abfd612157c142070f8714720eef54cfdf5a2dda864ae980942418641879ffdde5fe3d78af1f0735f74ce98fedd68ef85006054c4a2395ef3cc251e009b39f6fc8bd54ab688a6ae528cec899143d7746f52699512c2e3054f30a7199b70ecee940a81719f4405002e81bd23c43a3ddc05a56f91bfddfbdc62e34048d1e1675f7763c35d8eefad250b049de8eae776de7875a88506c60359f9a8b412592ac902192d4ade45681e8a9b473f2c445d3b34bc01fc60fa35b21c2287e58fb23cb675a8fc38599256e0b9ac1acd524278fc102aba997c123c1ee51350afa800a04120ef0811fef53c1735e693d0ba8546d7cb1f2383d1133dc8066fe8300016fcffdaaadd3fbcfe1f81aaf10b47f5e5fffe8edfc5c7f92619e35c7d8bc5023b22008004ec110228813d4200000000c03480cd060000000073c0e6b3bf705407b0d2b68e337e97bd2151dfe25d204cb1cc0bb504006024e08e0094309bfd79ee9b81aaf18d96f695a39b91fdc52f7e11d23e092ac56a652de34c7d17b0eee69bbd533f52f11934b40ae69236fce40f4b05cd28b3592477931062e32166d338b6d06182d16ef2709236fce40f4b05cd28b359247793106c76e801b36d7a8c7fe79b57daf0933f2c1534a3cc66915c2da1cef7a09dd9f3b3953b8f93a36fdffbfc8eac60fe182929af383b9e1d77eedd54d516c4b62931e96b57a746ea6f9a0adcdfbc6b6743af4a784f1a60b35decc1721311a29a02abbbfe3ac7a2f5f0e35dd72896a13197b4e1277f582a684699cd22b942425d7e76ebee953bd0ea976a0e1cdcb11abdf01f7b82f7c2456c2eb0cdc3860eb3b713c567af4d8f09458f8d0a417cccaee6fef8ece2bc246eae607bdbbd0d3b3d9861dcf192a09e730212c61fb09b57daf0933f2c1534a3cc66915c94508fcd6e6d6e882f5cb7742a3e8c5dbaa3e699a5c17b1b4e6c5424b679edd460b45561b3479cd720434cd6a68018adde86a64e84e217698d3b2048ae44d8889aecddbbcf75df6b2ff4a04c7d3b07071ee59d7fd847b1832f79809e531585544d2c3c7d53a63d68af650dec735694dfff0c4153906e6eaddc33db1f65852bcd8fabd43f998386df37912f9207ef22779350476cbce7f409343335846fad8b4f4c426d6e265311769603ceda89fdcdcd7da9a9f43b16b74662d89b552826b3587867677c3c75f11ba355b1714519b922bdb4b57766c7c747e1ced4534cd4a6');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(11, 5, NULL, 'bfb3534e94dbe7eb21ebad486589382527aa0fc5c7637576f52d1222de34f4ddd11c954af3d29c4979b46076f1da68dc0452c4c6dd5b5717f7bd4b34219b62e5930d0131ab7cd9f3a0e2d7a87e7640440836e6959c108bf6ef204fcc63a116646c150c0be42b6daef1564a074ab5b123a417b90e3ffbecc9f766cf40750f2eceb91dffdb762498e2b555ed259e69767171b12a2a4e63e6d83ea842e6e24432370a1d99801a852f50646a1afd825a2616b8c6b544a6e6289a8847ed9b38ee352d23361c99badaaf587d54b48e4244c528dad0a626142f0e2c70fb091dbb0491fb5257530d63d27352fb58fc7d6f677c769ea41d4bddd51c952df645643c6a72d72b3e35aa49cc89556aab22fd84bbc6c5fe2aea945aa7c51350cd26d6256949280060d7ade010d9bd806c72a07005ecf3c8203a93fadf0e852f6e11dd0e5541a93a5a837dbb9859fccae19222b82f8ac40af138739faa2ad7446f38dc9a36a2e43dac6385be15dc4a7ba15b576f572b55883aa4e238ffafc94bd7e3d45e88b00db3aa5d97b614f5b33cde5a77ef6195a6dbd59d2c96724d51b78239c8ab4796b9906cb78aaf40bb8b307ad4d9cefa019f6ee900e9504d42aeb35a21a1e4702b9c6f97dbc4e56ad1bab9945708ab53e3f2d3cf282f5495182e6af264e3df447ee0f1f2ab505ce4fa4f5fa0d0359f6d39beeb45f4d38335070e3e92f9fa930f06713e9b45c489e1c606125b6ec14cc45c9f1089fa3b8ef62245c83c2911fba42c9145a11365fb217e71ae0f89469396acea495f8beba5fe6c64941c4de8efe3681993be08e7eb6ca2960cfbcc642870fdd84cb013155943a8ad115b500ad6912922a44a1a8ac300a213b5c7246773a360995513d25cc5c4aca4dfb4558a898e12272aa8f6d2d84394a9a7af3f40eaafda81ca17523fdb6d9383fae3a8ec5de21cd87ad09a27c8ce83f8b8311f95be406e210f054be98f2f9dbbc92645cfd27b3eed38ea52a628b2753d46126badecb8fe09d18cdd4ff62824f5fc816cbea92b3ee9de902125b7df8196fd81954a131e408750c2a3625737d016f1b756fa78956478141d3b2457f2c0a32843bd35057ea809db30e37f739e10c75e2e6dd10e6954e7f1d4ba1bb65ca294831e57bc40776a712fa54829aa6499e556e8a7c5eef5b85389b2d495e852a712a147c9292bbd5f3c788b27a4f65514f7043b831bf15de0eda2936f13b7ab857fa5d12b44b8260521edeaebcae562d385bf172a570c2e2eb279b8897c8677f909677c957491eb3f7d8143d7ba71e7ecd58f086bc593ef2e9cbdf2e45912260a26d812b50961593219dcd640a7b95dcc03312882654f95d2a851d18cd4b2d033f19a1b625d1778f79dd32a27193d62a1e223f506ba75d5ad01196944b163b58624688e4df22eb4564c15a2d3b437fa7437ae4f22dcedb2c5c7da53dd7bfc51683464a4abb6d22a7802598467d93a2f05d9f3773ad93493301739a793317b3d2f9bb031d79cabe4f4133dc8fa0ec95c7f3fdd9d50e034a9c70bee0d1950f21e746c217a40d857740972d214695fb2ee77a86321adadcd27830c7622a82e1eb0de84d01d4453f2247d57a3adc3a83e1feda75f66e5a3ba8f89b21e5ae740c5a83b8c6cd3512d426573c958c1b5d412b4ff51b9df127aa89d76d983d5ad1e0ee266d2090be96e57c8377532a483e3c8a147354af7695a1b95070f50322abd5c33f26da271b5b8d64faf90c625ac4811dd8bb3e466f9ba922f3ffdf87ba172c5e0e2bf6c5e912e8c58de6523759abed3174074d8eca933ae3b7e125f305383218f077a8f76f4a7a60a7682632da9071de9c37c2af5cbc5d95f7a72b82ea81b52bbc2c8415719559bba8b48430e613c22c0d59078d20de4800c6c72d28fee6cc0bd91a05f2ecf831b11d14cd38c2a031e2af0b07a158d0496526bd4f8ae7c3b79053fd3b1e352fe07f26ccdbc839f2781f7225d5c64952f63566e43a6905c09767df62b561574eb7729f023ef5dea3fdd41f676c4639412df5f4fecd23a9755f722cb5be8012b42d45c75bb973a8c2cf793aede4f7b5e673d638d1ed546839eab25844d2718ff5dd51e2f9bb13e7deee8888dc72e5d91beffc53afa0af123bfdb713c33353958d2614f588a870b017121364bccb718fa26bf4aa293ddaa58352da963b259ac63916b6c9c8b6ae1b73216af0f5568dd0b444569e23d4d5c6086759443d75847aaa1f2775904eaf5929ce2dc32c9e0b92fc4ac44424925b76977322c12a3f144fba0bad71ce8cc56e63eb26730098ed171ba7ebabbc9df59b1ccc3d0037619f170be40984dd4bde096d39001258f45730ea183d2bca67a3a90f8ca62c4589839c64e527d039ba1ac3de4a96932e1b79d59eeaec7d0b1d3bcb6a613c751a8bfaed2f539eede3a9fb92474b9a6016d5ca25d2a9f8e8d0e2be20ddeeaf18e8feaf8a39ae895d6d140b1a35a3cefd4bf3c465d70ad8b41e7d5225c219bf7312d4a91c6bc802ff87da1ba8aa143cdb145e3b2d17ffa0288aed8f8fcfb9f3ffdb3958b5f20c7773e72607ed07aaaad6a1759b49d5d5c9c4d3f631fb38acdbbeedc1b559ccdbec0ce323183bd559b505e71360b127bf5b8dbaaf6261667c70b75743637a3d454ef8bc39844421b3a9dfa78497e5fde0ac3542445fb3b3bc58900a17d1606677aa3869a669cc6dac0896d8a9c422acba9a95d6773df22555f221ad4585d1c85e5951feeca3a89f221fed1762c2a7b8c0ce449dc950e78052772d66cba08e5b86a56d51d21c098368fdc9045c213c1eb901f1b9edd64d06da19149ec32ea715b390dcd35a2e4257f20ce50013dc65e85b547559c082c3819f9c8498d59d7699ab210152d54e59c4397e7482a5897a0f24271a30b3a0bc8690bc9f533d9bcb5cee5019cad9b05a5b9a58a841ea0fdd6f1b166bfa9ead1816feaa8cf8b4ed5f03583473c71342a93912f868263d1c67c94462f2439510df7f293afb47bddae902798d8257389951a0da3ba50956220ef6a4ae8bc897c60aedb653357bec8f59ebec061c1ffafaddabd207d45a06a247b8464faef895b2c9671be4946b0d537d26bce4cb947881a6c9c4ca482b9a4f52a7f452159dee577fc3fe0f5045c4153604699cd22399650e7bb4b0100000c0c9d7424bece280d6da0ea0180b1016c360000e62750ef0609bb778c0061068b8d7f3e299093d437c6f9ff9be51b128dbf8e100000000042c098f8d94909a3daf8cbe17084a42f8c80cd661be7ea3b9dce504b312a2c168b89543097b4e1277f582a684699cd22399690d9ecdb52120355e91b2deda1d60b00000000c2105def2e050000000020e4e8b3d93d7b0ae90621b7fe6ccfd9e0c976a4cce6c2c375e26b43eb1ec61fcb74ef5742ab924a9b02a2a27e054d2880cefabb2b322d76877fdf861e229f8c7e49b97a195d593f90fb27b3a2db2d51a92c37d14852fb20b6e115f4a4b29b7c01bc2c95b78bdcb563d1b1c6ee6dcdae20e8da3f7b5be12e74eff3076b0ebc7c73e33dbb5b832a7aee5607636b2e6a29c90ba9191b57c4666d71acf1ed87f6211f67180c873dae604ea393d1557e2c4def23c2ba6abfb3c486c2d24eabfb079577d1be41056b842793d4698d45a569a2eadcc4104a2d9c5522751c9346bfd88657d093ca543e950d713c5b10b017937577d41789f7cbfe55d631eb5863f7b6665708e8b0d964ffeccc15748f90a959f977365406755f2f99e405b9f86fd719d23ab1270e5f2d0a000415475d6946f90336f1a37555597946699d23d4621906da3f65f47944c628c29349ee34db03527771134344f78963a8288bc882a5de58848e9de8f6496cc32be88ef24226f2d577744b5fd9d38e65046a7f0ed24e8255abedc075acb17b5bb32b18269acf3ef276354229b7cc25ef3a70898d4b51f4b2329f83e04255ead0bb3a59f1058bb1d795714a0409593045e3ca6904a157a8cb5b27e6e5c889333c5c562675a37bb54aa799dba8a28b68be236579252da87a83aa064d511fde73ca67ddf93149f2e050c5b9a86f5a21e655670d26d6848cfa82671d8a0495f75ca108cfb986ea987b4dfc817a549aa654c24559f3428cdf9c5956ed44ebac398245e426860aebe265d2639e3c59972db6fa22b6f11574c756a270f5b003287dd15db11935962d0b5033b81784de54a705bc630ddedb5a5d21a2678f90ab66a1fdcdf4e17db6aef2f7a8f36410e7b48909606ca84629f687b2dc5e4f842d03fe4a88a12f40d5be554fed4c8abd8ac6de5b4af29871a1c92c2c4f63f24f2b8c5ecb9b68294eafb2a7e02ff60437144c048b6372c589330547ca3654cbc256bf2aca5afd267ac8c134e3c9d9528d960be10a5ced9bb754b954ab6cd4fd5b852455f6ae0d3831790de9122cc8167a9278a5c8b9eaa2bded588eaa5b7cd35d19a09b23c52411366975594ed73857692d2a1312d566339860134d64d298069425c459d648c79b95430c5b495779062a6a941f995c65cd097ef8672420a3cf2bba834f6b57c2662af4e6842e75dc32ecc1565af2b9bb2bd6d42e93e348a3af1b8f066ad7847aa46d083c75851e3f7bfefa1dab4f3c49d6a03d89f2d7ce0eaef0f27c363608d8a8bacd97f61c7e133ffb7317d038b9103fd74d4fddabd8c6e72ea73686966d79f3303178c96b882d9b4afdc40d6418d0724a1ea8305f3f765a1c1263f5c1a2e74c97a82a9557689d48bb464e7415144dbd26855f5dca35c206ab47deae16f3a2e4a5f694eab7959dccfd9624da970a8d7267be79a5c8b962bd4dd37cd25d119344b6ac2279742c3e42b05b2be71647a9aac4e0833d14a7340da8364d4a0915c78ab8230faeb2a6a5be60b33c7031cb63da61b7c4d52ea3b3f0cb6ae34c34d81835dd159964d8cc86298e676b97950570c4426e70b4ac4cb85f3676c48da38ef5a92bf4bd532576e98e9aa5f4a875db0bf13342b393766cd6f2dc92966a62a6dce6b145e3a36d9eb45197a5c639f6481935d5c401df7256383604674fb5a45cf31092e415a4a5fe2b894b3385ecec206e9a9777262b3290e15089f445ee727546b76fc9e0015de3455acf7592318f2fe171ea9695b10fa271b3e263b7f82ad24a0c21c478979067dee68a076cab5c25d42fadd1f41a1de274369d578c134fa8b1a163c78d6c167e6351c1663c76b4855aa860e84d0c362aef2a119475d8d3d046a735800d9099a3558acfc7c649c7eaed0a2bfbe0e37c36598f36f32ae3bd3d5f7283b1511b5d596ac1e9d4b914e42548863db488665a94978a450cb6188526c171bf10e607445cbd66b76f8520833f754a81096af6f970174bab7c506ac0ad41ec793f2013cf6a2dc854a8173f7a1cc10d2a28e717a579476ea2a1d02fb63915641eb63c47e3a82b456cda872db9189b80c35874ace17bdb33fa7eeb95f3a0b056bc75dfaef7d25383b77fb61ae5223499d8b9b760f75888e60ab16efd10d71d8913c0aed5abaa54c6c64308319562e09ac84b1d6532d6601e3399d9f6a3dae405b96c5280d6e1b2648dfb2d491427c9c95a33a988689379a5c8b9124b1dd953a239bc2237155be6d37db096596745227d6218fe4ea36b52d354bf3b5e831d15df27000db8462610102f559cbe273f1812263e6c59e20a04398d9f182ab1c91a34416c32b9cbae43fd621b5e4177840b57f4b029d2a40ff9c51b5d72e1547eed0fca31aebc066b2c3ad6d8bdadd9150c3db1f1f9eb1f695e5c78fb4e849cb357bffc54704d76f5069bc20ae56edde2b6082d366bcbd653b60d');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(11, 6, NULL, '345f6e6e2e5959c5471daac54e20ae8bac9beaca635f0849884c106fcdaddec09aceb5db5149090dc9073bc0a0529e4a47e47d38cf66131388ef4a6686f3849c29f6adf6940d647ce15b5800577be661b17772b73a482ff478fc1629259112b14d2ec19d796a2bf6aab9a5847345644dc9cdd59ec6b095341659d22ca5e4183f0e58fcb4a4ab3c33ce42b6b54119e55dfb6d413e1b3e43225cb3ec96384b014b2052fb3801482c4441419ca5a3d159e25b491380cfe8894cd63df834db58a274eea5347e628820bfd9ab8d13c4ce902c997eb10dafa02bc22fb0ebe5eb9888385a0bed8ef2fea62d58c7ac638ddcdb1eba4280edebb5207d45a09a7ba3a57d65a6ff3f9cb6582ca3d924834e444bb6d77c18688f1012723fb53cb83f82873d4240da71257f582a684699cd223996d044bfcfd642f8c1af109ba573a46ee173000000000803c6642fcee0c202d962e01b3bd926f5b10d045b879ebb754ba8250100000024586cfcf349819ca5be312ec6efb237244e0f759f0000000080111993fdb39312a68da606a34ce8860203cd6787487d83cf2779c5f85362e69536fce40f4b05cd28b359240f8ff96c00000000181780cd060000000073a0672fce3d8539db149b669fd9f333f2eef15b55896387fb9655a344b92798cbfe60ea4643b069978b98e3692f6aaa2f27ddf306d246df5e5ab973bd2f6f8ae2ea657465fd80bb535b376fdf906e036d26c2df5f4ebfd88657d093ca6ef28df565c96d5a7963c927215c7a5b534182579bddbaad70d77bcacfbb57eeb0feea60cd81cde9fb37ee1e6babaddcb38b6c59b521b47614007c41b113197d5fd4b134bd8f08f5ae9dfaca980fd23fa89ceeb6518e0ad6b057a2899da6dcba8c9b1842a985b34aa416f76fd02fb6e115f4a4b2fb6e2ec21b5782dd7477477d91786789ef290a97ded65450c093cd3e5bf7e0e29c9f9f48cfbc4e4e6b6d6e882f5c421699cf5fb2faba86e63136daf415e0e29e5d64af2db3be2b05188790dd9515af2a25efcf92765e0658ff94b1dd36f6b32793dc69f4ddaf427771134384627f39f2f655f66659fd621b5e4177941732914ff19a78873ded58c6186e31a7d1344976dd6f205c7a5b52466343058f7ef6b4fc976a0eec5832434e51ee1142f6d5fef07410dc5ef5ce90540c21a45d47ff2304cde510ba1c50ee91be0f60a45b51a9b24a7e5b2cc65e57163821e4861495b94f20d050b3d441fc76bd952a935f27ce4b7cb8ac4c9a5970914a15d8173f7894fce13d3af6f8e2c72485d7f32ae25cd437ad10f3866e8b47b209866af36eb5f75ca108cfb986ea987b4dfc01ba018342091765cd0b777b0665a2b49703373154d0f78dcbefbd17de05ad5f6ce32be88ead44e1ea91ad9d45ba2b36a3c6b265416fdaed1ddc288c7a5b4b41114f367b6af2fc506f6645de97425fbbcd333bd5a7a66da1db6a931caf5e5325ecb18d8f056b71a42cafa4856dbf8d6b6929793a00569b562aec57b535b7a5248f49e5b1ad9637d152269bb4adc668da8f63edc495e4899a6ea8961b675b9e900e7a133de46092eee1ccd96b942a39b55cd8afbc4b9e8ae025b654a3e5c27e5d6e5291cd40c4a156cfe137917d6932ce236e3e26494ea63eba84cdbf96a36a6f3bb229a364730ae43d654bd3eab29cae71aed25a716366b5d90c26d8448bdb66736cac2c21ceb2463adeac1c6290f70ed30d18a4e71657597342f76643469f5774079fd6ae84cd54e8cd093ebf40dee4906d5144c7b7bb624ded32dfb7bc0940d3c478d7ae09f5987c2c75f5a0a0e1d78dd3883831dc64870ff5723121662eec0ac9795f292db9662a75ee3604666f2e6193afdce5c226190b8854c2d6551edb62b209824a5b51fa27c0992e71aa80b62fd4465a5f2327ba36acb1a9b866296c60c97fc9a667d2ce5cfc44b64129472ad96813938de538f276b5748ec8a626e44bfc550beb4c9ae65977454c926ccc238f8ec54708766be5dce2285595187ca4ed8f44e32d9b26a5848a632f7b757295352df5059be5818b591ebe0ebb25ae76199d855f561b67a2c1c6a8613b72b2618ae3d9da6565c11ab1a89a268f02b4ac4cb8b33676c485dd29f0a8a0e16d36859a44c1a17e55b7b32c445d05e7cedf5da579485b6953532818e7b16acb1571cb6cb17d716820879d957b71b20d3a35f1a194c7449e54c46893110533d9e41b61d4453b8ab30da7d71db9555b662b8d1b77534ea3edd4498d37769a653f5a29a17e698da6d7e810a7b35d67498d0c1d3b6e64b3f01b8b8c18591d1bbd89d59477e474d8d3d0c620596c97a615ab1f04c2ee147854d0479bad9cc356ce6d070361a36cddce32dd0e3b77ab62d59a6c57468524015d20472b1db3b65c519869d9549297838b6167fd2306cd52dc4880c7f000572aec91c7bd79f8886cb29130a520c25c7ca962babd0b83bb585ae583aa0cb841516e82cb5458bccc2c96290870830acaf94569de919b6828f48b6d4e05999b2b1b12b2833d9bf6614b2ec62ae0e0d6b40661d4db9ef1d5cf9e9f9adeb9631f592ddeba6fd77be9a963bb99b6e0be9649f3a2f222729db0f02c0d690720364e22c392af4f0db522261fe0b6f8026067549c2726ed534f978c1d98cb4be6a87556a5594a9cfb269a48ea71133d4a45c2e471251b4a98c94e5e20c7d4c9792593e2641426567c648fc2f72637155be6d37db096596745227d6218fe4ea36b52d354bf3b5e83bd05df2700c3ce8d10205eaa1876203f1812263e6c59e20a04398d9f182ab1c91a34416c32c3caae43fd621b5e4177840bb74bb965b634e943a34764c9c518eca8cd6f5a3d1a96576b854b6f6b2ac8f0795faff9f7ffeace9c9f2f6e404e94b9b9666c4d364a5e5365efca2bd9606326057b6abab77366db7d096573ed765452427cba64fd81811671ab30b16dec463389842fa47dba47df169f6a4973b135d2fec379369b98407a834c05e7093953ec5bed291bc878c1ab9baf592ad77ecdab36db0644230744bd1ead44d57972950ab169f2052cf680f39c7958ec505609cadab2f5948d0a91929b4ba228ac42c59ef4e471c0e2a78a8de033cabbf6db46d9bb630e8970cdb25be22c052c8148ed63389158888282384b87cbc6f761013ea3273259f7e0d36c6389d2b997d2f8892182fc66af364e103b433227fac536bc82ae08bfc0ae97af6322e2985868bd4d2b9e0434c14a8fc2a3b705f9b80a0ab07dbd16a4af0854736fb4b4afccf4c5175663b158c6f92619a1549f04cc4f2d77a80746dcc43153dfe0efe8f78af1b71930afb4e1277f582a684699cd2239ec110200000000a6016c36000000009803161bff7c522067a66f8c8bf1bbec0d89d343dd27000000006044d81ab4db52120355e31b2ded4909d3fc2efeb7f68f4753dcecb4759c01f5432dc53852c15cd2869ffc61a9a01965368be4309f0d00000000a6016c360000000098031d36bb674f61ceb6563d8900000000008c195e6d76ebb6c25defe94a0400000000600cf164b3cfd63db838e7e727d233aff3960800000000c058e3d1cf9e96ff52cd811d4b66784f0400000000608cf1f4bef1a9c9f37526020000000030d69077aa3cf3f2a1c0565af8a305a1d62b64ec78e5ed508b10022e9e1c156a110060bc3330381c6a11009fb9f08208fd99ff4fd6b7889fbdf2ae94004af0fc6b2da3afc4a460831dd8ce340baf3575875a04000000f371d105befde29ad8ec8fff27c0a3b37f7c3d72e945e3e897df4323cef3834e3c58b9edd6b901ef4cbfb9e442cb372f9980a5ba39f54665faf06fe222fead2b204d4cfac6849849a48949d157865a5d0018eff8faf4078c80affb884df4a7900e460cbda15920191e710e0c51839d36772c7ad23f2eb98819ecf937259f1f62624d7c7e26faf63df820bae3573d4d15432b3f1c4d13932f65067bf0a22bfa3f3f1f6a8d8131e7fce048a845007c060c7998416cf6a21f6fffcb4bebf4e4feae3ae777b50b8e78da85f4d3170b9ffb5927fb607126befaa7ef2f1a7b554fbdf6e2c25de72c99d9a737cc0a549dc34e34440df6f7d2e6ba2adcfb6ee143fdf7be7cfb5c978fe4a0b9cd2267b4d87ef0e60f3e516566f959368b33e169e557de900c76d2dce48121397d42c28f26fcfde579f65fbe5bf278eca255afbdd38e138786860606cf9f3ffff5f9afbfc67ff1714eee0fbd361179d984ab2647e026265cfacd8b02789200000828174d049b1d56b075e3d8fabef9d2837a0ab8e4746ab896da7ef689c76fdbfb028a7ef28515f9d3103ad392736fd38196efa78efd6af4ab96aef868a967d97c03d7333c4c0c76baed46ce4ee934c5297d217d2407094f57dea6b4c1cede7e5566969f653b5bffcaf2c75a5ffde5bca93aa4baf4a20953a8c14ebc21696058768c26bf321bffc5067be4f295f3ec089bed7f4115dfdad835383c323834323444fe7efecf811dcfbda62cc525faf2881991c460c3d2330030383e2d71028c8ffc5baf5b7efc8ca35297d956e6d472a735ed626be7f31664b936e1bb53699ea929d5cfa3ca8fe971eb1f673cd62ee4b25cbba8e99994abcfb4dcbdb2e91dc1d7ccc8ee5e3f0bd19496f8c47f45ed2fbc4fd26fbaffbedf2dfd2652e494136985a4606aa7f5e7e8a55fa17b848fb81e74a2f8f6bd2f302f36fa89e7e90002a1b7b6fddf7bea5925624e3e58f1911162b0176383addd574ef5cc83f4d1c99b91704f14526293affdce4b9f7c8c0fbc9d1a62b02f25067be69cef48217181debb3f886cfb3936d582c18eb9f9becb531f1b181e1e1a7412b33d38323034747e70786060c0a5a00bb15744cc8a9e889bb802e6b001c0f0406c3ccc50fd3edb96ffcc734fffbb9e6252ce0fcf0d71336886c669baf3fda69b339ab051ec5a370b9bed1f4f45ce963f5a1f6fc7a6fa2fdb53ae46277eb1aedff971cbddf735b5646677af9bf5d1de1717edde7bf78cfbaa8545d99d7db39ffb49f7b413bfc8d8fbdb5d879ab2bf7f33ae96e6c4c69826febe3265c58f05193e6cbe7bff398412259170cdb9b8e6f8454da4ad4f5f5af7dc632b5f44cfadb8a5e5456cb0b1bdafce268380dc1a4d2d8829a5067bf6f5df39d9cfef01f4e9c85768a4b77fe8a4cb4797746e6697146e11376226455c338518ec5973bec33fd99dd51f45de894a1ebf327565ef5bcf5d74d323827b4dfe0d0e0b7f07ce7f65f1d0c41511f13117088bce0c33770f040978fa9b11b84fc30c95cdaedcfe80ce6252ce0b22f84ff8112d477b6e66e5ededf907c8a1b37eafb59eb8b99b2af2e39a8987bde29ef9d3479c2368e6e35b67363ff334f69bff75e14c5cd5f46951089d6be9ee1b994f2fc16b1316c53a474626cfbc16a1f7fb3efcd8f92f53e7bf5a28343a7371067ae1c0b90f4e3b5984d799b0e58ff957e38377f7d38f2327dfeec035a7dc328bb63579d12dd1cef7cfbdfe76ff8c53d8b4a3963f7f70f2cef957c74a15f2c176ebdb372479eaa3088b05bdbf65fdfb5282055d3b31c272a15bfaedab1fb8f74a9c88c8b7aae22ce5e8c1b73f58f8fde4080fc694c4ab6752f7f7daef684ad59f77fca3ffeabcbafff5cb531fbf78c1a324244edc6b6cb3b1c11ec60703f8e3c0f98809fc86ae9c14f1ad2b491393a2ae8427c138c469197d1d40d0815b35bc906d76d54ebd065b99536baec4c39cf1c2c2878e172274a6f547ffd6d462c10f8273c5bf3bfe5bfa1509384bde303df86df1d3bf954a7ef8e9a911f95b79d2758494faffcf3cbde2');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(11, 7, NULL, '0db9153943dc37a70bc76254da291e086d4d9f4e0604ad273f59b86c514a7d53cb074db76435e1f494827b5fc99ee2223c36a4166ab06f987783976e8ac0ff8b2f2efb1ef379fffbf0638f7f72c1446cb3d5e9ec5b9c6821dfaa8abfff642131ed96190b9ffde9cc0bb59b9a72d9841953267a1f462034343c34e327c7bf1a181c1c943d6c62b689f11efef2fcd0279ff471d7ac486382cba3c0c31ea758e0c49b1038696106b3d9ff59b6566701979c5a7eb6d60b794eefdbff564a66de548462e6fff6f5f9a7f7557eefb973d8189f8823df8e8cc8058549d51f3ffed0a3cac55a675be9522e926d902edb46e4d756e82fdb9fbeef4f68fe7df7beb864caa19de498542514718a758e881fe981536cebf4a93efc77de55530663666391f0b15043abe344d70fa65ca5683c62029a6821063b658137834dbb16774dc44474a1cb4797746e669612ffcbdf7c2fd95b3b932f99307d32b1a6df999be42d2f1a1e62d67a605870b249487c8004c6696c1cff1dfc7aa2db382cf2b2086b2469e2b2c868a7131e02e3150b38dae6036ed83083d8ecdfffa650676e979c1e0a7ef6157fedf11783e736ad7efaef1bd7ff84d8a24fffe420e1e8653f9c9b89fa36fda9fde597deb9ebdbf3a7a14f5ffb7fc7172c494d7ea3594c41a8b775cdbe29654b46c8ecf1c8c8175f8d7c869cb411e757e747fe49adaf357af2675ff5779c20c7e7cfe30c94612713e63cfb78f96d0b722a7e5febf8a0fd36d21696c1e28c4a4b9adcb0fdc58f96fcf8ae18f4ed3b48d37fbb66f2e55f89952074f1059649175bb0dd5a7957ca07bd83de3b2b8298e10ba570b7f4d1259d9b999bc283bed5244290ea6f1f79ff91f4d0d0a060a789e51e1e1e181cd9f5e2eb03035f0f9cff7a60e07c6fcfc7834383116a3f7bcaa511d74c61065be775028425f0f4078090436cf658fc166064c4c935dbdfb065ac6d7a69e7e66d35f42336966b9f5a9e1533fc294adfbf6e24737bf35d79cd24ddbaf0b9cbe63df9d488fd672c85242ecafaf49f2383b4f6cffe39fc0d34fc256de1cb7f0ecf4e5f38e7e0a19acddb6a9d51d75197fdfcd7b84efaf5e0c8a78249ff5afa38f3bee7b2cedf57c7da72463df0d4f2b4cb868f0cf66d59b76d8bd056dcc2e7eeb1b282085df18d09932e9e20bd96f59b9745fce36b6fef9788b04c40968889960b5c3e9283ce9fded72965b4dc72c7c13b54891667c296d229aae23c2ebb7842d4a5b254519747fccf3fbd4895766b4a794de3f23b6e1226b077bff87ad49449d75ebbe0eb8191babaff7c7afb5697fc932f9d701575e22f9d120d4fec710eb8d966046edb3083dc85ffa5c33fd38fe32f7f15deb9fde1b9a1735f18e5459ea3419acabd644af4979f9c13b4fb9f2f47be1c08e56ba12eb970c264fa3b6ca554673e1bfaec4bef52bdf2f2bef303e731ab57e79796ec18a0c79b7ef9a84bb62b2e9930ed0aa6780835050c02986c3302263b9c28c89c1d6a110000000000d0c7ff0213f3f4dc3864a0220000000049454e44ae426082504b03041400060008000000210092ccdd862c020000c406000018000000786c2f64726177696e67732f64726177696e67322e786d6cdc95db6adc301086ef0b7d07a1fbc6a73d45ac1d429694426897d03e8022cb6b515b3292b2bb79fb8e0e5e27610b692037bd594633f2fcbf469fd8f5d5b1efd09e6b23942c71769162c42553b590bb12fffa79fb658591b154d6b4539297f8891b7c557dfeb43ed69a1ccc462368200d8165895b6b07922486b5bca7e6420d5c42b551baa716967a97d49a1ea075df25799a2e1233684e6bd3726e37a182633ffa8e6e3d151257de993da81bde75d792b54a8754a3551f22a6ba2a5b27ee042ef41f40f0a369aaf494762b5fd1ea506545c8bb784c3edb0e69bfddb79c74ac3af5fe9bde6259ac66b3d579d53c9a7cad3a5f66f368f485f2a837081684e57e2bd8369e9f7ddf6f35127589738c24ede132a16a1f3547194635370c6e306670129dc337a103258360778afd3648aa9b96ca1dbf36036716a071bbc3344fdbfdf285fc4327865bd1c1b8297171bce73751a39a4630be51ecb1e7d2067434efa805684d2b06839126bc7fe07038fdadf68628315673cb5a27d880f03d9875469f15bccbc99803c20c6e5e941c1b0db45002d2e8586278164fee171a50c28f1631482e0ab887e51c2306b5ac5865593ef7b3983e1fb4b15fb9ea910bc01c78004229a1fb3b13dd8c5be20c8301ef0c261eafa11370ee0db5749cf419becfa42614ff1df9d944583011519bd2ef44bec8f3c5e56c711ef931ff1a79186e7a4ef9adc817ff39f27920f3c391cf57b3e5e509f90c904ffda3805735be9891e70f46debf10f70754fd010000ffff0300504b030414000600080000002100dde46a54f70100000b04000018000000786c2f64726177696e67732f64726177696e67312e786d6c9c534d6fd43010bd23f11f2cdf69d2854525daa42abb2c97d2562a9c5753dbd958f547649b4dfaef19dbc9121007208768e6cdf8bdf9b037d7a356e4249c97d6d4f4f2a2a4441866b934c79a7efbba7f7345890f6038286b444d5f84a7d7cdeb579b91bb6af03b4790c0f80add9a7621f4555178d6090dfec2f6c260b4b54e4340d71d0bee60406aad8a5559be2f7cef0470df0911763942273ef80f360dd2d026551606bb154add18d65997a1d6599d2d6655536e8ad84134d30134eedb7601472f459c1d66389a33b6c846386527c69f32c19ea99bcb77ffa4b75ee5f4bf119c657c4f3430676b4a49106350d23ca39d6b30a7c7fe611a04bb3b3d382239aebb7c8beb35a071b187d1fbf6c070680766b5162650d249ce45bc16b4985ab94b3c248c1fed18f1660395ef6f2d7bf6c4d847a1040b114767db81398a1b873d7471c9134d1e7be6697297cbe23c96499e862f96634df03dd82431b60e7707956d5b82ba78495fe21fab820a5b250cc10febd5ba2c31c430363b985140351fef9d0f9f85d5241a3575586ca287d3ad0f39754e498d5925f95e2abc22d8a53b3e6d9523275035dda72fea23bb5fa62943862c9f67b38cfd4281a5c66aff40a165108e28a96b7a754e822a0ef193e17800aa0052651bf59599e618677736a78529899bdc418028146ffc6f2f2361f11d373f000000ffff0300504b03041400060008000000210048a698f87f0600007811000014000000786c2f736861726564537472696e67732e786d6c94586b4f1c3714fd5ea9ffc1dacfb00f088fac8088005153a5340a345285a2ca3b7377c7cd8c3db53dc0f6d7f75c7b6660c72c6aa44861fcb88f73cf3dd770f2eeb12ac53d59a78c3e1dcdc6d391209d995ce9d5e9e88fdb0fbbc723e1bcd4b92c8da6d3d19adce8ddd9cf3f9d38e705ee6a773a2abcafe79389cb0aaaa41b9b9a347696c656d2e3d3ae26aeb624735710f9aa9cec4da787934a2a3d129969b43f1dededc16fa3d53f0d5dc495a3e3d1d9895367277e727632e11fc2c7d94d465a5a65c4c7cb9389dfd8faab800fb2c3e59c5c6655ed91e070cb172416c65af3905e5b2a8b0cb5ac6878abbb31bf2b8dd4e3f7ad816ff38fd7c3a3c1c8356ccceffe96f7725c4abd1adf780b74bfcd97b27489f1526ef1ca1b3f6469a1ac2f442e7de223ec5c62a38daaf1aa1cf3f796986e6eae2f4c9e986997ff776a99a55c79e13263135b71ef86b7e6774afb6f736f9be4d49aa42dd74281a06959e2e6c7b0f78a8d7f550dd6a5d9609d937c299b974261ea70f9871547af58ff22ea7cbaa5cc27fcf8854076874453d6041b3f501fdd540bb2c22c4565b42f80502dd71569ef86d1c593bf2f7f8be73eb7c75ab85e24a4acb8218786e2ea6bf73847e18df82acbb4908cc5ad095bf3bbdc348b721bf72e201c9ec4da3416cc89bdefc6e3f130a08b5265df454196d8a9cc32724e70910a2a6b11946778e516bb578f1995bd61b1546542badb42b9cd13020b8da39c3d0165402fcb3238eb23149a380269d77ce85e968a1b31a6619b92dc8e80a6f686a443c9c01b943064eac10ce11a85ff8541e2aa6a4ac90ae692c4cfe1ba731be277a0b7f6505721c54d875844402c1a2f2ab9ee4f182004f3accbb816a0cec543415aac4893854bbdda482c78109eaa1af1d08e80c80b7a94f8642c6bca3c60f942ae29619033ec17af1e2983d0182d2e09d1956e2c02b2bf5c7dfa1cadd6d6dc2ba835fa3bce0e3e8c7f5cc536c45c39385ec307d2f3496112703e56b5b1985e7e2eae09530e0d92ab256a029399299b4a63b8d926f30d7803f09f5c25a606500ec8c4a370ee6a99614462d639b2f734ea87951396c2aaf6f849965cd3a5cabc021e4de092c8a443e6be909e19c0f4da200e07b6a042de2b5ced581288341657322b046658c48492a2f7bec1250d285b4e4406560d98d613a6a5f113799f97c242b114343c143dd0340410ba201497b8a484edb2340fcc9c8e19ae300f48eec1f4cedd5c0c103cbb361848e04ede64f0817c1c32f60f04323e2b579cf1915bbc1cc77497539fc9f3b803a8ccfa0531aecb06bd6a440e3e9478aa5810f14f208e189b3247df324dc2a0827954810349c8f08169cfb0778ed1090ae0055612f73bb41d0f1a3c479e058fa85d8b8e9b0fd3eff885878dd80d38f2db2390216a0c5a437bb55430bce13ab4592823e717de5049bccfde40307e2e969668d7d3234a4f081b1d0ffe33ef3288762b699a07ed53230614594c5d38182dc26358ef60481c2f1aa7749062b29583efaba0972d40ac1e5cc4ee3a4af1dea008b135a3f4358bee4b22c68a5fa2ded875e229d2872bc939288d1644b3a1783bc2af6b9541a28316cb3c17b9c91a9e8f4152773668b6758e049d0a32244aa5bf07d49f08c8ed17a99904f655b9062d2f559e8ce3db8d6eb97f3a18a7562888616ded46470f54429f73080b0692557861428b5b227a530bab5645982c1c6d2b7a815a4ae78085478cc47ac580c46ad22344160886da00bc208d6dc9d039287aa008e58096054b31c620d38e88ef0b7cf2b4e3553ce2264b7ee746b57106123416bf186e32a4c782cc520795470c818a0a8f56b9990c776b14fe10511b6b02f439bcdaef62056e43325e40a2a4256b9dc564ebc43ef8e4f98e07a55715b0781a3170eb9ad58a47b1648ef0a08ffd10c662475e3631161f5811e220dc112a8cf1ae911815b2ccc0280c5c1c19000b29efb48f90071690ce217c475731634686fd0d2c6d4a975a693c9ff902106d0df1932108b4763ce298021d87846db007382ca6769936d439a2e45f8d042a1cee85976d3b245fe65160039f6dc9d20e177870b5c163005981399625cce1adc0621626b9148ef0fee117d2a5f49245020fa7d06c49956fdaf1359d0d15f45753e8e1daa549de73b3bdfddd3707bb8747c76f87a7dfcef6f7a6c3c5dee1de7067865f64876bfde9fdad3b6f863bc7fb47af183a181e9f1e1e1c6ef77b383c7e743c7dc5fa5172fc603a4d5cf6591d0f8ff73b0998ddce6c6bacb3a484fd9d04eb7e672baeb304d7feced67c66095afd9d04987e672b06b3ad183c67d5047f3939fb0f0000ffff0300504b0304140006000800000021007949e1e6e2030000452100001b000000786c2f64726177696e67732f766d6c44726177696e67312e766d6cec9a5f6fa33810c0df4fbaef60b10f7d691a0c2424de1069d5d3beddad7477d23d56049ce0adc1117652ba9ffec6366d5389a05dd5f044943fd8630f9ef14f');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(11, 8, NULL, '33d8cea62939824f25c939f14e75456456d03295b39265b59062af669928c9b9e4deefbfb52d455f4bb1dfb38c12fbf3d6a7f9893eb4c928f7b6709f8d20b2488f94a7cfe2a4d099d046251ecd9932622d6779991edf49509eaa34f1b037372ae6ef746c3767ab523d1f296279e23d3452ee1fe08efc012c2c69a53c045d8e56e6c3eba1c47eb8d236a04c883a97ec074dbc002f7dffd67cdb0e30b2c00f3c744c559178e52db7c2da36e4f6a7a1edc86118aa168f147d17ac92ea9983ca92295adb612318a756840e759a331894f183784c3c33bc4c5415cd943622f16ab87a31f6c2ba57535b338d2912fbc1c243b6e3a72edbed586e8e4232c54445d29d14fca4e8676d7f99d60756cd38dd2b12afef1647f5b9ad52e248625d7e62b92a088ea23b532c283b148ae0c007d98f19ab72da106c949d99643bc6997a2605cb735adda03de33c135cd489f7690f2f8ab56fc141549522075bd393126f1e2cd25c3c215119af589b24ab0e9c7a305346cb8ea7d923e8d8c9ec545398eed653affe15e49d2f2b51d1b71950c0db4e34a8f54929c52c67dadde09859ca15d1c3b9d19821b4c9d9f9a5a1ee077276a88876d5cd763307a969b7999f49abd6961b72cff504ff01d4a26fbbefa0fd5f33ad7f09d5c282360df9539ce97f4c15f700aa3464c32d1bf20fb0d851fda5ca0a51db81a1e016f9b76871f18d7561336fc8653bd0f605ccf90a53b0fd9a72494d83971a6b6343fe164fdb8596e88b97ca7b20a4acb658d7b7d75a648aafc6e9d6da7a43f25538976ee0c42bdff27705cf600d3876b2194c6c02f263b1195d50199beb81d80c1db019bb613308a2bba0277486a109ac9d7486139d23d27919335743d21939a073e588ce65dc93d5b5ac13cc6802734430971761733d249826d57f30a5afdd8019faebde941ef936aa76e2b998f01c114f9bc96df4c4f0ec09ef81d2faf2e38133f41df1b9887bf90c75caef847339c139229c3691b770e221e18c1dc0090b60178bf5084757b37ae0e36b64c6139923926933794ba65db50f1436570ec884ad2e27642ef4ce50f7323df0fb72fa6a82734438db3cded2190e1937d70ee80c1dd1b90efa927a80e3eb6bf5f5c4e7987cda54def269f795068a9ed8ec9d7e6c5514466e005de29e9da4a87d22ed7ceac4fec4e7987c5e6ec36b30610d3f149f0e36e24347a744cb459bc2bb333c1ca25d0fa0783a27d2c74f63edc5639bd4db080a780e4868e020c53b3a2a8a713fa1d1aa87d0e9b46854422f8f8b30ec320d48e82f1d18cde1bf13dbff010000ffff0300504b030414000600080000002100b1dcf1ad480100006002000011000801646f6350726f70732f636f72652e786d6c20a2040128a00001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000008c925f4bc33014c5df05bf43c97b9ba6635243dbe11f0682c38113c5b790dc6dc1260d49b4dbb737edb6daa10f3ee69e737ff7dc4b8ad94ed5d11758271b5d2292a42802cd1b21f5a6442fab799ca3c879a605ab1b0d25da8343b3eaf2a2e086f2c6c2d23606ac97e0a240d28e7253a2adf78662ecf81614734970e820ae1bab980f4fbbc186f10fb6019ca5e91556e099609ee10e189b81888e48c107a4f9b4750f101c430d0ab477982404ff783d58e5fe6ce895915349bf3761a763dc315bf08338b8774e0ec6b66d9376d2c708f9097e5b3c3ef7abc65277b7e280aa4270ca2d30dfd8ea266cbb8568f9f450e051b93b61cd9c5f846baf2588db7da5d6b55405fe2d045c9ffec00411853cf490fea4bc4eeeee577354652999c6e9754cf2559a5342683679efe69ef577f90e05759cfe7f624ea7d9887802547deef33f517d030000ffff0300504b0304140006000800000021006622820efb0100008e0b000010000000786c2f636f6d6d656e7473312e786d6cd456c18ed33010bd23f10f239fe0405d38ac5628c94ab05be85256885db8cf3a93c6526c077b5cb6fbf54c9a96030704a2918a14459ef168f2f2c6cf33c5c583eb604331d9e04bf572365740de84dafa75a9bedc2d5e9c2b488cbec62e782ad59692baa89e3e294c708e3c2790043e95aa65ee5f6b9d4c4b0ed32cf4e465a709d1218b19d73af591b04e2d11bb4ebf9acfcfb443eb555560e636c4745854d79f7347a9d0a3bf3a2c2460ffd5954dfcd380484da9de9c2918e39775a9e69295e94182a23c9fe4951e61835da9ce9516cf22781eed3b6c83c3c1a977715c5d79a60808d9db6f99607909f21740685a48863c461b668596d45ad2eaf12b7a0fec1750974706c52d0da805d500a9b13131787404986000328385109e3b313112f8c09072df87c854ff29e6ab49310bb4e3435e4c0af9de466ea146ded18ce3ead978b2c150d7c1772b010826270e6edcdf6fdb06869a991ca38805444260d3ae2e26f80d793b78c987bc6e9f1fa378ef2665e2f6f6e66da88f7adade4f0ad844aaad68c00451c3200af0d9dd8bba7f53be7dc4bf17f0af95b79c948b2d61ecb660e5761f2f8cd326e37a52321e6d0fd2e58e7a943f4c8a589a70e4ffe4165a4dcac45ea0a101275dbc9533dde3769c454e5ee21f2765065dc8d24f4e9e859b49595805f4c001beee06a55324e3302d8e63ecc14ad50f000000ffff0300504b0304140006000800000021003f9ac49e860100001a03000010000801646f6350726f70732f6170702e786d6c20a2040128a00001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009c92414fe3301085ef2bf11f22dfa94317a155e5b85a15500faca8d40267af33692c5c3bf20c51cbaf6792a8345d0e487b9b99f7f4f2653c6abedff9ac85842e86425c4d729141b0b174615b88a7cdfde52f912199501a1f0314e20028e6fae2875aa5d8402207987144c042d444cd4c4ab435ec0c4e580eac5431ed0c719bb6325695b3701beddb0e02c9699edf48d8138412cacbe633500c89b396fe37b48cb6e3c3e7cda16160ad7e378d77d610ffa5fee36c8a182bcaeef616bc92635131dd1aec5b7274d0b992e356adadf1b0e0605d198fa0e469a09660baa5ad8c4ba8554bb3162cc594a17be7b54d45f6d720743885684d7226106375b6a1e96bdf2025fd12d32bd600844ab26118f6e5d83baeddb59ef6062ece8d5dc000c2c239e2c691077cac5626d177c43dc3c03be0ac2d04068f67889fb0cbbb87d517f67e1d4cf1cf771f5c78c5a766136f0dc171afe743b5ae4d82929fe2a89f066ac92b4dbe0b59d4266ca13c7abe0add153c0fa7aeafae27f9cf9c1f783453f274d4fa030000ffff0300504b03041400060008000000210063d96af9ad010000f204000013000801646f6350726f70732f637573746f6d2e786d6c20a2040128a0000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000b494514fdb3010c7df27ed3b587e5e9c3450a05152349af2ca048517c483675fdb6c8e6dd9e7d20aedbbcf6dc946410869531e4ff7bfbb9fefce579eaf5b4556e07c637445072ca304b430b2d18b8adece2e93334a3c722db9321a2aba014fcfc79f3f95df9cb1e0b0014f620aed2bba44b4459a7ab184967b16dd3a7ae6c6b51ca3e916a999cf1b01b511a1058d699e6527a9081e4d9bd83fe9e83e5fb1c27f4d298dd8d2f9bbd9c646dc71f99c7c43e62d36b2a24ff57052d7c36c98e4d3d1241964838b6474343a4db2b32ccb2ff2c9e5e8ebf41725762bce29d1bc8d4f87b505812019ac41048c0d63129037ca33bf0440b695c56a2b2c947df4e8c6d3e70832ed2248bd8f28d3bfaa32edf8fe93f4a8237541818f402620b3dc452c8c133e4073608dc3e25e19aed9f5ce7828ae6e675f168e4b28ee7ff015678aeb05bb41179761e7ec85fab8a356467075d840d0bd941c7625bd00cd5d63de9de04d27e885e3a4e380b5504102fb1e3bfe930950ea705ae802f44270da1148f0c23576b7d5c2a8d0eab7ebfc42d30b4c3c35af7e9a031f543c1e1ffdafebbdee3daa747b0ef6c76afc1b0000ffff0300504b01022d001400060008000000210084fc57bfae010000970700001300000000000000000000000000000000005b436f6e74656e745f54797065735d2e786d6c504b01022d0014000600080000002100135ebe6505010000df0200000b00000000000000000000000000e70300005f72656c732f2e72656c73504b01022d00140006000800000021004aa9a661fa000000470300001a000000000000000000000000001d070000786c2f5f72656c732f776f726b626f6f6b2e786d6c2e72656c73504b01022d0014000600080000002100b4e4b6a8590100003f0200000f0000000000000000000000000057090000786c2f776f726b626f6f6b2e786d6c504b01022d0014000600080000002100cff7167b1a050000862200000d00000000000000000000000000dd0a0000786c2f7374796c65732e786d6c504b01022d0014000600080000002100fb62a56d94060000a71b0000130000000000000000000000000022100000786c2f7468656d652f7468656d65312e786d6c504b01022d00140006000800000021004bcce67ec0030000540e00001800000000000000000000000000e7160000786c2f776f726b7368656574732f7368656574322e786d6c504b01022d001400060008000000210042343a0be3000000460200002300000000000000000000000000dd1a0000786c2f776f726b7368656574732f5f72656c732f7368656574312e786d6c2e72656c7350');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(11, 9, NULL, '4b01022d00140006000800000021003d06b464bd0000002b0100002300000000000000000000000000011c0000786c2f776f726b7368656574732f5f72656c732f7368656574322e786d6c2e72656c73504b01022d001400060008000000210056c4669cc7000000ab0100002300000000000000000000000000ff1c0000786c2f64726177696e67732f5f72656c732f64726177696e67322e786d6c2e72656c73504b01022d000a0000000000000021000077278cb5140000b51400001300000000000000000000000000071e0000786c2f6d656469612f696d616765322e706e67504b01022d0014000600080000002100a33fddfb2f0a0000dc3700001800000000000000000000000000ed320000786c2f776f726b7368656574732f7368656574312e786d6c504b01022d000a0000000000000021004bd08478c5360000c53600001300000000000000000000000000523d0000786c2f6d656469612f696d616765312e706e67504b01022d001400060008000000210092ccdd862c020000c4060000180000000000000000000000000048740000786c2f64726177696e67732f64726177696e67322e786d6c504b01022d0014000600080000002100dde46a54f70100000b0400001800000000000000000000000000aa760000786c2f64726177696e67732f64726177696e67312e786d6c504b01022d001400060008000000210048a698f87f060000781100001400000000000000000000000000d7780000786c2f736861726564537472696e67732e786d6c504b01022d00140006000800000021007949e1e6e2030000452100001b00000000000000000000000000887f0000786c2f64726177696e67732f766d6c44726177696e67312e766d6c504b01022d0014000600080000002100b1dcf1ad48010000600200001100000000000000000000000000a3830000646f6350726f70732f636f72652e786d6c504b01022d00140006000800000021006622820efb0100008e0b0000100000000000000000000000000022860000786c2f636f6d6d656e7473312e786d6c504b01022d00140006000800000021003f9ac49e860100001a03000010000000000000000000000000004b880000646f6350726f70732f6170702e786d6c504b01022d001400060008000000210063d96af9ad010000f20400001300000000000000000000000000078b0000646f6350726f70732f637573746f6d2e786d6c504b050600000000150015008f050000ed8d00000000');     
INSERT INTO "PUBLIC"."VSINPUTDATA" VALUES
(1, 127, 100, 238, 1, 13, 'Loan Data Excel', 'e871171f-b312-42ca-82e6-98d44c94eca8', NULL, NULL, NULL, 5, SYSTEM_COMBINE_BLOB(10), 'loanvalidation-simulation.xlsx', 'ExcelFile', FALSE, NULL),
(2, 127, 238, 2147483647, 1, 13, 'Loan Data Excel', 'e871171f-b312-42ca-82e6-98d44c94eca8', NULL, NULL, NULL, 5, SYSTEM_COMBINE_BLOB(11), 'loanvalidation-simulation.xlsx', 'ExcelFile', FALSE, 5);  
CREATE INDEX "PUBLIC"."VSINPUTDATA_PRJBRANCH" ON "PUBLIC"."VSINPUTDATA"("PROJECT", "BASELINE");
CREATE UNIQUE INDEX "PUBLIC"."VSINPUTDATAUUIDUNIQUE" ON "PUBLIC"."VSINPUTDATA"("UUID", "BASELINE", "ENDID");   
CREATE INDEX "PUBLIC"."FKVSINPUTDATATYPIDX" ON "PUBLIC"."VSINPUTDATA"("TYPE"); 
CREATE INDEX "PUBLIC"."FKVSINPUTDATASTRTDIDX" ON "PUBLIC"."VSINPUTDATA"("STARTID");            
CREATE INDEX "PUBLIC"."FKVSINPUTDATANDDIDX" ON "PUBLIC"."VSINPUTDATA"("ENDID");
CREATE INDEX "PUBLIC"."FKVSINPUTDATABSLNIDX" ON "PUBLIC"."VSINPUTDATA"("BASELINE");            
CREATE INDEX "PUBLIC"."FKVSINPUTDATADIDX" ON "PUBLIC"."VSINPUTDATA"("UUID");   
CREATE INDEX "PUBLIC"."FKVSINPUTDATARLPCKGIDX" ON "PUBLIC"."VSINPUTDATA"("RULEPACKAGE");       
CREATE INDEX "PUBLIC"."FKVSINPUTDATAPRTNIDX" ON "PUBLIC"."VSINPUTDATA"("OPERATION");           
CREATE CACHED TABLE "PUBLIC"."VSKPI"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER,
    "MEASURE" CLOB(52428800),
    "ENABLED" BOOLEAN NOT NULL,
    "OPERATION" INTEGER
);      
ALTER TABLE "PUBLIC"."VSKPI" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_4E" PRIMARY KEY("ID");        
-- 52 +/- SELECT COUNT(*) FROM PUBLIC.VSKPI;   
INSERT INTO "PUBLIC"."VSKPI" VALUES
(1, 125, 112, 250, 1, 13, 'Average insurance rate', '3a9f1f4a-6509-4a95-b48d-1ce8f212d5fc', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Average"><Metric Id="13fb2d83-117e-4860-a20d-4af3e5dd1aa2" Type="number" Name="Insurance rate"/></Aggregate></Definition></Kpi>', FALSE, NULL),
(2, 125, 113, 251, 2, 13, 'Average granted loan amount', 'c410d2b9-24ab-4e52-b070-52faef32248d', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Average"><Metric Id="9d7c5dba-a4ff-494b-8638-b8b227789392" Type="number" Name="Granted loan amount"/></Aggregate></Definition></Kpi>', FALSE, NULL),
(3, 125, 114, 252, 3, 13, 'Maximum granted loan amount', 'c94eeec0-e48c-4866-ad45-b3ca93f86ead', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Max"><Metric Id="9d7c5dba-a4ff-494b-8638-b8b227789392" Type="number" Name="Granted loan amount"/></Aggregate></Definition></Kpi>', FALSE, NULL),
(4, 125, 115, 253, 4, 13, 'Minimum granted loan amount', 'a673100c-2c31-4689-94be-624adf1ecfbc', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Min"><Metric Id="9d7c5dba-a4ff-494b-8638-b8b227789392" Type="number" Name="Granted loan amount"/></Aggregate></Definition></Kpi>', FALSE, NULL),
(5, 125, 116, 254, 5, 13, 'Average interest rate', '5e8ebe3c-14f3-4367-b7e6-51fbd8ad44dc', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Average"><Metric Id="e036e33c-61f9-488a-a76c-58e927ab79ab" Type="number" Name="Interest rate"/></Aggregate></Definition></Kpi>', FALSE, NULL),
(6, 125, 117, 255, 6, 13, 'Ratio of required insurance', '6e5f028e-68e0-4db7-91eb-8b5eda29e0e1', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Ratio"><Metric Id="47e7db0c-407b-4304-9a16-d683c73e2291" Type="boolean" Name="Required insurance"/></Aggregate></Definition></Kpi>', FALSE, NULL),
(7, 125, 118, 256, 7, 13, 'Average granted loan amount by submission year', 'c95d53b0-f3f5-4c9b-b03d-f09c20d77776', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Average"><Metric Id="9d7c5dba-a4ff-494b-8638-b8b227789392" Type="number" Name="Granted loan amount"/><GroupBy><Metric Id="7539ac5f-4a30-40d0-ae3e-a781f31dddec" Type="date" Name="Loan submission date"/><DateInterval>Year</DateInterval></GroupBy></Aggregate></Definition></Kpi>', FALSE, NULL),
(8, 125, 119, 257, 8, 13, 'Scored loans by grade', 'fdb5d919-5624-46cd-bcc3-ed704c0ac3c4', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Count"><Metric Id="3518d0b4-3130-4418-8ed3-5a1f48e13727" Type="boolean" Name="Scored loan"/><GroupBy><Metric Id="95100df6-2f0e-4ab5-9127-fd2cf0847a9c" Type="string" Name="Loan grade"/></GroupBy></Aggregate></Definition></Kpi>', FALSE, NULL),
(9, 125, 120, 258, 9, 13, 'Ratio of scored loans', '5a1c14db-765e-48a7-bd8d-e99c32c1441f', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Ratio"><Metric Id="3518d0b4-3130-4418-8ed3-5a1f48e13727" Type="boolean" Name="Scored loan"/></Aggregate></Definition></Kpi>', FALSE, NULL),
(10, 125, 121, 259, 10, 13, 'Ratio of granted loans - overall', 'ca7f1b56-5bd8-411f-968e-12fe72733fa1', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Ratio"><Metric Id="34053b24-dbaf-4390-a637-e5b5afbf303a" Type="boolean" Name="Granted loan - overall"/></Aggregate></Definition></Kpi>', FALSE, NULL),
(11, 125, 122, 260, 11, 13, 'Min DTI', 'cf4a0300-92a2-4107-83f4-234cf2057836', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Min"><Metric Id="37b256af-3b6b-4f92-b514-cf2d8e3bc0d7" Type="number" Name="DTI"/></Aggregate></Definition></Kpi>', FALSE, NULL);            
INSERT INTO "PUBLIC"."VSKPI" VALUES
(12, 125, 123, 261, 12, 13, 'Average DTI', '3df57d06-a824-4ebe-bce9-cb0ddca0ed90', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Average"><Metric Id="37b256af-3b6b-4f92-b514-cf2d8e3bc0d7" Type="number" Name="DTI"/></Aggregate></Definition></Kpi>', FALSE, NULL),
(13, 125, 124, 262, 13, 13, 'Max DTI', 'e906b8eb-4289-4269-9f24-de0d7be50d56', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Max"><Metric Id="37b256af-3b6b-4f92-b514-cf2d8e3bc0d7" Type="number" Name="DTI"/></Aggregate></Definition></Kpi>', FALSE, NULL),
(14, 125, 125, 263, 14, 13, 'Average DTI by loan amount', '9b6551dd-92bb-4242-ab66-4b514583b365', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Average"><Metric Id="37b256af-3b6b-4f92-b514-cf2d8e3bc0d7" Type="number" Name="DTI"/><GroupBy><Metric Id="0c7bd617-4dd8-41fd-aba5-e3d968bc465f" Type="number" Name="Loan amount"/><NumberInterval>100000</NumberInterval></GroupBy></Aggregate></Definition></Kpi>', FALSE, NULL),
(15, 125, 126, 264, 15, 13, 'Ratio of granted loans - with scoring', '65fe17c7-bb02-4df7-a280-d94964ff4995', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Ratio"><Metric Id="ad2c05ab-2460-420f-84db-f689b257bd2a" Type="boolean" Name="Granted loan - with scoring"/></Aggregate></Definition></Kpi>', FALSE, NULL),
(16, 125, 127, 265, 16, 13, 'Ratio of granted loans by amount', 'a7821ace-49c0-4e39-b61d-b8657068372d', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Ratio"><Metric Id="ad2c05ab-2460-420f-84db-f689b257bd2a" Type="boolean" Name="Granted loan - with scoring"/><GroupBy><Metric Id="0c7bd617-4dd8-41fd-aba5-e3d968bc465f" Type="number" Name="Loan amount"/><NumberInterval>100000</NumberInterval></GroupBy></Aggregate></Definition></Kpi>', FALSE, NULL),
(17, 125, 250, 284, 1, 13, 'Average insurance rate', '3a9f1f4a-6509-4a95-b48d-1ce8f212d5fc', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Average"><Metric Id="13fb2d83-117e-4860-a20d-4af3e5dd1aa2" Type="number" Name="Insurance rate"/></Aggregate></Definition></Kpi>', FALSE, 5),
(18, 125, 251, 285, 2, 13, 'Average granted loan amount', 'c410d2b9-24ab-4e52-b070-52faef32248d', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Average"><Metric Id="9d7c5dba-a4ff-494b-8638-b8b227789392" Type="number" Name="Granted loan amount"/></Aggregate></Definition></Kpi>', FALSE, 5),
(19, 125, 252, 286, 3, 13, 'Maximum granted loan amount', 'c94eeec0-e48c-4866-ad45-b3ca93f86ead', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Max"><Metric Id="9d7c5dba-a4ff-494b-8638-b8b227789392" Type="number" Name="Granted loan amount"/></Aggregate></Definition></Kpi>', FALSE, 5),
(20, 125, 253, 287, 4, 13, 'Minimum granted loan amount', 'a673100c-2c31-4689-94be-624adf1ecfbc', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Min"><Metric Id="9d7c5dba-a4ff-494b-8638-b8b227789392" Type="number" Name="Granted loan amount"/></Aggregate></Definition></Kpi>', FALSE, 5),
(21, 125, 254, 290, 5, 13, 'Average interest rate', '5e8ebe3c-14f3-4367-b7e6-51fbd8ad44dc', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Average"><Metric Id="e036e33c-61f9-488a-a76c-58e927ab79ab" Type="number" Name="Interest rate"/></Aggregate></Definition></Kpi>', FALSE, 5),
(22, 125, 255, 291, 6, 13, 'Ratio of required insurance', '6e5f028e-68e0-4db7-91eb-8b5eda29e0e1', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Ratio"><Metric Id="47e7db0c-407b-4304-9a16-d683c73e2291" Type="boolean" Name="Required insurance"/></Aggregate></Definition></Kpi>', FALSE, 5);           
INSERT INTO "PUBLIC"."VSKPI" VALUES
(23, 125, 256, 288, 7, 13, 'Average granted loan amount by submission year', 'c95d53b0-f3f5-4c9b-b03d-f09c20d77776', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Average"><Metric Id="9d7c5dba-a4ff-494b-8638-b8b227789392" Type="number" Name="Granted loan amount"/><GroupBy><Metric Id="7539ac5f-4a30-40d0-ae3e-a781f31dddec" Type="date" Name="Loan submission date"/><DateInterval>Year</DateInterval></GroupBy></Aggregate></Definition></Kpi>', FALSE, 5),
(24, 125, 257, 289, 8, 13, 'Scored loans by grade', 'fdb5d919-5624-46cd-bcc3-ed704c0ac3c4', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Count"><Metric Id="3518d0b4-3130-4418-8ed3-5a1f48e13727" Type="boolean" Name="Scored loan"/><GroupBy><Metric Id="95100df6-2f0e-4ab5-9127-fd2cf0847a9c" Type="string" Name="Loan grade"/></GroupBy></Aggregate></Definition></Kpi>', FALSE, 5),
(25, 125, 258, 294, 9, 13, 'Ratio of scored loans', '5a1c14db-765e-48a7-bd8d-e99c32c1441f', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Ratio"><Metric Id="3518d0b4-3130-4418-8ed3-5a1f48e13727" Type="boolean" Name="Scored loan"/></Aggregate></Definition></Kpi>', FALSE, 5),
(26, 125, 259, 295, 10, 13, 'Ratio of granted loans - overall', 'ca7f1b56-5bd8-411f-968e-12fe72733fa1', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Ratio"><Metric Id="34053b24-dbaf-4390-a637-e5b5afbf303a" Type="boolean" Name="Granted loan - overall"/></Aggregate></Definition></Kpi>', FALSE, 5),
(27, 125, 260, 296, 11, 13, 'Min DTI', 'cf4a0300-92a2-4107-83f4-234cf2057836', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Min"><Metric Id="37b256af-3b6b-4f92-b514-cf2d8e3bc0d7" Type="number" Name="DTI"/></Aggregate></Definition></Kpi>', FALSE, 5),
(28, 125, 261, 297, 12, 13, 'Average DTI', '3df57d06-a824-4ebe-bce9-cb0ddca0ed90', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Average"><Metric Id="37b256af-3b6b-4f92-b514-cf2d8e3bc0d7" Type="number" Name="DTI"/></Aggregate></Definition></Kpi>', FALSE, 5),
(29, 125, 262, 298, 13, 13, 'Max DTI', 'e906b8eb-4289-4269-9f24-de0d7be50d56', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Max"><Metric Id="37b256af-3b6b-4f92-b514-cf2d8e3bc0d7" Type="number" Name="DTI"/></Aggregate></Definition></Kpi>', FALSE, 5),
(30, 125, 263, 282, 14, 13, 'Average DTI by loan amount', '9b6551dd-92bb-4242-ab66-4b514583b365', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Average"><Metric Id="37b256af-3b6b-4f92-b514-cf2d8e3bc0d7" Type="number" Name="DTI"/><GroupBy><Metric Id="0c7bd617-4dd8-41fd-aba5-e3d968bc465f" Type="number" Name="Loan amount"/><NumberInterval>100000</NumberInterval></GroupBy></Aggregate></Definition></Kpi>', FALSE, 5),
(31, 125, 264, 300, 15, 13, 'Ratio of granted loans - with scoring', '65fe17c7-bb02-4df7-a280-d94964ff4995', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Ratio"><Metric Id="ad2c05ab-2460-420f-84db-f689b257bd2a" Type="boolean" Name="Granted loan - with scoring"/></Aggregate></Definition></Kpi>', FALSE, 5),
(32, 125, 265, 283, 16, 13, 'Ratio of granted loans by amount', 'a7821ace-49c0-4e39-b61d-b8657068372d', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Ratio"><Metric Id="ad2c05ab-2460-420f-84db-f689b257bd2a" Type="boolean" Name="Granted loan - with scoring"/><GroupBy><Metric Id="0c7bd617-4dd8-41fd-aba5-e3d968bc465f" Type="number" Name="Loan amount"/><NumberInterval>100000</NumberInterval></GroupBy></Aggregate></Definition></Kpi>', FALSE, 5);      
INSERT INTO "PUBLIC"."VSKPI" VALUES
(33, 125, 282, 299, 14, 13, 'Average DTI by loan amount', '9b6551dd-92bb-4242-ab66-4b514583b365', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Average"><Metric Id="37b256af-3b6b-4f92-b514-cf2d8e3bc0d7" Type="number" Name="DTI"/><GroupBy><Metric Id="validation.Metric:1" Type="number" Name="Loan amount"/><NumberInterval>100000</NumberInterval></GroupBy></Aggregate></Definition></Kpi>', FALSE, 5),
(34, 125, 283, 301, 16, 13, 'Ratio of granted loans by amount', 'a7821ace-49c0-4e39-b61d-b8657068372d', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Ratio"><Metric Id="ad2c05ab-2460-420f-84db-f689b257bd2a" Type="boolean" Name="Granted loan - with scoring"/><GroupBy><Metric Id="validation.Metric:1" Type="number" Name="Loan amount"/><NumberInterval>100000</NumberInterval></GroupBy></Aggregate></Definition></Kpi>', FALSE, 5),
(35, 125, 284, 2147483647, 1, 13, 'Average insurance rate', '3a9f1f4a-6509-4a95-b48d-1ce8f212d5fc', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Average"><Metric Id="validation.Metric:2" Type="number" Name="Insurance rate"/></Aggregate></Definition></Kpi>', FALSE, 5),
(36, 125, 285, 2147483647, 2, 13, 'Average granted loan amount', 'c410d2b9-24ab-4e52-b070-52faef32248d', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Average"><Metric Id="validation.Metric:3" Type="number" Name="Granted loan amount"/></Aggregate></Definition></Kpi>', FALSE, 5),
(37, 125, 286, 2147483647, 3, 13, 'Maximum granted loan amount', 'c94eeec0-e48c-4866-ad45-b3ca93f86ead', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Max"><Metric Id="validation.Metric:3" Type="number" Name="Granted loan amount"/></Aggregate></Definition></Kpi>', FALSE, 5),
(38, 125, 287, 2147483647, 4, 13, 'Minimum granted loan amount', 'a673100c-2c31-4689-94be-624adf1ecfbc', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Min"><Metric Id="validation.Metric:3" Type="number" Name="Granted loan amount"/></Aggregate></Definition></Kpi>', FALSE, 5),
(39, 125, 288, 292, 7, 13, 'Average granted loan amount by submission year', 'c95d53b0-f3f5-4c9b-b03d-f09c20d77776', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Average"><Metric Id="validation.Metric:3" Type="number" Name="Granted loan amount"/><GroupBy><Metric Id="7539ac5f-4a30-40d0-ae3e-a781f31dddec" Type="date" Name="Loan submission date"/><DateInterval>Year</DateInterval></GroupBy></Aggregate></Definition></Kpi>', FALSE, 5),
(40, 125, 289, 293, 8, 13, 'Scored loans by grade', 'fdb5d919-5624-46cd-bcc3-ed704c0ac3c4', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Count"><Metric Id="3518d0b4-3130-4418-8ed3-5a1f48e13727" Type="boolean" Name="Scored loan"/><GroupBy><Metric Id="validation.Metric:4" Type="string" Name="Loan grade"/></GroupBy></Aggregate></Definition></Kpi>', FALSE, 5),
(41, 125, 290, 2147483647, 5, 13, 'Average interest rate', '5e8ebe3c-14f3-4367-b7e6-51fbd8ad44dc', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Average"><Metric Id="validation.Metric:5" Type="number" Name="Interest rate"/></Aggregate></Definition></Kpi>', FALSE, 5),
(42, 125, 291, 2147483647, 6, 13, 'Ratio of required insurance', '6e5f028e-68e0-4db7-91eb-8b5eda29e0e1', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Ratio"><Metric Id="validation.Metric:6" Type="boolean" Name="Required insurance"/></Aggregate></Definition></Kpi>', FALSE, 5);    
INSERT INTO "PUBLIC"."VSKPI" VALUES
(43, 125, 292, 2147483647, 7, 13, 'Average granted loan amount by submission year', 'c95d53b0-f3f5-4c9b-b03d-f09c20d77776', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Average"><Metric Id="validation.Metric:3" Type="number" Name="Granted loan amount"/><GroupBy><Metric Id="validation.Metric:7" Type="date" Name="Loan submission date"/><DateInterval>Year</DateInterval></GroupBy></Aggregate></Definition></Kpi>', FALSE, 5),
(44, 125, 293, 2147483647, 8, 13, 'Scored loans by grade', 'fdb5d919-5624-46cd-bcc3-ed704c0ac3c4', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Count"><Metric Id="validation.Metric:8" Type="boolean" Name="Scored loan"/><GroupBy><Metric Id="validation.Metric:4" Type="string" Name="Loan grade"/></GroupBy></Aggregate></Definition></Kpi>', FALSE, 5),
(45, 125, 294, 2147483647, 9, 13, 'Ratio of scored loans', '5a1c14db-765e-48a7-bd8d-e99c32c1441f', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Ratio"><Metric Id="validation.Metric:8" Type="boolean" Name="Scored loan"/></Aggregate></Definition></Kpi>', FALSE, 5),
(46, 125, 295, 2147483647, 10, 13, 'Ratio of granted loans - overall', 'ca7f1b56-5bd8-411f-968e-12fe72733fa1', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Ratio"><Metric Id="validation.Metric:9" Type="boolean" Name="Granted loan - overall"/></Aggregate></Definition></Kpi>', FALSE, 5),
(47, 125, 296, 2147483647, 11, 13, 'Min DTI', 'cf4a0300-92a2-4107-83f4-234cf2057836', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Min"><Metric Id="validation.Metric:10" Type="number" Name="DTI"/></Aggregate></Definition></Kpi>', FALSE, 5),
(48, 125, 297, 2147483647, 12, 13, 'Average DTI', '3df57d06-a824-4ebe-bce9-cb0ddca0ed90', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Average"><Metric Id="validation.Metric:10" Type="number" Name="DTI"/></Aggregate></Definition></Kpi>', FALSE, 5),
(49, 125, 298, 2147483647, 13, 13, 'Max DTI', 'e906b8eb-4289-4269-9f24-de0d7be50d56', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Max"><Metric Id="validation.Metric:10" Type="number" Name="DTI"/></Aggregate></Definition></Kpi>', FALSE, 5),
(50, 125, 299, 2147483647, 14, 13, 'Average DTI by loan amount', '9b6551dd-92bb-4242-ab66-4b514583b365', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Average"><Metric Id="validation.Metric:10" Type="number" Name="DTI"/><GroupBy><Metric Id="validation.Metric:1" Type="number" Name="Loan amount"/><NumberInterval>100000</NumberInterval></GroupBy></Aggregate></Definition></Kpi>', FALSE, 5),
(51, 125, 300, 2147483647, 15, 13, 'Ratio of granted loans - with scoring', '65fe17c7-bb02-4df7-a280-d94964ff4995', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Ratio"><Metric Id="validation.Metric:11" Type="boolean" Name="Granted loan - with scoring"/></Aggregate></Definition></Kpi>', FALSE, 5),
(52, 125, 301, 2147483647, 16, 13, 'Ratio of granted loans by amount', 'a7821ace-49c0-4e39-b61d-b8657068372d', NULL, NULL, NULL, 5, '<?xml version="1.0" ?><Kpi xmlns="http://schemas.ibm.com/Rules/Cdi/Kpi/8.6"><Definition><Aggregate Operator="Ratio"><Metric Id="validation.Metric:11" Type="boolean" Name="Granted loan - with scoring"/><GroupBy><Metric Id="validation.Metric:1" Type="number" Name="Loan amount"/><NumberInterval>100000</NumberInterval></GroupBy></Aggregate></Definition></Kpi>', FALSE, 5);        
CREATE INDEX "PUBLIC"."VSKPI_PRJBRANCH" ON "PUBLIC"."VSKPI"("PROJECT", "BASELINE");            
CREATE UNIQUE INDEX "PUBLIC"."VSKPIUUIDUNIQUE" ON "PUBLIC"."VSKPI"("UUID", "BASELINE", "ENDID");               
CREATE INDEX "PUBLIC"."FKVSKPITYPIDX" ON "PUBLIC"."VSKPI"("TYPE");             
CREATE INDEX "PUBLIC"."FKVSKPISTRTDIDX" ON "PUBLIC"."VSKPI"("STARTID");        
CREATE INDEX "PUBLIC"."FKVSKPINDDIDX" ON "PUBLIC"."VSKPI"("ENDID");            
CREATE INDEX "PUBLIC"."FKVSKPIBSLNIDX" ON "PUBLIC"."VSKPI"("BASELINE");        
CREATE INDEX "PUBLIC"."FKVSKPIDIDX" ON "PUBLIC"."VSKPI"("UUID");               
CREATE INDEX "PUBLIC"."FKVSKPIRLPCKGIDX" ON "PUBLIC"."VSKPI"("RULEPACKAGE");   
CREATE INDEX "PUBLIC"."FKVSKPIPRTNIDX" ON "PUBLIC"."VSKPI"("OPERATION");       
CREATE CACHED TABLE "PUBLIC"."VSMETRIC"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER,
    "DEFAULTVALUE" VARCHAR(100),
    "MAPPING" CLOB(52428800),
    "METRICTYPE" VARCHAR(30),
    "ENABLED" BOOLEAN NOT NULL,
    "OPERATION" INTEGER
);    
ALTER TABLE "PUBLIC"."VSMETRIC" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_93A" PRIMARY KEY("ID");    
-- 22 +/- SELECT COUNT(*) FROM PUBLIC.VSMETRIC;
INSERT INTO "PUBLIC"."VSMETRIC" VALUES
(1, 124, 101, 239, 1, 13, 'Loan amount', '0c7bd617-4dd8-41fd-aba5-e3d968bc465f', NULL, NULL, NULL, 5, NULL, 'the amount of ''the loan''', 'Numeric', FALSE, NULL),
(2, 124, 102, 240, 2, 13, 'Insurance rate', '13fb2d83-117e-4860-a20d-4af3e5dd1aa2', NULL, NULL, NULL, 5, NULL, 'the insurance rate of ''the loan report'' when the insurance rate of ''the loan report'' is more than 0', 'Numeric', FALSE, NULL),
(3, 124, 103, 241, 3, 13, 'Granted loan amount', '9d7c5dba-a4ff-494b-8638-b8b227789392', NULL, NULL, NULL, 5, NULL, 'the amount of ''the loan'' when ''the loan report'' is approved', 'Numeric', FALSE, NULL),
(4, 124, 104, 242, 4, 13, 'Loan grade', '95100df6-2f0e-4ab5-9127-fd2cf0847a9c', NULL, NULL, NULL, 5, NULL, '''the grade''', 'String', FALSE, NULL),
(5, 124, 105, 243, 5, 13, 'Interest rate', 'e036e33c-61f9-488a-a76c-58e927ab79ab', NULL, NULL, NULL, 5, NULL, 'the yearly interest rate of ''the loan report'' when ''the loan report'' is approved', 'Numeric', FALSE, NULL),
(6, 124, 106, 244, 6, 13, 'Required insurance', '47e7db0c-407b-4304-9a16-d683c73e2291', NULL, NULL, NULL, 5, NULL, '''the loan report'' is insurance required when ''the loan report'' is approved', 'Boolean', FALSE, NULL),
(7, 124, 107, 245, 7, 13, 'Loan submission date', '7539ac5f-4a30-40d0-ae3e-a781f31dddec', NULL, NULL, NULL, 5, NULL, 'the start date of ''the loan''', 'DateTime', FALSE, NULL),
(8, 124, 108, 246, 8, 13, 'Scored loan', '3518d0b4-3130-4418-8ed3-5a1f48e13727', NULL, NULL, NULL, 5, NULL, '''the grade'' is not null', 'Boolean', FALSE, NULL),
(9, 124, 109, 247, 9, 13, 'Granted loan - overall', '34053b24-dbaf-4390-a637-e5b5afbf303a', NULL, NULL, NULL, 5, NULL, '''the loan report'' is approved', 'Boolean', FALSE, NULL),
(10, 124, 110, 248, 10, 13, 'DTI', '37b256af-3b6b-4f92-b514-cf2d8e3bc0d7', NULL, NULL, NULL, 5, NULL, 'the yearly repayment of ''the loan report'' / the yearly income of ''the borrower'' when the yearly repayment of ''the loan report'' is more than 0', 'Numeric', FALSE, NULL),
(11, 124, 111, 249, 11, 13, 'Granted loan - with scoring', 'ad2c05ab-2460-420f-84db-f689b257bd2a', NULL, NULL, NULL, 5, NULL, '''the loan report'' is approved when  ''the grade'' is not null', 'Boolean', FALSE, NULL),
(12, 124, 239, 2147483647, 1, 13, 'Loan amount', '0c7bd617-4dd8-41fd-aba5-e3d968bc465f', NULL, NULL, NULL, 5, NULL, 'the amount of ''the loan''', 'Numeric', FALSE, 5),
(13, 124, 240, 2147483647, 2, 13, 'Insurance rate', '13fb2d83-117e-4860-a20d-4af3e5dd1aa2', NULL, NULL, NULL, 5, NULL, 'the insurance rate of ''the loan report'' when the insurance rate of ''the loan report'' is more than 0', 'Numeric', FALSE, 5),
(14, 124, 241, 2147483647, 3, 13, 'Granted loan amount', '9d7c5dba-a4ff-494b-8638-b8b227789392', NULL, NULL, NULL, 5, NULL, 'the amount of ''the loan'' when ''the loan report'' is approved', 'Numeric', FALSE, 5),
(15, 124, 242, 2147483647, 4, 13, 'Loan grade', '95100df6-2f0e-4ab5-9127-fd2cf0847a9c', NULL, NULL, NULL, 5, NULL, '''the grade''', 'String', FALSE, 5),
(16, 124, 243, 2147483647, 5, 13, 'Interest rate', 'e036e33c-61f9-488a-a76c-58e927ab79ab', NULL, NULL, NULL, 5, NULL, 'the yearly interest rate of ''the loan report'' when ''the loan report'' is approved', 'Numeric', FALSE, 5),
(17, 124, 244, 2147483647, 6, 13, 'Required insurance', '47e7db0c-407b-4304-9a16-d683c73e2291', NULL, NULL, NULL, 5, NULL, '''the loan report'' is insurance required when ''the loan report'' is approved', 'Boolean', FALSE, 5),
(18, 124, 245, 2147483647, 7, 13, 'Loan submission date', '7539ac5f-4a30-40d0-ae3e-a781f31dddec', NULL, NULL, NULL, 5, NULL, 'the start date of ''the loan''', 'DateTime', FALSE, 5),
(19, 124, 246, 2147483647, 8, 13, 'Scored loan', '3518d0b4-3130-4418-8ed3-5a1f48e13727', NULL, NULL, NULL, 5, NULL, '''the grade'' is not null', 'Boolean', FALSE, 5),
(20, 124, 247, 2147483647, 9, 13, 'Granted loan - overall', '34053b24-dbaf-4390-a637-e5b5afbf303a', NULL, NULL, NULL, 5, NULL, '''the loan report'' is approved', 'Boolean', FALSE, 5),
(21, 124, 248, 2147483647, 10, 13, 'DTI', '37b256af-3b6b-4f92-b514-cf2d8e3bc0d7', NULL, NULL, NULL, 5, NULL, 'the yearly repayment of ''the loan report'' / the yearly income of ''the borrower'' when the yearly repayment of ''the loan report'' is more than 0', 'Numeric', FALSE, 5);        
INSERT INTO "PUBLIC"."VSMETRIC" VALUES
(22, 124, 249, 2147483647, 11, 13, 'Granted loan - with scoring', 'ad2c05ab-2460-420f-84db-f689b257bd2a', NULL, NULL, NULL, 5, NULL, '''the loan report'' is approved when  ''the grade'' is not null', 'Boolean', FALSE, 5);           
CREATE INDEX "PUBLIC"."VSMETRIC_PRJBRANCH" ON "PUBLIC"."VSMETRIC"("PROJECT", "BASELINE");      
CREATE UNIQUE INDEX "PUBLIC"."VSMETRICUUIDUNIQUE" ON "PUBLIC"."VSMETRIC"("UUID", "BASELINE", "ENDID");         
CREATE INDEX "PUBLIC"."FKVSMETRICTYPIDX" ON "PUBLIC"."VSMETRIC"("TYPE");       
CREATE INDEX "PUBLIC"."FKVSMETRICSTRTDIDX" ON "PUBLIC"."VSMETRIC"("STARTID");  
CREATE INDEX "PUBLIC"."FKVSMETRICNDDIDX" ON "PUBLIC"."VSMETRIC"("ENDID");      
CREATE INDEX "PUBLIC"."FKVSMETRICBSLNIDX" ON "PUBLIC"."VSMETRIC"("BASELINE");  
CREATE INDEX "PUBLIC"."FKVSMETRICDIDX" ON "PUBLIC"."VSMETRIC"("UUID");         
CREATE INDEX "PUBLIC"."FKVSMETRICRLPCKGIDX" ON "PUBLIC"."VSMETRIC"("RULEPACKAGE");             
CREATE INDEX "PUBLIC"."FKVSMETRICPRTNIDX" ON "PUBLIC"."VSMETRIC"("OPERATION"); 
CREATE CACHED TABLE "PUBLIC"."VSMODEL"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER,
    "REPORTCONFIGURATION" CLOB(52428800),
    "ENABLED" BOOLEAN NOT NULL,
    "OPERATION" INTEGER
);        
ALTER TABLE "PUBLIC"."VSMODEL" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_57" PRIMARY KEY("ID");      
-- 12 +/- SELECT COUNT(*) FROM PUBLIC.VSMODEL; 
INSERT INTO SYSTEM_LOB_STREAM VALUES(12, 0, '[{"name":"Approval","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - overall","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - overall","operationName":"loan validation with score and grade","id":"ca7f1b56-5bd8-411f-968e-12fe72733fa1","lastChangedBy":"odmAdmin","operation":"9017e68b-1f53-496e-998f-5d41393e1c84"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - overall: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - with scoring","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - with scoring","operationName":"loan validation with score and grade","id":"65fe17c7-bb02-4df7-a280-d94964ff4995","lastChangedBy":"odmAdmin","operation":"9017e68b-1f53-496e-998f-5d41393e1c84"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - with scoring: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of scored loans","lockMessage":null,"valueType":"NUMBER","name":"Ratio of scored loans","operationName":"loan validation with score and grade","id":"5a1c14db-765e-48a7-bd8d-e99c32c1441f","lastChangedBy":"odmAdmin","operation":"9017e68b-1f53-496e-998f-5d41393e1c84"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of scored loans: </b>${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"COUNT","displayName":"Scored loans by grade","lockMessage":null,"valueType":"NUMBER","groupingType":"STRING","name":"Scored loans by grade","operationName":"loan validation with score and grade","id":"fdb5d919-5624-46cd-bcc3-ed704c0ac3c4","lastChangedBy":"odmAdmin","operation":"9017e68b-1f53-496e-998f-5d41393e1c84"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"chartType":"PIE","dataLabel":"PERCENTAGE","palette":["#2D7FB5","#42B0A1","#ED742D","#DEA10A","#973D99","#50923D"],"title":"Loan grade distribution"}}},{"kpis":[{"groupingInterval":100000,"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans by amount","lockMessage":null,"valueType":"NUMBER","groupingType":"NUMBER","name":"Ratio of granted loans by amount","operationName":"loan validation with score and grade","id":"a7821ace-49c0-4e39-b61d-b8657068372d","lastChangedBy":"odmAdmin","operation":"9017e68b-1f53-496e-998f-5d41393e1c84"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"outlineWidth":"3","chartType":"LINE","xAxisTitle":"Amount","palette":["#50923d"],"title":"Ratio of granted loans by amount","yLabelFormat":"##0.#%","xLabelFormat":"$###,##0","yAxisTitle":"Granted loan (%)"}}}]}]},{"name":"Amounts","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MIN","displayName":"Minimum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Minimum granted loan amount","operationName":"loan validation with score and grade","id":"a673100c-2c31-4689-94be-624adf1ecfbc","lastChangedBy":"odmAdmin","operation":"9017e68b-1f53-496e-998f-5d41393e1c84"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Minimum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Average granted loan amount","operationName":"loan validation w', NULL);         
INSERT INTO SYSTEM_LOB_STREAM VALUES(12, 1, 'ith score and grade","id":"c410d2b9-24ab-4e52-b070-52faef32248d","lastChangedBy":"odmAdmin","operation":"9017e68b-1f53-496e-998f-5d41393e1c84"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Average granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MAX","displayName":"Maximum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Maximum granted loan amount","operationName":"loan validation with score and grade","id":"c94eeec0-e48c-4866-ad45-b3ca93f86ead","lastChangedBy":"odmAdmin","operation":"9017e68b-1f53-496e-998f-5d41393e1c84"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Maximum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"groupingInterval":"YEAR","lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount by submission year","lockMessage":null,"valueType":"NUMBER","groupingType":"DATE","name":"Average granted loan amount by submission year","operationName":"loan validation with score and grade","id":"c95d53b0-f3f5-4c9b-b03d-f09c20d77776","lastChangedBy":"odmAdmin","operation":"9017e68b-1f53-496e-998f-5d41393e1c84"}]}]}]}]', NULL);               
INSERT INTO SYSTEM_LOB_STREAM VALUES(13, 0, '[{"name":"Approval","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - overall","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - overall","operationName":"loan validation with score and grade","id":"ca7f1b56-5bd8-411f-968e-12fe72733fa1","lastChangedBy":"odmAdmin","operation":"9017e68b-1f53-496e-998f-5d41393e1c84"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - overall: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - with scoring","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - with scoring","operationName":"loan validation with score and grade","id":"65fe17c7-bb02-4df7-a280-d94964ff4995","lastChangedBy":"odmAdmin","operation":"9017e68b-1f53-496e-998f-5d41393e1c84"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - with scoring: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of scored loans","lockMessage":null,"valueType":"NUMBER","name":"Ratio of scored loans","operationName":"loan validation with score and grade","id":"5a1c14db-765e-48a7-bd8d-e99c32c1441f","lastChangedBy":"odmAdmin","operation":"9017e68b-1f53-496e-998f-5d41393e1c84"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of scored loans: </b>${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"COUNT","displayName":"Scored loans by grade","lockMessage":null,"valueType":"NUMBER","groupingType":"STRING","name":"Scored loans by grade","operationName":"loan validation with score and grade","id":"fdb5d919-5624-46cd-bcc3-ed704c0ac3c4","lastChangedBy":"odmAdmin","operation":"9017e68b-1f53-496e-998f-5d41393e1c84"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"chartType":"PIE","dataLabel":"PERCENTAGE","palette":["#2D7FB5","#42B0A1","#ED742D","#DEA10A","#973D99","#50923D"],"title":"Loan grade distribution"}}},{"kpis":[{"groupingInterval":100000,"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans by amount","lockMessage":null,"valueType":"NUMBER","groupingType":"NUMBER","name":"Ratio of granted loans by amount","operationName":"loan validation with score and grade","id":"a7821ace-49c0-4e39-b61d-b8657068372d","lastChangedBy":"odmAdmin","operation":"9017e68b-1f53-496e-998f-5d41393e1c84"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"outlineWidth":"3","chartType":"LINE","xAxisTitle":"Amount","palette":["#50923d"],"title":"Ratio of granted loans by amount","yLabelFormat":"##0.#%","xLabelFormat":"$###,##0","yAxisTitle":"Granted loan (%)"}}}]}]},{"name":"Amounts","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MIN","displayName":"Minimum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Minimum granted loan amount","operationName":"loan validation with score and grade","id":"a673100c-2c31-4689-94be-624adf1ecfbc","lastChangedBy":"odmAdmin","operation":"9017e68b-1f53-496e-998f-5d41393e1c84"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Minimum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Average granted loan amount","operationName":"loan validation w', NULL);         
INSERT INTO SYSTEM_LOB_STREAM VALUES(13, 1, 'ith score and grade","id":"c410d2b9-24ab-4e52-b070-52faef32248d","lastChangedBy":"odmAdmin","operation":"9017e68b-1f53-496e-998f-5d41393e1c84"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Average granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MAX","displayName":"Maximum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Maximum granted loan amount","operationName":"loan validation with score and grade","id":"c94eeec0-e48c-4866-ad45-b3ca93f86ead","lastChangedBy":"odmAdmin","operation":"9017e68b-1f53-496e-998f-5d41393e1c84"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Maximum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"groupingInterval":"YEAR","lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount by submission year","lockMessage":null,"valueType":"NUMBER","groupingType":"DATE","name":"Average granted loan amount by submission year","operationName":"loan validation with score and grade","id":"c95d53b0-f3f5-4c9b-b03d-f09c20d77776","lastChangedBy":"odmAdmin","operation":"9017e68b-1f53-496e-998f-5d41393e1c84"}]}]}]}]', NULL);               
INSERT INTO SYSTEM_LOB_STREAM VALUES(14, 0, '[{"name":"Approval","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - overall","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - overall","operationName":"loan validation with score and grade","id":"ca7f1b56-5bd8-411f-968e-12fe72733fa1","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - overall: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - with scoring","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - with scoring","operationName":"loan validation with score and grade","id":"65fe17c7-bb02-4df7-a280-d94964ff4995","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - with scoring: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of scored loans","lockMessage":null,"valueType":"NUMBER","name":"Ratio of scored loans","operationName":"loan validation with score and grade","id":"5a1c14db-765e-48a7-bd8d-e99c32c1441f","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of scored loans: </b>${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"COUNT","displayName":"Scored loans by grade","lockMessage":null,"valueType":"NUMBER","groupingType":"STRING","name":"Scored loans by grade","operationName":"loan validation with score and grade","id":"fdb5d919-5624-46cd-bcc3-ed704c0ac3c4","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"chartType":"PIE","dataLabel":"PERCENTAGE","palette":["#2D7FB5","#42B0A1","#ED742D","#DEA10A","#973D99","#50923D"],"title":"Loan grade distribution"}}},{"kpis":[{"groupingInterval":100000,"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans by amount","lockMessage":null,"valueType":"NUMBER","groupingType":"NUMBER","name":"Ratio of granted loans by amount","operationName":"loan validation with score and grade","id":"a7821ace-49c0-4e39-b61d-b8657068372d","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"outlineWidth":"3","chartType":"LINE","xAxisTitle":"Amount","palette":["#50923d"],"title":"Ratio of granted loans by amount","yLabelFormat":"##0.#%","xLabelFormat":"$###,##0","yAxisTitle":"Granted loan (%)"}}}]}]},{"name":"Amounts","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MIN","displayName":"Minimum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Minimum granted loan amount","operationName":"loan validation with score and grade","id":"a673100c-2c31-4689-94be-624adf1ecfbc","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Minimum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Average granted loan amount","operationName":"loan validation with score and grade","id":"c410d2b9-24ab-4e52-b070-52faef32248d","lastChangedBy":"odmAdmin","operation":"dsm.Opera', NULL);         
INSERT INTO SYSTEM_LOB_STREAM VALUES(14, 1, 'tion:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Average granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MAX","displayName":"Maximum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Maximum granted loan amount","operationName":"loan validation with score and grade","id":"c94eeec0-e48c-4866-ad45-b3ca93f86ead","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Maximum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"groupingInterval":"YEAR","lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount by submission year","lockMessage":null,"valueType":"NUMBER","groupingType":"DATE","name":"Average granted loan amount by submission year","operationName":"loan validation with score and grade","id":"c95d53b0-f3f5-4c9b-b03d-f09c20d77776","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}]}]}]}]', NULL);          
INSERT INTO SYSTEM_LOB_STREAM VALUES(15, 0, '[{"name":"Approval","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - overall","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - overall","operationName":"loan validation with score and grade","id":"ca7f1b56-5bd8-411f-968e-12fe72733fa1","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - overall: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - with scoring","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - with scoring","operationName":"loan validation with score and grade","id":"65fe17c7-bb02-4df7-a280-d94964ff4995","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - with scoring: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of scored loans","lockMessage":null,"valueType":"NUMBER","name":"Ratio of scored loans","operationName":"loan validation with score and grade","id":"5a1c14db-765e-48a7-bd8d-e99c32c1441f","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of scored loans: </b>${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"COUNT","displayName":"Scored loans by grade","lockMessage":null,"valueType":"NUMBER","groupingType":"STRING","name":"Scored loans by grade","operationName":"loan validation with score and grade","id":"fdb5d919-5624-46cd-bcc3-ed704c0ac3c4","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"chartType":"PIE","dataLabel":"PERCENTAGE","palette":["#2D7FB5","#42B0A1","#ED742D","#DEA10A","#973D99","#50923D"],"title":"Loan grade distribution"}}},{"kpis":[{"groupingInterval":100000,"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans by amount","lockMessage":null,"valueType":"NUMBER","groupingType":"NUMBER","name":"Ratio of granted loans by amount","operationName":"loan validation with score and grade","id":"a7821ace-49c0-4e39-b61d-b8657068372d","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"outlineWidth":"3","chartType":"LINE","xAxisTitle":"Amount","palette":["#50923d"],"title":"Ratio of granted loans by amount","yLabelFormat":"##0.#%","xLabelFormat":"$###,##0","yAxisTitle":"Granted loan (%)"}}}]}]},{"name":"Amounts","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MIN","displayName":"Minimum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Minimum granted loan amount","operationName":"loan validation with score and grade","id":"a673100c-2c31-4689-94be-624adf1ecfbc","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Minimum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Average granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:2","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"display', NULL);         
INSERT INTO SYSTEM_LOB_STREAM VALUES(15, 1, 'Configuration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Average granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MAX","displayName":"Maximum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Maximum granted loan amount","operationName":"loan validation with score and grade","id":"c94eeec0-e48c-4866-ad45-b3ca93f86ead","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Maximum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"groupingInterval":"YEAR","lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount by submission year","lockMessage":null,"valueType":"NUMBER","groupingType":"DATE","name":"Average granted loan amount by submission year","operationName":"loan validation with score and grade","id":"c95d53b0-f3f5-4c9b-b03d-f09c20d77776","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}]}]}]}]', NULL);              
INSERT INTO SYSTEM_LOB_STREAM VALUES(16, 0, '[{"name":"Approval","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - overall","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - overall","operationName":"loan validation with score and grade","id":"ca7f1b56-5bd8-411f-968e-12fe72733fa1","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - overall: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - with scoring","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - with scoring","operationName":"loan validation with score and grade","id":"65fe17c7-bb02-4df7-a280-d94964ff4995","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - with scoring: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of scored loans","lockMessage":null,"valueType":"NUMBER","name":"Ratio of scored loans","operationName":"loan validation with score and grade","id":"5a1c14db-765e-48a7-bd8d-e99c32c1441f","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of scored loans: </b>${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"COUNT","displayName":"Scored loans by grade","lockMessage":null,"valueType":"NUMBER","groupingType":"STRING","name":"Scored loans by grade","operationName":"loan validation with score and grade","id":"fdb5d919-5624-46cd-bcc3-ed704c0ac3c4","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"chartType":"PIE","dataLabel":"PERCENTAGE","palette":["#2D7FB5","#42B0A1","#ED742D","#DEA10A","#973D99","#50923D"],"title":"Loan grade distribution"}}},{"kpis":[{"groupingInterval":100000,"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans by amount","lockMessage":null,"valueType":"NUMBER","groupingType":"NUMBER","name":"Ratio of granted loans by amount","operationName":"loan validation with score and grade","id":"a7821ace-49c0-4e39-b61d-b8657068372d","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"outlineWidth":"3","chartType":"LINE","xAxisTitle":"Amount","palette":["#50923d"],"title":"Ratio of granted loans by amount","yLabelFormat":"##0.#%","xLabelFormat":"$###,##0","yAxisTitle":"Granted loan (%)"}}}]}]},{"name":"Amounts","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MIN","displayName":"Minimum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Minimum granted loan amount","operationName":"loan validation with score and grade","id":"a673100c-2c31-4689-94be-624adf1ecfbc","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Minimum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Average granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:2","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"display', NULL);         
INSERT INTO SYSTEM_LOB_STREAM VALUES(16, 1, 'Configuration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Average granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MAX","displayName":"Maximum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Maximum granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:3","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Maximum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"groupingInterval":"YEAR","lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount by submission year","lockMessage":null,"valueType":"NUMBER","groupingType":"DATE","name":"Average granted loan amount by submission year","operationName":"loan validation with score and grade","id":"c95d53b0-f3f5-4c9b-b03d-f09c20d77776","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}]}]}]}]', NULL);  
INSERT INTO SYSTEM_LOB_STREAM VALUES(17, 0, '[{"name":"Approval","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - overall","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - overall","operationName":"loan validation with score and grade","id":"ca7f1b56-5bd8-411f-968e-12fe72733fa1","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - overall: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - with scoring","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - with scoring","operationName":"loan validation with score and grade","id":"65fe17c7-bb02-4df7-a280-d94964ff4995","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - with scoring: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of scored loans","lockMessage":null,"valueType":"NUMBER","name":"Ratio of scored loans","operationName":"loan validation with score and grade","id":"5a1c14db-765e-48a7-bd8d-e99c32c1441f","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of scored loans: </b>${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"COUNT","displayName":"Scored loans by grade","lockMessage":null,"valueType":"NUMBER","groupingType":"STRING","name":"Scored loans by grade","operationName":"loan validation with score and grade","id":"fdb5d919-5624-46cd-bcc3-ed704c0ac3c4","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"chartType":"PIE","dataLabel":"PERCENTAGE","palette":["#2D7FB5","#42B0A1","#ED742D","#DEA10A","#973D99","#50923D"],"title":"Loan grade distribution"}}},{"kpis":[{"groupingInterval":100000,"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans by amount","lockMessage":null,"valueType":"NUMBER","groupingType":"NUMBER","name":"Ratio of granted loans by amount","operationName":"loan validation with score and grade","id":"a7821ace-49c0-4e39-b61d-b8657068372d","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"outlineWidth":"3","chartType":"LINE","xAxisTitle":"Amount","palette":["#50923d"],"title":"Ratio of granted loans by amount","yLabelFormat":"##0.#%","xLabelFormat":"$###,##0","yAxisTitle":"Granted loan (%)"}}}]}]},{"name":"Amounts","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MIN","displayName":"Minimum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Minimum granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:4","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Minimum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Average granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:2","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"dis', NULL);         
INSERT INTO SYSTEM_LOB_STREAM VALUES(17, 1, 'playType":"TEXT","displayOptions":{"htmlTemplate":"<b>Average granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MAX","displayName":"Maximum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Maximum granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:3","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Maximum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"groupingInterval":"YEAR","lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount by submission year","lockMessage":null,"valueType":"NUMBER","groupingType":"DATE","name":"Average granted loan amount by submission year","operationName":"loan validation with score and grade","id":"c95d53b0-f3f5-4c9b-b03d-f09c20d77776","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}]}]}]}]', NULL);      
INSERT INTO SYSTEM_LOB_STREAM VALUES(18, 0, '[{"name":"Approval","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - overall","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - overall","operationName":"loan validation with score and grade","id":"ca7f1b56-5bd8-411f-968e-12fe72733fa1","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - overall: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - with scoring","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - with scoring","operationName":"loan validation with score and grade","id":"65fe17c7-bb02-4df7-a280-d94964ff4995","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - with scoring: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of scored loans","lockMessage":null,"valueType":"NUMBER","name":"Ratio of scored loans","operationName":"loan validation with score and grade","id":"5a1c14db-765e-48a7-bd8d-e99c32c1441f","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of scored loans: </b>${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"COUNT","displayName":"Scored loans by grade","lockMessage":null,"valueType":"NUMBER","groupingType":"STRING","name":"Scored loans by grade","operationName":"loan validation with score and grade","id":"fdb5d919-5624-46cd-bcc3-ed704c0ac3c4","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"chartType":"PIE","dataLabel":"PERCENTAGE","palette":["#2D7FB5","#42B0A1","#ED742D","#DEA10A","#973D99","#50923D"],"title":"Loan grade distribution"}}},{"kpis":[{"groupingInterval":100000,"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans by amount","lockMessage":null,"valueType":"NUMBER","groupingType":"NUMBER","name":"Ratio of granted loans by amount","operationName":"loan validation with score and grade","id":"a7821ace-49c0-4e39-b61d-b8657068372d","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"outlineWidth":"3","chartType":"LINE","xAxisTitle":"Amount","palette":["#50923d"],"title":"Ratio of granted loans by amount","yLabelFormat":"##0.#%","xLabelFormat":"$###,##0","yAxisTitle":"Granted loan (%)"}}}]}]},{"name":"Amounts","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MIN","displayName":"Minimum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Minimum granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:4","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Minimum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Average granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:2","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"dis', NULL);         
INSERT INTO SYSTEM_LOB_STREAM VALUES(18, 1, 'playType":"TEXT","displayOptions":{"htmlTemplate":"<b>Average granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MAX","displayName":"Maximum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Maximum granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:3","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Maximum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"groupingInterval":"YEAR","lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount by submission year","lockMessage":null,"valueType":"NUMBER","groupingType":"DATE","name":"Average granted loan amount by submission year","operationName":"loan validation with score and grade","id":"validation.KPI:7","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}]}]}]}]', NULL);          
INSERT INTO SYSTEM_LOB_STREAM VALUES(19, 0, '[{"name":"Approval","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - overall","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - overall","operationName":"loan validation with score and grade","id":"ca7f1b56-5bd8-411f-968e-12fe72733fa1","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - overall: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - with scoring","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - with scoring","operationName":"loan validation with score and grade","id":"65fe17c7-bb02-4df7-a280-d94964ff4995","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - with scoring: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of scored loans","lockMessage":null,"valueType":"NUMBER","name":"Ratio of scored loans","operationName":"loan validation with score and grade","id":"5a1c14db-765e-48a7-bd8d-e99c32c1441f","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of scored loans: </b>${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"COUNT","displayName":"Scored loans by grade","lockMessage":null,"valueType":"NUMBER","groupingType":"STRING","name":"Scored loans by grade","operationName":"loan validation with score and grade","id":"validation.KPI:8","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"chartType":"PIE","dataLabel":"PERCENTAGE","palette":["#2D7FB5","#42B0A1","#ED742D","#DEA10A","#973D99","#50923D"],"title":"Loan grade distribution"}}},{"kpis":[{"groupingInterval":100000,"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans by amount","lockMessage":null,"valueType":"NUMBER","groupingType":"NUMBER","name":"Ratio of granted loans by amount","operationName":"loan validation with score and grade","id":"a7821ace-49c0-4e39-b61d-b8657068372d","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"outlineWidth":"3","chartType":"LINE","xAxisTitle":"Amount","palette":["#50923d"],"title":"Ratio of granted loans by amount","yLabelFormat":"##0.#%","xLabelFormat":"$###,##0","yAxisTitle":"Granted loan (%)"}}}]}]},{"name":"Amounts","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MIN","displayName":"Minimum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Minimum granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:4","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Minimum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Average granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:2","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","di', NULL);         
INSERT INTO SYSTEM_LOB_STREAM VALUES(19, 1, 'splayOptions":{"htmlTemplate":"<b>Average granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MAX","displayName":"Maximum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Maximum granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:3","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Maximum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"groupingInterval":"YEAR","lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount by submission year","lockMessage":null,"valueType":"NUMBER","groupingType":"DATE","name":"Average granted loan amount by submission year","operationName":"loan validation with score and grade","id":"validation.KPI:7","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}]}]}]}]', NULL);              
INSERT INTO SYSTEM_LOB_STREAM VALUES(20, 0, '[{"name":"Approval","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - overall","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - overall","operationName":"loan validation with score and grade","id":"ca7f1b56-5bd8-411f-968e-12fe72733fa1","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - overall: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - with scoring","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - with scoring","operationName":"loan validation with score and grade","id":"65fe17c7-bb02-4df7-a280-d94964ff4995","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - with scoring: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of scored loans","lockMessage":null,"valueType":"NUMBER","name":"Ratio of scored loans","operationName":"loan validation with score and grade","id":"validation.KPI:9","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of scored loans: </b>${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"COUNT","displayName":"Scored loans by grade","lockMessage":null,"valueType":"NUMBER","groupingType":"STRING","name":"Scored loans by grade","operationName":"loan validation with score and grade","id":"validation.KPI:8","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"chartType":"PIE","dataLabel":"PERCENTAGE","palette":["#2D7FB5","#42B0A1","#ED742D","#DEA10A","#973D99","#50923D"],"title":"Loan grade distribution"}}},{"kpis":[{"groupingInterval":100000,"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans by amount","lockMessage":null,"valueType":"NUMBER","groupingType":"NUMBER","name":"Ratio of granted loans by amount","operationName":"loan validation with score and grade","id":"a7821ace-49c0-4e39-b61d-b8657068372d","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"outlineWidth":"3","chartType":"LINE","xAxisTitle":"Amount","palette":["#50923d"],"title":"Ratio of granted loans by amount","yLabelFormat":"##0.#%","xLabelFormat":"$###,##0","yAxisTitle":"Granted loan (%)"}}}]}]},{"name":"Amounts","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MIN","displayName":"Minimum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Minimum granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:4","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Minimum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Average granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:2","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"html', NULL);         
INSERT INTO SYSTEM_LOB_STREAM VALUES(20, 1, 'Template":"<b>Average granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MAX","displayName":"Maximum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Maximum granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:3","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Maximum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"groupingInterval":"YEAR","lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount by submission year","lockMessage":null,"valueType":"NUMBER","groupingType":"DATE","name":"Average granted loan amount by submission year","operationName":"loan validation with score and grade","id":"validation.KPI:7","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}]}]}]}]', NULL);  
INSERT INTO SYSTEM_LOB_STREAM VALUES(21, 0, '[{"name":"Approval","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - overall","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - overall","operationName":"loan validation with score and grade","id":"validation.KPI:10","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - overall: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - with scoring","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - with scoring","operationName":"loan validation with score and grade","id":"65fe17c7-bb02-4df7-a280-d94964ff4995","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - with scoring: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of scored loans","lockMessage":null,"valueType":"NUMBER","name":"Ratio of scored loans","operationName":"loan validation with score and grade","id":"validation.KPI:9","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of scored loans: </b>${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"COUNT","displayName":"Scored loans by grade","lockMessage":null,"valueType":"NUMBER","groupingType":"STRING","name":"Scored loans by grade","operationName":"loan validation with score and grade","id":"validation.KPI:8","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"chartType":"PIE","dataLabel":"PERCENTAGE","palette":["#2D7FB5","#42B0A1","#ED742D","#DEA10A","#973D99","#50923D"],"title":"Loan grade distribution"}}},{"kpis":[{"groupingInterval":100000,"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans by amount","lockMessage":null,"valueType":"NUMBER","groupingType":"NUMBER","name":"Ratio of granted loans by amount","operationName":"loan validation with score and grade","id":"a7821ace-49c0-4e39-b61d-b8657068372d","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"outlineWidth":"3","chartType":"LINE","xAxisTitle":"Amount","palette":["#50923d"],"title":"Ratio of granted loans by amount","yLabelFormat":"##0.#%","xLabelFormat":"$###,##0","yAxisTitle":"Granted loan (%)"}}}]}]},{"name":"Amounts","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MIN","displayName":"Minimum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Minimum granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:4","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Minimum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Average granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:2","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Avera', NULL);         
INSERT INTO SYSTEM_LOB_STREAM VALUES(21, 1, 'ge granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MAX","displayName":"Maximum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Maximum granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:3","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Maximum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"groupingInterval":"YEAR","lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount by submission year","lockMessage":null,"valueType":"NUMBER","groupingType":"DATE","name":"Average granted loan amount by submission year","operationName":"loan validation with score and grade","id":"validation.KPI:7","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}]}]}]}]', NULL);     
INSERT INTO SYSTEM_LOB_STREAM VALUES(22, 0, '[{"name":"Approval","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - overall","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - overall","operationName":"loan validation with score and grade","id":"validation.KPI:10","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - overall: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - with scoring","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - with scoring","operationName":"loan validation with score and grade","id":"validation.KPI:15","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - with scoring: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of scored loans","lockMessage":null,"valueType":"NUMBER","name":"Ratio of scored loans","operationName":"loan validation with score and grade","id":"validation.KPI:9","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of scored loans: </b>${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"COUNT","displayName":"Scored loans by grade","lockMessage":null,"valueType":"NUMBER","groupingType":"STRING","name":"Scored loans by grade","operationName":"loan validation with score and grade","id":"validation.KPI:8","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"chartType":"PIE","dataLabel":"PERCENTAGE","palette":["#2D7FB5","#42B0A1","#ED742D","#DEA10A","#973D99","#50923D"],"title":"Loan grade distribution"}}},{"kpis":[{"groupingInterval":100000,"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans by amount","lockMessage":null,"valueType":"NUMBER","groupingType":"NUMBER","name":"Ratio of granted loans by amount","operationName":"loan validation with score and grade","id":"a7821ace-49c0-4e39-b61d-b8657068372d","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"outlineWidth":"3","chartType":"LINE","xAxisTitle":"Amount","palette":["#50923d"],"title":"Ratio of granted loans by amount","yLabelFormat":"##0.#%","xLabelFormat":"$###,##0","yAxisTitle":"Granted loan (%)"}}}]}]},{"name":"Amounts","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MIN","displayName":"Minimum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Minimum granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:4","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Minimum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Average granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:2","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Average granted loan amo', NULL);         
INSERT INTO SYSTEM_LOB_STREAM VALUES(22, 1, 'unt: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MAX","displayName":"Maximum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Maximum granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:3","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Maximum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"groupingInterval":"YEAR","lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount by submission year","lockMessage":null,"valueType":"NUMBER","groupingType":"DATE","name":"Average granted loan amount by submission year","operationName":"loan validation with score and grade","id":"validation.KPI:7","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}]}]}]}]', NULL);        
INSERT INTO SYSTEM_LOB_STREAM VALUES(23, 0, '[{"name":"Approval","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - overall","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - overall","operationName":"loan validation with score and grade","id":"validation.KPI:10","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - overall: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans - with scoring","lockMessage":null,"valueType":"NUMBER","name":"Ratio of granted loans - with scoring","operationName":"loan validation with score and grade","id":"validation.KPI:15","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of granted loans - with scoring: </b> ${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of scored loans","lockMessage":null,"valueType":"NUMBER","name":"Ratio of scored loans","operationName":"loan validation with score and grade","id":"validation.KPI:9","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Ratio of scored loans: </b>${value}","pattern":"##0.#%"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"COUNT","displayName":"Scored loans by grade","lockMessage":null,"valueType":"NUMBER","groupingType":"STRING","name":"Scored loans by grade","operationName":"loan validation with score and grade","id":"validation.KPI:8","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"chartType":"PIE","dataLabel":"PERCENTAGE","palette":["#2D7FB5","#42B0A1","#ED742D","#DEA10A","#973D99","#50923D"],"title":"Loan grade distribution"}}},{"kpis":[{"groupingInterval":100000,"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"RATIO","displayName":"Ratio of granted loans by amount","lockMessage":null,"valueType":"NUMBER","groupingType":"NUMBER","name":"Ratio of granted loans by amount","operationName":"loan validation with score and grade","id":"validation.KPI:16","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"CHART","displayOptions":{"outlineWidth":"3","chartType":"LINE","xAxisTitle":"Amount","palette":["#50923d"],"title":"Ratio of granted loans by amount","yLabelFormat":"##0.#%","xLabelFormat":"$###,##0","yAxisTitle":"Granted loan (%)"}}}]}]},{"name":"Amounts","columns":[{"parts":[{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MIN","displayName":"Minimum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Minimum granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:4","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Minimum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Average granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:2","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Average granted loan amount: </b> ${value}"', NULL);         
INSERT INTO SYSTEM_LOB_STREAM VALUES(23, 1, ',"pattern":"$###,##0"}}},{"kpis":[{"lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"MAX","displayName":"Maximum granted loan amount","lockMessage":null,"valueType":"NUMBER","name":"Maximum granted loan amount","operationName":"loan validation with score and grade","id":"validation.KPI:3","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}],"displayConfiguration":{"displayType":"TEXT","displayOptions":{"htmlTemplate":"<b>Maximum granted loan amount: </b> ${value}","pattern":"$###,##0"}}},{"kpis":[{"groupingInterval":"YEAR","lastChangedOn":{"formatted":"December 19, 2022 at 1:48 PM","timestamp":1671454091000},"aggregateOperator":"AVERAGE","displayName":"Average granted loan amount by submission year","lockMessage":null,"valueType":"NUMBER","groupingType":"DATE","name":"Average granted loan amount by submission year","operationName":"loan validation with score and grade","id":"validation.KPI:7","lastChangedBy":"odmAdmin","operation":"dsm.Operation:5:5"}]}]}]}]', NULL);           
INSERT INTO "PUBLIC"."VSMODEL" VALUES
(1, 126, 99, 236, 1, 13, 'Loan Report Template', '7acb83d6-6aec-4e0a-b03b-1a852dfa276d', NULL, '', NULL, 5, SYSTEM_COMBINE_CLOB(12), FALSE, NULL),
(2, 126, 236, 237, 1, 13, 'Loan Report Template', '7acb83d6-6aec-4e0a-b03b-1a852dfa276d', NULL, '', NULL, 5, SYSTEM_COMBINE_CLOB(13), FALSE, 5),
(3, 126, 237, 302, 1, 13, 'Loan Report Template', '7acb83d6-6aec-4e0a-b03b-1a852dfa276d', NULL, '', NULL, 5, SYSTEM_COMBINE_CLOB(14), FALSE, 5),
(4, 126, 302, 303, 1, 13, 'Loan Report Template', '7acb83d6-6aec-4e0a-b03b-1a852dfa276d', NULL, '', NULL, 5, SYSTEM_COMBINE_CLOB(15), FALSE, 5),
(5, 126, 303, 304, 1, 13, 'Loan Report Template', '7acb83d6-6aec-4e0a-b03b-1a852dfa276d', NULL, '', NULL, 5, SYSTEM_COMBINE_CLOB(16), FALSE, 5),
(6, 126, 304, 305, 1, 13, 'Loan Report Template', '7acb83d6-6aec-4e0a-b03b-1a852dfa276d', NULL, '', NULL, 5, SYSTEM_COMBINE_CLOB(17), FALSE, 5),
(7, 126, 305, 306, 1, 13, 'Loan Report Template', '7acb83d6-6aec-4e0a-b03b-1a852dfa276d', NULL, '', NULL, 5, SYSTEM_COMBINE_CLOB(18), FALSE, 5),
(8, 126, 306, 307, 1, 13, 'Loan Report Template', '7acb83d6-6aec-4e0a-b03b-1a852dfa276d', NULL, '', NULL, 5, SYSTEM_COMBINE_CLOB(19), FALSE, 5),
(9, 126, 307, 308, 1, 13, 'Loan Report Template', '7acb83d6-6aec-4e0a-b03b-1a852dfa276d', NULL, '', NULL, 5, SYSTEM_COMBINE_CLOB(20), FALSE, 5),
(10, 126, 308, 309, 1, 13, 'Loan Report Template', '7acb83d6-6aec-4e0a-b03b-1a852dfa276d', NULL, '', NULL, 5, SYSTEM_COMBINE_CLOB(21), FALSE, 5),
(11, 126, 309, 310, 1, 13, 'Loan Report Template', '7acb83d6-6aec-4e0a-b03b-1a852dfa276d', NULL, '', NULL, 5, SYSTEM_COMBINE_CLOB(22), FALSE, 5),
(12, 126, 310, 2147483647, 1, 13, 'Loan Report Template', '7acb83d6-6aec-4e0a-b03b-1a852dfa276d', NULL, '', NULL, 5, SYSTEM_COMBINE_CLOB(23), FALSE, 5);  
CREATE INDEX "PUBLIC"."VSMODEL_PRJBRANCH" ON "PUBLIC"."VSMODEL"("PROJECT", "BASELINE");        
CREATE UNIQUE INDEX "PUBLIC"."VSMODELUUIDUNIQUE" ON "PUBLIC"."VSMODEL"("UUID", "BASELINE", "ENDID");           
CREATE INDEX "PUBLIC"."FKVSMODELTYPIDX" ON "PUBLIC"."VSMODEL"("TYPE");         
CREATE INDEX "PUBLIC"."FKVSMODELSTRTDIDX" ON "PUBLIC"."VSMODEL"("STARTID");    
CREATE INDEX "PUBLIC"."FKVSMODELNDDIDX" ON "PUBLIC"."VSMODEL"("ENDID");        
CREATE INDEX "PUBLIC"."FKVSMODELBSLNIDX" ON "PUBLIC"."VSMODEL"("BASELINE");    
CREATE INDEX "PUBLIC"."FKVSMODELDIDX" ON "PUBLIC"."VSMODEL"("UUID");           
CREATE INDEX "PUBLIC"."FKVSMODELRLPCKGIDX" ON "PUBLIC"."VSMODEL"("RULEPACKAGE");               
CREATE INDEX "PUBLIC"."FKVSMODELPRTNIDX" ON "PUBLIC"."VSMODEL"("OPERATION");   
CREATE CACHED TABLE "PUBLIC"."VSCONFIG"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER,
    "DATAPARAMS" CLOB(52428800),
    "INPUTDATA" INTEGER,
    "REPORTNAME" VARCHAR(255),
    "RUNBASELINE" INTEGER,
    "SERVER" INTEGER,
    "SIMULATIONMODEL" INTEGER,
    "ENABLED" BOOLEAN NOT NULL,
    "OPERATION" INTEGER
);        
ALTER TABLE "PUBLIC"."VSCONFIG" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_83" PRIMARY KEY("ID");     
-- 4 +/- SELECT COUNT(*) FROM PUBLIC.VSCONFIG; 
INSERT INTO "PUBLIC"."VSCONFIG" VALUES
(1, 129, 98, 235, 1, 13, 'File Simulation', 'f471d78a-6d65-4402-8361-24e106ad9ae1', NULL, '', NULL, 5, '[]', NULL, 'File Simulation Report', NULL, 2, NULL, FALSE, NULL),
(2, 129, 235, 280, 1, 13, 'File Simulation', 'f471d78a-6d65-4402-8361-24e106ad9ae1', NULL, '', NULL, 5, '[]', NULL, 'File Simulation Report', NULL, 2, NULL, FALSE, 5),
(3, 129, 280, 281, 1, 13, 'File Simulation', 'f471d78a-6d65-4402-8361-24e106ad9ae1', NULL, '', NULL, 5, '[]', NULL, 'File Simulation Report', NULL, 2, 1, FALSE, 5),
(4, 129, 281, 2147483647, 1, 13, 'File Simulation', 'f471d78a-6d65-4402-8361-24e106ad9ae1', NULL, '', NULL, 5, '[]', 1, 'File Simulation Report', NULL, 2, 1, FALSE, 5);         
CREATE INDEX "PUBLIC"."VSCONFIG_PRJBRANCH" ON "PUBLIC"."VSCONFIG"("PROJECT", "BASELINE");      
CREATE UNIQUE INDEX "PUBLIC"."VSCONFIGUUIDUNIQUE" ON "PUBLIC"."VSCONFIG"("UUID", "BASELINE", "ENDID");         
CREATE INDEX "PUBLIC"."FKVSCONFIGTYPIDX" ON "PUBLIC"."VSCONFIG"("TYPE");       
CREATE INDEX "PUBLIC"."FKVSCONFIGSTRTDIDX" ON "PUBLIC"."VSCONFIG"("STARTID");  
CREATE INDEX "PUBLIC"."FKVSCONFIGNDDIDX" ON "PUBLIC"."VSCONFIG"("ENDID");      
CREATE INDEX "PUBLIC"."FKVSCONFIGBSLNIDX" ON "PUBLIC"."VSCONFIG"("BASELINE");  
CREATE INDEX "PUBLIC"."FKVSCONFIGDIDX" ON "PUBLIC"."VSCONFIG"("UUID");         
CREATE INDEX "PUBLIC"."FKVSCONFIGRLPCKGIDX" ON "PUBLIC"."VSCONFIG"("RULEPACKAGE");             
CREATE INDEX "PUBLIC"."FKVSCONFIGNPTDTIDX" ON "PUBLIC"."VSCONFIG"("INPUTDATA");
CREATE INDEX "PUBLIC"."FKVSCONFIGSMLTNMDLIDX" ON "PUBLIC"."VSCONFIG"("SIMULATIONMODEL");       
CREATE INDEX "PUBLIC"."FKVSCONFIGPRTNIDX" ON "PUBLIC"."VSCONFIG"("OPERATION"); 
CREATE CACHED TABLE "PUBLIC"."VSREPORT"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CREATEDBY" VARCHAR(100),
    "CREATEDON" TIMESTAMP,
    "LASTCHANGEDBY" VARCHAR(100),
    "LASTCHANGEDON" TIMESTAMP,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER,
    "ERRORSCENARIOCOUNT" INTEGER,
    "ESTIMATEDSCENARIOCOUNT" INTEGER,
    "EXECUTEDSCENARIOCOUNT" INTEGER,
    "JOBENDTIME" TIMESTAMP,
    "JOBID" VARCHAR(30),
    "PROGRESS" INTEGER,
    "REPORTBASELINE" INTEGER NOT NULL,
    "RESULT" CLOB(52428800),
    "SIMULATIONCONFIGURATION" INTEGER,
    "STARTDATE" TIMESTAMP,
    "STATUS" VARCHAR(30),
    "ENABLED" BOOLEAN NOT NULL,
    "OPERATION" INTEGER
);               
ALTER TABLE "PUBLIC"."VSREPORT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_9C2" PRIMARY KEY("ID");    
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.VSREPORT; 
CREATE UNIQUE INDEX "PUBLIC"."VSREPORTUUIDUNIQUE" ON "PUBLIC"."VSREPORT"("UUID");              
CREATE INDEX "PUBLIC"."FKVSREPORTTYPIDX" ON "PUBLIC"."VSREPORT"("TYPE");       
CREATE INDEX "PUBLIC"."FKVSREPORTRLPCKGIDX" ON "PUBLIC"."VSREPORT"("RULEPACKAGE");             
CREATE INDEX "PUBLIC"."FKVSREPORTSMLTNCNFGRTNIDX" ON "PUBLIC"."VSREPORT"("SIMULATIONCONFIGURATION");           
CREATE INDEX "PUBLIC"."FKVSREPORTPRTNIDX" ON "PUBLIC"."VSREPORT"("OPERATION"); 
CREATE CACHED TABLE "PUBLIC"."VTREPORT"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "CREATEDBY" VARCHAR(100),
    "CREATEDON" TIMESTAMP,
    "LASTCHANGEDBY" VARCHAR(100),
    "LASTCHANGEDON" TIMESTAMP,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER,
    "ARCHIVEERRORS" BOOLEAN,
    "ARCHIVEWARNINGS" BOOLEAN,
    "ERROR" BLOB,
    "JOBID" VARCHAR(255),
    "NBERRORS" INTEGER NOT NULL,
    "NBEXECUTED" INTEGER NOT NULL,
    "NBFAILURES" INTEGER NOT NULL,
    "NBSCENARIOS" INTEGER NOT NULL,
    "OPERATIONID" VARCHAR(100) NOT NULL,
    "ORIGINALBASELINE" INTEGER NOT NULL,
    "REPORTBASELINE" INTEGER NOT NULL,
    "SERVERKIND" VARCHAR(30),
    "STATUS" VARCHAR(30),
    "TESTSUITEID" VARCHAR(100),
    "ENABLED" BOOLEAN NOT NULL,
    "OPERATION" INTEGER
);     
ALTER TABLE "PUBLIC"."VTREPORT" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_D10" PRIMARY KEY("ID");    
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.VTREPORT; 
CREATE UNIQUE INDEX "PUBLIC"."VTREPORTUUIDUNIQUE" ON "PUBLIC"."VTREPORT"("UUID");              
CREATE INDEX "PUBLIC"."FKVTREPORTTYPIDX" ON "PUBLIC"."VTREPORT"("TYPE");       
CREATE INDEX "PUBLIC"."FKVTREPORTRLPCKGIDX" ON "PUBLIC"."VTREPORT"("RULEPACKAGE");             
CREATE INDEX "PUBLIC"."FKVTREPORTPRTNIDX" ON "PUBLIC"."VTREPORT"("OPERATION"); 
CREATE CACHED TABLE "PUBLIC"."VTDETAIL"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "EXECUTIONDETAIL" BLOB,
    "EXECUTIONID" VARCHAR(255),
    "SCENARIORESULT" BLOB,
    "TESTRESULT" BLOB,
    "CONTAINER" INTEGER NOT NULL
);             
ALTER TABLE "PUBLIC"."VTDETAIL" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_B9" PRIMARY KEY("ID");     
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.VTDETAIL; 
CREATE INDEX "PUBLIC"."VTDETAIL_CONTAINER" ON "PUBLIC"."VTDETAIL"("CONTAINER");
CREATE INDEX "PUBLIC"."FKVTDETAILTYPIDX" ON "PUBLIC"."VTDETAIL"("TYPE");       
CREATE CACHED TABLE "PUBLIC"."VTROINFO"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "EXTRACTOR" VARCHAR(255),
    "NAME" VARCHAR(255) NOT NULL,
    "OPERATIONID" VARCHAR(100) NOT NULL,
    "RULEFLOWENTRYPOINT" VARCHAR(255),
    "TARGETPROJECTNAME" VARCHAR(255),
    "CONTAINER" INTEGER NOT NULL
);     
ALTER TABLE "PUBLIC"."VTROINFO" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_D19" PRIMARY KEY("ID");    
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.VTROINFO; 
CREATE UNIQUE INDEX "PUBLIC"."VTROINFOCONTAINERUNIQUE" ON "PUBLIC"."VTROINFO"("CONTAINER");    
CREATE INDEX "PUBLIC"."FKVTROINFOTYPIDX" ON "PUBLIC"."VTROINFO"("TYPE");       
CREATE CACHED TABLE "PUBLIC"."VTRTSINFO"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "COMPARISIONPRECISION" INTEGER NOT NULL,
    "CREATEIOFILE" BOOLEAN,
    "NAME" VARCHAR(255) NOT NULL,
    "SCENARIOFILENAME" VARCHAR(255),
    "SERVERNAME" VARCHAR(255),
    "SNAPSHOT" BOOLEAN NOT NULL,
    "TESTSUITEID" VARCHAR(100) NOT NULL,
    "VERSION" VARCHAR(30) NOT NULL,
    "CONTAINER" INTEGER NOT NULL
);             
ALTER TABLE "PUBLIC"."VTRTSINFO" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_6A" PRIMARY KEY("ID");    
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.VTRTSINFO;
CREATE UNIQUE INDEX "PUBLIC"."VTRTSINFOCONTAINERUNIQUE" ON "PUBLIC"."VTRTSINFO"("CONTAINER");  
CREATE INDEX "PUBLIC"."FKVTRTSINFOTYPIDX" ON "PUBLIC"."VTRTSINFO"("TYPE");     
CREATE CACHED TABLE "PUBLIC"."VTSUITE"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER,
    "CREATEIOFILE" BOOLEAN,
    "DESCRIPTORFORMAT" VARCHAR(30),
    "DESCRIPTORXML" BLOB,
    "LASTTESTCASEUPLOADON" TIMESTAMP,
    "REPORTNAME" VARCHAR(255),
    "RUNBASELINE" INTEGER,
    "SERVERNAME" VARCHAR(255),
    "ENABLED" BOOLEAN NOT NULL,
    "OPERATION" INTEGER
);         
ALTER TABLE "PUBLIC"."VTSUITE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_59" PRIMARY KEY("ID");      
-- 2 +/- SELECT COUNT(*) FROM PUBLIC.VTSUITE;  
INSERT INTO "PUBLIC"."VTSUITE" VALUES
(1, 132, 97, 234, 1, 13, 'Main Scoring test suite', 'ad67b0f6-5623-443e-a4fd-503eb91efbc6', NULL, NULL, NULL, 5, FALSE, 'Excel2007Tabbed', X'3c3f786d6c2076657273696f6e3d22312e302220656e636f64696e673d225554462d38223f3e0a3c21444f43545950452070726f706572746965732053595354454d2022687474703a2f2f6a6176612e73756e2e636f6d2f6474642f70726f706572746965732e647464223e0a3c70726f706572746965733e0a3c636f6d6d656e742f3e0a3c656e747279206b65793d227363656e6172696f2e70726f76696465722e636c617373223e696c6f672e72756c65732e6476732e636f72652e7363656e6172696f70726f7669646572732e496c72457863656c323030335363656e6172696f50726f76696465723c2f656e7472793e0a3c656e747279206b65793d2276657273696f6e223e6a72756c65732d372e302e303c2f656e7472793e0a3c656e747279206b65793d22666f726d61742e70726f70657274696573223e6f66666963652e76657273696f6e3c2f656e7472793e0a3c656e747279206b65793d22666f726d61742e6e616d65223e457863656c323030375461626265643c2f656e7472793e0a3c656e747279206b65793d226e756d6265722e6f662e6469676974732e72696768742e746f2e7468652e646563696d616c2e706f696e742e666f722e636f6d70617269736f6e73223e2d313c2f656e7472793e0a3c656e747279206b65793d22666f726d61742e70726f70657274792e6f66666963652e76657273696f6e223e323030373c2f656e7472793e0a3c2f70726f706572746965733e0a', NULL, 'Report', NULL, 'Test and Simulation Execution', FALSE, NULL),
(2, 132, 234, 2147483647, 1, 13, 'Main Scoring test suite', 'ad67b0f6-5623-443e-a4fd-503eb91efbc6', NULL, NULL, NULL, 5, FALSE, 'Excel2007Tabbed', X'3c3f786d6c2076657273696f6e3d22312e302220656e636f64696e673d225554462d38223f3e0a3c21444f43545950452070726f706572746965732053595354454d2022687474703a2f2f6a6176612e73756e2e636f6d2f6474642f70726f706572746965732e647464223e0a3c70726f706572746965733e0a3c636f6d6d656e742f3e0a3c656e747279206b65793d227363656e6172696f2e70726f76696465722e636c617373223e696c6f672e72756c65732e6476732e636f72652e7363656e6172696f70726f7669646572732e496c72457863656c323030335363656e6172696f50726f76696465723c2f656e7472793e0a3c656e747279206b65793d2276657273696f6e223e6a72756c65732d372e302e303c2f656e7472793e0a3c656e747279206b65793d22666f726d61742e70726f70657274696573223e6f66666963652e76657273696f6e3c2f656e7472793e0a3c656e747279206b65793d22666f726d61742e6e616d65223e457863656c323030375461626265643c2f656e7472793e0a3c656e747279206b65793d226e756d6265722e6f662e6469676974732e72696768742e746f2e7468652e646563696d616c2e706f696e742e666f722e636f6d70617269736f6e73223e2d313c2f656e7472793e0a3c656e747279206b65793d22666f726d61742e70726f70657274792e6f66666963652e76657273696f6e223e323030373c2f656e7472793e0a3c2f70726f706572746965733e0a', NULL, 'Report', NULL, 'Test and Simulation Execution', FALSE, 5);       
CREATE INDEX "PUBLIC"."VTSUITE_PRJBRANCH" ON "PUBLIC"."VTSUITE"("PROJECT", "BASELINE");        
CREATE UNIQUE INDEX "PUBLIC"."VTSUITEUUIDUNIQUE" ON "PUBLIC"."VTSUITE"("UUID", "BASELINE", "ENDID");           
CREATE INDEX "PUBLIC"."FKVTSUITETYPIDX" ON "PUBLIC"."VTSUITE"("TYPE");         
CREATE INDEX "PUBLIC"."FKVTSUITESTRTDIDX" ON "PUBLIC"."VTSUITE"("STARTID");    
CREATE INDEX "PUBLIC"."FKVTSUITENDDIDX" ON "PUBLIC"."VTSUITE"("ENDID");        
CREATE INDEX "PUBLIC"."FKVTSUITEBSLNIDX" ON "PUBLIC"."VTSUITE"("BASELINE");    
CREATE INDEX "PUBLIC"."FKVTSUITEDIDX" ON "PUBLIC"."VTSUITE"("UUID");           
CREATE INDEX "PUBLIC"."FKVTSUITERLPCKGIDX" ON "PUBLIC"."VTSUITE"("RULEPACKAGE");               
CREATE INDEX "PUBLIC"."FKVTSUITEPRTNIDX" ON "PUBLIC"."VTSUITE"("OPERATION");   
CREATE CACHED TABLE "PUBLIC"."VTCRESOURCE"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "ILRKEY" VARCHAR(255),
    "NUMBEROFTESTCASES" INTEGER,
    "VALUE" BLOB,
    "CONTAINER" INTEGER NOT NULL
);        
ALTER TABLE "PUBLIC"."VTCRESOURCE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_15" PRIMARY KEY("ID");  
-- 1 +/- SELECT COUNT(*) FROM PUBLIC.VTCRESOURCE;              
INSERT INTO SYSTEM_LOB_STREAM VALUES(24, 0, NULL, '504b0304140006000800000021003d0acfd7c40100009e090000130008025b436f6e74656e745f54797065735d2e786d6c20a2040228a000020000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000cc56cb4eeb3010dd23f10f91b7578dcb4308a1a62c2e972520011f60ec6963357ec8e396f6ef19272d82aa6d8852e9b28913dbe731763ce3d1edd254d902026a670b76960f5906563aa5edb460af2ff7836b9661145689ca5928d80a90dd8e4f4f462f2b0f9811da62c1ca18fd0de7284b300273e7c1d2c8c40523227d8629f742cec414f8f97078c5a5b3116c1cc4c4c1c6a33b98887915b37f4bea6e9c783b65d9df665e922a9836099ffaf94e44800ab720c2fb4a4b112936beb06acbd760ed2927643d074bedf10f19dfa39046be7bfa2ab01fb73888db61cc4d265a8272726e689972c2df05f14e5b928c3dd26e05ad207b12213e08434bc397157f7761f6e6dc2c3fecb25d0d7d00a1b00488a6caeb363742dbcdc21cd0af2723af9bb3231b49f1d5c41d7d9cff121f17bfc4c7e57ff211293500af9ffd7f8d9aa6e547c0b8aa008f1c6d43daa65c8a00ea39063ab14737f095bbc5876a9206f2f54bff755f13b5e84a6752dec2fe7adf73d186b7457e3becfe19a05bd8fdf58e1276ff84f383b0a9463d05e7914a7a80ee676d5381137ae0890842d4f0598377959a4f45aabddd05b72a2ba40b8702d5555bce313ad35bbea1d921ceebdbd5f8030000ffff0300504b030414000600080000002100135ebe6505010000df0200000b0008025f72656c732f2e72656c7320a2040228a000020000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ac92cf4ec3300cc6ef48bc4394fbea6e2084d0d25d26a4dd102a0f6012f78fdac6519241f7f60424049546bb03c7d89f3ffffc29dbdd38f4e28d7c68d92ab9ce7229c86a36adad957c291f57f7528488d660cf96943c5190bbe2fa6afb4c3dc634149ad605915c6c50b289d13d0004ddd08021634736752af603c6f4f43538d41dd6049b3cbf03ffdb4316134f71304afa83b991a23cb9b479d99babaad5b4677d1cc8c6332b80c648d69059399fd87c6cd335a2445f5354d2b07e4ae500e85c96b0259c27da5c4ef4f7b5305044831141b3a7799e4fc51cd0fa72a0e588a68a9f74c61eded977afccdd1ccbed7fb2e863883c2c84f3a5f94682c9b72c3e000000ffff0300504b030414000600080000002100815bb8c91a010000610400001a000801786c2f5f72656c732f776f726b626f6f6b2e786d6c2e72656c7320a2040128a0000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000bc94cb6ac3301045f785fe83987d2ddb49d3522267530ad9b6e907087bfc20b66434d387ffbec24de50682bb31dd086606dd7bb88cb4dd7d76ad7847478d350a9228068126b745632a05af87a79b7b10c4da14bab506150c48b0cbaeafb6cfd86af697a86e7a125ec590829ab97f9092f21a3b4d91edd1f849695da7d997ae92bdce8fba4299c6f146badf1a909d698a7da1c0ed8b1588c3d07be7bfb56d5936393edafcad43c3172ce4877547aa11d98b6a57212b082d92e364157962909761ee9684a15a3b2c5ed8f9ac69023a6bcfc1a44bc284182690d03a2593cec124ff0c93ccc16c9684211e5abff46161beeb39fbdb25edd93f259cdcc7528ee76c04eb2519c2264c1ca1755a8ef54f20f2ec63c8be000000ffff0300504b030414000600080000002100749fccd1b20100001e0300000f000000786c2f776f726b626f6f6b2e786d6c8c524d4fe33010bdafb4ffc16b715d92ba1f62ab2608445720ad108202c795b1278d856347b64bcabf67ec5030372e7166c6efcdbc375e9dee3b4d5ec079654d4527c72525608495ca6c2b7abff9fbfb84121fb8915c5b03157d054f4feb9f3f568375cf4fd63e132430bea26d08fdb228bc68a1e3fed8f660b0d258d7f180a1db16be77c0a56f0142a70b56968ba2e3cad09161e9bec3619b4609b8b062d78109238903cd038eef5bd57b5aaf1aa5e161544478df5ff30ee7de6b4a34f7612d550059d1398676802f09b7ebcf774a63f5cfb49cd2a2fe1079e3888486ef74d8a0bc033bfac5668c2de2cd68c58382c17f826248f68fca483b5494cd4fd0dbd74338c56048a54725438b75369fe15063ee12d4b60d91bf9c60928ba05e60c39f30139b1559b7e427764d273149ec9d00c39db21e7717edbe4249134adc52e18fbb92892407acf73d08f485dc824791398e6538169be7b8ffd2c615e6f7a7e9bd04b4bc555202aef7a36db234875faeffdd6423ceb2bbb3a4335d467168be3220e32abf46ef82c731ce687d18e8d7d1d9d164891fb62a32305a97454825b816b8dc784493cad4f5f0b4eb37000000ffff0300504b030414000600080000002100703ee3da750400001414000018000000786c2f776f726b7368656574732f7368656574342e786d6c9c585d6f9b4a107dbf52ff03e2bdc66076135bb6ab5651d53c54aaae6e6f9f09ac6d1460119038f9f79d59be963543a12f0984d9737666cecc6c76ffe92d4dac575194b1cc0eb6bb5adb96c84219c5d9f960fffcefebc77bdb2aab208b824466e260bf8bd2fe74fcf0cffe2a8be7f22244650142561eec4b55e53bc729c38b488372257391c197932cd2a082d7e2ec94792182482d4a13c75bafb993067166d708bb620e863c9de2503cc8f025155955831422092ad87f7989f3b2454bc3397069503cbfe41f4399e600f1142771f5ae406d2b0d778fe74c16c153027ebfb97e10b6d8eae5063e8dc34296f254ad00cea9377aebf3d6d93a8074dc4731788061b70a713ad89fbddde3cfbbb5ed1cf72a42ffc7e25a6acf1606fc49ca67fcf0181d6c65eadcd87e5501ff51589138052f49f5afbc7e13f1f95241761938807eeca2f707518610408059790c494399001dfcb4d21895000108ded4ef6b1c559783edaf5c7fcdc118f4f08e21f17cdb0a5fca4aa6bf6a0bb7c1a911bc06017e3708aec757de3d73d902944d8bc280b8c151926cb7005b77eabdab503c045570dc17f26a819c80bacc0314a7bb83678c8177371a039f4146425cf3190cc1ae84f7d7e37aefbc227ef3ed0b0202066ca533f17967e3006dc70dc1d1b9c7e3de72827107687222107072cdc4bf1be7041b9d53f90b2127d3ded2ebd8263d629af4f7e3f498172ddcd32e8331e93202d5a9ea4cfced38a70b0d4b27553e837847c8377d8e7155076d7aac20815edf21eb8d065976c7243627e4b890de41a3b3ad66c35c22008b84e64e290d3f42dc37e3c119f8ed415dde847d8edfb890f45ba1c206207f9d0df3c6fd568d68b6da0625dbe75255fc170565e88d6d085ae81fbae3233a03b8b6b0b0db749edcd0221478ab2b81f904eda2da1a48f786b6aeae016d6f33cc32087081b3ba5c7bc426c608653acbc69d4501cea725e45ad32a2883b6dfdac05954dd02565da33d62c38a50062b23e604e66101ad2e961bdaba6dccc9ecc6a8df6919a335296305653a4b0ca8cda26685d6346dd3acc6b736cc2c9e59b456a1ce42dbd5f858d4a6043c4ef02328b8adef91118371b3a869a035ed76d334f41ecd88d9b831ca77f6790017d23b682a590f0eefa53888bcbfa8a6d09aa45550106fdd718ad56896e837ba342d725f9ff73d725dd1f811b33d709a98c86c51fb426bd2690505b4fa018d130391198d64de490857d1f47543198c134e0c466694f66cb1e1427a0775950f4ebf9c9891f81f825ee6d3e9466b9a16a18c536f2f8981c4d9df1eba7121bd8191633727c62533e4fe07bfa764aea0e6151937f23dcd8ad6a4b30a0a58f5bec78971c9172519ad69daf949e67f9b645c486f602cc9c4e4e48b46085ad3b4f50819d414216e6e486b5e27c555343b421aa5c589b9c98d01f6078d4d4d2d0565d0124ec325cca08fccee64b890f45ba11a1be0e6e0aeaf73ea3b8c3c388bef41718eb3d24ac40980d72bc85c51dfe5a8e74ae6eaaf20e42759c1454cfb76817b36019719eb151c8f4e5256ed0bdc9644457085db3d');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(24, 1, NULL, 'abd8c5d1c12e1e23756de374f779c7df000000ffff0300504b03040a0000000000000021000077278cb5140000b514000013000000786c2f6d656469612f696d616765322e706e6789504e470d0a1a0a0000000d49484452000001280000007b080200000048088aa30000002b744558744372656174696f6e2054696d650057656420332044656320323030382031353a34363a3136202b3031303069fd92ff0000000774494d4507d80c030e2f0cf4c82f41000000097048597300000ec300000ec301c76fa8640000000467414d410000b18f0bfc61050000140d4944415478daed9dfd6b1b499ac79f0efe030626c7782761d3c2c3c57b1826c126e3908148383f4871200c18ecfdc173071299f5e5c23020453066608e90058d0443980bda0912ecae614938c3dd40bcd20f315260433c212613ceec3a90a0f6e2cdfab809f327e8eaaddfa496d4adb76ab59f0f4e6895aa5af574d7d3f554777dab957abd0ede79befbfafdc977bb28e85b8264d1a8db32eaf57763e011d9754090c3083a1e8248001d0f4124808e87201240c7431009a0e3218804c69eefbeeea2d8a95f1c935d7304196194ee9ee3298a527f2abbee08329a2833186a22880cd0f11044027d76bcd40c28d740eba2e401c448d95bb28f07820c857e381ef119741804f142cf8e47bcee1294659b8120a3c5588fe58b3799d7ad81b20615fd3ee7ca8c70c5e4b7909d1689240acdf1ad65a87fda7a87d720f1986e14ee437cbc3111ce42ed1b504177f86548aed1dd56ee43c6faf129849d4af114feadf61d846e40f40b285dd6aba76773a8aafde74e9dfaa71f7ef8b3ec73d71f4efd233cfb83ec4a1c3e7a75bcf82aacb316c91be806f9f71816ee43699cb5f24f609eb572b359b316ac400bdf5b03b80ff5719a3f71092658d9ea2dea2ddc0f497ae89aee7b2c3fd97f16a86364ac1f5b949abb40abb7b10de169d0349aadfc00b4cba06e53778a5ed0bdae5555d7844312afabd7f7649fbbfea028276457e1303280bb9a67618ef55413efd1ff5f1d00589a358c437a99b6e0aa63d965d1cbcd2feb658947add9d31fc3e681f95baafda7c5c716a5d40f200ab0b34f1337d620c9d235d2fbb194850f3a57b5f614f00126d23bbdf6786ee0cdba7c03941b662271aaf078cb22aa4affdffd1b009b2113559dd3e13dbbe3d93f3a949a8685b39020bddc07b00390fe94fa15a9c9ab07e27aa17def5cd5c825b6b56cffb9a0a0ccd0fff182324c86e178ea71fabf319a72038f0327f5796965cd39bd3d8ea568b4790336bf87f259c893c4b3b0fe3d4c3da6d553c9d74e5525edb27e1fef2121fda4e750731ca63ae69986241f4db14fed9ef5ad41918591240e1421ab1eef35a677aa55ab523cda4cdc10dd23f143d2bfe5789ce958d5191a5e22487fe9438f474650397657b370bf659e2c69bb331062218d7967b219e22d3741e1773557459ef0a7507849efb524da97b5d3b2d4388d36cb8f21f921fdc47b63c32d69e766ad2a1bd4b9f93904f1044e92b6dba58f768407b6ce16bcbb9a813ca1fe042749db5066cc0d6c85c84041c71b0831e58462fe7d5cd49c32697763b1bb9ab71d2301618c048ddd9534fa8740d2ab75d14cadb4a4cab662a826235e18fbf2cb2fbb28464a8d7c30666f678e979f56367a6ea3a4735b8185a97482cd7c4956f6b2e1fde24aba5c8690928e161e95e6fe140ba5d9e38af385daefe360e4bf52a9af8687723c649ed0a67331f2adab93818738d46c716aeb4fcdbfee29a74346a8c9e3c9727a777eaf5edfab57aee43224e5783c9f89928eb1be578aefa742afd275f66dede2fa8a35ff90bc4e3201733317061e62c783c6c3d1abb359611e55e77f3ce68c66ae86d957ea44b421b3a6edc09d08f752d2ef955f69d6fc878443e67b87dbf1c037e7dbeaa887a4976bc627e762280606caf19499c63faf8763d8f0ce4d55a7cae9db5579d5f00f87c6f7fae078da77a29517d946f1c075c90148d7eb16c0fd5d10ebf9def6688523d6315eabc709ea523a4923cc58f178b696d989d8c784b2295e6307819c2336bf2fd5dd8a1e5dd05fdfd3ebdf7d86c1183876e11d78f0bf00ef5cf8b75f1ddd7d74f4dcb9b749ea9b47bff90f9aea8acd07a66034ee7a1a347011ed7bc3b47878949ae6b5c4c3fa96ba542a89cd7076afcee583b054aa2fd9f650025f300ea56f68ebdc915d91c11a38748e9cfbd5d2fb62fbe424fce7bf13fefbc5dbe722efbb2b2f54de6b6cdeb3a5af48cdd0de2cc67ac2aaa557247fa9eda682c6eed81e52b7f4ccfa57d58614b63292355bf156cbce8da4c7beebf2e8549b6ac20d0930c2e46bb0cb3fb30e217593ce6e0dd97b067206f9c1310fef8138e3fca483e5bc8b3c7c6fd79a5ac5ad96953177be2db235976a4cb1ff0a61d3693f669d895d2cf84a3554c68d39b7c47120addad80017a61d790147ffe11dbefd66f77f582f77f0e31bd7e729fe0d14ceb21eaf69ee72f925e4d97dc2f001acb04516c876651972bfa5e7af4dc11cbfc1f82d55a9dedea6472af29229508d144b36ca6348acb5ab24d5d775e12dcdbfab1b12486863324c5e859dc7e6575757216a9f9e4e1ad6fa05711f78ea867eb5bd44171f2029b52f20724b1cae8a3d0f399293ab7aab782084c535d5f9e2185ea41aae2adb2efe96cd6b6f2e6549491aaa65e357d8a7b9e6fd34c3962fb0eec49539a4e1add21692fb44dff89353259b18fbf1cddb47c76956801fffcf6d74e90aa1e306210848307569f2db760bae70c4713906e2b6fb34d48fd16b4fd9311b1bd739eec79aae10bccec06cfe5ddd904052d6e805d150df134bdba07e007089c98597f5a34ac2d1b370956baf2e033df4db744d101e32cf2fc306972feb4210ed7bd68b1a17c465a79f61d5a04b751c837580fc3475f8c65297a1b46a9ea6c903e66c0ddab1a6fd38a02f5f307996a9b4c19b395163e325545d9876e4e8db6f7eecf146820b48ff46af25402f0c46c7ed12da6bf36bcf7d887a29d8238ebfcb0d09241d2f8836c8d0e8293b326b667ce5151e0489bf16bf1eff17da87d09501f4eb7863a96d7a9ad24f45036b45f37e064a47d38e9cec7747e7008b9549879be5611b5f4cc5355c3f3ec1d66518a606dce1777543fab177dfcd902676a9c77511f001ac3f6e97995e956e09f72391185dc6669c0af9c57238db6c547c8cba6595256cac35ae1b40fb4c3dfcb38de51a98a6b11f89dcd2975b975a66bddcb6be369c8bfd74c6a3395e4d1b7bf49bbbcf7b3d659d6dc87f41d7d2e30b99908b41dc580d895c2f5f76d0b692409f181c99a1c737c9972a1acaab8a1c7e775a181248f86a17b57d16239d85a435d464add0babe1b89be0ad7f491331bfe11b26c818c044bab3001313d5c2c0f1962c4c588c6dca7f12d8d575bfbc355924d13319e63a9e4275487cd4f93b91e4ffbfdb8c09b39565c98a68cfa24e986bb260de3ba86cc1db4adae2dea8310964d9bcefb40c1e043216cc3b9285ea3f72de21dd7fbe844bff6d31703477ee68a7f9a8b959872b32a36b7526c5b2b7eecf03cdd1a701adb64a3c593f7e69d98293e0b5cfb037bbc9478af676fe9d77efac7c83b1e400731417fd4061e4927ef6c54d9567533979c0b93d82cfe7b3115b37232717bab75d12d07a5824ee34eb4bb2b8993159652997aa541e0986e77df45c27efa47977a3c181ddda4fb7af6d1a2f0fc95c8c656363c5bdd7851b8ba4a93483f26147764983ba1b52ac9940a39e58efef90ac9a99adfda77a2aa53908e2840357bd9d5a11da821e0abca0c82b16ab5da45b17038dcdd2a490345613424baac275dbec9b5459d65fbe17f2e647e5705d8d8b97855e50ef3c785da5e4915a3bb76b452af3bec64365bdfcbd268f644047a95ccfae7847a3a17a308313008a1a6819fced6f1b985171ba9cd9d850f559e10bd38c7b6b4cd3fda1e8a94458828d2db2b151a76a2dd4d15f799fb3d2a445f0431d60c2c81723cb0ab130c8d8214d4b98b3b3948c7d9c29dea527a4ae81556764f9ad300d4a57ce145c4963edb52a9d0bc135585c43996f3dcfac2afe3aa2c5b11cff4cff1b4624c4955bbfbd677d0ea9a74577175a96489fda81081dd052965574b2492a41a051a4f1af74b44ba286857afb7da090b35450af7705f601ebd98e506ae9e683d9a8e897eaab5876a7b33d0c9f10e36ae87f3cf641f07895453a1c45445ef326b859d881f1ac6a8408f1e146aecc84162853762e3905692b9887e301d1325d69a9f735aeb90a88dfb6a7b353068a1663fa86ee4a20573c113359e2f4473e2e900d20976f4f22cec55e3a57a896d9987347cd538988e8992d05eed40729ed685d43a9d841d3660765f6dcf061e61fd9b807573cff24bd92770efb3f0f50d3e23c6cca0a77436c3b1d7a657005bbfcbe2cfa29e37e6acd31e3eea64b49cb0dedfa00d281bb65458760d7d0c6dc153136aeb4475628a376bc74459a8730b8667507f59a037b1dc57dbbb8147889b85beae52eea66a9f11d73bbd7237750616bfae7e354f1ff3133f7c78fe2ecbf07528bbc47cf360a3ad119648ad3265f4da00b9c8c67cbdb1dfcdad439e27da1bbb44889fd12ab618e0d10acbaea18fd176cbd149f0d1d0cd25e4a4d72633acd299c95a69e037aa8edc3b93fae834db1c9fffaaba72bae1fb675bf7ce9c9fe6136d4e7f943a736feb191c6c3f6cb74b4baf0de1f9a4e9e87afc467a143337bfb634244a279c15033cdd03cd16a4571869453991d12fa6b9886fe2980e90602cb4bec046a60beba1c15f315c8cf19e649744a84963d0ceb06b9e2a3ed0b06d57e3db4d1148cb44ffc03cb04602f48cde80dc55d8abeac77f2aa1eed187786c64639c7d7fc37a8bb41899a693838f7b5d38de99148f3439b63ed1f12181d5d7ec5e381ad081a8dd283a00189106241ddbd937122d231c63e4e398e82bdc57dbbb8147169f64ff8b3f3aa037518cdb27b5d77ce3f4ece29387db22f1599e65189f3e6fa99918926a9bebc2c52c89749ceac303da1e76072a627b02b5928082a7759dd97b11e8c3ee5871bf496d406778d174e0420492b86fcb3fd2d0fe420f0faab713653ee820430e318437d39c1365559bde5ce1d5d68a19bdd1baafb67703abf4568a6091df65d19316bfb67eb266a0fb320641fa9749e3c9178dcd4462943dd0e1297a0663db315112609ff552b1ae22a01b61549265de6bf75713ef45a8d7ef25e92c4a7b22d9a0898f0ad1f3855a43fe61ff1956f6ef589aa7df72468d236a3dcb8e89f5be56a68b5a1be7db53b5bd19a8046992742f789d24dd41086be85cad7a028a98caac153f0e251ed2f704f11927f274b1a610d63727f4304c92eec33bd0910e38a90dd48993000fbbda1d120470e6cac068f75e84ad54042af57b5389cfcda1a42e536003bf9b5557bf818c2a632468ecae64d7af92f52dfdb488be17e14444b94383c95a26163a21764d7b3ff5b6b20895bd3089d82b9b4ae8e604093eadf9e746dffc6055662006e2184f1c88fe8ef146071ce3493110434d0491003a1e82480085b02dabdbab10f6f08242d8ce06628fe7000a617b0185b02884ed0e1f0b6147602e350a61dd0961af5fcfe7afeb22d806cdab6d0d08fd03cbd3c98cc32e848d99ef61267f87e9a11c0a615d0a61e1c93df825571d3c3345b15cf33a3e7d9e09f028548497fae8b4d0c5b6350285b0ec799d391fb2a7e52e470c14c2ba83849a677efe33b679f0ba068bb35cf5737a76');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(24, 2, NULL, '910a144ccfa37e777e7adcaa8b6d050a619d0f8ba151601d200b1a8b29f6916edf4cc5e8b7a9ea7e516cb478b302ffe4e79728a010d605c4f142ef7247fafb5f9fe83e08f0b39f9f79f2d7bf5305d019aa10127e47bf61bad876bb44212ca12c16c0d43d6d2b154a4f556807582bbc88a4b6789edd79bd3f2cbf98ccefd52b577291cf816f64daf98faf5fa280425817586eae085fe3e85e383effcbd0c3ed67a6df715dac5e5d14c2b6a021d4d4b49d6846f4f77317a3b9cd2acb63dec1e14b44ab135163a3fdfe8dfe3372077634f612853b11d69786b352235b14c2ba14c29a9be3ef86401fd1919052ef094fcf86b29f6585dfd974b128849584fe120521e4a3497c65dbb90de9f7725008ebce40ab2c88ae2f765dc491a45ffb4a2cf240c77b303b3faee7794df2e845c2d94a528928ec15b8c94a5d4418d95a2116e2b35ca3855a49e601edea24c44bf50912f22b0991408de86db44d350a8bb7ab4bd9307bed41f25f4ba065dc1464920555bc2ce1a2996e7b89c245fa1285cd0fb371fa1285c9d8e7a44cb8a7eaf60439fdaf62e2e09136111689464331d29c1325411f1aad8778b5c9f9ce7aadb657037192b47e20fa3a493a16bbdba86a3515b14c0b6b55be5a55b3f60d607a5992259abc023b13f93cacb0742d7522c2ae76229d291ef81bc04d71ad5b5b7092b40403d1f1cc6381ea04d97531aa147cc7c3992b08228180cb0d0747f07a3c64988c75d7a73fdf7dfdfee4bbb22bdf4f3c5914487db47fa2bbe0b5ae660331d4441009a0e3218804d0f14690111007211d40c7431009a0e30d8446f580558b00d0f43605a398914d17284093ac0102f4a285430c3ade4068540f80558bb0950abd4a8bb7295c5c5fb1078d229b21506896351c8fe7c58b163ccd50417c053ade6068500f80458ba0693b5449c0be0d91becb2e4031b2718182a3ac01197dd0f10642937ac0cea1d5a7233ae87883c1a61eb0e3fc36851658323359c35c98a79765ab5d91de40c71b08e929a1405fd93dd9d4e3cd666b999dc809772b35989943899395ec2c4da32f5aa0c12ade5c195dba9c061ebc493d5ea78c056fae264e191ba681d8e3218804d0f1104402e878082201743c049180f2c35ffe26bb0ea3c7a95f1c0bdecd156c09c304ef6a7663912fee6a5a974bea01bcab29c5400c35114402e87803c1f62683e65720585e9660794d823d05dabe6ea141a3d04aee80f81574bc81d0f94d06fc65095c8510617ed598d2fe750b568dc27e3bb903e24bd0f10642e73719e89339213c978417d43b1b52aa9d5eb760d05eee80f81274bc8130ec3719a0dc61d440c71b08293a7d99bec9a01065bd99de0b398815aa9b39a3afb3a6845be812acf0dd7a923b20fe001d6f3024ceb15b1de7d6177e1d0f2fe5c920ad41ac60bc402f0215fe48a031c5499760c5d4281cf72277407c013ec7ebc6a25e9fe3353f82ebd343b92ec0e778520cc41e0f412430d6fb2e10cfa84ba552a71424d0608f87201240c7431009a0e30d185c6e1d71021d0f4124808e872012187bbefbbabb925d17f42dfdb4884498a1b498a412cdc8b66ce8e607ab328360acbb2795c17bc4d95f8bb8b0a014164fc64702ff9cd0e0b5ae6603f139de40c81af35af0011de2048ef1104402e878082201743c0491003a1e8248006fae74c35b6fbd65a86910a40bd0f1bae1a79f7ee21b8aa2c8ae0b329260a8892012c01eaf27fca3dab612f807d001007b3c0491003a1e8248001d0f4124f0ff5426dc331dfd721c0000000049454e44ae426082504b03040a0000000000000021009b12f802502500005025000013000000786c2f6d656469612f696d616765332e706e6789504e470d0a1a0a0000000d4948445200000372000000510802000000186503b3000000017352474200aece1ce90000000467414d410000b18f0bfc6105000000206348524d00007a26000080840000fa00000080e8000075300000ea6000003a98000017709cba513c0000001874455874536f667477617265005061696e742e4e45542076332e3336a9e7e225000024aa49444154785eed5deb8f56c779dffe11dd4aeda77e71d46f555545b252d16e1ba52476a4f2a528926962088644959ad40b519c10db49080e2bd74dec96622f3727768873c1068c2f4020b0c0da3818c72cecc2aeb99805ccc5d7705908a673e6769e9979e6cc39ef397b6eefb31ac1fbce3bf3cc33bf7966e6779eb99c3fe9e9e959bde500fbb790bfbff9cb3feb58ce5fffd55f749c97321202840021400810028400214008548fc0e98b570b098c9edecaf1c7807880fe72201059d26bb7281002dd83c0ad9e1e18a80b744fd3d7bfa6649cf56f23d230270288910b4a5b08a764428856e6e0840564a53935670fa1ec4d44806865135bad4b7426e3ec9286eee66ada464eb4b20036571b11442bbbb96f7773ddf5b8465da09bcda09e7527e3ac67bb9056052260187998561e7a7a56df8c4ff070dbfca7f7272e9717edaddc301a2fa98f6ea880bdad18bac834a8a4e84e6a8bcfa99b077b7afa0b34a0cca22a57a00e1b03e6f0ae76fb208e5e67107596ab7c344ad1538c6b45768152d4cedc9b32355f73ab509ae6a51454bc716632837a26eee621b1e41629d9c8c3b472ebb2db96ee4ab94a5e28ad84948ef3cb8b432b3ae15a79f234965642332ac5a49266c7ca15988e3e9cad523b7a7a66f66c36b7bde66fa36c3a54b7e9b62c3d0d5ad93df032f32e0be1e925c1b09f9656a3b20a2ad838a7634c2b5566770f8925f7d9928d3c482b372c9d316bdd4415b49253c9c6380af390d7c2f2c6ae9afc736a81434c59365dde9c9775504011c8df464d01b64c3df5a9b5ee8137ab3516d8b5a74f546936535a410cab028d73fa902f4772970f8925f7d9928d3c442b271e9d3fffd14369cf8917eaad142be028af048be3f1effec88b43436a353df6780a47a4fc53d1d23b39aa8ab6bc95200fee3a955ed58cc50d69554637c4b5003547ab869051356cb10741f1c73d64c2a456f6cbb895ca6b15c58364d668c25628e6ec8889da9299f22b9a4b0b67f2442e96ecf6fe9edbd9f7fed895e293a98b86b964c73335147561ca883f5d175701b42c37bb2bcaada0956bc9f19ed74c842de82c09f157a0b025a1b336b29993d39a68bb4000a3ba385e4cb48975e41cd6b2c0ae4476a889af509152030e9bafc0994ccedc457481e980b7630b47cd527631d58f933de241e483d622ba1bda0793eb65cc6ac7a36181894a1e49e6b0f10adbba43c6097b1c1cbed20c65be0e88da866b0f2cbb8e5cc28662b502933c95b82379b386c492fb2c3af1c1c8fa8fc0215ab9abbf6ffeacf97c63655f985f164a2b1f7840b32983c3716e2762e2b571b04a6e50412142a47656d5257173f2c65cd69565176c92bb1cc549caea51d58dc65c9cfea761c5f6a241410cd6600d228e040c039d09f05c7c0a17534e244a730e15a945e132ad4235f7c23414e39166ae725cf329a0a7257326135c4a8c8ffab3dcf5e82f34cec5c57a9fff2c65fc895dd622ead5491b61850ae68ab68b551783d5a186014445335002ad4c6c0b9b7d4ec3965f492bcd068266532dbc4213f938d4b1856ba372ba18f284e35820dadf13acc5ea6e681fb4eb050d8f29a03aa07ce0643b8c7d75574c25da78e79a0719a7e914e8642853a86a33c07ba5af23c306129f4353896d5a4d1b124beeb3c149b6fe2370805646e775349b641473d986528fec44d4c976df015619332b73ef25583e377e707668428f25e79822c27669829f940bd1b3d9b3a3e25c760b19b0b76a09de4a774e858f95bc57b331253e3e0206fd785a32670231c48773a92126ea8a4ea1d6ece24e1b30175a164cc0f461738fed6fd3631ca6bfad553a58d0baf868a5110fd170e6489b56a65306f2069caf639b96f45085b70b60f628ec0611c12a85a3e1a4b49aaf4027a516e5a595f580b7330bf71a95dbc53cfb77b3218ff562ddddd03ee8b52b254a2f77b00faccfa266a6d3f81edbc838b59de71fca50517897741a51361037bfe0a4d0f421b1e43edb02230f792be1f277e4b94c5e102fd85b19132740f73042672c681bebda3e9e27c92a279060b5dd3ea203be9b74d67396274f71306f2cde5fb54cb452711addc3e10287b5a0ac47166b26802b207ad92d5e173357e26ccea4147065a23cc95796455f34ad140f94f24fcdb56e593ead92614173f968a5970d076965f636826aa30f092e2c3e04742ba08661572a71113c5ca86a2874093e27d7f4d2ca7ac00bf147a1462d3c6854691e7260bb04363f30109d263668253066d107ad7ab9d6c8124491ec614f7111d063a50717d2cae841c8e932649c0617744c1ad271df088f9a413052d883dd40fea684bd3868bdf92be54af091ddf0e894385097d0675b60e40da195c07d87123aef49710fcf338e03f916d0cd7573b3dc6cdeca54c5e1b4122cf4874ff6f817c1b139d577d94d3c2288915dcd04b6b7122ec7e863ce41579623338156ba1a063d25700541ce4c40ff34b4122fd40130cd446ef8083ba295c96da475087ab3504dd02a18c3316c62ad7f62131b0d1474d63aa7e373724a963d13ad2c1f5e2ffd427b93f2c707fd3da9acd15384c0dcdb70a08d62068946622c07f6c739337b560a7269b9b894628cb5e81621e34c699c9667177fd4c46e81b0c652cb0c507bb01bc8f556fa0a4a1c3d32d1ca94b014382496dc675b3002076825bb5d482f7cb305f132efad043e44735b24ea41849cccf7d9de8a29b6502a7720b2d26d960b099e8fc626b1d850711e5a69f04a2f7d1694d39c53b105b2b887c0a55274d9940f10d144a26682a8f363b9e00a69b4232ad19585c8f46de8c4ca12cf9a73d4a9205116aa8018aa2cfd83b412ad209a0b1d942544d6c632cf464c2801572cd446466b3a85666d1739b8a385f21d05c2c5a577f6c02d5351a4da26a19d4cae31f8f0cfcf26b5048356e6eb02d3012f3adbc19e855a7870779acf1ad1070f1f63c31bcee96ea88676bd1c6bd4eb0fd251eaefdd620124b8b732eeaa5d6e9cee962767f77cf25325da2bbda307580b8ab7b63b6e05a3475bdb3493f756767d9f45e720b17fac292370d05bb97fdd7c79177a686365e12f6f34d77fe1b19d78bf2538290e22e3b4decd8e50043f89cdf3242c8247b42ded497071bfa6436fc5f2fca8a7381fad34f697265fde19d34a6185ec4f9eb8f42d97a885287da4da9ae085431efe2a2615f127e355592c66c90e70cc13f55ea8b3326889d684e7962512d8671e310544452cfdc3b4121e50c5ce43c41200c21668b1dac95bdf72b7915d1dd12a7a88cfd82e86cfc0350c3e37449c5e9dca9214934746c7424573870a0d9e47ce493135adccdf05a603de0e2d1c3b376d88f258234c1340dedf70567743fba0b75ed0216dae6b23230938681c3e098eddabd0bdc6997a8447cd0089f40caa7a89163f096e4e16c890d2c021b1e43e2bddcf4d1e8183b432e58d9522d9b4edad0cafff520ac35b99736e465725ea201375b4242896357d51756cb31cbf6fbb0eb58e6925b61e57070d9375a895c5a2cad44a431b4c32ceb2ccbed666501608c2fcca86a2f6464eb4b24d7c346acd62274e638f76417d358fccac1d384f59c522d91e69b51fd41a0d75560b9fd6ca12ad2c16dec2c7e762d50b4a832be3709f653063bb1394dd676b3f0213ad245ae97f4b35b30ef7eab81ce4522e7be59099be03e72fabdd4361e7b5ab');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(24, 3, NULL, 'fda0d679d572d8765185a6b7f0a24acceaecaf9586e4ad2cc10c6011e245ded15f8e61bc649da7bbb8b27b44ed476061206cf1baa870f0c864c7411b2c7d20040801428010200408014280106824024571cafc7b2b77d25f0e0498f1c52fa4a44f8440f721405da0fbdabc313526e36c4c5391a29d221033e04ce772121213adccc1090bc84ac356a77d81f2b50401ea022d69c83656838cb38dad4a753210205a590093ab95081ab6a88b773902d405badc00ea5c7d32ce3ab70ee9560802e96865f45af019eceacadb4277a11772c19062698fccb677137c72d17af1e3fa459f64bfcd7e242da1e3a274eeb4b91a998e86ad423a06092918811dfcf6d3e86fe6e07125fbf820bb42dd8abba523615a37652cd0964b5dc06e3b08a96a86fe1d205504266817f64b94c548e2b41917a4936045809f0bb6a6e68a93c689c3653641fa4aa28de56d4147aea30cdaf071b61c929ddeeea964fa22d2a35442ca86aa5d34326968257b0ff88c59eb26186564f7a2dfb67457f27279718be09c0bc6d451b04cf19d68a597f2d29c5a741f2179b91188465b3565460c464c5b3197314663166d4f6b9e945aaf586614455d00a395095481c3df6fc2ee99204da4391f118269424dd74b6ce32c04b79c42ececee438659b70e586c560db3a64f07feb4a46a90aad3527f44680a5a19b92a976de0579d9fbec828e6fc470f89cf7898365ab93387cb3147d6a6b92c694e2dabef50399d21c0262d4e316d2e2979a7fa1908f7a454294caa43b4d26d96e4994ffc6aa5c1b3388da393d1e49aae373481568a273eff7308d14ad8d664f98ee5378856426a68792bf572f9ecd9f86a7702ad14a2f81f5c2507d1e0072967915a9eafe1ba3ad1ca74c33ba5aa0681d87189934516eb2c0526d24ae8091555a22e90c95ba9d13538233e5902f7a455064daee9fa539856728cedc562345297c8c11f54f9241f842da2768ccc1c1c940f750162046cc12d1a294e6f49f1ace3bbe691a246911bdc2c2b961e6707fc3785aa3a49cc9a839accecef8f9a84e7807b6fa208b3e2b09ac962d3594b4353a5a09591877246ffd6c837295e0e2e3e97e4ad8c1584bc0fd24af859f04b97ec796925f801a681ebef4ebc949f7521be24b727cda90ded8aed575b8eb37a6a885d22e217356ccf9c69efb844530ac0103a435d00a395c6480a267f402020aff4d24430af427f1698e6e392027bf4da6ff26e0d43b412f809cded22124bd48f08fa4fec68d42d081ebc78e3253fb659ddca340fd147938b435bd53627b49a20a7a1bcd2180524968cc9e4aac6eb20f0b3bb3ae2c75619b25584b3ea92ac4cd7d87b1a5a79f5b43ab2336bddae47e7974b2be3bd95d27fc82300a533d99d873f7aa20379a1c752e861c8a9e7ca3acda95dd3799b595138762b2e327370873c2102a640ee0950e3b99bd2cb2ac95be918869723728c639a01da26218b14aff825edadccd21103b4d2803db05d242ed6e8354a84fdbf7e0acb422b510f76627138189639a1d5441da8b02c9d0bd928e3d95463675775c74561466f5416aa88b58ec186f54315aa6e16a3695ada74b432f64d56b9b712903a9b569a47c4537b2bb918ec78b95c55e73fc1a342442b9b66e0a46fed104007d90e2351f2434f5698b732c5b16e311b64a2897ad20dd3d0da1962250a0568254ae3d048948429ff7dc49e505a693e46481948dba922e19aafb60e23bdb20010a99e01ad8b02800562353272a1fc0cd6c85d6cf73260f868ea7c462be8c556796ae12e0588467ab65a89f1955568465a691cdf29fbc84e02add407c68bf1561a67d09d4570c543c95b59969552396d42006390382909a744d928d1cab4b4d2853d992622ab8438796993bd165b976abc959a84a1be37d70c74bff2fa050d8911594b7eaec8e5adc4b8a04b2b510f28caf9588b263b3e7db4d2408fbc95de9e918656c61eca0d4b675477c1105c81f6ecad94abd6a9bd95c6aab6bdcd525055b5104e8be0c58eae24ad9b10b016be9d5d4de8a6a968e84f48a91c33ae178e68654a5a89ee2593b325ce12b847c9ba78547c256f65ba0e3d7d7b2bc10e42bd03527f903fdaed2774b6db0eda05e495904839fb1d51c2aa31492802b5c2446fa571523d2e1708d21f83b4d270df869e63ad12e21b2d9cb57578961ead603a6b6968aa34b4f2eae9adcbd8499d1a5c87ae9d921d9d0437f6acebb56ffc2438b88a7df6a278a99c16c11b6ae7a476c508c42b5cf0e212bd02855d916e5c7182a5b43606ea1a12ad4c472b3d5bbec42c081a4c0c9cc6492b3d961a4e2b7384052bea151b5f9d8a0fd14ab8cc8af60aeca835274fea24b84b71e2f3cafe93e046db198f6a6ed7458b53af31c08f69e17e71cbb2403b0568a5b1189d74a63b4c2b3da270421c63116f078715b78bf357b04e3659b82ee968a5ffdcb77b1ebcb87b2b3b393a5dcf85e94e6ad2691e9a530bef2424b05908501768567b7595b6151b273995bbcada2aaa6c0b6825bc54c83c83d329336b74be8a87ad8aec988a2504c85b4936507f042a189fc1226cf24a75fdd1230d1b81400b68a53aab2dab52c31bca4ba5a9150c5b8db07452b26b10a02ed0354dddbc8a56629ce0b8335d25da3c9b699cc631ad648bd745858347263b0ec8f61c8a2204080142801020040801428010681002092fcec9f453b57b2b4b750cd6b2b04a9e861bf738450ab71801ea022d6edca6578d8cb3e92d48fa071168c522782de95d554ad1b015347a4ad06e04a80bb4bb7d1b5d3b32ce46371f299f0601a29555d1bfe92a9786ad34764f695a8c00758116376ed3ab46c6d9f41624fd8308a4a095f69b7526d86bc1a33b2cfb966dc02e1e2a7a111cdc20a9afadcc45c93c57a91b321b7c4f110d5b41a3a704f542007903071f97f09b12c12ffa1639f32e3fea02def6756ea39440ef88ae3937ffb057de09b9c69d82ee3e2f3a1492d4bd62e3ecb6bb7ebaadbef51a644bd526482bd92b760c06a95fb4e37be34ea1b41252c0a2a81ed1ca522d8c0a2304121110a754351789be26bdb7c57c210f9a926865d8e4102a6fd0c1a46640afaa0e17492922048856921db41e81245ab97fdd7ce6959cb574d9acd83119bfc8f1b4e7fde085d24ae3e5dcb97c947166a295adb76aaa60331010beb399fdfdec1d213b2c4f58f4d57d0d8c75051f24a3b1c7926865b8f943b4d274499a0e48a295617cbd298856e6008fb2360381445ab975d77eb6cc0de9a3412501c504abe1c5d34a77ed5b3243fe5645fe37fb9178ad5cbcbd3bfa03ef65ecd12f6b94b12295f51248cd3d133ca3f8cb1e3d6549398b664b3d4bb85493e6d466f43cd292ada6eed8711c2eaa5a9f1d5a695ce66c102383805217081b17d1ca3046d392224c2be10b02a3eec1ffc0cd93f211cc7883227c4f3b503b944b3e2e98a2e248fec02757122cad0cfb515f1235379e1ea7055a125a1704828be0d5d24a70d539646492da716a283f8b9f9d4573c931214dcce5ad0482a04ce85575e225a3f551d8829cb04a0ccda975e95ba4474a046c8208e64de3bde016158a3d97623ad32e35ea0261e043b4d20437c15be9ecada4ad9589e8876825f0c79bfb3d24ae7a7702377ae9a207992c5289e6021d8c0b80fd473fbaf148d598ae56c080d8c7480c78b4d3c9c18320a7b8641ce1aed98214b5a7959c2dd9ae4883a1f928a3ebb1743d9419bd956672c7a509bda3a22c2349519b43937928cda92de896dd550584e244e3d2ccc1e820493c11b95bfe9577c44a495d206c3f1eccf57c106f29c061e7cde2fe142eb8db530468a5df070ffc969a0baa560a3784e27c86c35f31c16024a6958e7359a5b60cd4a7d9ed16d005f56f06ad044bdadc2b998a564a2eca3388cfc5d04aed36055af8ca225ad9057d88aa981301efa4682c6d274e9db4089eb10d12bc95869b0ae38e905090ff2923f0015ae933f9787d993f704917a3ffb4bed02a3997debc6c1a83540146a25a493a29ff3396e939ad60ca3982c95b99d15c9a993c23adbc58f2911dc33117d3b834b4d238ed53d022b8cf5be92d8b686533bb05695d26023ec288ce76a862664af256865b2f8156b2ccf13970f1c5bcc04947849d646145ba2d4527de4ac39b08fd8e89b4d29b2b6e4dc020d1c8c041ba1dfd7c9d406475cfd7095aab0593b5748dad67a595574bbd60083a19a18b3235ad140e4ab5389ddb5b69ac6adbdb2cb1b28856764d4fa28a768c8067e1cfdc30e64e4af13c666d2d235a196e8a645a69124b836442ca4944210cb49da293bd95d6cec694de4a6f2eb5c551933ee1d4141cd28834aefd02db34e1964bcd1b21af84dc570aa6bd95d98da5a93932d3cad391c3b2bcebd08dc3dcfa34771a5a097764f6cce687c6dd633d897b2bcdcde86aed1b3f090e2e6d876511ad6c6ac720bdcb43c06227faf8aae123c39c21784a7035607975685a49215a29cf1e1bfc410e88e6b64be7c80e9dcb48b40593561ae84960e3956bc3d12792c6db88610be2fc1e0a624e454eef78ca4175f97de02438dce18068255c94605d1bacb9c7b1aa93d249f0a68d119deb9b825662afd239ed8f2cf482a1824f4977833872d574de1b28672b10a02ed08a666c67252a364e948092d7b99db65659ad8856b68d6a563c6c5566c95430212011a02e40a6505b042a364ea295b5b58c162946b49268658bcc99aa4208c0f7e3111a8440cd10205a59b30621758a4720a6956cf1baa870f0c864c701d9aa435184002140081002840021400810020d422061bb64a69f72eead647cb478f2dc4d1209c06e6a6daa2b82007501328bda2240c659dba621c58a428019b9a4be99b8e3f41dd9a15e97b36909c09c0052f6a623405da0e92dd862fdc9385bdcb854358100d1cab659020d5b6d6b51aa4f4604a80b64048c9297870019677958534915219082561e7a7a56dfb20dd68d4268244f438be01535a52c9686ad6af1a7d22b4780ba40e54d400af81020e324db683d02415a195d7e7e9b4d2bd1c8885312adacdc6268d8aabc0948816a11a02e502dfe547a0202649c641ead47208956ee5f37ff137d33662d5d06bd956824dc6a49deca6a8d8686ad6af1a7d22b4780ba40e54d400a90b7926ca06b1148a4955b77ed670e4873bd7b3f1649b4b23e0644736a7dda8234a90401ea0295c04e85a641808c330d4a94a6d1080417c16d5a291924edadac6bb3d3b055d79621bd4a4280ba4049405331d91120e3cc8e19e5681802442b1bd660417569d80a424409da8d00758176b76fa36b47c6d9e8e623e5d32040b4320d4a4d4a43c356935a8b749d0604a80b4c03a824b21804c8388bc191a4d41801a295356e9c8e54a361ab23d828537b10a02ed09eb66c5d4dc8385bd7a454211b01a2956db3091ab6dad6a2549f8c085017c80818252f0f0132cef2b0a6922a4220a6953f7e6a1f85340854d45254ac8d409ac66a599a2daf9ca4400810028400214008d41901f94ef08faede2c24b089bc1039f514c26a47fcae0e08d4cacc4a508615f1c0936f502004080142801020046a8e80a495a367af1712c4145b88a81a0a11b5fbf8e35b142a41e0fa1f3f66f8b356a8836d9cba74432873e0c4140cfbbff5e7564cc75fc7df9145fce0678728100284002140081002f54740d1ca33d7478b0892561621aa107d8a15226af7c79bb71a18de5dfd9581debeb5ab4f95a5fcf0f37ffa8f03bd03c78ac26aea86e29435b02ecd29f78d5fd38111cafd4f2d62ffbefde212f62ffca9');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(24, 4, NULL, '83cf47ce5e17b4f5e15f1ea6400810028400214008340201492b8f9cb91e0c8c25c034d657f193205e41515182d7f77eba6f800989c8c797f7fe268502a9c4a27258594514216ac77c66783835fc79552351afcf3f73c99bd827245dfcf68148fe37f6793441845c1ae4b472f09495e5d8374c9d7bfb366f4fa743a06afb360b5ac99265d7d6aed755c529631b88ec67d34f7573ebafc0aea4757d77941b1b486c999ff553c8144f2a3fe56f47afc1f0ca4ffa199bbcf5fea060963f7aea75161e5eb77fd9e0d003ffb3ed9b0f6ffecf1ffcf2df1f7ccaca857e3d745a72cac79e1da5400810028400214008340501492b0f9f990a063149eb64f0b38e14c4ebf0e454281c59d037b0608b4cf6930737fd249c252873da1388da5dbbf1311e4e46b492d1b26dbe04c5c56f5b1eb5c5e2bd1e4d90822e3db130a2954f9cb4b21c5b1ce92ce38f3eb336e2820b878fe657752fa795cb8f31acb26b6b2879e5baf4531a4675600f638ab1d9e8af56bcb02b3712c46c5fb5a677de9eede92cf0e445b930bd75e40a0c91ab9273ca9b376f0a66c9c2fb1f4e5d78efea990b974f9dfd68e2ed0f5e1fbd3077f14a2ba3fbf5e0a929e1a77cfcf9631408014280102004088106212069256300239353c941d04a9d12cd22885750d4089fd49f444a3cb7749e7261cedbb32d4a20637afbd62c3dc0356479e7ed59fa207773aac86dabd668f53ebdea1c4cd6cb0ae259226951b9464696f2492e8a0599d18f83a81d63397838317c27a7952fc7092ead5cc88b5b7e2ccab28733ad85c363d78f2de264ee4efe2b0b77fefc9294c98548379bc8a532cac885c32fff3c227f3ac812d18c2092c3b576e5094b79a9898c171aea2a60325fe68c36d650d43aaa14931cd5579622442d3f3686696b0bf1417afde3cb539253da46659990fe8a9a961b0963bcd668f788138a536e7ee3b21bf63df975edad3cf5c2b7dffb70eafc7b57ce9cbf7cf2ec47e3a73e38fcd6a5e137cfddf5b547d1bc3af2b513d704a75cf7f204054280102004080142a05908c4b49291804d072f27044865583234bd205e5b7e7f39140e7da16fe0533f9ab4920d7c73a0f79b8760248b91c9d63fd7fbc5ddeb98e4edbb3fd537f085f5bc081da94b8c7e5d7def7633198b8cf24edefb4527632ce1d0bd8e3e967aa2768ce8e0e1b8a4952f1909146f3b2e28d766feab8e649f25f55c34f4f1652161f931267f94b33146372f0f49323a2a322e1c661f5ee2dc2eca22ca42331afa28c277dc521e6a22c50a055099b15622014b294ae15a89ba44b4929522d4e6a22c6d11211e48ffa03825624e51433f3760b43bff6ac58b046e248c41b33836fc3b45f89e7fe3321a18a7fcf57f2d64ff9edcf22df6ef3bef5e993cff8713673e3c76eafdc31397de18bbb0fbc0e4bf7e65b92f3b8bd79c72edcb1314080142801020040881c62110d3ca17dfbc921c34ad14c9d85737bd205edb46ae84c3cea1bf536eb9bb9e11e947eeea7bee11232f8c619f572fde79651bcbf8a5a1a74532f859669c5cfc254f3223b192f6cc73bd5a5a48edc055326f0ddf01f6293276b5e22d7e6dd3ee886089d0bf5b5ce434d6cffd9a2ff27b9d0eff2c629077fcecc28b3f046978aede1f8e1991ea1e282b12cda8c5f2122fac5810113ea9527c9f54a4097c60501ade4c50a677c1f0612d81d75ac5805294feac74545b4388ff7e2b86396e4bc07ea4eb54188f131f595714699a168879e4be81defb46922df60db5309ddc47d8664a4628dffd608a71cad38c534e7e78f4e4fb2313970e8e9d7f75e4dcf657defe9779dff349387052ae7daf7d6982022140081002840021d0440424addc7ef84a3088c95b27839f75a4205ebbc6ae6608bfdac8d6b2efdb7d75d7eea1bfefdbf818cc1bc5c0d55e95eceea15f88642c81fafc8bff95ebe0b1342b192b48c78c9db9efee817ffb1513127d1055e35f9382a8dd07573c619c13acbecd2f38095e78882f853f34a6f28edd0b53eee20cf2a13191cc58e05e30bc8247debbcb2854a4d49129322ac2376e292f3459bb62fce6c8d37c63e582e111ae3f2a7384d7516b78c7d3173e10b596b94029aa525a545c05578883d8879c6832c0bd2d62598bfeea5a91b013bf6901abc05bffd0a4247cc187a5879fdc7f9e39292f2827e55bef3227e5fe9177f61e3cbbf3b5d39b761d9f31eb3f50219ab6ae796982022140081002840021d0500424ad4cc302199980c9acafe22741bc8627ae660967be3377e0ee67af0eef1bfa87be8d2b8cbc87efb66378b2b943cf8a64faf3b38c9b8abc4cda9aefecc39219f299649e4c15f7ecffade9d56231fd47cf4e89da5dfcc8138e0e7f8e93c54d56829db1b7f2eb3b45deb1af8394077f1af1b9cffdf4c2a6651163536964296922d1345a2c2ff1c263f744f4f1b1a396f24213111fa5119ab02ca84c5d77f16bef3dc30745add907ab145eebde656309a262212662ef5d969c32c98a2c6bd15f112bc24c0b4de669774170778e5e0986e5abf74ebec39d94d1c2f7bb0739a7dc73f0ccced7dede3a7cf2d7bf19bffdce05ae90374f4bdabafac5710a840021400810028440731190b47278e25a214110af0327ae05c2a68d7d8f9f95695e1deaeb5bf3dd575996b3df9d3bd07bff619877d5fd033ae5aafb37ae629259fab9435b4411eaf396c7d7c88c5a1a922c923f6f13cfb8692323914cc896c737f2a2798c59345463fc1d79e10babddc4f91b787873ef6738595c6f2418fdaa8cd41f5876f7f39a81376f4c08095fdebb5b48605fbf3f3af112e76732f2fcc0f7a35f77af895cb39f59735e6a826634224589bc14443d15cfb330c95f7d095766fdf78d94bd4c3d5f5d84da51025b5b4c48acd5e47b7f14342e60485143737bd09620be5af1d6af6efa445b85edbefbe89560f8c1e3bf3d3ef9c1d193ef8d8cf385ef43e7e62e7efcaeaffd986da964cbdfb7dfb1f06fff79ae25841d4512f56dee20429a1302840021400810020201492bd9718442826003c72fde600e98c470e41e7dde999de6fe9d4e0c4e823f78844b30ce866f6531bfdbf34ff3f6441f8ccf5260efbc4df7cce302d1642c529e04dfb45648787e93da99a7621ccd5975c4c42f6a77ecdcf5d78e5f43c230233ac61276dfcac30fce8d62fa569e65e937af8cb820a3b39b8f1f9e672eee3f38ac049a4218d38d0a7a6ea35e77e6d959e2b3427224b06fe3132c06cb284ae469d6f431cadeb7262e485621d204c64b25454a47e613f7833d095213592fbb14aeb3d4dfd4761e2644e0c9b08550271952d494a0c9f457d5c43162cc90cc487639c05a2b3b66ae56bb1f393bb56ffc6a307cebbfb71c1abff4fae8f95738a75cfcd0fac15ffffeb1f5073f3b67899b97c914f55df5c238054280102004080142a0e908485af9fbb7a70a09fa50cbdb976e8c9d9d6a4160151113ffe00be3ba766c275c709b5d62027660889139eb7c528a734ea14345f9b4aa5801bdbf10425d9521a1ed3e766eead5b7ae06c3d7beb7fe2b4bd6314ec9520a3fe567effab69b8b49d3a6c5aa4c811020040801428010683a029256f2c3c20504edd22b445a4d84449c72cb380bc5d5ce38095e936ad6418d6980ba73ab2e41195d8430300a840021400810028440a31190b45210a6fce1892dc7f20ba99b0456291deaa65bcbf4a915d42528038ba0cf840021400810028440d31190b492fe230408014280102004080142801020047222f0ffe914db5e8f3008230000000049454e44ae426082504b03041400060008000000210023a473d69a0100002203000018000000786c2f776f726b7368656574732f7368656574332e786d6c9492416be3301085ef85fe07a17b2d3bddb65b63bb0442d91e1696d2ddbb2c8f6d114b23242569fefd8e6c12ca660fedc13083469fdf7ba3eae9dd4c6c0f3e68b4352fb29c33b00a3b6d879aff7e7bbef9ce5988d27672420b353f42e04fcdf5557540bf0d23406444b0a1e6638cae1422a8118c0c193ab074d2a3373252eb07119c07d9cd97cc2456797e2f8cd4962f84d27f86817daf156c50ed0cd8b8403c4c3292fe306a174e34a33e8333d26f77ee46a1718468f5a4e37186726654f93258f4b29dc8f77bf14daa137b6e2ef0462b8f01fb98114e2c422f3d3f8a4741a4a6ea343948b1330f7dcdd745b95e71d154733e7f341cc2879aa5b85bc46d3a78e96a9ea7517131fb3cc7fdcbb30e7ab99be22b1e7e801ec648bbbd23f9c945d91d371014c547986c7577fee94646d9541e0f8c5651d0de9d4c8b2d4aaaff7fb3a9549a5dd300c15a72b56f8a4aec499aa28f5067deea2b3c1a3ef3f27f788be945ab9303fc947ed036b009fad9d003677e719c67544774c9e603b96f314634a76ea4b708243ecf6e39eb11e3a949c19e5f77f3170000ffff0300504b030414000600080000002100728c60b87e040000490e000018000000786c2f776f726b7368656574732f7368656574322e786d6cac57db8ee238107d5f69ff219b97791a4242b8340246d304342dcd48a3bdcc3e9bc4900827cedaa669fe7e8f9d905b67687ab50fdd09f6f1a9aae32aa7bcf8f49232eb990a99f06c69bb83a16dd12ce451921d96f65f7f6e3fce6c4b2a924584f18c2eed0b95f6a7d5afbf2cce5c1c654ca9b2c090c9a51d2b95cf1d4786314d891cf09c6698d9739112859fe2e0c85c501299452973bce170e2a424c9ec82612eeee1e0fb7d12d28087a79466aa2011941105ff659ce4f2caf612ddc517097246ac577f1a2e06c54cc5e7faaffc4b935070c9f76a10f2d4295c7b1de583f3d08a330d5f11f5889512713ce51f419c23b85dc2127531e1da561ace9f0e191764c7b0232fae4fc28697e435fdfd7e8269b5881268ab13c21274bfb41fbdf9d6f56d67b5305bf723a167d978b714d9fd41190d158d9041b6a53363c7f951039f303404a534004d4942953cd335656c696f406bc97f8c15fd0e134e65a3f97eb5b735d9f45d5811dd931353bff3f3179a1c6205c363dbe227c5928c7ea5cf9461ca7863e499479780ca1019037706de585b0a39032dfe5b69a2531fba929722802452f1d21ed95678928aa77f17bfdd725581f74a3c9ee772de1bb8fe7002f65bebc06aece059ae1bb983d978ec4f66d3db2ba195598967b9d29f0ebcd9d81dbf6513bc66259e579bd3fb6c4eca95785e6df63ae9146a9acd0b8822ab85e0670b150879644ef4f9e0cd41d2bf1bd8068d7dd460ec0002c43e49a4cdf3ca1f2f9c67a442883f5056bc90ef7e5e0d062f3caf78476e3f2f30f7f36a30781157c55bd39a90d625e4a101197995698309fa30933666d387796863b63d18bfb6d5920f2e37c38c9328a24511346bc854c3ed2dd344804d1bf10ddb6ead0b88872f4ba5d268d4c6047d98691bb3e9c1f81d5bdb3e4c6dab25015cfe7f24d0446f4850403c9c31b5047e3bbce00ecce60eccf636a62581feb6378af3bf67812682047854f1d58957144201f150e2156454d77651087d98595ba64d0fc6ef14ddb60f53cbdd920085d99400c71823b92cbf64b7535f2fc5b186c3a58a68dac9c77581710bccce9c681d678302e2b768bad57f0766db87a94ba815b48b5a6c467d33ce40a3eb08ebfd685322b79b94ef11d2d56b3b4acebaf953825a5276d40e34a6f274d699dddc9cdd96fc3fdb8776b0eff9aa056e33e7673f398d745c4dfdded89266b6ccea8c6a7ba99bab4679bf6b4bf4dace964c3bdf9bb5e9de50f6cdecee');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(24, 5, NULL, '88ae1b474d0459757367bee0458b577409117a851f842578ea06de0af949f768aeee425b5396bae468765922956d11c6f8f99191eca8a1968cf9f929cb4fea1b95921c002b07374270d11a2c7acdf5c37ced0efdd9783a81217d453931e2ae22aeaf239f174e35b270da5e2084f6003ac8188e09b49dc7e67bd9394319c64313dbd2fef065f3f5fb87df3ec3b92891392397a5bd664978b4622aa8a5387ae31011582aa618623902c3fdca08d7349223c46f441c12e8c5e81e720d0738f445d1079b77c573338a8e60c7155ad8ebaf1817308a566b38806b7bced5f50776a7bc0a59629e444b5b3c45a6e165f440c24b7919aae73ce35675095cfd0b0000ffff0300504b03041400060008000000210042343a0be30000004602000023000000786c2f776f726b7368656574732f5f72656c732f7368656574312e786d6c2e72656c73ac91cb6ac3301045f785fe83987d243b81524ae46c4221db927ec0208d1fc47aa051f3f8fbaa34a435b874939d34179d7b18ad3767378a23251e82d750cb0a047913ece03b0deffbd7c53308cee82d8ec193860b316c9ac787f51b8d98cb23ee87c8a2503c6be8738e2f4ab1e9c921cb10c997a40dc9612ed7d4a988e6801da965553da9f49b01cd8429765643dad91588fd2596e6ffd9a16d0743db603e1cf93c53a14c705f111726a68eb206296fc35a165750f31acb7b6a1cddb84d782a3b9e88d8ef19ab9fbc96e5fc97537d4fa76bf9bcd035bc6d484d7ebff9040000ffff0300504b030414000600080000002100cf309ad5e30000004602000023000000786c2f776f726b7368656574732f5f72656c732f7368656574322e786d6c2e72656c73ac91cb6ac3301045f785fe83987d24c781524ae46c4221db927e8090c60f623dd0a879fc7da734a435b874939d34179d7b18ad37673f8a23661a62d0b09415080c36ba21741adef7af8b6710544c70668c01355c9060d33c3eacdf7034851f513f24124c09a4a12f25bd2845b6476f48c684819336666f0a5f73a792b107d3a1aaabea49e5df0c68264cb1731af2cead40ec2f899bff67c7b61d2c6ea3fdf018ca4c85b2d17f45c44c933b2c1aa4bc0d6bc9aea0e635ea7b6a1cfdb8cde6c43b9e88b8ef19a99fbc967cfecb69794fa76bf9bcd035bc6d484d7ebff9040000ffff0300504b0304140006000800000021001a6391e5bd0000002b01000023000000786c2f776f726b7368656574732f5f72656c732f7368656574342e786d6c2e72656c73848fcd0a02310c84ef82ef5072b75d154464bb5e44f02aeb038436fb83bb6d69eadfdbdbcb8282e02d93906f66cafd731cc49d22f7de6958ca020439e36def5a0d97fab8d882e084cee2e01d697811c3be9acfca330d98f213777d6091298e357429859d526c3a1a91a50fe4f2a5f171c494656c554073c596d4aa28362a7e32a0fa628a93d5104f7609a27e85ecfc9fed9ba63774f0e636924b3f2c948df8c8cd3212634b498394d38ea7612d73645055a9be2a566f000000ffff0300504b030414000600080000002100d6dfcd4bcf0000003202000023000000786c2f64726177696e67732f5f72656c732f64726177696e67332e786d6c2e72656c73bc91cb6a03310c45f785fe83d1bed6cc044229f1645302d996e40384adf1988e1fd84e69febe86524820a4bb2c2571cf3da0cdf6db2fe28b73713128e8650782838ec605abe078d8bdbc82289582a125065670e602dbf1f969f3c10bd5162ab34b45344a280ae65ad31b62d1337b2a32260eed32c5eca9b6315b4ca43fc9320e5db7c67cc980f18a29f64641de9b1588c339b5e6ffd9719a9ce6f7a84f9e43bd5181ceb7ee06a46cb92a90123d1b47bffb954cc102ded6181ea631dcd3e81fa6d1ff69e0d5a7c71f000000ffff0300504b030414000600080000002100e9e33f96980500003d16000018000000786c2f776f726b7368656574732f7368656574312e786d6c9c98db8ea3381086ef57da7760b999ab21989ca390d14c0e9db346ab3d5cd3e024a801b3403a9db7dfb20d041b27a467a41e1cfcb95c76fd2ea0c6df3ec2407bc749ea93c8d69161ea1a8e5ce2f9d1d1d6fffe6bf175a06b69e6449e139008dbfa15a7fab7c9efbf8d2f24794b4f18671a5888525b3f65593c6ab552f784432735488c23e83990247432f8991c5b699c60c76383c2a0659966af153a7ea4730ba3e4191be470f05d3c23ee39c451c68d24387032f03f3df9715a58fbf09eb2e725ce05d65af8537171c67b4a7ba853f32ff4dd84a4e490192e095bdcb5fa2a87ada1b0ced0ad19526c56e8246fe7f82b188e6171af7ee06757b65c5d0bddd1ea1891c4790d20221fa8e3b8152f9dbaf9e7fd044b93b1e7c3de524168093ed8fa0f6bb447486f4dc62c74fff8f89256da5a46e22d3e64531c04b6febdab6b541aaf84bc5172e5d9ba0936531c6097064973e0f28e39fd0381ded2fff834d086395ae524d57631e182c9e967a279f8e09c83ec4f725962ff78ca40bb30333967811fe12d7ec70174c14dd818ba3f23ef3ac3a90b9201770cab4b6772490066e17f2df4a9f661639d0f76bdf85e76b2f5b6aeb9e73423e1bffc37db8392b7721eae398f2c0375cc1e587f340eacb279e05a8c338d3e3287edfee3819d7c205cf38103a3db37dba86142b0ca26846b39ce1a7451b7c9d35e3eb05f19f8c4022163b0f9e09acf377c665f86f930b87e6e5fa88678e4a0910fed19836eb7d31b346c29c83a1f0a8d72739e58232aa24f1bf940ab6d3cb5ada850006d94fe3ea30054488036f29108191dabdb1fdc51418bab9c1daa9993399371422e1aa446f03b8d1d9ab8ad1135a73e26703e28fc83d2703480830394c2797e9fb4cd71eb1dcea80b7f60b3340c8bfa84614a8361d0e6cd30521b06e6138629cd0e7369f7e62f5bd3b4919871a2535d75a7f48d19992b10699e4533f2d28c2c9b915533b26e46360ac49296b4553012b26b46f60f11415390893e117a4a338197a1bf298a879e13307f49b4c5b8ce380199af24ba2231af13039158d40924edd28b02b1442b4b8ed02457ba822415ae544c4fb4b3563192c79bba3b96b4755b052279b3532092337b0572f345083d844008fdc9f73ccc1fd7d5a73d3bea8f7318b5c41eeae53e4ad19872027cbb47cc38014fb6929056366f24168dc44b23b1e4047d7cdd7364d58cac9b914ddd154b12e8b619d93523fb8788a008fa45527d72fdba22a8255bafa677696dd33a21270a4ec04b4b1988be78f0e6756228128b3a81a463f7a240244f961ca12f24a52b484a5a2b1523f9bb563192c79bba3b96e4ce568148deec1488e4cc5e81dc7c116401211064012f3e8113a7d87b2235d0b1901a60b272ebfa7272c81921d25294669ce95473755f92d45cc5487bb7c819c45eb45067d097b6e54565444ac3cb9cb198919e29ad672574774df827aa72ad9a438ae02667b8a31dd3b4a474b8156669f7a439764237a24e48c45e204ce34ef0d9776435297c26fa6cb014fe8114b66901813f378dc8f1cfa1c7025042b2020ae8be040a42109bac8102ba2702b15fa5828210a691655040f7755010dc1124bf51eea47e85277b11b92f057828fe7222a04fd45a26b8698ebf3d16d06329704b0d5250413529e4d00329a8ccd4a4904377a520f42b02b0ced72d2ea92605c15b554a28cc7047ac8e74e277523f4b0a1243eb51ecd1cd6dd4b5c0ab48fc8337c4c991d59b52cd25675a01a2a3cabbbcc835eb8ee0e308aa42d2fd4d7704df29b42e557640d1e8748d710295a6b76a3baf96c1176d405c5690b4f52fcbf9f6e7973fbe83bb9e9fc68173b5f569e0bb6fda0927184a67500e73719a6ad909c3ad20d6d8973a9bb03a49ec1cf1ce498e7e946a0114db68150bde98125efa626d28c3b1bbf055f34a32a85a15bf4e5074c5f0116f1ae0da8190acf801abcacb9f5a32f23d5b4f561eab7105f8e8b8d7bc007aebb3985b65e177f23f000000ffff0300504b03040a0000000000000021004bd08478c5360000c536000013000000786c2f6d656469612f696d616765312e706e6789504e470d0a1a0a0000000d4948445200000291000000900802000000df8aa7100000002c744558744372656174696f6e2054696d65005475652032312041707220323030392031303a34383a3531202b3031303099dee18b0000000774494d4507d9041508332734d067c9000000097048597300000ec300000ec301c76fa8640000000467414d410000b18f0bfc61050000361c4944415478daed9d0b7c54c5bdf867093eea0329494c00950d5093546c8c40841ba91b493569ac044b4ca80d5724f72f5c8980cd4aabd594daea85e42f20f809fc9ba8353e922657c03625d8d0ac8df9a38994e6824da2600222249744afdaaae4b57766ce9cd7ee9cddb39bcdee399bdfb7349e9d9dc7ef37e7f19bdf6f66cf2004000000008019b0e0ffd756edfe7cd2fc00567a635c4ca8f50200000080b0e286c4e91385a3db52120355e91b2ded4909d3fc2eded6716634c50153130667df5c2a984bdaf0933f2c1534a3cc26927c42a8050000000000401760b301000000c01c4cd495ab674f61e1aebfd3c31f3c72607d727065ec6fdeb5b3a157384eca2bce8e1f5d759d7bf7a2ecd15662323af76e6a4f1c75cf0100000021458fcd6edd56b86bd623077660537d64dbad4f3e3863c7334b63832520b636553de96b8b5747b24f9bf68eca6c77eeadea895e1b2ce98d427c7631d86b000000b3a323367ea4f9f5d9ab7305df3af9eec2d99d27cf064b3aec6157b525e5ad4e8d6409f1d979496ded9da3a8b1af07c54645fa5f010000000084081d7e76f2fa3fcbc1f08f4f1e0f9e70fd1d477bb1c5567988a2c748a3bd79a8aaaa2d267dedeaa8a64d556df47b45f09cb8e842224b1583ec559b10fd2c67e084dc71e61a94c3860b526c592e429aa55f2ae3ceca7c0af15215830485548aafdc6455a52993da13d74637523564a139a59502a4c7369c4b94925de5d712090000003018fae6b345ced655629ffbe520cd6753939dc68fe9127fb9adad3dafb8385b0a9f635b43acf2ae666276888b8e2d73b168a8f612a3959a937e74e7b9346abeb8a5142d4446c5f6b6f7e1ff12f3ddd8939ea36a881cefdc1b856bc292c4442f92a4128e95e2a920a1795683544514194ac432594559c828c45d295a6d0d4e2e260ad634f7c76b68aa140067384aa5e2cacf150902e900000006c48775e367eb1ebce785999b9f5a3a3578e2c54447f1bfe83bd78b5d42625bb041c5ae648e606f2353d3927acff591c3841ca5e96115e16249898269e4975210151dd3d3d78f0f3a9b1a62d3886d6c54c4e9e3139310fd1a572905dba563593c1770b1de869d9bf692f07e7c7631b5994d0dbd497962dec8d4d5c5ab53115f3ca15a4104b95d9ea64a01584e0df97922010000004644af9f4d0d362adcb13e90ef4bf30e35550aef570c58f7b5b725a515d32fb04542bdbd3b3735489992c8fb61fa9a76ee6c930b26e55137b2bd8df9c41aa594888e36692b11bbcb9dd80cba0f21e42a156e76a72c9e2bd42a6235366daa12e2d8c423768b26f0c5c35993d2b223d56d7135550a20e6ece3cacf1329a8a718000000d08b2e9bcd3cec9a201b6c6c34d151ec0ac64bc60fbba4e8fab5d865ec90e3d188371bad8cf792806f23355674015a62a4662917a8a3ddd97c94c6c5298ad56bc45663518824d72f62c6b1');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(24, 6, NULL, 'e328ba3e2752694f918b545810e22613673a95cc3877620954a6946589e289d7df7c1445e7b00fc4794e8cd4d054258098b38f273f572430da0000008644476cbc67cf9321f0b009346a5bd3dc2f7c22f3b63d42bc58198fc696b5ad91e5213f05db25e66760a3d686e48835338fde4a11e898a191c6c5dd8b5461939710491d62b19d9d0d72649cbb361dd7d0dbd0c456bd63a3292979b443ae368934c7154f592db5ca2e4eb3aca94b4e613a802b3f5724000000c09078f7b35bf791b7a9fcbdf0f69d624af05eab129f5d9cb777931822c69ea7b0865ce546620731ef9c9847cc12b928bd71a790169394a4d8b1a4b761e72e44fc4a5e2957a2a2512f1e25c4eb6a28293d3d260645216d379bd550b5495eb81d4f95cc6b57544b9d6b5e5bcae082e4d2a3788ea6aa65711da273ce57992b92e47d7b3806000000820ddbd76b41fa8a40d5f8464bfbca4cff4dba91ded28e3dfba6a8d530bf1b3c8c74f6c7850ae69236fce40f4b05cd28b35924b7582cf0be714dfa9b6b8e5ebf080c3600000060107cfb7df6b881be6584448a210a0c0000001805161bff7c52205798dd181733fa4a000000000090b821713af3b36f4b491c5d55326fb4b48f664ac0f8330a00e001735dc0e69236fce40f4b05cd28b3892487f96c00000000300760b301000000c01ce8b3d947b62dceb91dffbb35e7c13d3dc115b01b655a9085fecbac50253a9407da651dde2af79461dce25fcfb897529f298bdb3f87565bbcfc7ae581d30a004098a2eb3d68854f7eb876c781833507fefcc8cc1d85db5a83269d0359e2d0b22ee474927f730a14665bc08af63b912db85de61d93da8cb117bbd1c94ea5f4cfa63b7f57394acbc43286433f000000f8870e9b1dbb7447cd334b63e97172ea9de8c3d3c172b52b36a3a246b4caca3e9634a2fa0278988e53acab50513d3ad81d6a3900000042876ff3d974ffecb405b14111ad1bd5d6a32c9b22c5e6e699295d224534d5ee70abac829f4e70b895525455d12da664227ba62a9cabcaa0c01e87ea114a5396d5ceac1480fcb37364e00ae6495a515f979cdc444db175f64ca8d1544aa7f06e899c7e0000003006ba6d76cf9ec29cdbc9769ceb82b57f7637aacf4056ddd9f1a3764e238da376a163696a77dc81e20a48a0b5c4c6299856474b35a252b1945d0ac837a28238b12afc20dfc8060dfc0c22255d2883c6758508812c182f33c99046c2094206542a5b0e7775b4125d85e9466b0ac4c0b2a41737515b6c1f7ac6a53f9593d0d4fef1bf520e50f45c0e15a834032d76b920b495d229bc7ba27b3f0000001804ddef412311f2a5e8c8b65b0bb75d15ec4d3975e0200ff42e1b3da693dccaaf2c69e4116cd3285afe002b95a1acca4a8f6da83c03d539908d7e4cb06a67d0aabd1b1dc3b6dec632172174a29bd5265122494b3368aae32191272d6b88062724b8895ae8ea1937c5555d8dbdd8388daf74906671add9cacbc6554a97f048b3f70000000c888fbff50ae67c367edad6eb5d73d47d42f3abb4cda8b11c6daed0cc30cbea96548fe2445fb0a09e975323034f3255b4202103757473f248e1d9526d7534757417065bf42e541ba75e6fcf4df488fe9e19231abd2e58d3564aaff0c1d5080000603418f8f7d956b48cfa3d32d4b6716719adb334ab69dc8f6cabc89a731fa627b1efa530159c88bad70c0a2d94238f8e7ad159572aa5581b5fa4ad8ea68e5c61a8232e44d191a43b37d127f42b1e34f42bc515de801a01000068a0c3661fd9766b8ef8fbae9ed32782b6060da1551bc964a4f414268b838a3466196d6451f1b30e7acc33ed0f94a38235fabc769b6a7db2dd7d94e03503e584906845739038f2701037dad5ffeb2633be42a2c3cefc6cbe3ada89aec2b8fd5a89d4cf4dd412dbbf9e093efa94d2145e5b234ffd000000102274d8ece4f52fdffbe14f8577aa149e5cf154b0d6a0213a43495706b1b87111729668e62da1cbb284754f731a5d4dbbf04ba1353a02c2425552b815357246095e32d00801165b58b12c0b9686cabbdc02bc741a55589cb539811c0bc173ae3a5a89aec2585159b9b8e08be6b4218d446db1fdeb19cfb8ae41532cea567ea5276e2fc9ec45296fc2737bcf6b3f0000008404b6afd782f41581aaf18d96f69599c97e1737c55bda01400b735dc0e69236fce40f4b05cd28b35924b7582cc6dd3fdb62197d1d00302af4acae070000081ac6b5d9f0b80400000000252c36fef9a440fee2fac6b89850eb050000000061c50d89d3999f7d5b4a62a02a7da3a57d345302c69f511853407db3ab6f2e15cc256df8c91f960a9a516613496ee0df670300000000a0006c360000000098035f6c36d92624889b670300000000a0c0079bddba6fd77ba1161700000000c62dba6df6916d1bbbe3af0bb5b800000000306ed169b3cfecf91ddabc2e2dd4d202000000c0f84597cd3e5bf71f7fbef96ec3ed990d00000000e3093d36bbb5faadb447b28cfeab3500000000086fbcbfbbb475f7cfd1dd0782b7971700000000003cbcdaecd6e606f4fb86db7f2f7efe69cefe1f3c7260bdff1b770100000000e00f5e6df6fcf53507d60b873d7b0a0b4faea8590f13db00000000107ce03d6800000000600e7cd98b3376e98e9a50cb0b00000000e315f0b301000000c01c80cd060000000073c062e393aa6f09548dcbc82ea47b4653435bc799d0764a6819cfeadf90383dd422000000181766b32fb7e506aac62f1cd5a3d936dc14bb8e8f1de35c7d8cf3dd504b000086c1320fee0840065f0f101b07000000007300361b00000000cc813e9b7dee831faddd9740ffc5977cf051a88506c61bf679c85288bafd28d9833271d9eda1560000028aff770442158524c4ea08b50a807fe8fb7df67f7f7178e14d9df7c4865a5a603c81cd6d35dabf2ed462008041803b02d0e96737ffeda3b9532f0bb5a8c078023f9eee40f5a19602008c02dc1100458fcdfe47f7992bb2ae079b0d048f8a5fd3c753a52a88b7661ef988ffd90fcb39ed62a2e700b8100fc4ff2a7a38897298518ca50bd53a5c3e6a9452061bbbf791e3cc7d0af1c46c1c5179f503803b01bf23e49addef02245e99f35cef1ae17aaed8ced2a5eb1c081aba6cf6f193a8ee053a99bdd6f1f2b9508b0c8c03563d8a32f07ff2c90f5d6c42d221b4ec0fe463f942547a3f7b6ce12748e942d4f52e72fe0165546a3fa42a117a94942d42a8e00e56d6b11d151c42e5b4cea243284ef9c0aa4459ef2a9a567ce4965a9c4e72d5d1e76637ada5be81d67618952294918eac9e4575690e00dc08f01d21a27517d8b14f4fdb6277cdaf1577c721847259bbf54fc04033d8e8b0d9e7bee84428ebde251d3b9774ee4c38bee9afcda1161a188f2c448be9828a59b3c9df133d2a8b8862d1c67c62fc1cdcb2f968152d9b952f96ed419b2bd5e987d0c11eb92dabba69f651a394f526f23c3d769a24d655a2229ade8ded374d59769337515d9a03003d8ce68e10d0be0b4ab0b55ec75c705ca7703d6bb60b04111d363bfa5bafecb4dd132d7dfebc1b5c6dc0000816118ff485305d5a25f9e8f90962b592bf1d1fb38f19567e3a9aad36a2ea8f9c52b168d942ea5bf7a063f8d9b78eb8265892830dec01e745d4d960b38100e0c71d8134ee0221c05e9bcefc6cc038f8b2af17001809eb55e46fc66368ff12bd4584c07582f882d4fa6e7eba67b8a54878fc0974f01d54bf1095e1c485a8f61d34e71011cf8abfd612157c142070f8714720eef54cfdf5a2dda864ae980942418641879ffdde5fe3d78af1f0735f74ce98fedd68ef85006054c4a2395ef3cc251e009b39f6fc8bd54ab688a6ae528cec899143d7746f52699512c2e3054f30a7199b70ecee940a81719f4405002e81bd23c43a3ddc05a56f91bfddfbdc62e34048d1e1675f7763c35d8eefad250b049de8eae776de7875a88506c60359f9a8b412592ac902192d4ade45681e8a9b473f2c445d3b34bc01fc60fa35b21c2287e58fb23cb675a8fc38599256e0b9ac1acd524278fc102aba997c123c1ee51350afa800a04120ef0811fef53c1735e693d0ba8546d7cb1f2383d1133dc8066fe8300016fcffdaaadd3fbcfe1f81aaf10b47f5e5fffe8edfc5c7f92619e35c7d8bc5023b22008004ec110228813d4200000000c03480cd060000000073c0e6b3bf705407b0d2b68e337e97bd2151dfe25d204cb1cc0bb504006024e08e0094309bfd79ee9b81aaf18d96f695a39b91fdc52f7e11d23e092ac56a652de34c7d17b0eee69bbd533f52f11934b40ae69236fce40f4b05cd28b3592477931062e32166d338b6d06182d16ef2709236fce40f4b05cd28b359247793106c76e801b36d7a8c7fe79b57daf0933f2c1534a3cc66915c2da1cef7a09dd9f3b3953b8f93a36fdffbfc8eac60fe182929af383b9e1d77eedd54d516c4b62931e96b57a746ea6f9a0adcdfbc6b6743af4a784f1a60b35decc1721311a29a02abbbfe3ac7a2f5f0e35dd72896a13197b4e1277f582a684699cd22b942425d7e76ebee953bd0ea976a0e1cdcb11abdf01f7b82f7c2456c2eb0cdc3860eb3b713c567af4d8f09458f8d0a417cccaee6fef8ece2bc246eae607bdbbd0d3b3d9861dcf192a09e730212c61fb09b57daf0933f2c1534a3cc66915c94508fcd6e6d6e882f5cb7742a3e8c5dbaa3e699a5c17b1b4e6c5424b679edd460b45561b3479cd720434cd6a68018adde86a64e84e217698d3b2048ae44d8889aecddbbcf75df6b2ff4a04c7d3b07071ee59d7fd847b1832f79809e531585544d2c3c7d53a63d68af650dec735694dfff0c4153906e6eaddc33db1f65852bcd8fabd43f998386df37912f9207ef22779350476cbce7f409343335846fad8b4f4c426d6e265311769603ceda89fdcdcd7da9a9f43b16b74662d89b552826b3587867677c3c75f11ba355b1714519b922bdb4b57766c7c747e1ced4534cd4a6bfb3534e94dbe7eb21ebad486589382527aa0fc5c7637576f52d1222de34f4ddd11c954af3d29c4979b46076f1da68dc0452c4c6dd5b5717f7bd4b34219b62e5930d0131ab7cd9f3a0e2d7a87e7640440836e6959c108bf6ef204fcc63a116646c150c0be42b6daef1564a074ab5b123a417b90e3ffbecc9f766cf40750f2eceb91dffdb762498e2b555ed259e69767171b12a2a4e63e6d83ea842e6e24432370a1d99801a852f50646a1afd825a2616b8c6b544a6e6289a8847ed9b38ee352d23361c99badaaf587d54b48e4244c528dad0a626142f0e2c70fb091dbb0491fb5257530d63d27352fb58fc7d6f677c769ea41d4bddd51c952df645643c6a72d72b3e35aa49cc89556aab22fd84bbc6c5fe2aea945aa7c51350cd26d6256949280060d7ade010d9bd806c72a07005ecf3c8203a93fadf0e852f6e11dd0e5541a93a5a837dbb9859fccae19222b82f8ac40af138739faa2ad7446f38dc9a36a2e43dac6385be15dc4a7ba15b576f572b55883aa4e238ffafc94bd7e3d45e88b00db3aa5d97b614f5b33cde5a77ef6195a6dbd59d2c96724d51b78239c8ab4796b9906cb78aaf40bb8b307ad4d9cefa019f6ee900e9504d42aeb35a21a1e4702b9c6f97dbc4e56ad1bab9945708ab53e3f2d3cf282f5495182e6af264e3df447ee0f1f2ab505ce4fa4f5fa0d0359f6d39beeb45f4d38335070e3e92f9fa930f06713e9b45c489e1c606125b6ec14cc45c9f1089fa3b8ef62245c83c2911fba42c9145a11365fb217e71ae0f8946');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(24, 7, NULL, '9396acea495f8beba5fe6c64941c4de8efe3681993be08e7eb6ca2960cfbcc642870fdd84cb013155943a8ad115b500ad6912922a44a1a8ac300a213b5c7246773a360995513d25cc5c4aca4dfb4558a898e12272aa8f6d2d84394a9a7af3f40eaafda81ca17523fdb6d9383fae3a8ec5de21cd87ad09a27c8ce83f8b8311f95be406e210f054be98f2f9dbbc92645cfd27b3eed38ea52a628b2753d46126badecb8fe09d18cdd4ff62824f5fc816cbea92b3ee9de902125b7df8196fd81954a131e408750c2a3625737d016f1b756fa78956478141d3b2457f2c0a32843bd35057ea809db30e37f739e10c75e2e6dd10e6954e7f1d4ba1bb65ca294831e57bc40776a712fa54829aa6499e556e8a7c5eef5b85389b2d495e852a712a147c9292bbd5f3c788b27a4f65514f7043b831bf15de0eda2936f13b7ab857fa5d12b44b8260521edeaebcae562d385bf172a570c2e2eb279b8897c8677f909677c957491eb3f7d8143d7ba71e7ecd58f086bc593ef2e9cbdf2e45912260a26d812b50961593219dcd640a7b95dcc03312882654f95d2a851d18cd4b2d033f19a1b625d1778f79dd32a27193d62a1e223f506ba75d5ad01196944b163b58624688e4df22eb4564c15a2d3b437fa7437ae4f22dcedb2c5c7da53dd7bfc51683464a4abb6d22a7802598467d93a2f05d9f3773ad93493301739a793317b3d2f9bb031d79cabe4f4133dc8fa0ec95c7f3fdd9d50e034a9c70bee0d1950f21e746c217a40d857740972d214695fb2ee77a86321adadcd27830c7622a82e1eb0de84d01d4453f2247d57a3adc3a83e1feda75f66e5a3ba8f89b21e5ae740c5a83b8c6cd3512d426573c958c1b5d412b4ff51b9df127aa89d76d983d5ad1e0ee266d2090be96e57c8377532a483e3c8a147354af7695a1b95070f50322abd5c33f26da271b5b8d64faf90c625ac4811dd8bb3e466f9ba922f3ffdf87ba172c5e0e2bf6c5e912e8c58de6523759abed3174074d8eca933ae3b7e125f305383218f077a8f76f4a7a60a7682632da9071de9c37c2af5cbc5d95f7a72b82ea81b52bbc2c8415719559bba8b48430e613c22c0d59078d20de4800c6c72d28fee6cc0bd91a05f2ecf831b11d14cd38c2a031e2af0b07a158d0496526bd4f8ae7c3b79053fd3b1e352fe07f26ccdbc839f2781f7225d5c64952f63566e43a6905c09767df62b561574eb7729f023ef5dea3fdd41f676c4639412df5f4fecd23a9755f722cb5be8012b42d45c75bb973a8c2cf793aede4f7b5e673d638d1ed546839eab25844d2718ff5dd51e2f9bb13e7deee8888dc72e5d91beffc53afa0af123bfdb713c33353958d2614f588a870b017121364bccb718fa26bf4aa293ddaa58352da963b259ac63916b6c9c8b6ae1b73216af0f5568dd0b444569e23d4d5c6086759443d75847aaa1f2775904eaf5929ce2dc32c9e0b92fc4ac44424925b76977322c12a3f144fba0bad71ce8cc56e63eb26730098ed171ba7ebabbc9df59b1ccc3d0037619f170be40984dd4bde096d39001258f45730ea183d2bca67a3a90f8ca62c4589839c64e527d039ba1ac3de4a96932e1b79d59eeaec7d0b1d3bcb6a613c751a8bfaed2f539eede3a9fb92474b9a6016d5ca25d2a9f8e8d0e2be20ddeeaf18e8feaf8a39ae895d6d140b1a35a3cefd4bf3c465d70ad8b41e7d5225c219bf7312d4a91c6bc802ff87da1ba8aa143cdb145e3b2d17ffa0288aed8f8fcfb9f3ffdb3958b5f20c7773e72607ed07aaaad6a1759b49d5d5c9c4d3f631fb38acdbbeedc1b559ccdbec0ce323183bd559b505e71360b127bf5b8dbaaf6261667c70b75743637a3d454ef8bc39844421b3a9dfa78497e5fde0ac3542445fb3b3bc58900a17d1606677aa3869a669cc6dac0896d8a9c422acba9a95d6773df22555f221ad4585d1c85e5951feeca3a89f221fed1762c2a7b8c0ce449dc950e78052772d66cba08e5b86a56d51d21c098368fdc9045c213c1eb901f1b9edd64d06da19149ec32ea715b390dcd35a2e4257f20ce50013dc65e85b547559c082c3819f9c8498d59d7699ab210152d54e59c4397e7482a5897a0f24271a30b3a0bc8690bc9f533d9bcb5cee5019cad9b05a5b9a58a841ea0fdd6f1b166bfa9ead1816feaa8cf8b4ed5f03583473c71342a93912f868263d1c67c94462f2439510df7f293afb47bddae902798d8257389951a0da3ba50956220ef6a4ae8bc897c60aedb653357bec8f59ebec061c1ffafaddabd207d45a06a247b8464faef895b2c9671be4946b0d537d26bce4cb947881a6c9c4ca482b9a4f52a7f452159dee577fc3fe0f5045c4153604699cd22399650e7bb4b0100000c0c9d7424bece280d6da0ea0180b1016c360000e62750ef0609bb778c0061068b8d7f3e299093d437c6f9ff9be51b128dbf8e100000000042c098f8d94909a3daf8cbe17084a42f8c80cd661be7ea3b9dce504b312a2c168b89543097b4e1277f582a684699cd22399690d9ecdb52120355e91b2deda1d60b00000000c2105def2e050000000020e4e8b3d93d7b0ae90621b7fe6ccfd9e0c976a4cce6c2c375e26b43eb1ec61fcb74ef5742ab924a9b02a2a27e054d2880cefabb2b322d76877fdf861e229f8c7e49b97a195d593f90fb27b3a2db2d51a92c37d14852fb20b6e115f4a4b29b7c01bc2c95b78bdcb563d1b1c6ee6dcdae20e8da3f7b5be12e74eff3076b0ebc7c73e33dbb5b832a7aee5607636b2e6a29c90ba9191b57c4666d71acf1ed87f6211f67180c873dae604ea393d1557e2c4def23c2ba6abfb3c486c2d24eabfb079577d1be41056b842793d4698d45a569a2eadcc4104a2d9c5522751c9346bfd88657d093ca543e950d713c5b10b017937577d41789f7cbfe55d631eb5863f7b6665708e8b0d964ffeccc15748f90a959f977365406755f2f99e405b9f86fd719d23ab1270e5f2d0a000415475d6946f90336f1a37555597946699d23d4621906da3f65f47944c628c29349ee34db03527771134344f78963a8288bc882a5de58848e9de8f6496cc32be88ef24226f2d577744b5fd9d38e65046a7f0ed24e8255abedc075acb17b5bb32b18269acf3ef276354229b7cc25ef3a70898d4b51f4b2329f83e04255ead0bb3a59f1058bb1d795714a0409593045e3ca6904a157a8cb5b27e6e5c889333c5c562675a37bb54aa799dba8a28b68be236579252da87a83aa064d511fde73ca67ddf93149f2e050c5b9a86f5a21e655670d26d6848cfa82671d8a0495f75ca108cfb986ea987b4dfc817a549aa654c24559f3428cdf9c5956ed44ebac398245e426860aebe265d2639e3c59972db6fa22b6f11574c756a270f5b003287dd15db11935962d0b5033b81784de54a705bc630ddedb5a5d21a2678f90ab66a1fdcdf4e17db6aef2f7a8f36410e7b48909606ca84629f687b2dc5e4f842d03fe4a88a12f40d5be554fed4c8abd8ac6de5b4af29871a1c92c2c4f63f24f2b8c5ecb9b68294eafb2a7e02ff60437144c048b6372c589330547ca3654cbc256bf2aca5afd267ac8c134e3c9d9528d960be10a5ced9bb754b954ab6cd4fd5b852455f6ae0d3831790de9122cc8167a9278a5c8b9eaa2bded588eaa5b7cd35d19a09b23c52411366975594ed73857692d2a1312d566339860134d64d298069425c459d648c79b95430c5b495779062a6a941f995c65cd097ef8672420a3cf2bba834f6b57c2662af4e6842e75dc32ecc1565af2b9bb2bd6d42e93e348a3af1b8f066ad7847aa46d083c75851e3f7bfefa1dab4f3c49d6a03d89f2d7ce0eaef0f27c363608d8a8bacd97f61c7e133ffb7317d038b9103fd74d4fddabd8c6e72ea73686966d79f3303178c96b882d9b4afdc40d6418d0724a1ea8305f3f765a1c1263f5c1a2e74c97a82a9557689d48bb464e7415144dbd26855f5dca35c206ab47deae16f3a2e4a5f694eab7959dccfd9624da970a8d7267be79a5c8b962bd4dd37cd25d119344b6ac2279742c3e42b05b2be71647a9aac4e0833d14a7340da8364d4a0915c78ab8230faeb2a6a5be60b33c7031cb63da61b7c4d52ea3b3f0cb6ae34c34d81835dd159964d8cc86298e676b97950570c4426e70b4ac4cb85f3676c48da38ef5a92bf4bd532576e98e9aa5f4a875db0bf13342b393766cd6f2dc92966a62a6dce6b145e3a36d9eb45197a5c639f6481935d5c401df7256383604674fb5a45cf31092e415a4a5fe2b894b3385ecec206e9a9777262b3290e15089f445ee727546b76fc9e0015de3455acf7592318f2fe171ea9695b10fa271b3e263b7f82ad24a0c21c478979067dee68a076cab5c25d42fadd1f41a1de274369d578c134fa8b1a163c78d6c167e6351c1663c76b4855aa860e84d0c362aef2a119475d8d3d046a735800d9099a3558acfc7c649c7eaed0a2bfbe0e37c36598f36f32ae3bd3d5f7283b1511b5d596ac1e9d4b914e42548863db488665a94978a450cb6188526c171bf10e607445cbd66b76f8520833f754a81096af6f970174bab7c506ac0ad41ec793f2013cf6a2dc854a8173f7a1cc10d2a28e717a579476ea2a1d02fb63915641eb63c47e3a82b456cda872db9189b80c35874ace17bdb33fa7eeb95f3a0b056bc75dfaef7d25383b77fb61ae5223499d8b9b760f75888e60ab16efd10d71d8913c0aed5abaa54c6c64308319562e09ac84b1d6532d6601e3399d9f6a3dae405b96c5280d6e1b2648dfb2d491427c9c95a33a988689379a5c8b9124b1dd953a239bc2237155be6d37db096596745227d6218fe4ea36b52d354bf3b5e831d15df27000db8462610102f559cbe273f1812263e6c59e20a04398d9f182ab1c91a34416c32b9cbae43fd621b5e4177840b57f4b029d2a40ff9c51b5d72e1547eed0fca31aebc066b2c3ad6d8bdadd9150c3db1f1f9eb1f695e5c78fb4e849cb357bffc54704d76f5069bc20ae56edde2b6082d366bcbd653b60d345f6e6e2e5959c5471daac54e20ae8bac9beaca635f0849884c106fcdaddec09aceb5db5149090dc9073bc0a0529e4a47e47d38cf66131388ef4a6686f3849c29f6adf6940d647ce15b5800577be661b17772b73a482ff478fc1629259112b14d2ec19d796a2bf6aab9a5847345644dc9cdd59ec6b095341659d22ca5e4183f0e58fcb4a4ab3c33ce42b6b54119e55dfb6d413e1b3e43225cb3ec96384b014b2052fb3801482c4441419ca5a3d159e25b491380cfe8894cd63df834db58a274eea5347e628820bfd9ab8d13c4ce902c997eb10dafa02bc22fb0ebe5eb9888385a0bed8ef2fea62d58c7ac638ddcdb1eba4280edebb5207d45a09a7ba3a57d65a6ff3f9cb6582ca3d924834e444bb6d77c18688f1012723fb53cb83f82873d4240da71257f582a684699cd223996d044bfcfd642f8c1af109ba573a46ee173000000000803c6642fcee0c202d962e01b3bd926f5b10d045b879ebb754ba8250100000024586cfcf349819ca5be312ec6efb237244e0f759f0000000080111993fdb39312a68da606a34ce8860203cd6787487d83cf2779c5f85362e69536fce40f4b05cd28b359240f8ff96c00000000181780cd060000000073a0672fce3d8539db149b669fd9f333f2eef15b55896387fb9655a344b92798cbfe60ea4643b069978b98e3692f6aaa2f27ddf306d246df5e5ab973bd2f6f8ae2ea657465fd80bb535b376fdf906e036d26c2df5f4ebfd88657d093ca6ef28df565c96d5a7963c927215c7a5b534182579bdd');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(24, 8, NULL, 'baad70d77bcacfbb57eeb0feea60cd81cde9fb37ee1e6babaddcb38b6c59b521b47614007c41b113197d5fd4b134bd8f08f5ae9dfaca980fd23fa89ceeb6518e0ad6b057a2899da6dcba8c9b1842a985b34aa416f76fd02fb6e115f4a4b2fb6e2ec21b5782dd7477477d91786789ef290a97ded65450c093cd3e5bf7e0e29c9f9f48cfbc4e4e6b6d6e882f5c421699cf5fb2faba86e63136daf415e0e29e5d64af2db3be2b05188790dd9515af2a25efcf92765e0658ff94b1dd36f6b32793dc69f4ddaf427771134384627f39f2f655f66659fd621b5e4177941732914ff19a78873ded58c6186e31a7d1344976dd6f205c7a5b52466343058f7ef6b4fc976a0eec5832434e51ee1142f6d5fef07410dc5ef5ce90540c21a45d47ff2304cde510ba1c50ee91be0f60a45b51a9b24a7e5b2cc65e57163821e4861495b94f20d050b3d441fc76bd952a935f27ce4b7cb8ac4c9a5970914a15d8173f7894fce13d3af6f8e2c72485d7f32ae25cd437ad10f3866e8b47b209866af36eb5f75ca108cfb986ea987b4dfc01ba018342091765cd0b777b0665a2b49703373154d0f78dcbefbd17de05ad5f6ce32be88ead44e1ea91ad9d45ba2b36a3c6b265416fdaed1ddc288c7a5b4b41114f367b6af2fc506f6645de97425fbbcd333bd5a7a66da1db6a931caf5e5325ecb18d8f056b71a42cafa4856dbf8d6b6929793a00569b562aec57b535b7a5248f49e5b1ad9637d152269bb4adc668da8f63edc495e4899a6ea8961b675b9e900e7a133de46092eee1ccd96b942a39b55cd8afbc4b9e8ae025b654a3e5c27e5d6e5291cd40c4a156cfe137917d6932ce236e3e26494ea63eba84cdbf96a36a6f3bb229a364730ae43d654bd3eab29cae71aed25a716366b5d90c26d8448bdb66736cac2c21ceb2463adeac1c6290f70ed30d18a4e71657597342f76643469f5774079fd6ae84cd54e8cd093ebf40dee4906d5144c7b7bb624ded32dfb7bc0940d3c478d7ae09f5987c2c75f5a0a0e1d78dd3883831dc64870ff5723121662eec0ac9795f292db9662a75ee3604666f2e6193afdce5c226190b8854c2d6551edb62b209824a5b51fa27c0992e71aa80b62fd4465a5f2327ba36acb1a9b866296c60c97fc9a667d2ce5cfc44b64129472ad96813938de538f276b5748ec8a626e44bfc550beb4c9ae65977454c926ccc238f8ec54708766be5dce2285595187ca4ed8f44e32d9b26a5848a632f7b757295352df5059be5818b591ebe0ebb25ae76199d855f561b67a2c1c6a8613b72b2618ae3d9da6565c11ab1a89a268f02b4ac4cb8b33676c485dd29f0a8a0e16d36859a44c1a17e55b7b32c445d05e7cedf5da579485b6953532818e7b16acb1571cb6cb17d716820879d957b71b20d3a35f1a194c7449e54c46893110533d9e41b61d4453b8ab30da7d71db9555b662b8d1b77534ea3edd4498d37769a653f5a29a17e698da6d7e810a7b35d67498d0c1d3b6e64b3f01b8b8c18591d1bbd89d59477e474d8d3d0c620596c97a615ab1f04c2ee147854d0479bad9cc356ce6d070361a36cddce32dd0e3b77ab62d59a6c57468524015d20472b1db3b65c519869d9549297838b6167fd2306cd52dc4880c7f000572aec91c7bd79f8886cb29130a520c25c7ca962babd0b83bb585ae583aa0cb841516e82cb5458bccc2c96290870830acaf94569de919b6828f48b6d4e05999b2b1b12b2833d9bf6614b2ec62ae0e0d6b40661d4db9ef1d5cf9e9f9adeb9631f592ddeba6fd77be9a963bb99b6e0be9649f3a2f222729db0f02c0d690720364e22c392af4f0db522261fe0b6f8026067549c2726ed534f978c1d98cb4be6a87556a5594a9cfb269a48ea71133d4a45c2e471251b4a98c94e5e20c7d4c9792593e2641426567c648fc2f72637155be6d37db096596745227d6218fe4ea36b52d354bf3b5e83bd05df2700c3ce8d10205eaa1876203f1812263e6c59e20a04398d9f182ab1c91a34416c32c3caae43fd621b5e4177840bb74bb965b634e943a34764c9c518eca8cd6f5a3d1a96576b854b6f6b2ac8f0795faff9f7ffeace9c9f2f6e404e94b9b9666c4d364a5e5365efca2bd9606326057b6abab77366db7d096573ed765452427cba64fd81811671ab30b16dec463389842fa47dba47df169f6a4973b135d2fec379369b98407a834c05e7093953ec5bed291bc878c1ab9baf592ad77ecdab36db0644230744bd1ead44d57972950ab169f2052cf680f39c7958ec505609cadab2f5948d0a91929b4ba228ac42c59ef4e471c0e2a78a8de033cabbf6db46d9bb630e8970cdb25be22c052c8148ed63389158888282384b87cbc6f761013ea3273259f7e0d36c6389d2b997d2f8892182fc66af364e103b433227fac536bc82ae08bfc0ae97af6322e2985868bd4d2b9e0434c14a8fc2a3b705f9b80a0ab07dbd16a4af0854736fb4b4afccf4c5175663b158c6f92619a1549f04cc4f2d77a80746dcc43153dfe0efe8f78af1b71930afb4e1277f582a684699cd2239ec110200000000a6016c36000000009803161bff7c522067a66f8c8bf1bbec0d89d343dd27000000006044d81ab4db52120355e31b2ded4909d3fc2efeb7f68f4753dcecb4759c01f5432dc53852c15cd2869ffc61a9a01965368be4309f0d00000000a6016c360000000098031d36bb674f61ceb6563d8900000000008c195e6d76ebb6c25defe94a0400000000600cf164b3cfd63db838e7e727d233aff3960800000000c058e3d1cf9e96ff52cd811d4b66784f0400000000608cf1f4bef1a9c9f37526020000000030d69077aa3cf3f2a1c0565af8a305a1d62b64ec78e5ed508b10022e9e1c156a110060bc3330381c6a11009fb9f08208fd99ff4fd6b7889fbdf2ae94004af0fc6b2da3afc4a460831dd8ce340baf3575875a04000000f371d105befde29ad8ec8fff27c0a3b37f7c3d72e945e3e897df4323cef3834e3c58b9edd6b901ef4cbfb9e442cb372f9980a5ba39f54665faf06fe222fead2b204d4cfac6849849a48949d157865a5d0018eff8faf4078c80affb884df4a7900e460cbda15920191e710e0c51839d36772c7ad23f2eb98819ecf937259f1f62624d7c7e26faf63df820bae3573d4d15432b3f1c4d13932f65067bf0a22bfa3f3f1f6a8d8131e7fce048a845007c060c7998416cf6a21f6fffcb4bebf4e4feae3ae777b50b8e78da85f4d3170b9ffb5927fb607126befaa7ef2f1a7b554fbdf6e2c25de72c99d9a737cc0a549dc34e34440df6f7d2e6ba2adcfb6ee143fdf7be7cfb5c978fe4a0b9cd2267b4d87ef0e60f3e516566f959368b33e169e557de900c76d2dce48121397d42c28f26fcfde579f65fbe5bf278eca255afbdd38e138786860606cf9f3ffff5f9afbfc67ff1714eee0fbd361179d984ab2647e026265cfacd8b02789200000828174d049b1d56b075e3d8fabef9d2837a0ab8e4746ab896da7ef689c76fdbfb028a7ef28515f9d3103ad392736fd38196efa78efd6af4ab96aef868a967d97c03d7333c4c0c76baed46ce4ee934c5297d217d2407094f57dea6b4c1cede7e5566969f653b5bffcaf2c75a5ffde5bca93aa4baf4a20953a8c14ebc21696058768c26bf321bffc5067be4f295f3ec089bed7f4115dfdad835383c323834323444fe7efecf811dcfbda62cc525faf2881991c460c3d2330030383e2d71028c8ffc5baf5b7efc8ca35297d956e6d472a735ed626be7f31664b936e1bb53699ea929d5cfa3ca8fe971eb1f673cd62ee4b25cbba8e99994abcfb4dcbdb2e91dc1d7ccc8ee5e3f0bd19496f8c47f45ed2fbc4fd26fbaffbedf2dfd2652e494136985a4606aa7f5e7e8a55fa17b848fb81e74a2f8f6bd2f302f36fa89e7e90002a1b7b6fddf7bea5925624e3e58f1911162b0176383addd574ef5cc83f4d1c99b91704f14526293affdce4b9f7c8c0fbc9d1a62b02f25067be69cef48217181debb3f886cfb3936d582c18eb9f9becb531f1b181e1e1a7412b33d38323034747e70786060c0a5a00bb15744cc8a9e889bb802e6b001c0f0406c3ccc50fd3edb96ffcc734fffbb9e6252ce0fcf0d71336886c669baf3fda69b339ab051ec5a370b9bed1f4f45ce963f5a1f6fc7a6fa2fdb53ae46277eb1aedff971cbddf735b5646677af9bf5d1de1717edde7bf78cfbaa8545d99d7db39ffb49f7b413bfc8d8fbdb5d879ab2bf7f33ae96e6c4c69826febe3265c58f05193e6cbe7bff398412259170cdb9b8e6f8454da4ad4f5f5af7dc632b5f44cfadb8a5e5456cb0b1bdafce268380dc1a4d2d8829a5067bf6f5df39d9cfef01f4e9c85768a4b77fe8a4cb4797746e6697146e11376226455c338518ec5973bec33fd99dd51f45de894a1ebf327565ef5bcf5d74d323827b4dfe0d0e0b7f07ce7f65f1d0c41511f13117088bce0c33770f040978fa9b11b84fc30c95cdaedcfe80ce6252ce0b22f84ff8112d477b6e66e5ededf907c8a1b37eafb59eb8b99b2af2e39a8987bde29ef9d3479c2368e6e35b67363ff334f69bff75e14c5cd5f46951089d6be9ee1b994f2fc16b1316c53a474626cfbc16a1f7fb3efcd8f92f53e7bf5a28343a7371067ae1c0b90f4e3b5984d799b0e58ff957e38377f7d38f2327dfeec035a7dc328bb63579d12dd1cef7cfbdfe76ff8c53d8b4a3963f7f70f2cef957c74a15f2c176ebdb372479eaa3088b05bdbf65fdfb5282055d3b31c272a15bfaedab1fb8f74a9c88c8b7aae22ce5e8c1b73f58f8fde4080fc694c4ab6752f7f7daef684ad59f77fca3ffeabcbafff5cb531fbf78c1a324244edc6b6cb3b1c11ec60703f8e3c0f98809fc86ae9c14f1ad2b491393a2ae8427c138c469197d1d40d0815b35bc906d76d54ebd065b99536baec4c39cf1c2c2878e172274a6f547ffd6d462c10f8273c5bf3bfe5bfa1509384bde303df86df1d3bf954a7ef8e9a911f95b79d2758494faffcf3cbde20db9153943dc37a70bc76254da291e086d4d9f4e0604ad273f59b86c514a7d53cb074db76435e1f494827b5fc99ee2223c36a4166ab06f987783976e8ac0ff8b2f2efb1ef379fffbf0638f7f72c1446cb3d5e9ec5b9c6821dfaa8abfff642131ed96190b9ffde9cc0bb59b9a72d9841953267a1f462034343c34e327c7bf1a181c1c943d6c62b689f11efef2fcd0279ff471d7ac486382cba3c0c31ea758e0c49b1038696106b3d9ff59b6566701979c5a7eb6d60b794eefdbff564a66de548462e6fff6f5f9a7f7557eefb973d8189f8823df8e8cc8058549d51f3ffed0a3cac55a675be9522e926d902edb46e4d756e82fdb9fbeef4f68fe7df7beb864caa19de498542514718a758e881fe981536cebf4a93efc77de55530663666391f0b15043abe344d70fa65ca5683c62029a6821063b658137834dbb16774dc44474a1cb4797746e669612ffcbdf7c2fd95b3b932f99307d32b1a6df999be42d2f1a1e62d67a605870b249487c8004c6696c1cff1dfc7aa2db382cf2b2086b2469e2b2c868a7131e02e3150b38dae6036ed83083d8ecdfffa650676e979c1e0a7ef6157fedf11783e736ad7efaef1bd7ff84d8a24fffe420e1e8653f9c9b89fa36fda9fde597deb9ebdbf3a7a14f5ffb7fc7172c494d7ea3594c41a8b775cdbe29654b46c8ecf1c8c8175f8d7c869cb411e757e747fe49adaf357af2675ff5779c20c7e7cfe30c94612713e63cfb78f96d0b722a7e5febf8a0fd36d21696c1e28c4a4b9adcb0fdc58f96fcf8ae18f4');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(24, 9, NULL, 'ed3b48d37fbb66f2e55f89952074f1059649175bb0dd5a7957ca07bd83de3b2b8298e10ba570b7f4d1259d9b999bc283bed5244290ea6f1f79ff91f4d0d0a060a789e51e1e1e181cd9f5e2eb03035f0f9cff7a60e07c6fcfc7834383116a3f7bcaa511d74c61065be775028425f0f4078090436cf658fc166064c4c935dbdfb065ac6d7a69e7e66d35f42336966b9f5a9e1533fc294adfbf6e24737bf35d79cd24ddbaf0b9cbe63df9d488fd672c85242ecafaf49f2383b4f6cffe39fc0d34fc256de1cb7f0ecf4e5f38e7e0a19acddb6a9d51d75197fdfcd7b84efaf5e0c8a78249ff5afa38f3bee7b2cedf57c7da72463df0d4f2b4cb868f0cf66d59b76d8bd056dcc2e7eeb1b282085df18d09932e9e20bd96f59b9745fce36b6fef9788b04c40968889960b5c3e9283ce9fded72965b4dc72c7c13b54891667c296d229aae23c2ebb7842d4a5b254519747fccf3fbd4895766b4a794de3f23b6e1226b077bff87ad49449d75ebbe0eb8191babaff7c7afb5697fc932f9d701575e22f9d120d4fec710eb8d966046edb3083dc85ffa5c33fd38fe32f7f15deb9fde1b9a1735f18e5459ea3419acabd644af4979f9c13b4fb9f2f47be1c08e56ba12eb970c264fa3b6ca554673e1bfaec4bef52bdf2f2bef303e731ab57e79796ec18a0c79b7ef9a84bb62b2e9930ed0aa6780835050c02986c3302263b9c28c89c1d6a110000000000d0c7ff0213f3f4dc3864a0220000000049454e44ae426082504b0304140006000800000021005167a067e00300003f2100001b000000786c2f64726177696e67732f766d6c44726177696e67312e766d6cec9a5f6fa33810c0df4fbaef60b10f7d691accdfc41b22ad7adab7bb95ee4ebac78a8013bc3576044e4af7d3dfd8a66d2a11b4ab024f4469021e7b9819ff3413dbdd342547f0276a724e9c5325489d15b44ceb45c9b24ad672af16992cc9b9e4ceefbfb53d655f4fb9dfb38c12fbf536a6f98931b4c92877b6f09c8d2475911e294f9fe549a133a18d4a1c9a3365c45acef2323dbe93a03c5569e2606769542cdfe9d86ece56a57a3e52c4f2c47968ea7aff004fe40fe061498572100c395a990baf8712bb7eac7d409994555eb31f34713c1cb9eeadf9b403c032cff51c744c559138e52db7c2ca76e4f6aba1ade56086aae42345df2513b57ae6a0b2648a56d66c04766a45e850a53903a34c1ce463e218f3322904cd947622712ab87a71f6c2bb57575b378d2b3576bdd04176e0a72edfad2d37475933c5a420e9ae96fca4e867ed7f99560726169cee1589d777e1517d6e9b943c9258df3fb15c150407c19db92d283b148a60cf05d98f0513396d0836caceac663bc6997a2605cb732a6ed09e719e492eabc4f9b48717c53ab61020aa4a9983afe949c9b70816692e9f9014262ad6a79a8903a70ecc94d1b2e369f6083a767576aa284c771ba9d7f84af22e96420afa36030a78dbc906b531296bb9c8990e370466917245b439371a338436393bbf74d4e340ce0e82e850dd6c374b909a7e9be599b46aed7d43eeb99ee03f805af46df71db4ff6ba6f52fa95a58d0a6217fca33fd8fa9e21e40ad0dd9f0c886fc032c76347f1159212b6b18f26e917b8bc28b4fac6f36cb865cf6036d5fc09daf3005dbaf29afa9e9f0d2627d6cc8dff2691b6a89be7869bc07424ab1c5babdbdd62273fbea9ceeadbd37245f85331a064ebc722d7f57f0f4d68063279bdecc26203f159bc10595b1b91e894d7f0036e361d8f4bce0ceeb499dbe6f126b279dfe4ce784745ee6ccd598740603d0b91a88ce28eea9ea5ad609663083392198d145da5c8f09a629f51f2ce9eb61c0f4dd756f490f5c9b553bf10c673c27c4d356729b3d31fcf684f748653dfa78e2f4dd81f80ce35e3e7d5df23be18c66382784d316f2164e3c269cf10070c2027888c57a8083ab55dd73f13532e399cc09c9b495bc25d3aeda474a9bab01c884adae41c80cf5ce50f732dd73fb6afa6a86734238db3aded2e98f9937d703d0e90f44e7daeb2bea1e8eafafd5d7339f53f2694b79cba7dd571a297b62b377fab155911f0c0368847b769202bf674984dd99cf29f9bcdc8637608eb628c2036cc4fb039d1245615bc2bb2b3c0ea36bbf3df17c4aa40f9fa6da89c7b6a4b7f9d36e308d953fbd010afc40074531eee5d363a27bcd8ee773a249e9bc3c28c2a39e14e15f3a2a5ac27f4d6cff070000ffff0300504b030414000600080000002100ab099f577a020000b909000018000000786c2f64726177696e67732f64726177696e67332e786d6cdc96516f9b3010c7df27ed3b587e5fc110024581aa6ad46952b545d5f6015c63021ad8c87693f4dbef0c2634119bba4adbb4be44f6d9dcfd7dfedd39abab43dba01d57ba9622c3e4c2c7880b268b5a6c33fcedebed8704236da828682305cff013d7f82a7fff6e752854bad76b85c081d0294c335c19d3a59ea759c55baa2f64c705ac9652b5d4c0546dbd42d13db86e1b2ff0fda5a73bc569a12bcecd7a58c1ce1f7d85b796d602e7bd32b39737bc69ae05aba41a4ca592ed3062b2c9c9cab327b0c3fe03187c29cbdc3f9aedac5f51729f9370b0dbf1687cb61dccfdf6dee514c7c8a3ef9fc50b92058993309e0f1b3895e761a398444ee949e8316057b321b2d86d6ab67109609f771b85ea22c3014682b6709bb06a1e154704a3826b0657e82cd873d2e19bc1034dbb9add49f65d23216f2a2ab6fc5a779c19a0c6ee1ed279dcde4f4fc23f3475775b37906f9adab1bbe8176123cbb2667c2dd963cb8519d851bca106a8d555dd698c54cadb070e87539f8a5e104db551dcb0ca062c21f03d88b5429f2df42a27619608ddd97cd1f4502ac085a6101a1d320c75f1647fc1014df9c12006c66508f710471831582361424810f5b9983eef94361fb96c911d8038d00088d294eeeeb453336e71391c04f4ca20e3ee1a9a1acebda6868e999e017cc634b1f8fbcc2f26c206110eb5c9fc4ae649121192b88a7275371655be58ce571a24d79f8bfc52e4c3378e7c3090f9c7918786155f1e912780bcdf170554d5583123cfff1ff291ebc3e7fd760ebca9b446047f51622458fa248ac7a67d0efd3298879e904b7faa87a9dcc688c7fe70d268a73ebf78e3d0877f09fa64e1133f8227c0f6f9181edf7fd5e6fb57c1feebca7f000000ffff0300504b030414000600080000002100e4980254250b00002026000014000000786c2f736861726564537472696e67732e786d6ccc5a696f1b3912fd1e20ff812b0c160ee0c8679289c6f6c0f1017be1750c4bc960610406d54d491c77373524dbb67690ffbeaf8a4d1ddd72e26411234680a80f16eb78f5582cf6ceeff779266e9575da14bbad8df67a4ba82231a92e86bbad0fbde397bfb684f3b24865660ab5db9a28d7fa7deff9b31de7bcc0d8c2edb646de8f3b6b6b2e19a95cbab619ab024f06c6e6d2e3d20ed7dcd82a99ba91523ecfd636d7d75fafe552172d9198b2f098f7cdeb96280bfd57a90ec29d5fb75b7b3b4eefedf8b5bd9d35fac1177bdd4415d26a234e0f77d6fcc2a3eb11e650b67e3b552eb17aec6160fd911f29d137d69abbe6b081b6b0b090b9aa8f8a233a57999145fb5d25e053e7f4bcfe2a0b39878cced59ff256b633590cdb5d6fe1dd4f9d81cc5c4378261f98951e7c93a4beb67e2452e91b73f093433ca8b42abdceda74fd804eddeef981491b62aadb8f362db12ad55eb8c4d886acf0ac4b8f3a57baf09f3ade968db7264ada6c223400da0c4b7878cacfbe20e3bf7a0cd435adc17d32729935cb5421e850f8eb1147ae58bfd4ebf476059933fcbc5400bb83a14dd4b08c6f884f51e67d65851988dc147e040f8de52457857775edc29bef07ff0eef5d54af55ee5a0a48995342d60585bb5f1a47360a6fc44799350349bee8197ed4b94a4dd9cf1ec2de0188c32b3131a5057242eebb76bb5d57e820d3c98d1829ab68529924ca3941411aa96c2c98796a4388bd3a6e2c13b01ae8c9297bab5a7b31aec2aab14124b513723cb6e656a5021143ca8a9a9cbd8b93eb8dedb75b9b6f5fbdde5adf78b37ebddeb9ea1b9329592c8b6e61c4bbfdb3c8b902b4a0330907d4c42e57cf9699aa548b6a5d9cfc72fdcb8202b85e177f3f7f26f077375285f85b840bba31e3a1f7fd3f55e2575e888135b9f8d7e587b3a3ee75efbc7b7d71b67f7074f2feecf0e8b27bddededf73e74db43e5f78b30e274c0813b75876aa00b951e1b7b91c18d2393817e575a4d7fb45efc1614f84c21813e3375bc9dcc5f92867a20565682fbdbd148b1bb2b9a725fbca88fa5f173965c1e5dbcbfecb5659a764b8604743de228f6907b2bad4744bbb5ba64e2d52a0653fd56454b155333490bfafb2c1428fed13a1e0309a5554face32c169f45227d32122bbd119644c2a4f00d0f2ff5ee11d6500bbdbfc5abbee9b3cf154a9e3fc32fd4188b0bbc7830617324bb1c2a4714580f6995b42b65612ce0a9d2175f4fe08de62a70f569492e2fd7682e47a3624b73742302e367c8d18d29781f9da33a33c33619ebdae9ad6bdbbe474ea1b2694b073245e5b7cfff7f4075e1da89c932b00d8ab0907f1f623862a647572d49b78defcaf38387669c8134cef948dc2ca3828d291544614d58ff5f54f09399f163d822faeef1817822f648502861a3f288457ff3493863f367e28ccd27e38c832a0c8f208bcdef248b10e7c771c31415cb1861f3c733c2d3ebfaf4693fefe3274af6d4a084288cc7fe903dfcf54261eb49927eeb674afaad274bfa4384e3dcf86fc8fdadefcafdda3c8fa38006569651c1d68fa6829f40f5a7678665aeff6686d83bd659264c816609ed18129561673f3096afd00d2833efa8eb20ee64e1a9a540c5ed92be430f838fee317cda9d1003ddd8cceff5466824c4fe05bf419d85d2a1ab00d968d5a07f23a110e9125f0317296a63486c91f1d2adcc3475f3422f84ebee5581c6ec549074e8fba065814d10b74b4863e14a8dff050c733a2f334915b86b744ff631759c96b573530e94a21bdb2ea18d22faa517b99c4cdf30501ae2a9b98b61dcaf4943df61a80a653165315c302cd8ef553e863e6a95ddaeee252ec997636c13e096cb2a0664e1f4e6d1bd4ad0ad34853854a8cbb0af10ecd993a3b38b20955a353a85c5ba4034d180a697f18f1d1b544cb5c3c413cca1e97e3d300de79ce6d409020c3ae25ca1558e2e5baa07156e4c56e6053ae4b64c3cf6eeb1800dde6888aab9f2511bdcd918f444a84f053cc2c900af85c9d852c1c492b184edbb83e57e243d4317f05a000ef9a0af46f25663684449d8c08923898d3f76fdc127aa11f4e9dcc05231c36840605e026971d18c309e81773e1416fb718d5d38079d61ca0a70167070158554e17196993b424e44861b993b187767a648759dc60a8df54275809db44c3007ec71b0d8df29349dc87aec42295ce1a0009d3d608b6e875eff3401a225f37ab35309f57d45693b2891ab46a4c04386f30e0b20fe0764011dcb2c45de124cb8db0df1880229d20003fa254291dbe3c4c804222546a5a27c478318a722e85acc290fad89a8c83bae5303d0fce98878c97ea4030c0643e018a446e1f54043f0c2d4ec0a0e23d9c707310d7d9155f12005c2f7d13654eaa557f7083dd893321ef8474801c322525a41ddfa5922b217a9231bb83548c48c7c3fbaa13171bf74e833523f57d9dc61ee23e6cbca4191b4e37084e21d3a9155ac03f595fd107938');         
INSERT INTO SYSTEM_LOB_STREAM VALUES(24, 10, NULL, '0f3ae688bbf4c64e1a3305f85024c906ecfbd0c7e0e0ad0a3f19eb04d8662e464351a42629a9c9ce14b3ba00b3079bd1cc53cc0d22d3c54d0d80947e019a0dc53e6a87deb3903a6df4f417b3e576f662687d73400c716b5c3aa68e6ac0671fc4828cb01ac754e0e20a88de8c85d5c311af2c7359c4d0d2450ab7d01223e1f19c1c12a2a9ee41b2b473a611701e53631532640e828e57a91f07d7126169871f00d3aa088714b8a4d58eeee224686d408765816d9c0105b5c5097af236ac7438a2409281e5a1034351e3e44b2e1a43d91a889f35aa746d387a1fb3da1b3104b641194b3c91a901719dc5ca16c99ee7a46504a7525ea3971167226782aeca217a931e0a818a68a10ff9c0cb62042f89688b636284b010ae521b9c62c75ec258784559426020060a8e6487b1c9ab55117247041227c4dc61aa60317986e6ab495aa42e3d44638e129268ab124425031374e16889a380460c095be219dc61b16a67cd84da879674be2a10611ec7c763559bb662e31a8e180df46e05966a71c10c6e6c88b0b95eb244610eb5029119afe4523885fa872aa443e92591040a274eb64694a70545ac32ba541ad4d9141210ad2a0b1a43421a93a2d08ccb45d69c63c6450c696afad43e6a8bcbb228b80c9aabc9ee08a5787dee602bd4301c440014d654d51e92295445712a1e4b734b941dc044bc4ff15d20f686e93da6e98a0627584c483277cec9819ce3d58a4c5949348854451ea22603c9a1f4a3591f700697d3d5ea59253e06d22f88c2193b70338d1837bdb95a5c5a1e36f4e602a58f25b122f6afc48521c98061e852aaa07e17a721a952c3fbfc985b8c341248a5cd0238897e48791a2d382ef086bbd1e3b14a1b2af6f4b8c36500bc56501b219c5d2277d55dd49acfda287a988df70dc1a9ccd2f075553123ae104065358a640f14c7af1e686f016542e51c978f42a02816ff4401fd1b76008814c7a83ea9f64d85114a5e87e66b24c6f5b4feaf07675a3469a2aa1a2ac181393ec110fd501cd76b0faec1300e60a581fa765666e2738eca43a0a35390468a4f05a874e76c07ed043d028b809948344d46c755f3ca7379c8653e08941615313406bb11636f48c2d8225f748285c4a3521b8e1805d372007771749c617db9516acc4e8c8effa2d9d5c1521800c51a7efe830e3d29c40c23ca5109bf0351c05a60b9d539aee7fcc5ae2d8f109f61996ce0d586d7ba29df8160e13536977037abbc614f5a8e71344eac4889db8d4082bfa75c41fcdc5789a445945e622d71115298bf48c1eb9c2c4b50ff518166518da2467037750a5d78c81f4cf0d9fc186c527fb52bf3faadfd54e68d7a677b73fbe5abd72fdfbcdddeacbffff6d5d69bc6cda60af56197509c4c687ecd81ded3102b4adc37ff83b2db06334628c3fb5424c423eabad413944c4b85f60cca1f3dc416b6efd7c2f72a8276c9a623d6dbdb1b753967956b97ca7a5793b3cc883fc02644bd58a427bc4d99b3a0005c1eb0620d5f78edfd0f0000ffff0300504b0304140006000800000021007eaad079250200006e0a000018000000786c2f64726177696e67732f64726177696e67312e786d6cec56c96edb3010bd17e83f10bc37529cb875054b416a37bda44980b46763425116112e02c95acadf77484a8e03f810f45afb60ccc6f766e1985e5e0d4a921db74e185dd2f3b39c12ae99a985de96f4f7af9b4f0b4a9c075d83349a97f4853b7a557dfcb01c6a5bf46e6d09026857a05ad2d6fbaec832c75aaec09d998e6bf436c62af0a8da6d565be8115ac96c96e79f33d7590eb56b39f7ebe4a1231efc039a02a1691533f3bd597129af356b8d4da6c61a95246664952fb3504110e30114ee9be6c01cb4e8b1a69fcc419c6c07d1688ed111f195c69b3d74757e799c6f9e5f2e66f3bdef0de97c96ecef619db85c4714306b4a4a89e78397423fa39c12d1bbc7ee61ec06bbdb3d58226a9c797ef185120d0aa7bb199c6b360c3bb7614629ae3d25ada86b1eee06cdc67aee220ef1c33733047bb584c275b7863d3ba2cd23979cf9604765d582def26b8b35b461d2234cea7dc2a9529587c9394c933cf53f4d8d39c11f6f22c5d0581c2014a66908f2e24d7d09df981514582a6168fc3a9fcdf31c5d0c7d9382111914d3f1ce3aff831b458250528bc94678d8dd3a9f42a790589891a2be1112ef095669b74f2b69c90e64496fe227f023ba3b0c939af4893ef5e6d0f70602530dd91e8150c2734ba450255dec83a0084dfcae6b3c00850721938cfc528f7d0cbddb8be3c0a4c049aec143200ad7fec87a1c31bd5ee5d3c6e04fc57e6366a77581e2b42ea707e67d0fccc5695dfeeb75892f4ef8ab58fd050000ffff0300504b030414000600080000002100b070c0e5e70500002e2d00000d000000786c2f7374796c65732e786d6cd45a5b6fe238147e5f69ff4394771a42a153106134b4c36aa4d9d148ed4afb6a8203561d1b25a603b3daffbec7cecd40003334a6fb0289639ff39dab6f67f8711d53e7152729e12c70fd9bb6eb6016f21961f3c0fdeb79d2ba779d5420364394331cb81b9cba1f47bfff364cc586e2a705c6c201122c0ddc8510cb81e7a5e102c728bde14bcce04bc4931809784de65eba4c309aa572504cbd4ebb7de7c5883037a33088431322314a5e56cb56c8e32512644a28111b45cb75e270f065ce7882a614a0aefd2e0a0bdaea658f7c4cc284a73c123740cee3514442bc8fb2eff53da0341a469c89d409f98a89c0edf8405bb218bc30fe834de437d060de6d344c7f3aaf88428bef7aa361c8294f1cc266788d67817b2fdb188a71d6e70151324d886c8c504ce8266beec806a5cfbc5f4c403ad9e8492819a08ad30ed167b4e0313ad8db6fcb4fc7717d4a08a27b14a61255215d1d95be1c5249574fa5a0a050efc0388b40ad2046144e0ab2a3d17a41742a75c2181139a60dbb046ad56904819cf28bcead8963ac4e91f1555c9cf2af93688c5c44a772b1713b75c172b723cd2441ec8512e6fcc1c58284ce98f317a9b6da90f7efe4a79de8b98c62f7cd29369e00a77b1e73ca398a70cb9cfd706fa5f414122da1b4ccfc90d1b396d110a62081133681cf4efefcbc59c2e4c360b6ccac069f4ef69e2768e3777ae60314f9d1703a7fd89e57ee94f53c0d96741c130829a76426e5da259905ad0d4e3de52836387554ccd9e074a78c6a83535725171b9c54e2fc151fcbbd76cfc514416bc8cf61a46207e27fca93192c928bb59f7f0b9192b58d86144702125042e60bf92ff8127ea75c0858528e863382e69c210a8f5e31a2f8bf6c24accb61091eb8304b3080b33b09649940b2d8c266340a6438430423927b40ce51d2851c8c8667163b6d3023629ab446fd95f328df31eaaed9c7a8bfa96c60933a377e531e46c4ece9cf20441b46dc64201841af9caf846234ee5caf32225a8131eaae45828125a18ba26f44ba4252aac5020b2368c7349fcf3230698598d2273947fc1d95335707668a75e4b0553c89c517388980031f7996503cc252317fcc26a9ec05e43e34c8870322b9c0941dfbae538d528b394fc79021d2c0747bbf84c659472761752a54f0a8a32a473b68b9a49b6fab788a93893aa592c73759ab3ccdd1de40beea6dacd602f2fd885a6e2bfef058f1073005faabf0073056f8770fc80fed56f8f70ef0b7a5ff43fc6de9ff43253fa8bcf23fc06545ff5a56d8e26f4bfe43fc6df91fa4c2222b6ec97f6dfdcb43eb3c7b369a7f0ee9ffce127f38d8290d003ced07001c129500ae3203c129e9750140a81721008f95052035597141d8a4d70300dfb4020002bf5601901bacf0d71c00745e1940c68615005a12d806602b0bf99a09ae83e0a00a6c2d4420f9154e08734fe504b626222d0f832e2afe7b3e38c917d94716d53e802e84914e5c51b3e6509a380d22c8a6e64f94cc598cb39dc8680877c4d9abf32341cb67bc563b145097b78e8eeccfec203e6635cd051bd4d911045a2284c786bca6219b3507f888c2a4998a406b0ec01b6a4cb370832e7602f08227e4271c1cc8aa0f7980e9aa7a8f2c7c4f85a99d186950001fe6d7c2651a34c17b77da7d1fd093f5190ef12e42705f1a59c164e6d1ef222475e5d78660576ed4f3f34f5fdbb4d7af95609971f1a1614d0c664ddf132e7028b242bcbdb3451d28d49194b1f6bf015abf0bbfa246d5e62037bdaed17707545afb6c9c6627d86fe18c952fd66b0ee05f1c3447d2be36733677d256a3277d410e05b4828472de87fb2855c52397e4eaf203ae3bb49b98ad7b98f26ec491054881fb4d5e42506d6f3e5d112a082b2f3bea0738e599eace950b309eadabab1f551f22646dacba142aa1807d6638422b2a9ecb8f815b3dff89676415433acf7b7d27af5c2812815b3d7f95e50f59391aec4cbea6507500ffce2a2181fbcfe7f187fee3e749a775df1edfb7bab7b8d7eaf7c68fad5ef761fcf838e9b73bed877f417059483c80a2da0b0a755541316c87fcee20a550ce9be4c2e6e09faab6c0d55e32f8ca74001b6c5708e1a565a1f3e83f000000ffff0300504b0304140006000800000021008bf1b922280200006b0a000018000000786c2f64726177696e67732f64726177696e67322e786d6cec56c96edb3010bd17e83f10bc3752ecb849054b416a37bda44980b46763425116112e02c95acadf77284ab602f850f450a0a87d3066e37bb3704c2faf3b25c98e5b278ccee9f9594a09d7cc94426f73fae3fbed872b4a9c075d82349ae7f4953b7a5dbc7fb7ec4a9bb56e6d09026897a19ad3dafb264b12c76aaec09d99866bf456c62af0a8da6d525a68115ac96496a61f13d7580ea5ab39f7ebe8a1031efc019a02a169d167e65bb3e252de68561b1b4d95352a4accc8225d26a18220f6075078a8aa893968bdc79a76340771b44da2d1dc47f788071a6ff6d0c5e238dde5f9c5fcf2e07bc3b9b888677e8774a4720d51c0acc929259e775e0afd8272cc43ef9e9ac7a119ec7ef7688928733a4b17734a34281ceea673aeda306cdc8619a5b8f694d4a22c79b81a3419cab9ef7188ef3e9b2ed88b2564aeb933ecc5116d9eb8e4cc073b2aab1af496df58aca10e831e6062eb234e11ab9c26e7304df2dc7e3325e6043fbde929bacae2fc2033554590172fea6bf8c6ac20c3520943e3a7c56c91a6e862e81b158c48201b8f37d6f9afdc2812849c5a4cb68787dd9df331740ce90b335294b742e235c12aedf679252dd981cce96dff09fc88eea661529336d2c7de4c7d6f2030d590ed1108253cb7440a95d3ab7d1064a1895f74890720f3206494915feaa18fa1777b7118981438c935780844e1d61fd98e23a6c34d3e2d4c365998d3b64076da967ffe7999ff95e7e5f4b6e04ff57fbc2dfd7b13fe2716bf000000ffff0300504b030414000600080000002100ac557125cf020000490c00001b000000786c2f64726177696e67732f766d6c44726177696e67322e766d6cec97df6bdb3010c7df07fb1f84fb9097a4716c276d543b503afab60db6c11e83622bb15a59672cc575fad7ef2439fd0169d958daa71a224bbad3f9bea70f1249bb4a12fc294ddb2cd8368aeabce415d3a34ae40d68589b510e156d2b197cfed47bc26b9eb05e8b9c53ff7a5cd3fdc51adee55c060bfc4e0a5497ace692ed606b484b7967b28017c238b3b58ba262f5330b299861591005631762fc2cc6226d7d48b3ab391145162c3badd74bfca25ca2c28a2b13105c527b5b88cfb28ac2696c');        
INSERT INTO SYSTEM_LOB_STREAM VALUES(24, 11, NULL, '35901ca029b4b8e7187f320bc3a16bfd02cc2c0aa380d4cc9459500da53736de51fa57c7fbcc310dd3c02d27372094363b89212b6178e3d32698a70d44360d2b0426e5ea00b759e0d2cb41299e1b2b220b1aecedc53e51f720b597e9a468948239fa852787b4fb5c063568610428ca561ae4d6f00babbf62cd46a891e46b43a364767a36adcd453f69a0a6b310c777a230259d9dc7a79135975c6c4a4327a11ddc8f842a7847272e5c2bb4580929cc8e96a228b81a90b5903207094d169cacf1e1135b5d2c11371514a8966d0d3cd6b06405dc1150ae2e5e95166a2379807be5a2ac24cb6f31c64ae7db86e386f7b57aa830d067d554a0f8e31e18246e051de9ab52691815c2161c4b3362d2509bcec08246485a8876ef68d7a15d6c14b5c51a2cd2315a9d5f3a6e691fd68f3b7a25ed167f416ec9f7d50d46ffe536f61b981e179276f42bb4fcb730e515a2aa1ddbf8c98efe441a0f4c5faabc84c62746e22109872471edccb5133b48c71d7dea87d12e51ce356ec1e29a49cd9dc37ec66bece80fb85b24d6623bfbc92b64a4528bc8cef77d6b72c30771d6dbaa772cbf88276ef831f04ce62fb3999cc72f81197d8089bcbf17981e49df9ebd2598f111c00c8f03e66c1ebf766ec671f4cab9197fe0f98e784e1d921ecff3b7c4d39da7ff776e26f3e3e0398fed1d7ef84e8f843a7c9d271f58be2396fe0af758cedf12cbe9bf9c9a63fcffb0f8030000ffff0300504b030414000600080000002100fb62a56d94060000a71b000013000000786c2f7468656d652f7468656d65312e786d6cec594f6fdb3614bf0fd87720746f6d27b61b07758ad8b19bad4d1bc46e871e6999965853a240d2497d1bdae38001c3ba619701bbed306c2bd002bb749f265b87ad03fa15f6484ab218cb4bd2061bd6d58744227f7cffdfe32375f5da8388a1432224e571dbab5dae7a88c43e1fd338687b7786fd4b1b1e920ac763cc784cdade9c48efdad6fbef5dc59b2a241141b03e969bb8ed854a259b958af46118cbcb3c2131cc4db888b082571154c6021f01dd8855d6aad56625c234f6508c23207b7b32a13e41434dd2dbca88f718bcc64aea019f8981264d9c15063b9ed63442ce659709748859db033e637e34240f948718960a26da5ed5fcbccad6d50ade4c1731b5626d615ddffcd275e982f174cdf014c128675aebd75b577672fa06c0d432aed7eb757bb59c9e0160df074dad2c459af5fe46ad93d12c80ece332ed6eb551adbbf802fdf525995b9d4ea7d14a65b1440dc83ed697f01bd5667d7bcdc11b90c53796f0f5ce76b7db74f00664f1cd257cff4aab5977f10614321a4f97d0daa1fd7e4a3d874c38db2d856f007ca39ac2172888863cba348b098fd5aa588bf07d2efa00d04086158d919a2764827d88e22e8e468262cd006f125c98b143be5c1ad2bc90f4054d54dbfb30c190110b7aaf9e7fffeaf953f4eaf993e387cf8e1ffe74fce8d1f1c31f2d2d67e12e8e83e2c297df7ef6e7d71fa33f9e7ef3f2f117e57859c4fffac327bffcfc793910326821d18b2f9ffcf6ecc98baf3efdfdbbc725f06d814745f8904644a25be4081df0087433867125272371be15c3105367050e817609e99e0a1de0ad396665b80e718d775740f128035e9fdd77641d8462a66809e71b61e400f738671d2e4a0d7043f32a5878388b8372e66256c41d607c58c6bb8b63c7b5bd590255330b4ac7f6dd903862ee331c2b1c909828a4e7f8949012edee51ead8758ffa824b3e51e81e451d4c4b4d32a4232790168b7669047e9997e90cae766cb3771775382bd37a871cba484808cc4a841f12e698f13a9e291c95911ce288150d7e13abb04cc8c15cf8455c4f2af074401847bd3191b26ccd6d01fa169c7e0343bd2a75fb1e9b472e52283a2da37913735e44eef06937c45152861dd0382c623f905308518cf6b92a83ef713743f43bf801c72bdd7d9712c7dda717823b3470445a04889e9989125f5e27dc89dfc19c4d303155064aba53a9231aff5dd96614eab6e5f0ae6cb7bd6dd8c4ca9267f744b15e85fb0f96e81d3c8bf70964c5f216f5ae42bfabd0de5b5fa157e5f2c5d7e54529862aad1b12db6b9bce3b5ad9784f2863033567e4a634bdb7840d68dc8741bdce1c3a497e104b4278d4990c0c1c5c20b0598304571f51150e429c40df5ef3349140a6a40389122ee1bc68864b696b3cf4feca9e361bfa1c622b87c46a8f8fedf0ba1ece8e1b3919235560ceb419a3754de0acccd6afa44441b7d76156d3429d995bcd88668aa2c32d57599bd89ccbc1e4b96a30985b133a1b04fd1058b909c77ecd1ace3b9891b1b6bbf551e616e3858b74910cf198a43ed27a2ffba8669c94c5ca92225a0f1b0cfaec788ad50adc5a9aec1b703b8b938aecea2bd865de7b132f6511bcf012503b998e2c2e26278bd151db6b35d61a1ef271d2f626705486c72801af4bdd4c6216c07d93af840dfb5393d964f9c29bad4c3137096a70fb61edbea4b053071221d50e96a10d0d339586008b35272bff5a03cc7a510a9454a3b349b1be01c1f0af490176745d4b2613e2aba2b30b23da76f6352da57ca6881884e3233462337180c1fd3a54419f319570e3612a827e81eb396d6d33e516e734e98a97620667c7314b429c965b9da259265bb82948b90ce6ad201ee8562abb51eefcaa9894bf20558a61fc3f5345ef277005b13ed61ef0e1765860a433a5ed71a1420e552809a9df17d03898da01d10257bc300d410577d4e6bf2087fabfcd394bc3a4359c24d5010d90a0b01fa95010b20f65c944df29c46ae9de6549b2949089a882b832b1628fc82161435d039b7a6ff75008a16eaa495a060cee64fcb9ef69068d02dde414f3cda964f9de6b73e09fee7c6c3283526e1d360d4d66ff5cc4bc3d58ecaa76bd599eedbd4545f4c4a2cdaa675901cc0a5b412b4dfbd714e19c5badad584b1aaf3532e1c08bcb1ac360de1025709184f41fd8ffa8f099fde0a137d4213f80da8ae0fb8526066103517dc9361e4817483b3882c6c90eda60d2a4ac69d3d6495b2ddbac2fb8d3cdf99e30b696ec2cfe3ea7b1f3e6cc65e7e4e2451a3bb5b0636b3bb6d2d4e0d993290a4393ec20631c63be94153f66f1d17d70f40e7c369831254d30c1a72a81a1871e983c80e4b71ccdd2adbf000000ffff0300504b0304140006000800000021006945131f630100005b04000010000000786c2f636f6d6d656e7473322e786d6ce4534d4fc3300cbd23f11fac9cd9329040136acb019804e280f8f801a6f1d64a495cc5290c7e3d6ebb71e0c481dba428ca731cbff79ca4b8da060fef94a4e5589ad3f9c200c59a5d1b37a5797d59cd9606246374e83952693e49cc55757c54d41c02c52ca005a294a6c9b9bbb456ea8602ca9c3b8abab3e614302b4c1b2b5d2274d210e5e0edd962716103b6d15405f6b9e124fb4575ffd47b92c24ef16abfd0841deb432bf90740a27569aecf0d4cf977ae340bad9a69ab4949c7a34ef205efe84bb33456232b8e79c22fd870c02168c7bc5c3d93a73a030efb3d412fda0bc80d814bdccd1c7f44f0ca2fd0c6315c93f7322fac925925b213afdd49fd25f3e6df64dec64c69d228a07d1eb50412c10d09f07ac49e316a7f3a4e6a48609076028475037a9b83010447aead319383c108bc91e78ff12cabe7247358e91df65e4f6322889c41fa6e2848eeafa66f0fd1f4ea404cef1ffaf427f748aa6f000000ffff0300504b030414000600080000002100e62b69f62f020000ed0b000010000000786c2f636f6d6d656e7473312e786d6cd4564d6f1a3110bd57ea7f18f9d41e8a690f5154b11ba90db4a434aa12d2fbe01db0d5b5bdf50781fcfaccb290430f55a3b2129110f27cb0bcf766c63ba38b8dad614d211aef0af17e3014404ef9cab85521eee69377e70262425761ed1d15624b515c94af5f8d94b7965c8ac00f70b1103aa5e6a3945169b21807be21c791a50f16139b6125631308aba88992ade587e1f04c5a344e9423cc49fb100f87f2ea26d71447b2f397870327ecff7566627a3220d0b2109fce0474f9d3aa10437e6aa20d2705fefce0aff8006bac0b712e247b26dea5ce9ea3f6165ba7dce5a572ec120540c8cefcce04d34b601640a83444450e83f103986b82887617b639265810e44815dc6b722d220aac23ab08499bf8f443306db0c6d466faf06ba7068c370da9d6754331d72cd7483272c9a8654742ee79ffc1f9f2c89c139362919874cb786902f3722d498cd00219c084eb996b363110389f20e6a6f181b1ff2be671af9819daf1214f7a85bc302169a8b8255a99b13bbde9060714d535dc1b4e4050dc66de76f17dd82cb9bd882381bb2d014f2870b3b57551deadc999d64bcee7957e7b8ce27de95589dbdbebcfbe3a6ab77ded15b00a54199e01e5791a76c573d92ef8f2f84bf9f619ff5fc0674fdeb4572db684a1def2fdc657d50b10e3aa57311e4cc31378dc56fed62b627ec787f4426ea159af4aec07d42fc1f292a0b9a71bdc76abcec98ff8f75e9541eb33bf4f4e5e85eb5e55987974903cfcdc2d4aa728c6615becb6e48315cb47000000ffff0300504b03041400060008000000210000fa7231ba010000db03000010000801646f6350726f70732f6170702e786d6c20a2040128a00001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000009c53c16edb300cbd0fd83f18ba3772b66c18025945d166c8a1db82266d8f8326d3b150593244c648f6f593ed25b1d760c076a3c8a7c7c7274a5cef2b9b3410d07897b1e924650938ed73e3b6197bdc7cbefac41224e57265bd838c1d00d9b57cfb46ac82af2190014c2285c38c9544f59c73d425540a27b1ec62a5f0a152148f61cb7d51180d775eef2a70c4dfa5e9470e7b0297437e559f0859cf386fe87f4973af5b7df8b439d451b01437756d8d5614a7945f8c0e1e7d41c962afc10a3e2c8aa86e0d7a170c1d642af8f028d65a59b88dc4b2501641f073422c41b5a6ad9409284543f30634f990a0f9196d9bb1e4874268e564ac51c1284751560beb0f5d6c6ba4209f7d78c1128050f008e8935d38c40e633393b30e1083bf027baeafaa823c79506e0bffd2627ab945abb19f35f61ebbb0316401bf152b15e882291f86a674d27a4b7a956b0d2e7ae347124f7e2cf675f4b71d037067c7569d40df735f29e32e332c17f7ab6ea2df069f6ef5976e86b5d18c7f4c756fdc0b3ed61b7fa7088e8b314e8a75a902e471978ef573422ce34e04db92dc96ed93e447cceb42bbc64ffd5f95d3d9247d9fc60d1de4043fff4af90b0000ffff0300504b030414000600080000002100ff89eb614f0100006002000011000801646f6350726f70732f636f72652e786d6c20a2040128a000010000000000000000000000000000000000000000000000');        
INSERT INTO SYSTEM_LOB_STREAM VALUES(24, 12, NULL, '000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000084925f4bc33014c5df05bf43c97b9bb49d4e43dbe11f0682c38115c5b790dc6dc5260d4974dbb7376db7daa1e063ee39f777cfbd249bed641d7c81b155a37214470405a078232ab5ced14b390faf50601d5382d58d821cedc1a259717e96714d796360691a0dc65560034f5296729da38d739a626cf90624b39177282fae1a2399f34fb3c69af10fb6069c1072892538269863b805867a20a20352f001a93f4ddd0104c7508304e52c8ea318ff781d1869ff6ce8949153566eaffd4e87b863b6e0bd38b877b61a8cdbed36daa65d0c9f3fc66f8bc7e76ed5b052edad38a022139c7203cc35a6b8f1db6e20583e3d6478546e4f5833eb16fedaab0ac4edbe90abba9219fe2d785c97be6782087c1edaa73f2aafe9dd7d39474542e269482661322de3842684a6e4bd9d7bd2dfe6eb0bf230fd5fe24548aecb38a5644293e9887804145deed33f517c030000ffff0300504b030414000600080000002100f0de872fbb0100001005000013000801646f6350726f70732f637573746f6d2e786d6c20a2040128a0000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000b494516fd33010c7df91f80e969f899366745ba3a4136b3a8927d0d6f132f160ec6b1a706ccb3e975613df1db75918159a904079b4efeeefdffd6d5f79b5eb14d982f3add1159db08c12d0c2c8563715bd5fdd24979478e45a72653454740f9e5ecd5fbf2a3f3a63c1610b9e4409ed2bba41b4459a7ab1818e7b16c33a46d6c6751ce3d235a959af5b01b511a1038d699e65e7a9081e4d97d85f72b4d72bb6f8af92d288039dffb4dadb883b2f9fc4f764dd612b2bfa584f17753dcda649be9c2d924936b94e6667b38b24bbccb2fc3a5fdcccde2d7f50620fc939259a77b17517147840660232cb5ddcc3e85b94df62a1ec778f6eeec01a87c583325cb3dbe3e273f1e17ef5c60be3a078f8cab79c29ae1bf65e2334e0fa68e3b83c89dea18b17700c96e9b37c990e9dfc674f67434fb0132a48605f22d4372640a9d386d0051885e0ed338105812019ec40048ccf904940de2acffc06a2dd07f34f4c5eeefa0ab21c2a48dd578c423a1d482578e15a7b441446854effc9f65bce2830e7030c3c99c01cf8a0e2fffa9b59b77dde285417039517a0b96bcd8b387743c2281c7156f55f5519c1d5e9ab01fdd291e96158f4a36cfe130000ffff0300504b01022d00140006000800000021003d0acfd7c40100009e0900001300000000000000000000000000000000005b436f6e74656e745f54797065735d2e786d6c504b01022d0014000600080000002100135ebe6505010000df0200000b00000000000000000000000000fd0300005f72656c732f2e72656c73504b01022d0014000600080000002100815bb8c91a010000610400001a0000000000000000000000000033070000786c2f5f72656c732f776f726b626f6f6b2e786d6c2e72656c73504b01022d0014000600080000002100749fccd1b20100001e0300000f000000000000000000000000008d090000786c2f776f726b626f6f6b2e786d6c504b01022d0014000600080000002100703ee3da750400001414000018000000000000000000000000006c0b0000786c2f776f726b7368656574732f7368656574342e786d6c504b01022d000a0000000000000021000077278cb5140000b5140000130000000000000000000000000017100000786c2f6d656469612f696d616765322e706e67504b01022d000a0000000000000021009b12f80250250000502500001300000000000000000000000000fd240000786c2f6d656469612f696d616765332e706e67504b01022d001400060008000000210023a473d69a0100002203000018000000000000000000000000007e4a0000786c2f776f726b7368656574732f7368656574332e786d6c504b01022d0014000600080000002100728c60b87e040000490e000018000000000000000000000000004e4c0000786c2f776f726b7368656574732f7368656574322e786d6c504b01022d001400060008000000210042343a0be300000046020000230000000000000000000000000002510000786c2f776f726b7368656574732f5f72656c732f7368656574312e786d6c2e72656c73504b01022d0014000600080000002100cf309ad5e300000046020000230000000000000000000000000026520000786c2f776f726b7368656574732f5f72656c732f7368656574322e786d6c2e72656c73504b01022d00140006000800000021001a6391e5bd0000002b01000023000000000000000000000000004a530000786c2f776f726b7368656574732f5f72656c732f7368656574342e786d6c2e72656c73504b01022d0014000600080000002100d6dfcd4bcf00000032020000230000000000000000000000000048540000786c2f64726177696e67732f5f72656c732f64726177696e67332e786d6c2e72656c73504b01022d0014000600080000002100e9e33f96980500003d160000180000000000000000000000000058550000786c2f776f726b7368656574732f7368656574312e786d6c504b01022d000a0000000000000021004bd08478c5360000c53600001300000000000000000000000000265b0000786c2f6d656469612f696d616765312e706e67504b01022d00140006000800000021005167a067e00300003f2100001b000000000000000000000000001c920000786c2f64726177696e67732f766d6c44726177696e67312e766d6c504b01022d0014000600080000002100ab099f577a020000b9090000180000000000000000000000000035960000786c2f64726177696e67732f64726177696e67332e786d6c504b01022d0014000600080000002100e4980254250b0000202600001400000000000000000000000000e5980000786c2f736861726564537472696e67732e786d6c504b01022d00140006000800000021007eaad079250200006e0a000018000000000000000000000000003ca40000786c2f64726177696e67732f64726177696e67312e786d6c504b01022d0014000600080000002100b070c0e5e70500002e2d00000d0000000000000000000000000097a60000786c2f7374796c65732e786d6c504b01022d00140006000800000021008bf1b922280200006b0a00001800000000000000000000000000a9ac0000786c2f64726177696e67732f64726177696e67322e786d6c504b01022d0014000600080000002100ac557125cf020000490c00001b0000000000000000000000000007af0000786c2f64726177696e67732f766d6c44726177696e67322e766d6c504b01022d0014000600080000002100fb62a56d94060000a71b000013000000000000000000000000000fb20000786c2f7468656d652f7468656d65312e786d6c504b01022d00140006000800000021006945131f630100005b0400001000000000000000000000000000d4b80000786c2f636f6d6d656e7473322e786d6c504b01022d0014000600080000002100e62b69f62f020000ed0b0000100000000000000000000000000065ba0000786c2f636f6d6d656e7473312e786d6c504b01022d001400060008000000210000fa7231ba010000db0300001000000000000000000000000000c2bc0000646f6350726f70732f6170702e786d6c504b01022d0014000600080000002100ff89eb614f010000600200001100000000000000000000000000b2bf0000646f6350726f70732f636f72652e786d6c504b01022d0014000600080000002100f0de872fbb01000010050000130000000000000000000000000038c20000646f6350726f70732f637573746f6d2e786d6c504b0506000000001c001c007a0700002cc500000000');
INSERT INTO "PUBLIC"."VTCRESOURCE" VALUES
(1, 135, 97, 2147483647, 1, 13, 'assessment.xlsx', 3, SYSTEM_COMBINE_BLOB(24), 1);   
CREATE INDEX "PUBLIC"."VTCRESOURCE_CONTAINER" ON "PUBLIC"."VTCRESOURCE"("CONTAINER");          
CREATE INDEX "PUBLIC"."FKVTCRESOURCETYPIDX" ON "PUBLIC"."VTCRESOURCE"("TYPE"); 
CREATE INDEX "PUBLIC"."FKVTCRESOURCESTRTDIDX" ON "PUBLIC"."VTCRESOURCE"("STARTID");            
CREATE INDEX "PUBLIC"."FKVTCRESOURCENDDIDX" ON "PUBLIC"."VTCRESOURCE"("ENDID");
CREATE INDEX "PUBLIC"."FKVTCRESOURCEBSLNIDX" ON "PUBLIC"."VTCRESOURCE"("BASELINE");            
CREATE CACHED TABLE "PUBLIC"."VTCASE"(
    "ID" INTEGER NOT NULL,
    "TYPE" INTEGER NOT NULL,
    "STARTID" INTEGER NOT NULL,
    "ENDID" INTEGER NOT NULL,
    "ORIGINALID" INTEGER NOT NULL,
    "BASELINE" INTEGER NOT NULL,
    "NAME" VARCHAR(255) NOT NULL,
    "UUID" VARCHAR(46) NOT NULL,
    "RULEPACKAGE" INTEGER,
    "DOCUMENTATION" CLOB(52428800),
    "GRP" VARCHAR(100),
    "PROJECT" INTEGER,
    "ENTRYNAME" VARCHAR(255),
    "FORMAT" VARCHAR(30),
    "ORIGINALBASELINE" INTEGER NOT NULL,
    "TESTCASERESOURCE" INTEGER,
    "ENABLED" BOOLEAN NOT NULL,
    "OPERATION" INTEGER
);  
ALTER TABLE "PUBLIC"."VTCASE" ADD CONSTRAINT "PUBLIC"."CONSTRAINT_977" PRIMARY KEY("ID");      
-- 0 +/- SELECT COUNT(*) FROM PUBLIC.VTCASE;   
CREATE INDEX "PUBLIC"."VTCASE_PRJBRANCH" ON "PUBLIC"."VTCASE"("PROJECT", "BASELINE");          
CREATE UNIQUE INDEX "PUBLIC"."VTCASEUUIDUNIQUE" ON "PUBLIC"."VTCASE"("UUID", "BASELINE", "ENDID");             
CREATE INDEX "PUBLIC"."FKVTCASETYPIDX" ON "PUBLIC"."VTCASE"("TYPE");           
CREATE INDEX "PUBLIC"."FKVTCASESTRTDIDX" ON "PUBLIC"."VTCASE"("STARTID");      
CREATE INDEX "PUBLIC"."FKVTCASENDDIDX" ON "PUBLIC"."VTCASE"("ENDID");          
CREATE INDEX "PUBLIC"."FKVTCASEBSLNIDX" ON "PUBLIC"."VTCASE"("BASELINE");      
CREATE INDEX "PUBLIC"."FKVTCASEDIDX" ON "PUBLIC"."VTCASE"("UUID");             
CREATE INDEX "PUBLIC"."FKVTCASERLPCKGIDX" ON "PUBLIC"."VTCASE"("RULEPACKAGE"); 
CREATE INDEX "PUBLIC"."FKVTCASEPRTNIDX" ON "PUBLIC"."VTCASE"("OPERATION");     
CREATE FORCE VIEW "PUBLIC"."BASELINEDTLS"("ID", "TYPE", "CONTAINER", "PARENT", "MAXVERSIONID", "NAME", "BASELINEKIND", "CREATEDBY", "CREATEDON", "LASTCHANGEDBY", "LASTCHANGEDON", "LFT", "RGT") AS
SELECT
    "PUBLIC"."BASELINE"."ID",
    "PUBLIC"."BASELINE"."TYPE",
    "PUBLIC"."BASELINE"."CONTAINER",
    "PUBLIC"."BASELINE"."PARENT",
    "PUBLIC"."BASELINE"."MAXVERSIONID",
    "PUBLIC"."BASELINE"."NAME",
    "PUBLIC"."BASELINE"."BASELINEKIND",
    "PUBLIC"."BASELINE"."CREATEDBY",
    "PUBLIC"."BASELINE"."CREATEDON",
    "PUBLIC"."BASELINE"."LASTCHANGEDBY",
    "PUBLIC"."BASELINE"."LASTCHANGEDON",
    "PUBLIC"."BSLNLFTRGT"."LFT",
    "PUBLIC"."BSLNLFTRGT"."RGT"
FROM "PUBLIC"."BASELINE"
INNER JOIN "PUBLIC"."BSLNLFTRGT"
    ON 1=1
WHERE "PUBLIC"."BASELINE"."ID" = "PUBLIC"."BSLNLFTRGT"."ID"; 
CREATE FORCE VIEW "PUBLIC"."ABSTRACTQUERYDTLS"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "DEFINITION", "INCLUDEDEPENDENCIES", "LOCALE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "PROPERTYPATH", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "BSTRCTQRY"."ID",
    "BSTRCTQRY"."ORIGINALID",
    "BSTRCTQRY"."STARTID",
    "BSTRCTQRY"."ENDID",
    "BSTRCTQRY"."BASELINE",
    "BSTRCTQRY"."TYPE",
    "BSTRCTQRY"."DEFINITION",
    "BSTRCTQRY"."INCLUDEDEPENDENCIES",
    "BSTRCTQRY"."LOCALE",
    "BSTRCTQRY"."NAME",
    "BSTRCTQRY"."UUID",
    "BSTRCTQRY"."RULEPACKAGE",
    "BSTRCTQRY"."DOCUMENTATION",
    "BSTRCTQRY"."GRP",
    "BSTRCTQRY"."PROJECT",
    "BSTRCTQRY"."PROPERTYPATH",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."ABSTRACTQUERY" "BSTRCTQRY"
INNER JOIN "PUBLIC"."ABSTRACTQUERY" "ABSTRACTQUERYCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON 1=1
WHERE ("BSTRCTQRY"."STARTID" = "VUPDT"."ID")
    AND (("BSTRCTQRY"."ORIGINALID" = "ABSTRACTQUERYCR"."ID")
    AND ("ABSTRACTQUERYCR"."STARTID" = "VCR"."ID"));        
CREATE FORCE VIEW "PUBLIC"."BOM2XOMMAPPINGDTLS"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "BODY", "PLATFORM", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "BM2XMMPPNG"."ID",
    "BM2XMMPPNG"."ORIGINALID",
    "BM2XMMPPNG"."STARTID",
    "BM2XMMPPNG"."ENDID",
    "BM2XMMPPNG"."BASELINE",
    "BM2XMMPPNG"."TYPE",
    "BM2XMMPPNG"."BODY",
    "BM2XMMPPNG"."PLATFORM",
    "BM2XMMPPNG"."NAME",
    "BM2XMMPPNG"."UUID",
    "BM2XMMPPNG"."RULEPACKAGE",
    "BM2XMMPPNG"."DOCUMENTATION",
    "BM2XMMPPNG"."GRP",
    "BM2XMMPPNG"."PROJECT",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."BOM2XOMMAPPING" "BM2XMMPPNG"
INNER JOIN "PUBLIC"."BOM2XOMMAPPING" "BOM2XOMMAPPINGCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON 1=1
WHERE ("BM2XMMPPNG"."STARTID" = "VUPDT"."ID")
    AND (("BM2XMMPPNG"."ORIGINALID" = "BOM2XOMMAPPINGCR"."ID")
    AND ("BOM2XOMMAPPINGCR"."STARTID" = "VCR"."ID"));       
CREATE FORCE VIEW "PUBLIC"."BOMDTLS"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "BODY", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "BM"."ID",
    "BM"."ORIGINALID",
    "BM"."STARTID",
    "BM"."ENDID",
    "BM"."BASELINE",
    "BM"."TYPE",
    "BM"."BODY",
    "BM"."NAME",
    "BM"."UUID",
    "BM"."RULEPACKAGE",
    "BM"."DOCUMENTATION",
    "BM"."GRP",
    "BM"."PROJECT",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."BOM" "BM"
INNER JOIN "PUBLIC"."BOM" "BOMCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON 1=1
WHERE ("BM"."STARTID" = "VUPDT"."ID")
    AND (("BM"."ORIGINALID" = "BOMCR"."ID")
    AND ("BOMCR"."STARTID" = "VCR"."ID"));  
CREATE FORCE VIEW "PUBLIC"."DECISIONMODELSTDXTD"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "BODY", "SOURCE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT") AS
SELECT
    "DCSNMDL"."ID",
    "DCSNMDL"."ORIGINALID",
    "DCSNMDL"."STARTID",
    "DCSNMDL"."ENDID",
    "DCSNMDL"."BASELINE",
    "DCSNMDL"."TYPE",
    "DCSNMDL"."BODY",
    "DCSNMDL"."SOURCE",
    "DCSNMDL"."NAME",
    "DCSNMDL"."UUID",
    "DCSNMDL"."RULEPACKAGE",
    "DCSNMDL"."DOCUMENTATION",
    "DCSNMDL"."GRP",
    "DCSNMDL"."PROJECT"
FROM "PUBLIC"."DECISIONMODELSIBLING" "DCSNMDLSBLNG"
INNER JOIN "PUBLIC"."DECISIONMODEL" "DCSNMDL"
    ON 1=1
WHERE "DCSNMDL"."ID" = "DCSNMDLSBLNG"."ID";         
CREATE FORCE VIEW "PUBLIC"."DECISIONMODELDTLS"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "BODY", "SOURCE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "DCSNMDL"."ID",
    "DCSNMDL"."ORIGINALID",
    "DCSNMDL"."STARTID",
    "DCSNMDL"."ENDID",
    "DCSNMDL"."BASELINE",
    "DCSNMDL"."TYPE",
    "DCSNMDL"."BODY",
    "DCSNMDL"."SOURCE",
    "DCSNMDL"."NAME",
    "DCSNMDL"."UUID",
    "DCSNMDL"."RULEPACKAGE",
    "DCSNMDL"."DOCUMENTATION",
    "DCSNMDL"."GRP",
    "DCSNMDL"."PROJECT",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."DECISIONMODELSIBLING" "DCSNMDLSBLNG"
INNER JOIN "PUBLIC"."DECISIONMODEL" "DCSNMDL"
    ON 1=1
INNER JOIN "PUBLIC"."DECISIONMODEL" "DECISIONMODELCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON 1=1
WHERE ("DCSNMDL"."STARTID" = "VUPDT"."ID")
    AND (("DECISIONMODELCR"."STARTID" = "VCR"."ID")
    AND (("DCSNMDL"."ID" = "DCSNMDLSBLNG"."ID")
    AND ("DCSNMDL"."ORIGINALID" = "DECISIONMODELCR"."ID")));              
CREATE FORCE VIEW "PUBLIC"."DEPLOYMENTAGGRGTD"("ID", "ORIGINALID", "STARTID", "ENDID", "TYPE", "BASELINE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "MANAGINGXOM", "PRODUCTION", "RULEAPPNAME", "RULEAPPVERSION", "SNAPSHOTBASENAME", "SNAPSHOTCREATION", "DEPPROPERTYTAG_ID", "DEPPROPERTYTAG_ORIGINALID", "DEPPROPERTYTAG_STARTID", "DEPPROPERTYTAG_ENDID", "DEPPROPERTYTAG_BASELINE", "DEPPROPERTYTAG_TYPE", "DEPPROPERTYTAG_NAME", "DEPPROPERTYTAG_VALUE", "DEPGROUP_ID", "DEPGROUP_ORIGINALID", "DEPGROUP_STARTID", "DEPGROUP_ENDID", "DEPGROUP_BASELINE", "DEPGROUP_TYPE", "DEPGROUP_GRP", "DEPOPERATIONPROPERTY_ID", "DEPOPERATIONPROPERTY_ORIGINALID", "DEPOPERATIONPROPERTY_STARTID", "DEPOPERATIONPROPERTY_ENDID", "DEPOPERATIONPROPERTY_BASELINE", "DEPOPERATIONPROPERTY_TYPE", "DEPOPERATIONPROPERTY_NAME", "DEPOPERATIONPROPERTY_VALUE", "DEPOPERATIONPROPERTY_OPERATIONREFERENCE", "DEPOPERATION_ID", "DEPOPERATION_ORIGINALID", "DEPOPERATION_STARTID", "DEPOPERATION_ENDID", "DEPOPERATION_BASELINE", "DEPOPERATION_TYPE", "DEPOPERATION_ACTIVE", "DEPOPERATION_OPERATION", "DEPOPERATION_OPERATIONNAME", "DEPTARGET_ID", "DEPTARGET_ORIGINALID", "DEPTARGET_STARTID", "DEPTARGET_ENDID", "DEPTARGET_BASELINE", "DEPTARGET_TYPE", "DEPTARGET_ACTIVE", "DEPTARGET_NAME", "DEPVERSIONPOLICY_ID", "DEPVERSIONPOLICY_ORIGINALID", "DEPVERSIONPOLICY_STARTID", "DEPVERSIONPOLICY_ENDID", "DEPVERSIONPOLICY_BASELINE", "DEPVERSIONPOLICY_TYPE", "DEPVERSIONPOLICY_DEFAULTPOLICY", "DEPVERSIONPOLICY_DESCRIPTION", "DEPVERSIONPOLICY_LABEL", "DEPVERSIONPOLICY_RECURRENT", "DEPVERSIONPOLICY_RULEAPP", "DEPVERSIONPOLICY_RULESET", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "DPLYMNT"."ID",
    "DPLYMNT"."ORIGINALID",
    "DPLYMNT"."STARTID",
    "DPLYMNT"."ENDID",
    "DPLYMNT"."TYPE",
    "DPLYMNT"."BASELINE",
    "DPLYMNT"."NAME",
    "DPLYMNT"."UUID",
    "DPLYMNT"."RULEPACKAGE",
    "DPLYMNT"."DOCUMENTATION",
    "DPLYMNT"."GRP",
    "DPLYMNT"."PROJECT",
    "DPLYMNT"."MANAGINGXOM",
    "DPLYMNT"."PRODUCTION",
    "DPLYMNT"."RULEAPPNAME",
    "DPLYMNT"."RULEAPPVERSION",
    "DPLYMNT"."SNAPSHOTBASENAME",
    "DPLYMNT"."SNAPSHOTCREATION",
    "DPPRPRTYTG"."ID" AS "DEPPROPERTYTAG_ID",
    "DPPRPRTYTG"."ORIGINALID" AS "DEPPROPERTYTAG_ORIGINALID",
    "DPPRPRTYTG"."STARTID" AS "DEPPROPERTYTAG_STARTID",
    "DPPRPRTYTG"."ENDID" AS "DEPPROPERTYTAG_ENDID",
    "DPPRPRTYTG"."BASELINE" AS "DEPPROPERTYTAG_BASELINE",
    "DPPRPRTYTG"."TYPE" AS "DEPPROPERTYTAG_TYPE",
    "DPPRPRTYTG"."NAME" AS "DEPPROPERTYTAG_NAME",
    "DPPRPRTYTG"."VALUE" AS "DEPPROPERTYTAG_VALUE",
    "DPGRP"."ID" AS "DEPGROUP_ID",
    "DPGRP"."ORIGINALID" AS "DEPGROUP_ORIGINALID",
    "DPGRP"."STARTID" AS "DEPGROUP_STARTID",
    "DPGRP"."ENDID" AS "DEPGROUP_ENDID",
    "DPGRP"."BASELINE" AS "DEPGROUP_BASELINE",
    "DPGRP"."TYPE" AS "DEPGROUP_TYPE",
    "DPGRP"."GRP" AS "DEPGROUP_GRP",
    "DPPRTNPRPRTY"."ID" AS "DEPOPERATIONPROPERTY_ID",
    "DPPRTNPRPRTY"."ORIGINALID" AS "DEPOPERATIONPROPERTY_ORIGINALID",
    "DPPRTNPRPRTY"."STARTID" AS "DEPOPERATIONPROPERTY_STARTID",
    "DPPRTNPRPRTY"."ENDID" AS "DEPOPERATIONPROPERTY_ENDID",
    "DPPRTNPRPRTY"."BASELINE" AS "DEPOPERATIONPROPERTY_BASELINE",
    "DPPRTNPRPRTY"."TYPE" AS "DEPOPERATIONPROPERTY_TYPE",
    "DPPRTNPRPRTY"."NAME" AS "DEPOPERATIONPROPERTY_NAME",
    "DPPRTNPRPRTY"."VALUE" AS "DEPOPERATIONPROPERTY_VALUE",
    "DPPRTNPRPRTY"."OPERATIONREFERENCE" AS "DEPOPERATIONPROPERTY_OPERATIONREFERENCE",
    "DPPRTN"."ID" AS "DEPOPERATION_ID",
    "DPPRTN"."ORIGINALID" AS "DEPOPERATION_ORIGINALID",
    "DPPRTN"."STARTID" AS "DEPOPERATION_STARTID",
    "DPPRTN"."ENDID" AS "DEPOPERATION_ENDID",
    "DPPRTN"."BASELINE" AS "DEPOPERATION_BASELINE",
    "DPPRTN"."TYPE" AS "DEPOPERATION_TYPE",
    "DPPRTN"."ACTIVE" AS "DEPOPERATION_ACTIVE",
    "DPPRTN"."OPERATION" AS "DEPOPERATION_OPERATION",
    "DPPRTN"."OPERATIONNAME" AS "DEPOPERATION_OPERATIONNAME",
    "DPTRGT"."ID" AS "DEPTARGET_ID",
    "DPTRGT"."ORIGINALID" AS "DEPTARGET_ORIGINALID",
    "DPTRGT"."STARTID" AS "DEPTARGET_STARTID",
    "DPTRGT"."ENDID" AS "DEPTARGET_ENDID",
    "DPTRGT"."BASELINE" AS "DEPTARGET_BASELINE",
    "DPTRGT"."TYPE" AS "DEPTARGET_TYPE",
    "DPTRGT"."ACTIVE" AS "DEPTARGET_ACTIVE",
    "DPTRGT"."NAME" AS "DEPTARGET_NAME",
    "DPVRSNPLCY"."ID" AS "DEPVERSIONPOLICY_ID",
    "DPVRSNPLCY"."ORIGINALID" AS "DEPVERSIONPOLICY_ORIGINALID",
    "DPVRSNPLCY"."STARTID" AS "DEPVERSIONPOLICY_STARTID",
    "DPVRSNPLCY"."ENDID" AS "DEPVERSIONPOLICY_ENDID",
    "DPVRSNPLCY"."BASELINE" AS "DEPVERSIONPOLICY_BASELINE",
    "DPVRSNPLCY"."TYPE" AS "DEPVERSIONPOLICY_TYPE",
    "DPVRSNPLCY"."DEFAULTPOLICY" AS "DEPVERSIONPOLICY_DEFAULTPOLICY",
    "DPVRSNPLCY"."DESCRIPTION" AS "DEPVERSIONPOLICY_DESCRIPTION",
    "DPVRSNPLCY"."LABEL" AS "DEPVERSIONPOLICY_LABEL",
    "DPVRSNPLCY"."RECURRENT" AS "DEPVERSIONPOLICY_RECURRENT",
    "DPVRSNPLCY"."RULEAPP" AS "DEPVERSIONPOLICY_RULEAPP",
    "DPVRSNPLCY"."RULESET" AS "DEPVERSIONPOLICY_RULESET",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."DEPLOYMENT" "DPLYMNT"
LEFT OUTER JOIN "PUBLIC"."DEPPROPERTYTAG" "DPPRPRTYTG"
    ON ("DPLYMNT"."ENDID" <= "DPPRPRTYTG"."ENDID")
    AND (("DPPRPRTYTG"."STARTID" <= "DPLYMNT"."STARTID")
    AND (("DPLYMNT"."ORIGINALID" = "DPPRPRTYTG"."CONTAINER")
    AND ("DPLYMNT"."BASELINE" = "DPPRPRTYTG"."BASELINE")))
LEFT OUTER JOIN "PUBLIC"."DEPGROUP" "DPGRP"
    ON ("DPLYMNT"."ENDID" <= "DPGRP"."ENDID")
    AND (("DPGRP"."STARTID" <= "DPLYMNT"."STARTID")
    AND (("DPLYMNT"."ORIGINALID" = "DPGRP"."CONTAINER")
    AND ("DPLYMNT"."BASELINE" = "DPGRP"."BASELINE")))
LEFT OUTER JOIN "PUBLIC"."DEPOPERATIONPROPERTY" "DPPRTNPRPRTY"
    ON ("DPLYMNT"."ENDID" <= "DPPRTNPRPRTY"."ENDID")
    AND (("DPPRTNPRPRTY"."STARTID" <= "DPLYMNT"."STARTID")
    AND (("DPLYMNT"."ORIGINALID" = "DPPRTNPRPRTY"."CONTAINER")
    AND ("DPLYMNT"."BASELINE" = "DPPRTNPRPRTY"."BASELINE")))
LEFT OUTER JOIN "PUBLIC"."DEPOPERATION" "DPPRTN"
    ON ("DPLYMNT"."ENDID" <= "DPPRTN"."ENDID")
    AND (("DPPRTN"."STARTID" <= "DPLYMNT"."STARTID")
    AND (("DPLYMNT"."ORIGINALID" = "DPPRTN"."CONTAINER")
    AND ("DPLYMNT"."BASELINE" = "DPPRTN"."BASELINE")))
LEFT OUTER JOIN "PUBLIC"."DEPTARGET" "DPTRGT"
    ON ("DPLYMNT"."ENDID" <= "DPTRGT"."ENDID")
    AND (("DPTRGT"."STARTID" <= "DPLYMNT"."STARTID")
    AND (("DPLYMNT"."ORIGINALID" = "DPTRGT"."CONTAINER")
    AND ("DPLYMNT"."BASELINE" = "DPTRGT"."BASELINE")))
LEFT OUTER JOIN "PUBLIC"."DEPVERSIONPOLICY" "DPVRSNPLCY"
    ON ("DPLYMNT"."ENDID" <= "DPVRSNPLCY"."ENDID")
    AND (("DPVRSNPLCY"."STARTID" <= "DPLYMNT"."STARTID")
    AND (("DPLYMNT"."ORIGINALID" = "DPVRSNPLCY"."CONTAINER")
    AND ("DPLYMNT"."BASELINE" = "DPVRSNPLCY"."BASELINE")))
INNER JOIN "PUBLIC"."DEPLOYMENT" "DEPLOYMENTCR"
    ON TRUE
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON TRUE
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON TRUE
WHERE ("DPLYMNT"."STARTID" = "VUPDT"."ID")
    AND (("DPLYMNT"."ORIGINALID" = "DEPLOYMENTCR"."ID")
    AND ("DEPLOYMENTCR"."STARTID" = "VCR"."ID"));               
CREATE FORCE VIEW "PUBLIC"."DEPLOYMENTDTLS"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "MANAGINGXOM", "PRODUCTION", "RULEAPPNAME", "RULEAPPVERSION", "SNAPSHOTBASENAME", "SNAPSHOTCREATION", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "DPLYMNT"."ID",
    "DPLYMNT"."ORIGINALID",
    "DPLYMNT"."STARTID",
    "DPLYMNT"."ENDID",
    "DPLYMNT"."BASELINE",
    "DPLYMNT"."TYPE",
    "DPLYMNT"."NAME",
    "DPLYMNT"."UUID",
    "DPLYMNT"."RULEPACKAGE",
    "DPLYMNT"."DOCUMENTATION",
    "DPLYMNT"."GRP",
    "DPLYMNT"."PROJECT",
    "DPLYMNT"."MANAGINGXOM",
    "DPLYMNT"."PRODUCTION",
    "DPLYMNT"."RULEAPPNAME",
    "DPLYMNT"."RULEAPPVERSION",
    "DPLYMNT"."SNAPSHOTBASENAME",
    "DPLYMNT"."SNAPSHOTCREATION",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."DEPLOYMENT" "DPLYMNT"
INNER JOIN "PUBLIC"."DEPLOYMENT" "DEPLOYMENTCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON 1=1
WHERE ("DPLYMNT"."STARTID" = "VUPDT"."ID")
    AND (("DPLYMNT"."ORIGINALID" = "DEPLOYMENTCR"."ID")
    AND ("DEPLOYMENTCR"."STARTID" = "VCR"."ID"));      
CREATE FORCE VIEW "PUBLIC"."EVENTSTDXTD"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "BODY", "NAME", "UUID", "VALUE", "VALUETYPE", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "EFFECTIVEDATE", "EXPIRATIONDATE", "STATUS") AS
SELECT
    "VNT"."ID",
    "VNT"."ORIGINALID",
    "VNT"."STARTID",
    "VNT"."ENDID",
    "VNT"."BASELINE",
    "VNT"."TYPE",
    "VNT"."BODY",
    "VNT"."NAME",
    "VNT"."UUID",
    "VNT"."VALUE",
    "VNT"."VALUETYPE",
    "VNT"."RULEPACKAGE",
    "VNT"."DOCUMENTATION",
    "VNT"."GRP",
    "VNT"."PROJECT",
    "VNTSBLNG"."EFFECTIVEDATE",
    "VNTSBLNG"."EXPIRATIONDATE",
    "VNTSBLNG"."STATUS"
FROM "PUBLIC"."EVENTSIBLING" "VNTSBLNG"
INNER JOIN "PUBLIC"."EVENT" "VNT"
    ON 1=1
WHERE "VNT"."ID" = "VNTSBLNG"."ID";
CREATE FORCE VIEW "PUBLIC"."EVENTDTLS"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "BODY", "NAME", "UUID", "VALUE", "VALUETYPE", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "EFFECTIVEDATE", "EXPIRATIONDATE", "STATUS", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "VNT"."ID",
    "VNT"."ORIGINALID",
    "VNT"."STARTID",
    "VNT"."ENDID",
    "VNT"."BASELINE",
    "VNT"."TYPE",
    "VNT"."BODY",
    "VNT"."NAME",
    "VNT"."UUID",
    "VNT"."VALUE",
    "VNT"."VALUETYPE",
    "VNT"."RULEPACKAGE",
    "VNT"."DOCUMENTATION",
    "VNT"."GRP",
    "VNT"."PROJECT",
    "VNTSBLNG"."EFFECTIVEDATE",
    "VNTSBLNG"."EXPIRATIONDATE",
    "VNTSBLNG"."STATUS",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."EVENTSIBLING" "VNTSBLNG"
INNER JOIN "PUBLIC"."EVENT" "VNT"
    ON 1=1
INNER JOIN "PUBLIC"."EVENT" "EVENTCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON 1=1
WHERE ("VNT"."STARTID" = "VUPDT"."ID")
    AND (("EVENTCR"."STARTID" = "VCR"."ID")
    AND (("VNT"."ID" = "VNTSBLNG"."ID")
    AND ("VNT"."ORIGINALID" = "EVENTCR"."ID")));             
CREATE FORCE VIEW "PUBLIC"."OPERATIONAGGRGTD"("ID", "ORIGINALID", "STARTID", "ENDID", "TYPE", "BASELINE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "ADVANCEDPROPERTIES", "BUSINESSDISPLAYNAME", "DESCRIPTION", "ENGINECONFIGURATIONFILE", "EXTRACTOR", "RULEFLOW", "RULESETNAME", "RULESETPROPERTIES", "TARGETRULEPROJECT", "USINGEXTRACTOR", "USINGRULEFLOW", "OPERATIONVARIABLE_ID", "OPERATIONVARIABLE_ORIGINALID", "OPERATIONVARIABLE_STARTID", "OPERATIONVARIABLE_ENDID", "OPERATIONVARIABLE_BASELINE", "OPERATIONVARIABLE_TYPE", "OPERATIONVARIABLE_DIRECTION", "OPERATIONVARIABLE_VARIABLENAME", "OPERATIONVARIABLE_VARIABLESET", "OPERATIONTAG_ID", "OPERATIONTAG_ORIGINALID", "OPERATIONTAG_STARTID", "OPERATIONTAG_ENDID", "OPERATIONTAG_BASELINE", "OPERATIONTAG_TYPE", "OPERATIONTAG_NAME", "OPERATIONTAG_VALUE", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "PRTN"."ID",
    "PRTN"."ORIGINALID",
    "PRTN"."STARTID",
    "PRTN"."ENDID",
    "PRTN"."TYPE",
    "PRTN"."BASELINE",
    "PRTN"."NAME",
    "PRTN"."UUID",
    "PRTN"."RULEPACKAGE",
    "PRTN"."DOCUMENTATION",
    "PRTN"."GRP",
    "PRTN"."PROJECT",
    "PRTN"."ADVANCEDPROPERTIES",
    "PRTN"."BUSINESSDISPLAYNAME",
    "PRTN"."DESCRIPTION",
    "PRTN"."ENGINECONFIGURATIONFILE",
    "PRTN"."EXTRACTOR",
    "PRTN"."RULEFLOW",
    "PRTN"."RULESETNAME",
    "PRTN"."RULESETPROPERTIES",
    "PRTN"."TARGETRULEPROJECT",
    "PRTN"."USINGEXTRACTOR",
    "PRTN"."USINGRULEFLOW",
    "PRTNVRBL"."ID" AS "OPERATIONVARIABLE_ID",
    "PRTNVRBL"."ORIGINALID" AS "OPERATIONVARIABLE_ORIGINALID",
    "PRTNVRBL"."STARTID" AS "OPERATIONVARIABLE_STARTID",
    "PRTNVRBL"."ENDID" AS "OPERATIONVARIABLE_ENDID",
    "PRTNVRBL"."BASELINE" AS "OPERATIONVARIABLE_BASELINE",
    "PRTNVRBL"."TYPE" AS "OPERATIONVARIABLE_TYPE",
    "PRTNVRBL"."DIRECTION" AS "OPERATIONVARIABLE_DIRECTION",
    "PRTNVRBL"."VARIABLENAME" AS "OPERATIONVARIABLE_VARIABLENAME",
    "PRTNVRBL"."VARIABLESET" AS "OPERATIONVARIABLE_VARIABLESET",
    "PRTNTG"."ID" AS "OPERATIONTAG_ID",
    "PRTNTG"."ORIGINALID" AS "OPERATIONTAG_ORIGINALID",
    "PRTNTG"."STARTID" AS "OPERATIONTAG_STARTID",
    "PRTNTG"."ENDID" AS "OPERATIONTAG_ENDID",
    "PRTNTG"."BASELINE" AS "OPERATIONTAG_BASELINE",
    "PRTNTG"."TYPE" AS "OPERATIONTAG_TYPE",
    "PRTNTG"."NAME" AS "OPERATIONTAG_NAME",
    "PRTNTG"."VALUE" AS "OPERATIONTAG_VALUE",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."OPERATION" "PRTN"
LEFT OUTER JOIN "PUBLIC"."OPERATIONVARIABLE" "PRTNVRBL"
    ON ("PRTN"."ENDID" <= "PRTNVRBL"."ENDID")
    AND (("PRTNVRBL"."STARTID" <= "PRTN"."STARTID")
    AND (("PRTN"."ORIGINALID" = "PRTNVRBL"."CONTAINER")
    AND ("PRTN"."BASELINE" = "PRTNVRBL"."BASELINE")))
LEFT OUTER JOIN "PUBLIC"."OPERATIONTAG" "PRTNTG"
    ON ("PRTN"."ENDID" <= "PRTNTG"."ENDID")
    AND (("PRTNTG"."STARTID" <= "PRTN"."STARTID")
    AND (("PRTN"."ORIGINALID" = "PRTNTG"."CONTAINER")
    AND ("PRTN"."BASELINE" = "PRTNTG"."BASELINE")))
INNER JOIN "PUBLIC"."OPERATION" "OPERATIONCR"
    ON TRUE
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON TRUE
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON TRUE
WHERE ("PRTN"."STARTID" = "VUPDT"."ID")
    AND (("PRTN"."ORIGINALID" = "OPERATIONCR"."ID")
    AND ("OPERATIONCR"."STARTID" = "VCR"."ID"));             
CREATE FORCE VIEW "PUBLIC"."OPERATIONDTLS"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "ADVANCEDPROPERTIES", "BUSINESSDISPLAYNAME", "DESCRIPTION", "ENGINECONFIGURATIONFILE", "EXTRACTOR", "RULEFLOW", "RULESETNAME", "RULESETPROPERTIES", "TARGETRULEPROJECT", "USINGEXTRACTOR", "USINGRULEFLOW", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "PRTN"."ID",
    "PRTN"."ORIGINALID",
    "PRTN"."STARTID",
    "PRTN"."ENDID",
    "PRTN"."BASELINE",
    "PRTN"."TYPE",
    "PRTN"."NAME",
    "PRTN"."UUID",
    "PRTN"."RULEPACKAGE",
    "PRTN"."DOCUMENTATION",
    "PRTN"."GRP",
    "PRTN"."PROJECT",
    "PRTN"."ADVANCEDPROPERTIES",
    "PRTN"."BUSINESSDISPLAYNAME",
    "PRTN"."DESCRIPTION",
    "PRTN"."ENGINECONFIGURATIONFILE",
    "PRTN"."EXTRACTOR",
    "PRTN"."RULEFLOW",
    "PRTN"."RULESETNAME",
    "PRTN"."RULESETPROPERTIES",
    "PRTN"."TARGETRULEPROJECT",
    "PRTN"."USINGEXTRACTOR",
    "PRTN"."USINGRULEFLOW",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."OPERATION" "PRTN"
INNER JOIN "PUBLIC"."OPERATION" "OPERATIONCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON 1=1
WHERE ("PRTN"."STARTID" = "VUPDT"."ID")
    AND (("PRTN"."ORIGINALID" = "OPERATIONCR"."ID")
    AND ("OPERATIONCR"."STARTID" = "VCR"."ID"));        
CREATE FORCE VIEW "PUBLIC"."PRJRESOURCEDTLS"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "BODY", "EXTENSION", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "PRJRSRC"."ID",
    "PRJRSRC"."ORIGINALID",
    "PRJRSRC"."STARTID",
    "PRJRSRC"."ENDID",
    "PRJRSRC"."BASELINE",
    "PRJRSRC"."TYPE",
    "PRJRSRC"."NAME",
    "PRJRSRC"."UUID",
    "PRJRSRC"."RULEPACKAGE",
    "PRJRSRC"."DOCUMENTATION",
    "PRJRSRC"."GRP",
    "PRJRSRC"."PROJECT",
    "PRJRSRC"."BODY",
    "PRJRSRC"."EXTENSION",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."PRJRESOURCE" "PRJRSRC"
INNER JOIN "PUBLIC"."PRJRESOURCE" "PRJRESOURCECR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON 1=1
WHERE ("PRJRSRC"."STARTID" = "VUPDT"."ID")
    AND (("PRJRSRC"."ORIGINALID" = "PRJRESOURCECR"."ID")
    AND ("PRJRESOURCECR"."STARTID" = "VCR"."ID"));          
CREATE FORCE VIEW "PUBLIC"."RULEARTIFACTAGGRGTD"("ID", "ORIGINALID", "STARTID", "ENDID", "TYPE", "BASELINE", "CATEGORIES", "LOCALE", "TEMPLATE", "RETURNTYPE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "PRIORITY", "ACTIVE", "IMPORTS", "EFFECTIVEDATE", "EXPIRATIONDATE", "STATUS", "ARGUMENT_ID", "ARGUMENT_ORIGINALID", "ARGUMENT_STARTID", "ARGUMENT_ENDID", "ARGUMENT_BASELINE", "ARGUMENT_ARGUMENTTYPE", "ARGUMENT_NAME", "ARGUMENT_ILRORDER", "ARGUMENT_TYPE", "OVERRIDDENRULE_ID", "OVERRIDDENRULE_ORIGINALID", "OVERRIDDENRULE_STARTID", "OVERRIDDENRULE_ENDID", "OVERRIDDENRULE_BASELINE", "OVERRIDDENRULE_TYPE", "OVERRIDDENRULE_ILRRULE", "DEFINITION_ID", "DEFINITION_ORIGINALID", "DEFINITION_STARTID", "DEFINITION_ENDID", "DEFINITION_BASELINE", "DEFINITION_BODY", "DEFINITION_INFO", "DEFINITION_TYPE", "RULEARTIFACTTAG_ID", "RULEARTIFACTTAG_ORIGINALID", "RULEARTIFACTTAG_STARTID", "RULEARTIFACTTAG_ENDID", "RULEARTIFACTTAG_BASELINE", "RULEARTIFACTTAG_TYPE", "RULEARTIFACTTAG_NAME", "RULEARTIFACTTAG_VALUE", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "RLRTFCT"."ID",
    "RLRTFCT"."ORIGINALID",
    "RLRTFCT"."STARTID",
    "RLRTFCT"."ENDID",
    "RLRTFCT"."TYPE",
    "RLRTFCT"."BASELINE",
    "RLRTFCT"."CATEGORIES",
    "RLRTFCT"."LOCALE",
    "RLRTFCT"."TEMPLATE",
    "RLRTFCT"."RETURNTYPE",
    "RLRTFCT"."NAME",
    "RLRTFCT"."UUID",
    "RLRTFCT"."RULEPACKAGE",
    "RLRTFCT"."DOCUMENTATION",
    "RLRTFCT"."GRP",
    "RLRTFCT"."PROJECT",
    "RLRTFCT"."PRIORITY",
    "RLRTFCT"."ACTIVE",
    "RLRTFCT"."IMPORTS",
    "RLRTFCTSBLNG"."EFFECTIVEDATE",
    "RLRTFCTSBLNG"."EXPIRATIONDATE",
    "RLRTFCTSBLNG"."STATUS",
    "RGMNT"."ID" AS "ARGUMENT_ID",
    "RGMNT"."ORIGINALID" AS "ARGUMENT_ORIGINALID",
    "RGMNT"."STARTID" AS "ARGUMENT_STARTID",
    "RGMNT"."ENDID" AS "ARGUMENT_ENDID",
    "RGMNT"."BASELINE" AS "ARGUMENT_BASELINE",
    "RGMNT"."ARGUMENTTYPE" AS "ARGUMENT_ARGUMENTTYPE",
    "RGMNT"."NAME" AS "ARGUMENT_NAME",
    "RGMNT"."ILRORDER" AS "ARGUMENT_ILRORDER",
    "RGMNT"."TYPE" AS "ARGUMENT_TYPE",
    "VRRDDNRL"."ID" AS "OVERRIDDENRULE_ID",
    "VRRDDNRL"."ORIGINALID" AS "OVERRIDDENRULE_ORIGINALID",
    "VRRDDNRL"."STARTID" AS "OVERRIDDENRULE_STARTID",
    "VRRDDNRL"."ENDID" AS "OVERRIDDENRULE_ENDID",
    "VRRDDNRL"."BASELINE" AS "OVERRIDDENRULE_BASELINE",
    "VRRDDNRL"."TYPE" AS "OVERRIDDENRULE_TYPE",
    "VRRDDNRL"."ILRRULE" AS "OVERRIDDENRULE_ILRRULE",
    "DFNTN"."ID" AS "DEFINITION_ID",
    "DFNTN"."ORIGINALID" AS "DEFINITION_ORIGINALID",
    "DFNTN"."STARTID" AS "DEFINITION_STARTID",
    "DFNTN"."ENDID" AS "DEFINITION_ENDID",
    "DFNTN"."BASELINE" AS "DEFINITION_BASELINE",
    "DFNTN"."BODY" AS "DEFINITION_BODY",
    "DFNTN"."INFO" AS "DEFINITION_INFO",
    "DFNTN"."TYPE" AS "DEFINITION_TYPE",
    "RLRTFCTTG"."ID" AS "RULEARTIFACTTAG_ID",
    "RLRTFCTTG"."ORIGINALID" AS "RULEARTIFACTTAG_ORIGINALID",
    "RLRTFCTTG"."STARTID" AS "RULEARTIFACTTAG_STARTID",
    "RLRTFCTTG"."ENDID" AS "RULEARTIFACTTAG_ENDID",
    "RLRTFCTTG"."BASELINE" AS "RULEARTIFACTTAG_BASELINE",
    "RLRTFCTTG"."TYPE" AS "RULEARTIFACTTAG_TYPE",
    "RLRTFCTTG"."NAME" AS "RULEARTIFACTTAG_NAME",
    "RLRTFCTTG"."VALUE" AS "RULEARTIFACTTAG_VALUE",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."RULEARTIFACTSIBLING" "RLRTFCTSBLNG"
INNER JOIN "PUBLIC"."RULEARTIFACT" "RLRTFCT"
    ON 1=1
LEFT OUTER JOIN "PUBLIC"."ARGUMENT" "RGMNT"
    ON ("RLRTFCT"."ENDID" <= "RGMNT"."ENDID")
    AND (("RGMNT"."STARTID" <= "RLRTFCT"."STARTID")
    AND (("RLRTFCT"."ORIGINALID" = "RGMNT"."CONTAINER")
    AND ("RLRTFCT"."BASELINE" = "RGMNT"."BASELINE")))
LEFT OUTER JOIN "PUBLIC"."OVERRIDDENRULE" "VRRDDNRL"
    ON ("RLRTFCT"."ENDID" <= "VRRDDNRL"."ENDID")
    AND (("VRRDDNRL"."STARTID" <= "RLRTFCT"."STARTID")
    AND (("RLRTFCT"."ORIGINALID" = "VRRDDNRL"."CONTAINER")
    AND ("RLRTFCT"."BASELINE" = "VRRDDNRL"."BASELINE")))
LEFT OUTER JOIN "PUBLIC"."DEFINITION" "DFNTN"
    ON ("RLRTFCT"."ENDID" <= "DFNTN"."ENDID")
    AND (("DFNTN"."STARTID" <= "RLRTFCT"."STARTID")
    AND (("RLRTFCT"."ORIGINALID" = "DFNTN"."CONTAINER")
    AND ("RLRTFCT"."BASELINE" = "DFNTN"."BASELINE")))
LEFT OUTER JOIN "PUBLIC"."RULEARTIFACTTAG" "RLRTFCTTG"
    ON ("RLRTFCT"."ENDID" <= "RLRTFCTTG"."ENDID")
    AND (("RLRTFCTTG"."STARTID" <= "RLRTFCT"."STARTID")
    AND (("RLRTFCT"."ORIGINALID" = "RLRTFCTTG"."CONTAINER")
    AND ("RLRTFCT"."BASELINE" = "RLRTFCTTG"."BASELINE")))
INNER JOIN "PUBLIC"."RULEARTIFACT" "RULEARTIFACTCR"
    ON TRUE
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON TRUE
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON TRUE
WHERE ("RLRTFCT"."STARTID" = "VUPDT"."ID")
    AND (("RULEARTIFACTCR"."STARTID" = "VCR"."ID")
    AND (("RLRTFCT"."ID" = "RLRTFCTSBLNG"."ID")
    AND ("RLRTFCT"."ORIGINALID" = "RULEARTIFACTCR"."ID")));         
CREATE FORCE VIEW "PUBLIC"."RULEARTIFACTSTDXTD"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "CATEGORIES", "LOCALE", "TEMPLATE", "RETURNTYPE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "PRIORITY", "ACTIVE", "IMPORTS", "EFFECTIVEDATE", "EXPIRATIONDATE", "STATUS") AS
SELECT
    "RLRTFCT"."ID",
    "RLRTFCT"."ORIGINALID",
    "RLRTFCT"."STARTID",
    "RLRTFCT"."ENDID",
    "RLRTFCT"."BASELINE",
    "RLRTFCT"."TYPE",
    "RLRTFCT"."CATEGORIES",
    "RLRTFCT"."LOCALE",
    "RLRTFCT"."TEMPLATE",
    "RLRTFCT"."RETURNTYPE",
    "RLRTFCT"."NAME",
    "RLRTFCT"."UUID",
    "RLRTFCT"."RULEPACKAGE",
    "RLRTFCT"."DOCUMENTATION",
    "RLRTFCT"."GRP",
    "RLRTFCT"."PROJECT",
    "RLRTFCT"."PRIORITY",
    "RLRTFCT"."ACTIVE",
    "RLRTFCT"."IMPORTS",
    "RLRTFCTSBLNG"."EFFECTIVEDATE",
    "RLRTFCTSBLNG"."EXPIRATIONDATE",
    "RLRTFCTSBLNG"."STATUS"
FROM "PUBLIC"."RULEARTIFACTSIBLING" "RLRTFCTSBLNG"
INNER JOIN "PUBLIC"."RULEARTIFACT" "RLRTFCT"
    ON 1=1
WHERE "RLRTFCT"."ID" = "RLRTFCTSBLNG"."ID"; 
CREATE FORCE VIEW "PUBLIC"."RULEARTIFACTDTLS"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "CATEGORIES", "LOCALE", "TEMPLATE", "RETURNTYPE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "PRIORITY", "ACTIVE", "IMPORTS", "EFFECTIVEDATE", "EXPIRATIONDATE", "STATUS", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "RLRTFCT"."ID",
    "RLRTFCT"."ORIGINALID",
    "RLRTFCT"."STARTID",
    "RLRTFCT"."ENDID",
    "RLRTFCT"."BASELINE",
    "RLRTFCT"."TYPE",
    "RLRTFCT"."CATEGORIES",
    "RLRTFCT"."LOCALE",
    "RLRTFCT"."TEMPLATE",
    "RLRTFCT"."RETURNTYPE",
    "RLRTFCT"."NAME",
    "RLRTFCT"."UUID",
    "RLRTFCT"."RULEPACKAGE",
    "RLRTFCT"."DOCUMENTATION",
    "RLRTFCT"."GRP",
    "RLRTFCT"."PROJECT",
    "RLRTFCT"."PRIORITY",
    "RLRTFCT"."ACTIVE",
    "RLRTFCT"."IMPORTS",
    "RLRTFCTSBLNG"."EFFECTIVEDATE",
    "RLRTFCTSBLNG"."EXPIRATIONDATE",
    "RLRTFCTSBLNG"."STATUS",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."RULEARTIFACTSIBLING" "RLRTFCTSBLNG"
INNER JOIN "PUBLIC"."RULEARTIFACT" "RLRTFCT"
    ON 1=1
INNER JOIN "PUBLIC"."RULEARTIFACT" "RULEARTIFACTCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON 1=1
WHERE ("RLRTFCT"."STARTID" = "VUPDT"."ID")
    AND (("RULEARTIFACTCR"."STARTID" = "VCR"."ID")
    AND (("RLRTFCT"."ID" = "RLRTFCTSBLNG"."ID")
    AND ("RLRTFCT"."ORIGINALID" = "RULEARTIFACTCR"."ID")));          
CREATE FORCE VIEW "PUBLIC"."CHANGEVIEW"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "PARENT", "TYPE", "NAME", "CREATEDBY", "CREATEDON", "LASTCHANGEDBY", "LASTCHANGEDON", "PROJECT", "GRP", "DELETED", "LASTELTCHANGEDON") AS
(SELECT
    "RLRTFCT"."ID",
    "RLRTFCT"."ORIGINALID",
    "RLRTFCT"."STARTID",
    "RLRTFCT"."ENDID",
    "BSLN"."ID" AS "BASELINE",
    "BSLN"."PARENT",
    "RLRTFCT"."TYPE",
    "RLRTFCT"."NAME",
    "VERSIONCR"."USERNAME" AS "CREATEDBY",
    "VERSIONCR"."VERSDATE" AS "CREATEDON",
    "VERSIONUPDT"."USERNAME" AS "LASTCHANGEDBY",
    "VERSIONUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "RLRTFCT"."PROJECT",
    "RLRTFCT"."GRP",
    "VERSIONUPDT"."DELETED",
    CAST(NULL AS TIMESTAMP) AS "LASTELTCHANGEDON"
FROM "PUBLIC"."RULEARTIFACT" "RLRTFCT"
INNER JOIN "PUBLIC"."RULEARTIFACT" "RULEARTIFACTCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VERSIONCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VERSIONUPDT"
    ON 1=1
INNER JOIN "PUBLIC"."BASELINE" "BSLN"
    ON 1=1
WHERE ((("VERSIONUPDT"."SYSVERS" = FALSE)
    AND ("RLRTFCT"."STARTID" = "VERSIONUPDT"."ID"))
    OR (("VERSIONUPDT"."DELETED" = TRUE)
    AND ("RLRTFCT"."ENDID" = "VERSIONUPDT"."ID")))
    AND (("BSLN"."BASELINEKIND" = 'Branch')
    AND (("BSLN"."ID" = "RLRTFCT"."BASELINE")
    AND (("VERSIONCR"."SYSVERS" = FALSE)
    AND (("RULEARTIFACTCR"."ID" = "RLRTFCT"."ORIGINALID")
    AND ("RULEARTIFACTCR"."STARTID" = "VERSIONCR"."ID"))))))
UNION
(SELECT
    "BSLN"."ID",
    "BSLN"."ID" AS "ORIGINALID",
    "BSLN"."MAXVERSIONID" AS "STARTID",
    CAST(NULL AS INTEGER) AS "ENDID",
    "BSLN"."ID" AS "BASELINE",
    "BSLN"."PARENT",
    "BSLN"."TYPE",
    "BSLN"."NAME",
    "BSLN"."CREATEDBY",
    "BSLN"."CREATEDON",
    "BSLN"."LASTCHANGEDBY",
    "BSLN"."LASTCHANGEDON",
    "BSLN"."CONTAINER" AS "PROJECT",
    CAST(NULL AS VARCHAR(100)) AS "GRP",
    FALSE AS "DELETED",
    "PUBLIC"."VERSION"."VERSDATE" AS "LASTELTCHANGEDON"
FROM "PUBLIC"."BASELINE" "BSLN"
INNER JOIN "PUBLIC"."VERSION"
    ON 1=1
WHERE ("BSLN"."BASELINEKIND" = 'Standard')
    AND ("BSLN"."MAXVERSIONID" = "PUBLIC"."VERSION"."ID"))
ORDER BY 12 DESC;       
CREATE FORCE VIEW "PUBLIC"."RULEFLOWAGGRGTD"("ID", "ORIGINALID", "STARTID", "ENDID", "TYPE", "BASELINE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "BODY", "DIAGRAM", "FINALACTIONS", "IMPORTS", "INITIALACTIONS", "LOCALE", "MAINFLOWTASK", "SCOPEELEMENT_ID", "SCOPEELEMENT_ORIGINALID", "SCOPEELEMENT_STARTID", "SCOPEELEMENT_ENDID", "SCOPEELEMENT_BASELINE", "SCOPEELEMENT_TYPE", "SCOPEELEMENT_ILRORDER", "SCOPEELEMENT_ILRRULE", "SCOPEELEMENT_RULEPACKAGE", "SCOPEELEMENT_RULETASKNAME", "RULEFLOWTAG_ID", "RULEFLOWTAG_ORIGINALID", "RULEFLOWTAG_STARTID", "RULEFLOWTAG_ENDID", "RULEFLOWTAG_BASELINE", "RULEFLOWTAG_TYPE", "RULEFLOWTAG_NAME", "RULEFLOWTAG_VALUE", "TASK_ID", "TASK_ORIGINALID", "TASK_STARTID", "TASK_ENDID", "TASK_BASELINE", "TASK_TYPE", "TASK_DEFINITION", "TASK_ADVANCEDPROPERTIES", "TASK_ALGORITHM", "TASK_DYNAMIC", "TASK_EXITCRITERIA", "TASK_ORDERING", "TASK_ILRSELECT", "TASK_DOCUMENTATION", "TASK_FINALACTIONS", "TASK_INITIALACTIONS", "TASK_NAME", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "RLFLW"."ID",
    "RLFLW"."ORIGINALID",
    "RLFLW"."STARTID",
    "RLFLW"."ENDID",
    "RLFLW"."TYPE",
    "RLFLW"."BASELINE",
    "RLFLW"."NAME",
    "RLFLW"."UUID",
    "RLFLW"."RULEPACKAGE",
    "RLFLW"."DOCUMENTATION",
    "RLFLW"."GRP",
    "RLFLW"."PROJECT",
    "RLFLW"."BODY",
    "RLFLW"."DIAGRAM",
    "RLFLW"."FINALACTIONS",
    "RLFLW"."IMPORTS",
    "RLFLW"."INITIALACTIONS",
    "RLFLW"."LOCALE",
    "RLFLW"."MAINFLOWTASK",
    "SCPLMNT"."ID" AS "SCOPEELEMENT_ID",
    "SCPLMNT"."ORIGINALID" AS "SCOPEELEMENT_ORIGINALID",
    "SCPLMNT"."STARTID" AS "SCOPEELEMENT_STARTID",
    "SCPLMNT"."ENDID" AS "SCOPEELEMENT_ENDID",
    "SCPLMNT"."BASELINE" AS "SCOPEELEMENT_BASELINE",
    "SCPLMNT"."TYPE" AS "SCOPEELEMENT_TYPE",
    "SCPLMNT"."ILRORDER" AS "SCOPEELEMENT_ILRORDER",
    "SCPLMNT"."ILRRULE" AS "SCOPEELEMENT_ILRRULE",
    "SCPLMNT"."RULEPACKAGE" AS "SCOPEELEMENT_RULEPACKAGE",
    "SCPLMNT"."RULETASKNAME" AS "SCOPEELEMENT_RULETASKNAME",
    "RLFLWTG"."ID" AS "RULEFLOWTAG_ID",
    "RLFLWTG"."ORIGINALID" AS "RULEFLOWTAG_ORIGINALID",
    "RLFLWTG"."STARTID" AS "RULEFLOWTAG_STARTID",
    "RLFLWTG"."ENDID" AS "RULEFLOWTAG_ENDID",
    "RLFLWTG"."BASELINE" AS "RULEFLOWTAG_BASELINE",
    "RLFLWTG"."TYPE" AS "RULEFLOWTAG_TYPE",
    "RLFLWTG"."NAME" AS "RULEFLOWTAG_NAME",
    "RLFLWTG"."VALUE" AS "RULEFLOWTAG_VALUE",
    "TSK"."ID" AS "TASK_ID",
    "TSK"."ORIGINALID" AS "TASK_ORIGINALID",
    "TSK"."STARTID" AS "TASK_STARTID",
    "TSK"."ENDID" AS "TASK_ENDID",
    "TSK"."BASELINE" AS "TASK_BASELINE",
    "TSK"."TYPE" AS "TASK_TYPE",
    "TSK"."DEFINITION" AS "TASK_DEFINITION",
    "TSK"."ADVANCEDPROPERTIES" AS "TASK_ADVANCEDPROPERTIES",
    "TSK"."ALGORITHM" AS "TASK_ALGORITHM",
    "TSK"."DYNAMIC" AS "TASK_DYNAMIC",
    "TSK"."EXITCRITERIA" AS "TASK_EXITCRITERIA",
    "TSK"."ORDERING" AS "TASK_ORDERING",
    "TSK"."ILRSELECT" AS "TASK_ILRSELECT",
    "TSK"."DOCUMENTATION" AS "TASK_DOCUMENTATION",
    "TSK"."FINALACTIONS" AS "TASK_FINALACTIONS",
    "TSK"."INITIALACTIONS" AS "TASK_INITIALACTIONS",
    "TSK"."NAME" AS "TASK_NAME",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."RULEFLOWSIBLING" "RLFLWSBLNG"
INNER JOIN "PUBLIC"."RULEFLOW" "RLFLW"
    ON 1=1
LEFT OUTER JOIN "PUBLIC"."SCOPEELEMENT" "SCPLMNT"
    ON ("RLFLW"."ENDID" <= "SCPLMNT"."ENDID")
    AND (("SCPLMNT"."STARTID" <= "RLFLW"."STARTID")
    AND (("RLFLW"."ORIGINALID" = "SCPLMNT"."CONTAINER")
    AND ("RLFLW"."BASELINE" = "SCPLMNT"."BASELINE")))
LEFT OUTER JOIN "PUBLIC"."RULEFLOWTAG" "RLFLWTG"
    ON ("RLFLW"."ENDID" <= "RLFLWTG"."ENDID")
    AND (("RLFLWTG"."STARTID" <= "RLFLW"."STARTID")
    AND (("RLFLW"."ORIGINALID" = "RLFLWTG"."CONTAINER")
    AND ("RLFLW"."BASELINE" = "RLFLWTG"."BASELINE")))
LEFT OUTER JOIN "PUBLIC"."TASK" "TSK"
    ON ("RLFLW"."ENDID" <= "TSK"."ENDID")
    AND (("TSK"."STARTID" <= "RLFLW"."STARTID")
    AND (("RLFLW"."ORIGINALID" = "TSK"."CONTAINER")
    AND ("RLFLW"."BASELINE" = "TSK"."BASELINE")))
INNER JOIN "PUBLIC"."RULEFLOW" "RULEFLOWCR"
    ON TRUE
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON TRUE
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON TRUE
WHERE ("RLFLW"."STARTID" = "VUPDT"."ID")
    AND (("RULEFLOWCR"."STARTID" = "VCR"."ID")
    AND (("RLFLW"."ID" = "RLFLWSBLNG"."ID")
    AND ("RLFLW"."ORIGINALID" = "RULEFLOWCR"."ID")));   
CREATE FORCE VIEW "PUBLIC"."RULEFLOWSTDXTD"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "BODY", "DIAGRAM", "FINALACTIONS", "IMPORTS", "INITIALACTIONS", "LOCALE", "MAINFLOWTASK") AS
SELECT
    "RLFLW"."ID",
    "RLFLW"."ORIGINALID",
    "RLFLW"."STARTID",
    "RLFLW"."ENDID",
    "RLFLW"."BASELINE",
    "RLFLW"."TYPE",
    "RLFLW"."NAME",
    "RLFLW"."UUID",
    "RLFLW"."RULEPACKAGE",
    "RLFLW"."DOCUMENTATION",
    "RLFLW"."GRP",
    "RLFLW"."PROJECT",
    "RLFLW"."BODY",
    "RLFLW"."DIAGRAM",
    "RLFLW"."FINALACTIONS",
    "RLFLW"."IMPORTS",
    "RLFLW"."INITIALACTIONS",
    "RLFLW"."LOCALE",
    "RLFLW"."MAINFLOWTASK"
FROM "PUBLIC"."RULEFLOWSIBLING" "RLFLWSBLNG"
INNER JOIN "PUBLIC"."RULEFLOW" "RLFLW"
    ON 1=1
WHERE "RLFLW"."ID" = "RLFLWSBLNG"."ID";
CREATE FORCE VIEW "PUBLIC"."RULEFLOWDTLS"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "BODY", "DIAGRAM", "FINALACTIONS", "IMPORTS", "INITIALACTIONS", "LOCALE", "MAINFLOWTASK", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "RLFLW"."ID",
    "RLFLW"."ORIGINALID",
    "RLFLW"."STARTID",
    "RLFLW"."ENDID",
    "RLFLW"."BASELINE",
    "RLFLW"."TYPE",
    "RLFLW"."NAME",
    "RLFLW"."UUID",
    "RLFLW"."RULEPACKAGE",
    "RLFLW"."DOCUMENTATION",
    "RLFLW"."GRP",
    "RLFLW"."PROJECT",
    "RLFLW"."BODY",
    "RLFLW"."DIAGRAM",
    "RLFLW"."FINALACTIONS",
    "RLFLW"."IMPORTS",
    "RLFLW"."INITIALACTIONS",
    "RLFLW"."LOCALE",
    "RLFLW"."MAINFLOWTASK",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."RULEFLOWSIBLING" "RLFLWSBLNG"
INNER JOIN "PUBLIC"."RULEFLOW" "RLFLW"
    ON 1=1
INNER JOIN "PUBLIC"."RULEFLOW" "RULEFLOWCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON 1=1
WHERE ("RLFLW"."STARTID" = "VUPDT"."ID")
    AND (("RULEFLOWCR"."STARTID" = "VCR"."ID")
    AND (("RLFLW"."ID" = "RLFLWSBLNG"."ID")
    AND ("RLFLW"."ORIGINALID" = "RULEFLOWCR"."ID")));             
CREATE FORCE VIEW "PUBLIC"."RULEPACKAGESTDXTD"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "NAME", "UUID", "DOCUMENTATION", "GRP", "PROJECT", "PACKAGEKIND", "PARENT", "RULEORDER") AS
SELECT
    "RLPCKG"."ID",
    "RLPCKG"."ORIGINALID",
    "RLPCKG"."STARTID",
    "RLPCKG"."ENDID",
    "RLPCKG"."BASELINE",
    "RLPCKG"."TYPE",
    "RLPCKG"."NAME",
    "RLPCKG"."UUID",
    "RLPCKG"."DOCUMENTATION",
    "RLPCKG"."GRP",
    "RLPCKG"."PROJECT",
    "RLPCKG"."PACKAGEKIND",
    "RLPCKG"."PARENT",
    "RLPCKG"."RULEORDER"
FROM "PUBLIC"."RULEPACKAGESIBLING" "RLPCKGSBLNG"
INNER JOIN "PUBLIC"."RULEPACKAGE" "RLPCKG"
    ON 1=1
WHERE "RLPCKG"."ID" = "RLPCKGSBLNG"."ID";       
CREATE FORCE VIEW "PUBLIC"."RULEPACKAGEDTLS"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "NAME", "UUID", "DOCUMENTATION", "GRP", "PROJECT", "PACKAGEKIND", "PARENT", "RULEORDER", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "RLPCKG"."ID",
    "RLPCKG"."ORIGINALID",
    "RLPCKG"."STARTID",
    "RLPCKG"."ENDID",
    "RLPCKG"."BASELINE",
    "RLPCKG"."TYPE",
    "RLPCKG"."NAME",
    "RLPCKG"."UUID",
    "RLPCKG"."DOCUMENTATION",
    "RLPCKG"."GRP",
    "RLPCKG"."PROJECT",
    "RLPCKG"."PACKAGEKIND",
    "RLPCKG"."PARENT",
    "RLPCKG"."RULEORDER",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."RULEPACKAGESIBLING" "RLPCKGSBLNG"
INNER JOIN "PUBLIC"."RULEPACKAGE" "RLPCKG"
    ON 1=1
INNER JOIN "PUBLIC"."RULEPACKAGE" "RULEPACKAGECR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON 1=1
WHERE ("RLPCKG"."STARTID" = "VUPDT"."ID")
    AND (("RULEPACKAGECR"."STARTID" = "VCR"."ID")
    AND (("RLPCKG"."ID" = "RLPCKGSBLNG"."ID")
    AND ("RLPCKG"."ORIGINALID" = "RULEPACKAGECR"."ID")));      
CREATE FORCE VIEW "PUBLIC"."RULEPROJECTXTDSUMMARY"("ID", "TYPE", "CREATEDBY", "CREATEDON", "NAME", "UUID", "PLATFORM", "LASTCHANGEDBY", "LASTCHANGEDON") AS
SELECT
    "RLPRJCT"."ID",
    "RLPRJCT"."TYPE",
    "RLPRJCT"."CREATEDBY",
    "RLPRJCT"."CREATEDON",
    "RLPRJCT"."NAME",
    "RLPRJCT"."UUID",
    "RLPRJCT"."PLATFORM",
    "VRSN"."USERNAME" AS "LASTCHANGEDBY",
    "VRSN"."VERSDATE" AS "LASTCHANGEDON"
FROM "PUBLIC"."RULEPROJECT" "RLPRJCT"
INNER JOIN "PUBLIC"."VERSION" "VRSN"
    ON 1=1
INNER JOIN (
    SELECT
        MAX("VRSN"."ID") AS "ID"
    FROM "PUBLIC"."VERSION" "VRSN"
    GROUP BY "VRSN"."PROJECT"
) "LASTVERSION"
    ON 1=1
WHERE ("VRSN"."ID" = "LASTVERSION"."ID")
    AND (("RLPRJCT"."ID" <> 2147483647)
    AND ("RLPRJCT"."ID" = "VRSN"."PROJECT"));          
CREATE FORCE VIEW "PUBLIC"."SCENARIOSUITEAGGRGTD"("ID", "ORIGINALID", "STARTID", "ENDID", "TYPE", "BASELINE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "ENTRYPOINT", "FORMAT", "TESTBASELINE", "TESTEXTRACTOR", "SCENARIOSUITERESOURCE_ID", "SCENARIOSUITERESOURCE_ORIGINALID", "SCENARIOSUITERESOURCE_STARTID", "SCENARIOSUITERESOURCE_ENDID", "SCENARIOSUITERESOURCE_BASELINE", "SCENARIOSUITERESOURCE_TYPE", "SCENARIOSUITERESOURCE_ILRKEY", "SCENARIOSUITERESOURCE_VALUE", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "SCNRST"."ID",
    "SCNRST"."ORIGINALID",
    "SCNRST"."STARTID",
    "SCNRST"."ENDID",
    "SCNRST"."TYPE",
    "SCNRST"."BASELINE",
    "SCNRST"."NAME",
    "SCNRST"."UUID",
    "SCNRST"."RULEPACKAGE",
    "SCNRST"."DOCUMENTATION",
    "SCNRST"."GRP",
    "SCNRST"."PROJECT",
    "SCNRST"."ENTRYPOINT",
    "SCNRST"."FORMAT",
    "SCNRST"."TESTBASELINE",
    "SCNRST"."TESTEXTRACTOR",
    "SCNRSTRSRC"."ID" AS "SCENARIOSUITERESOURCE_ID",
    "SCNRSTRSRC"."ORIGINALID" AS "SCENARIOSUITERESOURCE_ORIGINALID",
    "SCNRSTRSRC"."STARTID" AS "SCENARIOSUITERESOURCE_STARTID",
    "SCNRSTRSRC"."ENDID" AS "SCENARIOSUITERESOURCE_ENDID",
    "SCNRSTRSRC"."BASELINE" AS "SCENARIOSUITERESOURCE_BASELINE",
    "SCNRSTRSRC"."TYPE" AS "SCENARIOSUITERESOURCE_TYPE",
    "SCNRSTRSRC"."ILRKEY" AS "SCENARIOSUITERESOURCE_ILRKEY",
    "SCNRSTRSRC"."VALUE" AS "SCENARIOSUITERESOURCE_VALUE",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."SCENARIOSUITE" "SCNRST"
LEFT OUTER JOIN "PUBLIC"."SCENARIOSUITERESOURCE" "SCNRSTRSRC"
    ON ("SCNRST"."ENDID" <= "SCNRSTRSRC"."ENDID")
    AND (("SCNRSTRSRC"."STARTID" <= "SCNRST"."STARTID")
    AND (("SCNRST"."ORIGINALID" = "SCNRSTRSRC"."CONTAINER")
    AND ("SCNRST"."BASELINE" = "SCNRSTRSRC"."BASELINE")))
INNER JOIN "PUBLIC"."SCENARIOSUITE" "SCENARIOSUITECR"
    ON TRUE
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON TRUE
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON TRUE
WHERE ("SCNRST"."STARTID" = "VUPDT"."ID")
    AND (("SCNRST"."ORIGINALID" = "SCENARIOSUITECR"."ID")
    AND ("SCENARIOSUITECR"."STARTID" = "VCR"."ID"));    
CREATE FORCE VIEW "PUBLIC"."SCENARIOSUITEDTLS"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "ENTRYPOINT", "FORMAT", "TESTBASELINE", "TESTEXTRACTOR", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "SCNRST"."ID",
    "SCNRST"."ORIGINALID",
    "SCNRST"."STARTID",
    "SCNRST"."ENDID",
    "SCNRST"."BASELINE",
    "SCNRST"."TYPE",
    "SCNRST"."NAME",
    "SCNRST"."UUID",
    "SCNRST"."RULEPACKAGE",
    "SCNRST"."DOCUMENTATION",
    "SCNRST"."GRP",
    "SCNRST"."PROJECT",
    "SCNRST"."ENTRYPOINT",
    "SCNRST"."FORMAT",
    "SCNRST"."TESTBASELINE",
    "SCNRST"."TESTEXTRACTOR",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."SCENARIOSUITE" "SCNRST"
INNER JOIN "PUBLIC"."SCENARIOSUITE" "SCENARIOSUITECR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON 1=1
WHERE ("SCNRST"."STARTID" = "VUPDT"."ID")
    AND (("SCNRST"."ORIGINALID" = "SCENARIOSUITECR"."ID")
    AND ("SCENARIOSUITECR"."STARTID" = "VCR"."ID"));             
CREATE FORCE VIEW "PUBLIC"."TEMPLATEAGGRGTD"("ID", "ORIGINALID", "STARTID", "ENDID", "TYPE", "BASELINE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "DEFINITION", "DEFINITIONINFO", "LOCALE", "RULETYPE", "INITIALVALUE_ID", "INITIALVALUE_ORIGINALID", "INITIALVALUE_STARTID", "INITIALVALUE_ENDID", "INITIALVALUE_BASELINE", "INITIALVALUE_TYPE", "INITIALVALUE_NAME", "INITIALVALUE_VALUE", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "TMPLT"."ID",
    "TMPLT"."ORIGINALID",
    "TMPLT"."STARTID",
    "TMPLT"."ENDID",
    "TMPLT"."TYPE",
    "TMPLT"."BASELINE",
    "TMPLT"."NAME",
    "TMPLT"."UUID",
    "TMPLT"."RULEPACKAGE",
    "TMPLT"."DOCUMENTATION",
    "TMPLT"."GRP",
    "TMPLT"."PROJECT",
    "TMPLT"."DEFINITION",
    "TMPLT"."DEFINITIONINFO",
    "TMPLT"."LOCALE",
    "TMPLT"."RULETYPE",
    "NTLVL"."ID" AS "INITIALVALUE_ID",
    "NTLVL"."ORIGINALID" AS "INITIALVALUE_ORIGINALID",
    "NTLVL"."STARTID" AS "INITIALVALUE_STARTID",
    "NTLVL"."ENDID" AS "INITIALVALUE_ENDID",
    "NTLVL"."BASELINE" AS "INITIALVALUE_BASELINE",
    "NTLVL"."TYPE" AS "INITIALVALUE_TYPE",
    "NTLVL"."NAME" AS "INITIALVALUE_NAME",
    "NTLVL"."VALUE" AS "INITIALVALUE_VALUE",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."TEMPLATE" "TMPLT"
LEFT OUTER JOIN "PUBLIC"."INITIALVALUE" "NTLVL"
    ON ("TMPLT"."ENDID" <= "NTLVL"."ENDID")
    AND (("NTLVL"."STARTID" <= "TMPLT"."STARTID")
    AND (("TMPLT"."ORIGINALID" = "NTLVL"."CONTAINER")
    AND ("TMPLT"."BASELINE" = "NTLVL"."BASELINE")))
INNER JOIN "PUBLIC"."TEMPLATE" "TEMPLATECR"
    ON TRUE
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON TRUE
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON TRUE
WHERE ("TMPLT"."STARTID" = "VUPDT"."ID")
    AND (("TMPLT"."ORIGINALID" = "TEMPLATECR"."ID")
    AND ("TEMPLATECR"."STARTID" = "VCR"."ID"));               
CREATE FORCE VIEW "PUBLIC"."TEMPLATEDTLS"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "DEFINITION", "DEFINITIONINFO", "LOCALE", "RULETYPE", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "TMPLT"."ID",
    "TMPLT"."ORIGINALID",
    "TMPLT"."STARTID",
    "TMPLT"."ENDID",
    "TMPLT"."BASELINE",
    "TMPLT"."TYPE",
    "TMPLT"."NAME",
    "TMPLT"."UUID",
    "TMPLT"."RULEPACKAGE",
    "TMPLT"."DOCUMENTATION",
    "TMPLT"."GRP",
    "TMPLT"."PROJECT",
    "TMPLT"."DEFINITION",
    "TMPLT"."DEFINITIONINFO",
    "TMPLT"."LOCALE",
    "TMPLT"."RULETYPE",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."TEMPLATE" "TMPLT"
INNER JOIN "PUBLIC"."TEMPLATE" "TEMPLATECR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON 1=1
WHERE ("TMPLT"."STARTID" = "VUPDT"."ID")
    AND (("TMPLT"."ORIGINALID" = "TEMPLATECR"."ID")
    AND ("TEMPLATECR"."STARTID" = "VCR"."ID"));    
CREATE FORCE VIEW "PUBLIC"."VARIABLESETAGGRGTD"("ID", "ORIGINALID", "STARTID", "ENDID", "TYPE", "BASELINE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "VARIABLE_ID", "VARIABLE_ORIGINALID", "VARIABLE_STARTID", "VARIABLE_ENDID", "VARIABLE_BASELINE", "VARIABLE_TYPE", "VARIABLE_BOMTYPE", "VARIABLE_INITIALVALUE", "VARIABLE_NAME", "VARIABLE_VERBALIZATION", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "VRBLST"."ID",
    "VRBLST"."ORIGINALID",
    "VRBLST"."STARTID",
    "VRBLST"."ENDID",
    "VRBLST"."TYPE",
    "VRBLST"."BASELINE",
    "VRBLST"."NAME",
    "VRBLST"."UUID",
    "VRBLST"."RULEPACKAGE",
    "VRBLST"."DOCUMENTATION",
    "VRBLST"."GRP",
    "VRBLST"."PROJECT",
    "VRBL"."ID" AS "VARIABLE_ID",
    "VRBL"."ORIGINALID" AS "VARIABLE_ORIGINALID",
    "VRBL"."STARTID" AS "VARIABLE_STARTID",
    "VRBL"."ENDID" AS "VARIABLE_ENDID",
    "VRBL"."BASELINE" AS "VARIABLE_BASELINE",
    "VRBL"."TYPE" AS "VARIABLE_TYPE",
    "VRBL"."BOMTYPE" AS "VARIABLE_BOMTYPE",
    "VRBL"."INITIALVALUE" AS "VARIABLE_INITIALVALUE",
    "VRBL"."NAME" AS "VARIABLE_NAME",
    "VRBL"."VERBALIZATION" AS "VARIABLE_VERBALIZATION",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."VARIABLESET" "VRBLST"
LEFT OUTER JOIN "PUBLIC"."VARIABLE" "VRBL"
    ON ("VRBLST"."ENDID" <= "VRBL"."ENDID")
    AND (("VRBL"."STARTID" <= "VRBLST"."STARTID")
    AND (("VRBLST"."ORIGINALID" = "VRBL"."CONTAINER")
    AND ("VRBLST"."BASELINE" = "VRBL"."BASELINE")))
INNER JOIN "PUBLIC"."VARIABLESET" "VARIABLESETCR"
    ON TRUE
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON TRUE
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON TRUE
WHERE ("VRBLST"."STARTID" = "VUPDT"."ID")
    AND (("VRBLST"."ORIGINALID" = "VARIABLESETCR"."ID")
    AND ("VARIABLESETCR"."STARTID" = "VCR"."ID"));
CREATE FORCE VIEW "PUBLIC"."VARIABLESETDTLS"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "VRBLST"."ID",
    "VRBLST"."ORIGINALID",
    "VRBLST"."STARTID",
    "VRBLST"."ENDID",
    "VRBLST"."BASELINE",
    "VRBLST"."TYPE",
    "VRBLST"."NAME",
    "VRBLST"."UUID",
    "VRBLST"."RULEPACKAGE",
    "VRBLST"."DOCUMENTATION",
    "VRBLST"."GRP",
    "VRBLST"."PROJECT",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."VARIABLESET" "VRBLST"
INNER JOIN "PUBLIC"."VARIABLESET" "VARIABLESETCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON 1=1
WHERE ("VRBLST"."STARTID" = "VUPDT"."ID")
    AND (("VRBLST"."ORIGINALID" = "VARIABLESETCR"."ID")
    AND ("VARIABLESETCR"."STARTID" = "VCR"."ID"));               
CREATE FORCE VIEW "PUBLIC"."VOCABULARYDTLS"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "BODY", "LOCALE", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "VCBLRY"."ID",
    "VCBLRY"."ORIGINALID",
    "VCBLRY"."STARTID",
    "VCBLRY"."ENDID",
    "VCBLRY"."BASELINE",
    "VCBLRY"."TYPE",
    "VCBLRY"."NAME",
    "VCBLRY"."UUID",
    "VCBLRY"."RULEPACKAGE",
    "VCBLRY"."DOCUMENTATION",
    "VCBLRY"."GRP",
    "VCBLRY"."PROJECT",
    "VCBLRY"."BODY",
    "VCBLRY"."LOCALE",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."VOCABULARY" "VCBLRY"
INNER JOIN "PUBLIC"."VOCABULARY" "VOCABULARYCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON 1=1
WHERE ("VCBLRY"."STARTID" = "VUPDT"."ID")
    AND (("VCBLRY"."ORIGINALID" = "VOCABULARYCR"."ID")
    AND ("VOCABULARYCR"."STARTID" = "VCR"."ID"));       
CREATE FORCE VIEW "PUBLIC"."VSCONFIGDTLS"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "DATAPARAMS", "INPUTDATA", "REPORTNAME", "RUNBASELINE", "SERVER", "SIMULATIONMODEL", "ENABLED", "OPERATION", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "VSCNFG"."ID",
    "VSCNFG"."ORIGINALID",
    "VSCNFG"."STARTID",
    "VSCNFG"."ENDID",
    "VSCNFG"."BASELINE",
    "VSCNFG"."TYPE",
    "VSCNFG"."NAME",
    "VSCNFG"."UUID",
    "VSCNFG"."RULEPACKAGE",
    "VSCNFG"."DOCUMENTATION",
    "VSCNFG"."GRP",
    "VSCNFG"."PROJECT",
    "VSCNFG"."DATAPARAMS",
    "VSCNFG"."INPUTDATA",
    "VSCNFG"."REPORTNAME",
    "VSCNFG"."RUNBASELINE",
    "VSCNFG"."SERVER",
    "VSCNFG"."SIMULATIONMODEL",
    "VSCNFG"."ENABLED",
    "VSCNFG"."OPERATION",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."VSCONFIG" "VSCNFG"
INNER JOIN "PUBLIC"."VSCONFIG" "VSCONFIGCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON 1=1
WHERE ("VSCNFG"."STARTID" = "VUPDT"."ID")
    AND (("VSCNFG"."ORIGINALID" = "VSCONFIGCR"."ID")
    AND ("VSCONFIGCR"."STARTID" = "VCR"."ID"));               
CREATE FORCE VIEW "PUBLIC"."VSINPUTDATADTLS"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "CONTENT", "FILENAME", "INPUTTYPE", "ENABLED", "OPERATION", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "VSNPTDT"."ID",
    "VSNPTDT"."ORIGINALID",
    "VSNPTDT"."STARTID",
    "VSNPTDT"."ENDID",
    "VSNPTDT"."BASELINE",
    "VSNPTDT"."TYPE",
    "VSNPTDT"."NAME",
    "VSNPTDT"."UUID",
    "VSNPTDT"."RULEPACKAGE",
    "VSNPTDT"."DOCUMENTATION",
    "VSNPTDT"."GRP",
    "VSNPTDT"."PROJECT",
    "VSNPTDT"."CONTENT",
    "VSNPTDT"."FILENAME",
    "VSNPTDT"."INPUTTYPE",
    "VSNPTDT"."ENABLED",
    "VSNPTDT"."OPERATION",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."VSINPUTDATA" "VSNPTDT"
INNER JOIN "PUBLIC"."VSINPUTDATA" "VSINPUTDATACR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON 1=1
WHERE ("VSNPTDT"."STARTID" = "VUPDT"."ID")
    AND (("VSNPTDT"."ORIGINALID" = "VSINPUTDATACR"."ID")
    AND ("VSINPUTDATACR"."STARTID" = "VCR"."ID"));  
CREATE FORCE VIEW "PUBLIC"."VSKPIDTLS"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "MEASURE", "ENABLED", "OPERATION", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "VSKP"."ID",
    "VSKP"."ORIGINALID",
    "VSKP"."STARTID",
    "VSKP"."ENDID",
    "VSKP"."BASELINE",
    "VSKP"."TYPE",
    "VSKP"."NAME",
    "VSKP"."UUID",
    "VSKP"."RULEPACKAGE",
    "VSKP"."DOCUMENTATION",
    "VSKP"."GRP",
    "VSKP"."PROJECT",
    "VSKP"."MEASURE",
    "VSKP"."ENABLED",
    "VSKP"."OPERATION",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."VSKPI" "VSKP"
INNER JOIN "PUBLIC"."VSKPI" "VSKPICR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON 1=1
WHERE ("VSKP"."STARTID" = "VUPDT"."ID")
    AND (("VSKP"."ORIGINALID" = "VSKPICR"."ID")
    AND ("VSKPICR"."STARTID" = "VCR"."ID"));          
CREATE FORCE VIEW "PUBLIC"."VSMETRICDTLS"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "DEFAULTVALUE", "MAPPING", "METRICTYPE", "ENABLED", "OPERATION", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "VSMTRC"."ID",
    "VSMTRC"."ORIGINALID",
    "VSMTRC"."STARTID",
    "VSMTRC"."ENDID",
    "VSMTRC"."BASELINE",
    "VSMTRC"."TYPE",
    "VSMTRC"."NAME",
    "VSMTRC"."UUID",
    "VSMTRC"."RULEPACKAGE",
    "VSMTRC"."DOCUMENTATION",
    "VSMTRC"."GRP",
    "VSMTRC"."PROJECT",
    "VSMTRC"."DEFAULTVALUE",
    "VSMTRC"."MAPPING",
    "VSMTRC"."METRICTYPE",
    "VSMTRC"."ENABLED",
    "VSMTRC"."OPERATION",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."VSMETRIC" "VSMTRC"
INNER JOIN "PUBLIC"."VSMETRIC" "VSMETRICCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON 1=1
WHERE ("VSMTRC"."STARTID" = "VUPDT"."ID")
    AND (("VSMTRC"."ORIGINALID" = "VSMETRICCR"."ID")
    AND ("VSMETRICCR"."STARTID" = "VCR"."ID"));              
CREATE FORCE VIEW "PUBLIC"."VSMODELDTLS"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "REPORTCONFIGURATION", "ENABLED", "OPERATION", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "VSMDL"."ID",
    "VSMDL"."ORIGINALID",
    "VSMDL"."STARTID",
    "VSMDL"."ENDID",
    "VSMDL"."BASELINE",
    "VSMDL"."TYPE",
    "VSMDL"."NAME",
    "VSMDL"."UUID",
    "VSMDL"."RULEPACKAGE",
    "VSMDL"."DOCUMENTATION",
    "VSMDL"."GRP",
    "VSMDL"."PROJECT",
    "VSMDL"."REPORTCONFIGURATION",
    "VSMDL"."ENABLED",
    "VSMDL"."OPERATION",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."VSMODEL" "VSMDL"
INNER JOIN "PUBLIC"."VSMODEL" "VSMODELCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON 1=1
WHERE ("VSMDL"."STARTID" = "VUPDT"."ID")
    AND (("VSMDL"."ORIGINALID" = "VSMODELCR"."ID")
    AND ("VSMODELCR"."STARTID" = "VCR"."ID"));    
CREATE FORCE VIEW "PUBLIC"."VTCASEDTLS"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "ENTRYNAME", "FORMAT", "ORIGINALBASELINE", "TESTCASERESOURCE", "ENABLED", "OPERATION", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "VTCS"."ID",
    "VTCS"."ORIGINALID",
    "VTCS"."STARTID",
    "VTCS"."ENDID",
    "VTCS"."BASELINE",
    "VTCS"."TYPE",
    "VTCS"."NAME",
    "VTCS"."UUID",
    "VTCS"."RULEPACKAGE",
    "VTCS"."DOCUMENTATION",
    "VTCS"."GRP",
    "VTCS"."PROJECT",
    "VTCS"."ENTRYNAME",
    "VTCS"."FORMAT",
    "VTCS"."ORIGINALBASELINE",
    "VTCS"."TESTCASERESOURCE",
    "VTCS"."ENABLED",
    "VTCS"."OPERATION",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."VTCASE" "VTCS"
INNER JOIN "PUBLIC"."VTCASE" "VTCASECR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON 1=1
WHERE ("VTCS"."STARTID" = "VUPDT"."ID")
    AND (("VTCS"."ORIGINALID" = "VTCASECR"."ID")
    AND ("VTCASECR"."STARTID" = "VCR"."ID"));           
CREATE FORCE VIEW "PUBLIC"."VTSUITEAGGRGTD"("ID", "ORIGINALID", "STARTID", "ENDID", "TYPE", "BASELINE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "CREATEIOFILE", "DESCRIPTORFORMAT", "DESCRIPTORXML", "LASTTESTCASEUPLOADON", "REPORTNAME", "RUNBASELINE", "SERVERNAME", "ENABLED", "OPERATION", "VTCRESOURCE_ID", "VTCRESOURCE_ORIGINALID", "VTCRESOURCE_STARTID", "VTCRESOURCE_ENDID", "VTCRESOURCE_BASELINE", "VTCRESOURCE_TYPE", "VTCRESOURCE_ILRKEY", "VTCRESOURCE_NUMBEROFTESTCASES", "VTCRESOURCE_VALUE", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "VTST"."ID",
    "VTST"."ORIGINALID",
    "VTST"."STARTID",
    "VTST"."ENDID",
    "VTST"."TYPE",
    "VTST"."BASELINE",
    "VTST"."NAME",
    "VTST"."UUID",
    "VTST"."RULEPACKAGE",
    "VTST"."DOCUMENTATION",
    "VTST"."GRP",
    "VTST"."PROJECT",
    "VTST"."CREATEIOFILE",
    "VTST"."DESCRIPTORFORMAT",
    "VTST"."DESCRIPTORXML",
    "VTST"."LASTTESTCASEUPLOADON",
    "VTST"."REPORTNAME",
    "VTST"."RUNBASELINE",
    "VTST"."SERVERNAME",
    "VTST"."ENABLED",
    "VTST"."OPERATION",
    "VTCRSRC"."ID" AS "VTCRESOURCE_ID",
    "VTCRSRC"."ORIGINALID" AS "VTCRESOURCE_ORIGINALID",
    "VTCRSRC"."STARTID" AS "VTCRESOURCE_STARTID",
    "VTCRSRC"."ENDID" AS "VTCRESOURCE_ENDID",
    "VTCRSRC"."BASELINE" AS "VTCRESOURCE_BASELINE",
    "VTCRSRC"."TYPE" AS "VTCRESOURCE_TYPE",
    "VTCRSRC"."ILRKEY" AS "VTCRESOURCE_ILRKEY",
    "VTCRSRC"."NUMBEROFTESTCASES" AS "VTCRESOURCE_NUMBEROFTESTCASES",
    "VTCRSRC"."VALUE" AS "VTCRESOURCE_VALUE",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."VTSUITE" "VTST"
LEFT OUTER JOIN "PUBLIC"."VTCRESOURCE" "VTCRSRC"
    ON ("VTST"."ENDID" <= "VTCRSRC"."ENDID")
    AND (("VTCRSRC"."STARTID" <= "VTST"."STARTID")
    AND (("VTST"."ORIGINALID" = "VTCRSRC"."CONTAINER")
    AND ("VTST"."BASELINE" = "VTCRSRC"."BASELINE")))
INNER JOIN "PUBLIC"."VTSUITE" "VTSUITECR"
    ON TRUE
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON TRUE
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON TRUE
WHERE ("VTST"."STARTID" = "VUPDT"."ID")
    AND (("VTST"."ORIGINALID" = "VTSUITECR"."ID")
    AND ("VTSUITECR"."STARTID" = "VCR"."ID"));           
CREATE FORCE VIEW "PUBLIC"."VTSUITEDTLS"("ID", "ORIGINALID", "STARTID", "ENDID", "BASELINE", "TYPE", "NAME", "UUID", "RULEPACKAGE", "DOCUMENTATION", "GRP", "PROJECT", "CREATEIOFILE", "DESCRIPTORFORMAT", "DESCRIPTORXML", "LASTTESTCASEUPLOADON", "REPORTNAME", "RUNBASELINE", "SERVERNAME", "ENABLED", "OPERATION", "CREATEDON", "CREATEDBY", "LASTCHANGEDON", "LASTCHANGEDBY") AS
SELECT
    "VTST"."ID",
    "VTST"."ORIGINALID",
    "VTST"."STARTID",
    "VTST"."ENDID",
    "VTST"."BASELINE",
    "VTST"."TYPE",
    "VTST"."NAME",
    "VTST"."UUID",
    "VTST"."RULEPACKAGE",
    "VTST"."DOCUMENTATION",
    "VTST"."GRP",
    "VTST"."PROJECT",
    "VTST"."CREATEIOFILE",
    "VTST"."DESCRIPTORFORMAT",
    "VTST"."DESCRIPTORXML",
    "VTST"."LASTTESTCASEUPLOADON",
    "VTST"."REPORTNAME",
    "VTST"."RUNBASELINE",
    "VTST"."SERVERNAME",
    "VTST"."ENABLED",
    "VTST"."OPERATION",
    "VCR"."VERSDATE" AS "CREATEDON",
    "VCR"."USERNAME" AS "CREATEDBY",
    "VUPDT"."VERSDATE" AS "LASTCHANGEDON",
    "VUPDT"."USERNAME" AS "LASTCHANGEDBY"
FROM "PUBLIC"."VTSUITE" "VTST"
INNER JOIN "PUBLIC"."VTSUITE" "VTSUITECR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VCR"
    ON 1=1
INNER JOIN "PUBLIC"."VERSION" "VUPDT"
    ON 1=1
WHERE ("VTST"."STARTID" = "VUPDT"."ID")
    AND (("VTST"."ORIGINALID" = "VTSUITECR"."ID")
    AND ("VTSUITECR"."STARTID" = "VCR"."ID"));  
DROP TABLE IF EXISTS SYSTEM_LOB_STREAM;        
CALL SYSTEM_COMBINE_BLOB(-1);  
DROP ALIAS IF EXISTS SYSTEM_COMBINE_CLOB;      
DROP ALIAS IF EXISTS SYSTEM_COMBINE_BLOB;      
ALTER TABLE "PUBLIC"."BOM" ADD CONSTRAINT "PUBLIC"."BOM_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;   
ALTER TABLE "PUBLIC"."SCOPEELEMENT" ADD CONSTRAINT "PUBLIC"."SCOPEELEMENT_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK; 
ALTER TABLE "PUBLIC"."PRJRESOURCE" ADD CONSTRAINT "PUBLIC"."PRJRESOURCE_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;   
ALTER TABLE "PUBLIC"."VSINPUTDATA" ADD CONSTRAINT "PUBLIC"."VSINPUTDATA_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;   
ALTER TABLE "PUBLIC"."RULEARTIFACT" ADD CONSTRAINT "PUBLIC"."RULEARTIFACT_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK; 
ALTER TABLE "PUBLIC"."VSMETRIC" ADD CONSTRAINT "PUBLIC"."VSMETRIC_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;         
ALTER TABLE "PUBLIC"."VARIABLESET" ADD CONSTRAINT "PUBLIC"."VARIABLESET_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;   
ALTER TABLE "PUBLIC"."VSCONFIG" ADD CONSTRAINT "PUBLIC"."VSCONFIG_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;         
ALTER TABLE "PUBLIC"."DEPTARGET" ADD CONSTRAINT "PUBLIC"."DEPTARGET_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;       
ALTER TABLE "PUBLIC"."INITIALVALUE" ADD CONSTRAINT "PUBLIC"."INITIALVALUE_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK; 
ALTER TABLE "PUBLIC"."DEPPROPERTYTAG" ADD CONSTRAINT "PUBLIC"."DEPPROPTAG_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK; 
ALTER TABLE "PUBLIC"."SCENARIOSUITE" ADD CONSTRAINT "PUBLIC"."SCSUITE_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;     
ALTER TABLE "PUBLIC"."BOM2XOMMAPPING" ADD CONSTRAINT "PUBLIC"."BOM2XOMMAPPING_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;             
ALTER TABLE "PUBLIC"."OPERATION" ADD CONSTRAINT "PUBLIC"."OPERATION_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;       
ALTER TABLE "PUBLIC"."RULEARTIFACTTAG" ADD CONSTRAINT "PUBLIC"."RULARTTAG_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK; 
ALTER TABLE "PUBLIC"."VOCABULARY" ADD CONSTRAINT "PUBLIC"."VOCABULARY_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;     
ALTER TABLE "PUBLIC"."ARGUMENT" ADD CONSTRAINT "PUBLIC"."ARGUMENT_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;         
ALTER TABLE "PUBLIC"."VTCASE" ADD CONSTRAINT "PUBLIC"."VTCASE_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;             
ALTER TABLE "PUBLIC"."DEPLOYMENT" ADD CONSTRAINT "PUBLIC"."DPLMNT_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;         
ALTER TABLE "PUBLIC"."DEPVERSIONPOLICY" ADD CONSTRAINT "PUBLIC"."DEPVERSPOLICY_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;            
ALTER TABLE "PUBLIC"."OPERATIONTAG" ADD CONSTRAINT "PUBLIC"."OPTAG_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;        
ALTER TABLE "PUBLIC"."DEPOPERATIONPROPERTY" ADD CONSTRAINT "PUBLIC"."DEPOPPROP_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;            
ALTER TABLE "PUBLIC"."SCENARIOSUITERESOURCE" ADD CONSTRAINT "PUBLIC"."SCSUITERS_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;           
ALTER TABLE "PUBLIC"."RULEFLOW" ADD CONSTRAINT "PUBLIC"."RULEFLOW_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;         
ALTER TABLE "PUBLIC"."EVENT" ADD CONSTRAINT "PUBLIC"."EVENT_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;               
ALTER TABLE "PUBLIC"."TEMPLATE" ADD CONSTRAINT "PUBLIC"."TEMPLATE_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;         
ALTER TABLE "PUBLIC"."RULEFLOWTAG" ADD CONSTRAINT "PUBLIC"."RULEFLOWTAG_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;   
ALTER TABLE "PUBLIC"."ABSTRACTQUERY" ADD CONSTRAINT "PUBLIC"."ABSTRACTQUERY_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;               
ALTER TABLE "PUBLIC"."DEPGROUP" ADD CONSTRAINT "PUBLIC"."DEPGROUP_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;         
ALTER TABLE "PUBLIC"."OVERRIDDENRULE" ADD CONSTRAINT "PUBLIC"."OVERRIDDENRULE_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;             
ALTER TABLE "PUBLIC"."VSKPI" ADD CONSTRAINT "PUBLIC"."VSKPI_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;               
ALTER TABLE "PUBLIC"."DEPOPERATION" ADD CONSTRAINT "PUBLIC"."DEPOP_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;        
ALTER TABLE "PUBLIC"."VTCRESOURCE" ADD CONSTRAINT "PUBLIC"."VTCRESOURCE_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;   
ALTER TABLE "PUBLIC"."OPERATIONVARIABLE" ADD CONSTRAINT "PUBLIC"."OPVARIABLE_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;              
ALTER TABLE "PUBLIC"."VSMODEL" ADD CONSTRAINT "PUBLIC"."VSMODEL_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;           
ALTER TABLE "PUBLIC"."RULEPACKAGE" ADD CONSTRAINT "PUBLIC"."RULEPACKAGE_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;   
ALTER TABLE "PUBLIC"."VTSUITE" ADD CONSTRAINT "PUBLIC"."VTSUITE_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;           
ALTER TABLE "PUBLIC"."VARIABLE" ADD CONSTRAINT "PUBLIC"."VARIABLE_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;         
ALTER TABLE "PUBLIC"."TASK" ADD CONSTRAINT "PUBLIC"."TASK_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK; 
ALTER TABLE "PUBLIC"."DEFINITION" ADD CONSTRAINT "PUBLIC"."DEFINITION_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;     
ALTER TABLE "PUBLIC"."DECISIONMODEL" ADD CONSTRAINT "PUBLIC"."DECISIONMODEL_CKENDIDSTARTID" CHECK("ENDID" >= "STARTID") NOCHECK;               
ALTER TABLE "PUBLIC"."ACTIVITYSUBSCRIPTION" ADD CONSTRAINT "PUBLIC"."ACMTSUBSCRUNIQUE" UNIQUE("USERNAME", "SRCBRANCH", "SRCPROJECT", "SRCRULE", "SOURCEARTIFACT", "SOURCEARTIFACTTYPE");       
ALTER TABLE "PUBLIC"."TEMPLATE" ADD CONSTRAINT "PUBLIC"."TEMPLATENAMEUNIQUE" UNIQUE("RULEPACKAGE", "BASELINE", "ENDID", "NAME");               
ALTER TABLE "PUBLIC"."ARGUMENT" ADD CONSTRAINT "PUBLIC"."ARGUMENTILRORDERUNIQUE" UNIQUE("ENDID", "CONTAINER", "ILRORDER", "BASELINE");         
ALTER TABLE "PUBLIC"."VARIABLESET" ADD CONSTRAINT "PUBLIC"."VARIABLESETNAMEUNIQUE" UNIQUE("RULEPACKAGE", "BASELINE", "ENDID", "NAME");         
ALTER TABLE "PUBLIC"."VSINPUTDATA" ADD CONSTRAINT "PUBLIC"."VSINPUTDATANAMEUNIQUE" UNIQUE("OPERATION", "BASELINE", "ENDID", "NAME");           
ALTER TABLE "PUBLIC"."RULEARTIFACT" ADD CONSTRAINT "PUBLIC"."RULEARTIFACTNAMEUNIQUE" UNIQUE("RULEPACKAGE", "BASELINE", "ENDID", "NAME");       
ALTER TABLE "PUBLIC"."VSKPI" ADD CONSTRAINT "PUBLIC"."VSKPINAMEUNIQUE" UNIQUE("OPERATION", "BASELINE", "ENDID", "NAME");       
ALTER TABLE "PUBLIC"."ABSTRACTQUERY" ADD CONSTRAINT "PUBLIC"."ABSTRACTQUERYNAMEUNIQUE" UNIQUE("RULEPACKAGE", "BASELINE", "ENDID", "NAME");     
ALTER TABLE "PUBLIC"."VSMODEL" ADD CONSTRAINT "PUBLIC"."VSMODELNAMEUNIQUE" UNIQUE("OPERATION", "BASELINE", "ENDID", "NAME");   
ALTER TABLE "PUBLIC"."SCENARIOSUITE" ADD CONSTRAINT "PUBLIC"."SCSUITENAMEUNIQUE" UNIQUE("RULEPACKAGE", "BASELINE", "ENDID", "NAME");           
ALTER TABLE "PUBLIC"."BOM2XOMMAPPING" ADD CONSTRAINT "PUBLIC"."BOM2XOMMAPPINGNAMEUNIQUE" UNIQUE("RULEPACKAGE", "BASELINE", "ENDID", "NAME");   
ALTER TABLE "PUBLIC"."VTCASE" ADD CONSTRAINT "PUBLIC"."VTCASENAMEUNIQUE" UNIQUE("OPERATION", "BASELINE", "ENDID", "NAME");     
ALTER TABLE "PUBLIC"."RULEPROJECT" ADD CONSTRAINT "PUBLIC"."RULEPROJECTNAMEUNIQUE" UNIQUE("NAME");             
ALTER TABLE "PUBLIC"."PRJRESOURCE" ADD CONSTRAINT "PUBLIC"."PRJRESOURCENAMEUNIQUE" UNIQUE("RULEPACKAGE", "BASELINE", "ENDID", "NAME", "EXTENSION");            
ALTER TABLE "PUBLIC"."EVENT" ADD CONSTRAINT "PUBLIC"."EVENTNAMEUNIQUE" UNIQUE("TYPE", "BASELINE", "ENDID", "NAME");            
ALTER TABLE "PUBLIC"."RULEAPP" ADD CONSTRAINT "PUBLIC"."RULEAPPNAMEUNIQUE" UNIQUE("NAME", "MAJOR", "MINOR");   
ALTER TABLE "PUBLIC"."VTSUITE" ADD CONSTRAINT "PUBLIC"."VTSUITENAMEUNIQUE" UNIQUE("OPERATION", "BASELINE", "ENDID", "NAME");   
ALTER TABLE "PUBLIC"."VOCABULARY" ADD CONSTRAINT "PUBLIC"."VOCABULARYNAMEUNIQUE" UNIQUE("RULEPACKAGE", "BASELINE", "ENDID", "NAME", "LOCALE"); 
ALTER TABLE "PUBLIC"."VSMETRIC" ADD CONSTRAINT "PUBLIC"."VSMETRICNAMEUNIQUE" UNIQUE("OPERATION", "BASELINE", "ENDID", "NAME"); 
ALTER TABLE "PUBLIC"."BOM" ADD CONSTRAINT "PUBLIC"."BOMNAMEUNIQUE" UNIQUE("RULEPACKAGE", "BASELINE", "ENDID", "NAME");         
ALTER TABLE "PUBLIC"."VSCONFIG" ADD CONSTRAINT "PUBLIC"."VSCONFIGNAMEUNIQUE" UNIQUE("OPERATION", "BASELINE", "ENDID", "NAME"); 
ALTER TABLE "PUBLIC"."BASELINE" ADD CONSTRAINT "PUBLIC"."BSLNNAMEUNIQUE" UNIQUE("NAME", "CONTAINER", "PARENT", "RULEAPP", "RULESET");          
ALTER TABLE "PUBLIC"."GROUPROLE" ADD CONSTRAINT "PUBLIC"."GROUPROLE_SECGRP" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."SECGRP"("ID") ON DELETE CASCADE NOCHECK;             
ALTER TABLE "PUBLIC"."BOM" ADD CONSTRAINT "PUBLIC"."BOM_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK; 
ALTER TABLE "PUBLIC"."VSMETRIC" ADD CONSTRAINT "PUBLIC"."VSMETRIC_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;       
ALTER TABLE "PUBLIC"."BASELINE" ADD CONSTRAINT "PUBLIC"."BSLN_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;    
ALTER TABLE "PUBLIC"."SCENARIOSUITERESOURCE" ADD CONSTRAINT "PUBLIC"."FKSCSUITERS_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;    
ALTER TABLE "PUBLIC"."OVERRIDDENRULE" ADD CONSTRAINT "PUBLIC"."FKOVERRIDDENRULE_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;  
ALTER TABLE "PUBLIC"."VTCRESOURCE" ADD CONSTRAINT "PUBLIC"."FKVTCRESOURCE_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."VTCRESOURCE" ADD CONSTRAINT "PUBLIC"."VTCRESOURCE_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."GROUPROLE" ADD CONSTRAINT "PUBLIC"."GROUPROLE_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;              
ALTER TABLE "PUBLIC"."SCOPEELEMENT" ADD CONSTRAINT "PUBLIC"."SCOPEELEMENT_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;           
ALTER TABLE "PUBLIC"."TEMPLATE" ADD CONSTRAINT "PUBLIC"."TEMPLATE_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;
ALTER TABLE "PUBLIC"."BSLNLFTRGT" ADD CONSTRAINT "PUBLIC"."BSLNLFTRGT_BSLN" FOREIGN KEY("ID") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;  
ALTER TABLE "PUBLIC"."VSREPORT" ADD CONSTRAINT "PUBLIC"."VSREPORT_REPORTSTATUSKIND" FOREIGN KEY("STATUS") REFERENCES "PUBLIC"."REPORTSTATUSKIND"("VALUE") NOCHECK;             
ALTER TABLE "PUBLIC"."VSCONFIG" ADD CONSTRAINT "PUBLIC"."VSCONFIG_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;
ALTER TABLE "PUBLIC"."DEPENDENCY" ADD CONSTRAINT "PUBLIC"."DEPENDENCY_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;            
ALTER TABLE "PUBLIC"."SERVER" ADD CONSTRAINT "PUBLIC"."SERVER_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;    
ALTER TABLE "PUBLIC"."SCENARIOTESTREPORT" ADD CONSTRAINT "PUBLIC"."SCTSTRPRT_SCENARIOSUITEREPORT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."SCENARIOSUITEREPORT"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."RULEARTIFACT" ADD CONSTRAINT "PUBLIC"."RULEARTIFACT_TEMPLATE" FOREIGN KEY("TEMPLATE") REFERENCES "PUBLIC"."TEMPLATE"("ID") ON DELETE CASCADE NOCHECK;    
ALTER TABLE "PUBLIC"."SCENARIOSUITERESOURCE" ADD CONSTRAINT "PUBLIC"."SCSUITERS_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;  
ALTER TABLE "PUBLIC"."ACTIVITYSUBSCRIPTION" ADD CONSTRAINT "PUBLIC"."ACMTSUBSCR_RULEARTIFACT" FOREIGN KEY("SRCRULE") REFERENCES "PUBLIC"."RULEARTIFACT"("ID") ON DELETE CASCADE NOCHECK;       
ALTER TABLE "PUBLIC"."TASK" ADD CONSTRAINT "PUBLIC"."TASK_EXITCRITERIAKIND" FOREIGN KEY("EXITCRITERIA") REFERENCES "PUBLIC"."EXITCRITERIAKIND"("VALUE") NOCHECK;               
ALTER TABLE "PUBLIC"."RULEPACKAGE" ADD CONSTRAINT "PUBLIC"."RULEPACKAGE_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."RPLFTRGT" ADD CONSTRAINT "PUBLIC"."RPLFTRGT_RULEPACKAGE" FOREIGN KEY("ID") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;            
ALTER TABLE "PUBLIC"."VARIABLESET" ADD CONSTRAINT "PUBLIC"."VARIABLESET_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK; 
ALTER TABLE "PUBLIC"."ABSTRACTQUERY" ADD CONSTRAINT "PUBLIC"."ABSTRACTQUERY_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;      
ALTER TABLE "PUBLIC"."RULEPROJECTTAG" ADD CONSTRAINT "PUBLIC"."RULEPRJTG_METAMODL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;          
ALTER TABLE "PUBLIC"."DEPOPERATIONPROPERTY" ADD CONSTRAINT "PUBLIC"."DEPOPPROP_OPERATION" FOREIGN KEY("OPERATIONREFERENCE") REFERENCES "PUBLIC"."OPERATION"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."ACTIVITYCOMMENTACCESS" ADD CONSTRAINT "PUBLIC"."ACMTACCES_ACOMMENT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."ACTIVITYCOMMENT"("ID") ON DELETE CASCADE NOCHECK;      
ALTER TABLE "PUBLIC"."VTCASE" ADD CONSTRAINT "PUBLIC"."VTCASE_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;  
ALTER TABLE "PUBLIC"."RULEARTIFACTTAG" ADD CONSTRAINT "PUBLIC"."RULARTTAG_RULEARTIFACT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."RULEARTIFACT"("ID") ON DELETE CASCADE NOCHECK;           
ALTER TABLE "PUBLIC"."VTREPORT" ADD CONSTRAINT "PUBLIC"."VTREPORT_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;
ALTER TABLE "PUBLIC"."SCENARIOSUITE" ADD CONSTRAINT "PUBLIC"."FKSCSUITE_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."TEMPLATE" ADD CONSTRAINT "PUBLIC"."TEMPLATE_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;       
ALTER TABLE "PUBLIC"."ACTIVITYCOMMENTATTACHMENT" ADD CONSTRAINT "PUBLIC"."ACMTATCHMT_ACOMMENT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."ACTIVITYCOMMENT"("ID") ON DELETE CASCADE NOCHECK; 
ALTER TABLE "PUBLIC"."TEMPLATE" ADD CONSTRAINT "PUBLIC"."FKTEMPLATE_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;  
ALTER TABLE "PUBLIC"."RULEFLOW" ADD CONSTRAINT "PUBLIC"."RULEFLOW_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;
ALTER TABLE "PUBLIC"."PRJRESOURCE" ADD CONSTRAINT "PUBLIC"."PRJRESOURCE_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."SCENARIOSUITERESOURCE" ADD CONSTRAINT "PUBLIC"."FKSCSUITERS_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;
ALTER TABLE "PUBLIC"."VSMODEL" ADD CONSTRAINT "PUBLIC"."FKVSMODEL_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;
ALTER TABLE "PUBLIC"."VSINPUTDATA" ADD CONSTRAINT "PUBLIC"."VSINPUTDATA_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;          
ALTER TABLE "PUBLIC"."RPLFTRGT" ADD CONSTRAINT "PUBLIC"."RPLFTRGT_BASELINE" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;            
ALTER TABLE "PUBLIC"."SERVER" ADD CONSTRAINT "PUBLIC"."SERVER_AUTHENTICATIONKIND" FOREIGN KEY("AUTHENTICATIONKIND") REFERENCES "PUBLIC"."AUTHENTICATIONKIND"("VALUE") NOCHECK; 
ALTER TABLE "PUBLIC"."BOMPATHENTRY" ADD CONSTRAINT "PUBLIC"."BOMPATHENTRY_BOM" FOREIGN KEY("BOM") REFERENCES "PUBLIC"."BOM"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."VSREPORT" ADD CONSTRAINT "PUBLIC"."VSREPORT_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."VTRTSINFO" ADD CONSTRAINT "PUBLIC"."VTRTSINFO_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;              
ALTER TABLE "PUBLIC"."EVENT" ADD CONSTRAINT "PUBLIC"."EVENT_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;             
ALTER TABLE "PUBLIC"."DSDEPLOYMENTREPORT" ADD CONSTRAINT "PUBLIC"."DSDEPLOYMENTREPORT_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."PRJRESOURCE" ADD CONSTRAINT "PUBLIC"."PRJRESOURCE_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK; 
ALTER TABLE "PUBLIC"."OPERATIONVARIABLE" ADD CONSTRAINT "PUBLIC"."FKOPVARIABLE_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;       
ALTER TABLE "PUBLIC"."RULESET" ADD CONSTRAINT "PUBLIC"."RULESET_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;  
ALTER TABLE "PUBLIC"."DEPLOYMENT" ADD CONSTRAINT "PUBLIC"."DPLMNT_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;
ALTER TABLE "PUBLIC"."VSINPUTDATA" ADD CONSTRAINT "PUBLIC"."FKVSINPUTDATA_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;            
ALTER TABLE "PUBLIC"."VERSION" ADD CONSTRAINT "PUBLIC"."VERSION_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;         
ALTER TABLE "PUBLIC"."VSMETRIC" ADD CONSTRAINT "PUBLIC"."VSMETRIC_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."VTSUITE" ADD CONSTRAINT "PUBLIC"."VTSUITE_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;
ALTER TABLE "PUBLIC"."RULEPACKAGE" ADD CONSTRAINT "PUBLIC"."FKRULEPACKAGE_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;            
ALTER TABLE "PUBLIC"."OPERATIONVARIABLE" ADD CONSTRAINT "PUBLIC"."OPVARIABLE_OPERATION" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."OPERATION"("ID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."DEPLOYMENT" ADD CONSTRAINT "PUBLIC"."DPLMNT_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;       
ALTER TABLE "PUBLIC"."VSMODEL" ADD CONSTRAINT "PUBLIC"."VSMODEL_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;  
ALTER TABLE "PUBLIC"."RULEPACKAGE" ADD CONSTRAINT "PUBLIC"."RULEPACKAGE_PARENT" FOREIGN KEY("PARENT") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;       
ALTER TABLE "PUBLIC"."DEFINITION" ADD CONSTRAINT "PUBLIC"."DEFINITION_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;            
ALTER TABLE "PUBLIC"."OPERATIONTAG" ADD CONSTRAINT "PUBLIC"."FKOPTAG_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK; 
ALTER TABLE "PUBLIC"."OPERATIONTAG" ADD CONSTRAINT "PUBLIC"."OPTAG_OPERATION" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."OPERATION"("ID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."VARIABLESET" ADD CONSTRAINT "PUBLIC"."VARIABLESET_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;          
ALTER TABLE "PUBLIC"."VARIABLESET" ADD CONSTRAINT "PUBLIC"."VARIABLESET_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."VSINPUTDATA" ADD CONSTRAINT "PUBLIC"."VSINPUTDATA_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;             
ALTER TABLE "PUBLIC"."BOM2XOMMAPPING" ADD CONSTRAINT "PUBLIC"."FKBOM2XOMMAPPING_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;  
ALTER TABLE "PUBLIC"."DECISIONMODEL" ADD CONSTRAINT "PUBLIC"."FKDECISIONMODEL_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."VTCASE" ADD CONSTRAINT "PUBLIC"."VTCASE_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;    
ALTER TABLE "PUBLIC"."BOM" ADD CONSTRAINT "PUBLIC"."BOM_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;          
ALTER TABLE "PUBLIC"."USERGROUP" ADD CONSTRAINT "PUBLIC"."USERGROUP_SECGRP" FOREIGN KEY("GRP") REFERENCES "PUBLIC"."SECGRP"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."SCENARIOTESTREPORT" ADD CONSTRAINT "PUBLIC"."SCTSTRPRT_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;     
ALTER TABLE "PUBLIC"."DEPOPERATIONPROPERTY" ADD CONSTRAINT "PUBLIC"."FKDEPOPPROP_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;     
ALTER TABLE "PUBLIC"."MERGEINFO" ADD CONSTRAINT "PUBLIC"."MERGEINFO_RMTBSLN" FOREIGN KEY("REMOTEBSLN") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;         
ALTER TABLE "PUBLIC"."ARGUMENT" ADD CONSTRAINT "PUBLIC"."ARGUMENT_RULEARTIFACT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."RULEARTIFACT"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."SCOPEELEMENT" ADD CONSTRAINT "PUBLIC"."SCOPEELEMENT_RULEARTIFACT" FOREIGN KEY("ILRRULE") REFERENCES "PUBLIC"."RULEARTIFACT"("ID") ON DELETE CASCADE NOCHECK;             
ALTER TABLE "PUBLIC"."TESTREPORT" ADD CONSTRAINT "PUBLIC"."TESTREPORT_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;            
ALTER TABLE "PUBLIC"."VOCABULARY" ADD CONSTRAINT "PUBLIC"."VOCABULARY_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;            
ALTER TABLE "PUBLIC"."RULEFLOW" ADD CONSTRAINT "PUBLIC"."RULEFLOW_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;
ALTER TABLE "PUBLIC"."VSKPI" ADD CONSTRAINT "PUBLIC"."VSKPI_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;      
ALTER TABLE "PUBLIC"."OPERATION" ADD CONSTRAINT "PUBLIC"."OPERATION_TARGETPRJ" FOREIGN KEY("TARGETRULEPROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;             
ALTER TABLE "PUBLIC"."DEPGROUP" ADD CONSTRAINT "PUBLIC"."DEPGROUP_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;
ALTER TABLE "PUBLIC"."DEPOPERATION" ADD CONSTRAINT "PUBLIC"."FKDEPOP_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK; 
ALTER TABLE "PUBLIC"."USR" ADD CONSTRAINT "PUBLIC"."USR_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;          
ALTER TABLE "PUBLIC"."VTSUITE" ADD CONSTRAINT "PUBLIC"."VTSUITE_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;         
ALTER TABLE "PUBLIC"."BOM2XOMMAPPING" ADD CONSTRAINT "PUBLIC"."FKBOM2XOMMAPPING_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;      
ALTER TABLE "PUBLIC"."DSDEPLOYMENTREPORT" ADD CONSTRAINT "PUBLIC"."DSDEPBSINREF" FOREIGN KEY("DEPLOYMENTSNAPSHOT") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;             
ALTER TABLE "PUBLIC"."DEPOPERATION" ADD CONSTRAINT "PUBLIC"."FKDEPOP_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;             
ALTER TABLE "PUBLIC"."ACTIVITYCOMMENT" ADD CONSTRAINT "PUBLIC"."ACOMMENT_PARENT" FOREIGN KEY("PARENT") REFERENCES "PUBLIC"."ACTIVITYCOMMENT"("ID") ON DELETE CASCADE NOCHECK;  
ALTER TABLE "PUBLIC"."ACTIVITYLOCK" ADD CONSTRAINT "PUBLIC"."ACTIVITYLOCK_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;        
ALTER TABLE "PUBLIC"."VSREPORT" ADD CONSTRAINT "PUBLIC"."REPORTSRBSLNREF" FOREIGN KEY("REPORTBASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."SCENARIOSUITERESOURCE" ADD CONSTRAINT "PUBLIC"."SCSUITERS_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;  
ALTER TABLE "PUBLIC"."SCENARIOSUITE" ADD CONSTRAINT "PUBLIC"."SCSUITE_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."DEPPROPERTYTAG" ADD CONSTRAINT "PUBLIC"."DEPPROPTAG_DPLMNT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."DEPLOYMENT"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."VSMODEL" ADD CONSTRAINT "PUBLIC"."FKVSMODEL_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;    
ALTER TABLE "PUBLIC"."TASK" ADD CONSTRAINT "PUBLIC"."TASK_ALGORITHMKIND" FOREIGN KEY("ALGORITHM") REFERENCES "PUBLIC"."ALGORITHMKIND"("VALUE") NOCHECK;        
ALTER TABLE "PUBLIC"."ARGUMENT" ADD CONSTRAINT "PUBLIC"."ARGUMENT_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;
ALTER TABLE "PUBLIC"."SYSTEMLOCK" ADD CONSTRAINT "PUBLIC"."SYSTEMLOCK_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;            
ALTER TABLE "PUBLIC"."DECISIONMODEL" ADD CONSTRAINT "PUBLIC"."DECISIONMODEL_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;      
ALTER TABLE "PUBLIC"."VOCABULARY" ADD CONSTRAINT "PUBLIC"."FKVOCABULARY_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."DEPPROPERTYTAG" ADD CONSTRAINT "PUBLIC"."FKDEPPROPTAG_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."ACTIVITYCOMMENT" ADD CONSTRAINT "PUBLIC"."BASELINEREF" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;           
ALTER TABLE "PUBLIC"."BOM2XOMMAPPING" ADD CONSTRAINT "PUBLIC"."BOM2XOMMAPPING_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;    
ALTER TABLE "PUBLIC"."ACTIVITYCOMMENT" ADD CONSTRAINT "PUBLIC"."ACOMMENT_BSLN" FOREIGN KEY("SOURCEBRANCH") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;     
ALTER TABLE "PUBLIC"."RULESETPROPERTY" ADD CONSTRAINT "PUBLIC"."RULESETPROPERTY_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;  
ALTER TABLE "PUBLIC"."DEPVERSIONPOLICY" ADD CONSTRAINT "PUBLIC"."DEPVERSPOLICY_DPLMNT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."DEPLOYMENT"("ID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."OPERATIONVARIABLE" ADD CONSTRAINT "PUBLIC"."OPVARIABLE_DIRECTIONKIND" FOREIGN KEY("DIRECTION") REFERENCES "PUBLIC"."DIRECTIONKIND"("VALUE") NOCHECK;     
ALTER TABLE "PUBLIC"."VSMODEL" ADD CONSTRAINT "PUBLIC"."VSMODEL_OPERATION" FOREIGN KEY("OPERATION") REFERENCES "PUBLIC"."OPERATION"("ID") ON DELETE CASCADE NOCHECK;           
ALTER TABLE "PUBLIC"."DEPENDENCY" ADD CONSTRAINT "PUBLIC"."DEPENDENCY_PROJECTINFO" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."PROJECTINFO"("ID") ON DELETE CASCADE NOCHECK; 
ALTER TABLE "PUBLIC"."PROJECTINFO" ADD CONSTRAINT "PUBLIC"."PROJECTINFO_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."RULEFLOWTAG" ADD CONSTRAINT "PUBLIC"."RULEFLOWTAG_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;          
ALTER TABLE "PUBLIC"."ABSTRACTQUERY" ADD CONSTRAINT "PUBLIC"."FKABSTRACTQUERY_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;    
ALTER TABLE "PUBLIC"."VSCONFIG" ADD CONSTRAINT "PUBLIC"."VSCONFIG_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;
ALTER TABLE "PUBLIC"."TASK" ADD CONSTRAINT "PUBLIC"."FKTASK_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."LVIPBRCH" ADD CONSTRAINT "PUBLIC"."PARENTBRCHFKNAME" FOREIGN KEY("PARENTBRCH") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;           
ALTER TABLE "PUBLIC"."OVERRIDDENRULE" ADD CONSTRAINT "PUBLIC"."OVERRIDDENRULE_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;    
ALTER TABLE "PUBLIC"."SCENARIOSUITEREPORT" ADD CONSTRAINT "PUBLIC"."SCENARIOSUITEREPORT_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK; 
ALTER TABLE "PUBLIC"."VTREPORT" ADD CONSTRAINT "PUBLIC"."VTREPORT_OPERATION" FOREIGN KEY("OPERATION") REFERENCES "PUBLIC"."OPERATION"("ID") ON DELETE CASCADE NOCHECK;         
ALTER TABLE "PUBLIC"."DEPLOYMENT" ADD CONSTRAINT "PUBLIC"."DPLMNT_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."DEPTARGET" ADD CONSTRAINT "PUBLIC"."DEPTARGET_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;              
ALTER TABLE "PUBLIC"."OPERATION" ADD CONSTRAINT "PUBLIC"."OPERATION_RULEFLOW" FOREIGN KEY("RULEFLOW") REFERENCES "PUBLIC"."RULEFLOW"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."DEPVERSIONPOLICY" ADD CONSTRAINT "PUBLIC"."FKDEPVERSPOLICY_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;     
ALTER TABLE "PUBLIC"."EXTRACTOR" ADD CONSTRAINT "PUBLIC"."EXTRACTOR_PROJECTINFO" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."PROJECTINFO"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."DEPLOYMENT" ADD CONSTRAINT "PUBLIC"."DPLMNT_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."VSMODEL" ADD CONSTRAINT "PUBLIC"."VSMODEL_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;
ALTER TABLE "PUBLIC"."DEPOPERATION" ADD CONSTRAINT "PUBLIC"."DEPOP_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;               
ALTER TABLE "PUBLIC"."OPERATION" ADD CONSTRAINT "PUBLIC"."OPERATION_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;            
ALTER TABLE "PUBLIC"."DEPLOYMENT" ADD CONSTRAINT "PUBLIC"."DPLMNT_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;
ALTER TABLE "PUBLIC"."RULEFLOWTAG" ADD CONSTRAINT "PUBLIC"."FKRULEFLOWTAG_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;            
ALTER TABLE "PUBLIC"."RULEARTIFACT" ADD CONSTRAINT "PUBLIC"."FKRULEARTIFACT_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;      
ALTER TABLE "PUBLIC"."DEPPROPERTYTAG" ADD CONSTRAINT "PUBLIC"."DEPPROPTAG_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;        
ALTER TABLE "PUBLIC"."VTCASE" ADD CONSTRAINT "PUBLIC"."VTCASE_OPERATION" FOREIGN KEY("OPERATION") REFERENCES "PUBLIC"."OPERATION"("ID") ON DELETE CASCADE NOCHECK;             
ALTER TABLE "PUBLIC"."VSCONFIG" ADD CONSTRAINT "PUBLIC"."VSCONFIG_SERVER" FOREIGN KEY("SERVER") REFERENCES "PUBLIC"."SERVER"("ID") ON DELETE CASCADE NOCHECK;  
ALTER TABLE "PUBLIC"."ACTIVITYCOMMENT" ADD CONSTRAINT "PUBLIC"."ACOMMENT_RULEARTIFACT" FOREIGN KEY("SOURCERULEARTIFACT") REFERENCES "PUBLIC"."RULEARTIFACT"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."DEPLOYMENT" ADD CONSTRAINT "PUBLIC"."DPLMNT_SNAPSHOTCREATIONKIND" FOREIGN KEY("SNAPSHOTCREATION") REFERENCES "PUBLIC"."SNAPSHOTCREATIONKIND"("VALUE") NOCHECK;           
ALTER TABLE "PUBLIC"."OVERRIDDENRULE" ADD CONSTRAINT "PUBLIC"."FKOVERRIDDENRULE_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;      
ALTER TABLE "PUBLIC"."BRSTUDIO" ADD CONSTRAINT "PUBLIC"."BRSTUDIO_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;       
ALTER TABLE "PUBLIC"."VSMETRIC" ADD CONSTRAINT "PUBLIC"."VSMETRIC_METRICKIND" FOREIGN KEY("METRICTYPE") REFERENCES "PUBLIC"."METRICKIND"("VALUE") NOCHECK;     
ALTER TABLE "PUBLIC"."VERSION" ADD CONSTRAINT "PUBLIC"."VERSION_BASELINE" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."VTREPORT" ADD CONSTRAINT "PUBLIC"."VTREPORT_SERVERKIND" FOREIGN KEY("SERVERKIND") REFERENCES "PUBLIC"."SERVERKIND"("VALUE") NOCHECK;     
ALTER TABLE "PUBLIC"."LVIPBRCH" ADD CONSTRAINT "PUBLIC"."LVIPBRCH_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;
ALTER TABLE "PUBLIC"."VSCONFIG" ADD CONSTRAINT "PUBLIC"."VSCONFIG_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;       
ALTER TABLE "PUBLIC"."EVENT" ADD CONSTRAINT "PUBLIC"."EVENT_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;    
ALTER TABLE "PUBLIC"."LOCKTBL" ADD CONSTRAINT "PUBLIC"."LOCKTBL_BSLN" FOREIGN KEY("BRANCH") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;    
ALTER TABLE "PUBLIC"."EVENT" ADD CONSTRAINT "PUBLIC"."EVENT_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;      
ALTER TABLE "PUBLIC"."RULEPROJECTTAG" ADD CONSTRAINT "PUBLIC"."RLPRJTAG_PROJECTINFO" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."PROJECTINFO"("ID") ON DELETE CASCADE NOCHECK;               
ALTER TABLE "PUBLIC"."VTREPORT" ADD CONSTRAINT "PUBLIC"."ORIGINALTRBSLNREF" FOREIGN KEY("ORIGINALBASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;    
ALTER TABLE "PUBLIC"."DEPOPERATIONPROPERTY" ADD CONSTRAINT "PUBLIC"."DEPOPPROP_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."DEPOPERATIONPROPERTY" ADD CONSTRAINT "PUBLIC"."FKDEPOPPROP_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK; 
ALTER TABLE "PUBLIC"."VSCONFIG" ADD CONSTRAINT "PUBLIC"."VSCONFIG_VSMODEL" FOREIGN KEY("SIMULATIONMODEL") REFERENCES "PUBLIC"."VSMODEL"("ID") ON DELETE CASCADE NOCHECK;       
ALTER TABLE "PUBLIC"."SCENARIOSUITEREPORT" ADD CONSTRAINT "PUBLIC"."SCENARIOSUITEREPORT_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;          
ALTER TABLE "PUBLIC"."VARIABLE" ADD CONSTRAINT "PUBLIC"."VARIABLE_VARIABLESET" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."VARIABLESET"("ID") ON DELETE CASCADE NOCHECK;     
ALTER TABLE "PUBLIC"."BOM2XOMMAPPING" ADD CONSTRAINT "PUBLIC"."BOM2XOMMAPPING_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;  
ALTER TABLE "PUBLIC"."OPERATION" ADD CONSTRAINT "PUBLIC"."FKOPERATION_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;
ALTER TABLE "PUBLIC"."RULEARTIFACT" ADD CONSTRAINT "PUBLIC"."RULEARTIFACT_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;           
ALTER TABLE "PUBLIC"."DSDEPLOYMENTREPORT" ADD CONSTRAINT "PUBLIC"."DSDEPLOYMENTREPORT_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;            
ALTER TABLE "PUBLIC"."VSREPORT" ADD CONSTRAINT "PUBLIC"."VSREPORT_VSCONFIG" FOREIGN KEY("SIMULATIONCONFIGURATION") REFERENCES "PUBLIC"."VSCONFIG"("ID") ON DELETE CASCADE NOCHECK;             
ALTER TABLE "PUBLIC"."DEFINITION" ADD CONSTRAINT "PUBLIC"."FKDEFINITION_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."ARGUMENT" ADD CONSTRAINT "PUBLIC"."FKARGUMENT_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;  
ALTER TABLE "PUBLIC"."OPERATION" ADD CONSTRAINT "PUBLIC"."FKOPERATION_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;            
ALTER TABLE "PUBLIC"."PROXY" ADD CONSTRAINT "PUBLIC"."PROXY_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;      
ALTER TABLE "PUBLIC"."OPERATIONTAG" ADD CONSTRAINT "PUBLIC"."FKOPTAG_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;             
ALTER TABLE "PUBLIC"."OVERRIDDENRULE" ADD CONSTRAINT "PUBLIC"."OVERRIDDENRULE_RULEARTIFACT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."RULEARTIFACT"("ID") ON DELETE CASCADE NOCHECK;       
ALTER TABLE "PUBLIC"."USERGROUP" ADD CONSTRAINT "PUBLIC"."USERGROUP_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;              
ALTER TABLE "PUBLIC"."TASK" ADD CONSTRAINT "PUBLIC"."TASK_ORDERINGKIND" FOREIGN KEY("ORDERING") REFERENCES "PUBLIC"."ORDERINGKIND"("VALUE") NOCHECK;           
ALTER TABLE "PUBLIC"."RULEARTIFACTSIBLING" ADD CONSTRAINT "PUBLIC"."FKRULEARTIFACT" FOREIGN KEY("ID") REFERENCES "PUBLIC"."RULEARTIFACT"("ID") ON DELETE CASCADE NOCHECK;      
ALTER TABLE "PUBLIC"."RTSSCHEMA" ADD CONSTRAINT "PUBLIC"."RTSSCHEMA_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;              
ALTER TABLE "PUBLIC"."DEPLOYMENTERROR" ADD CONSTRAINT "PUBLIC"."DEPLOYMENTERROR_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;  
ALTER TABLE "PUBLIC"."PARAMETER" ADD CONSTRAINT "PUBLIC"."PARAMETER_PROJECTINFO" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."PROJECTINFO"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."SCENARIOSUITE" ADD CONSTRAINT "PUBLIC"."SCSUITE_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;            
ALTER TABLE "PUBLIC"."GROUPUSER" ADD CONSTRAINT "PUBLIC"."GROUPUSER_SECGRP" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."SECGRP"("ID") ON DELETE CASCADE NOCHECK;             
ALTER TABLE "PUBLIC"."RULEPACKAGE" ADD CONSTRAINT "PUBLIC"."PACKAGEKINDREF" FOREIGN KEY("PACKAGEKIND") REFERENCES "PUBLIC"."PACKAGEKIND"("VALUE") NOCHECK;     
ALTER TABLE "PUBLIC"."DEPGROUP" ADD CONSTRAINT "PUBLIC"."DEPGROUP_DPLMNT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."DEPLOYMENT"("ID") ON DELETE CASCADE NOCHECK;           
ALTER TABLE "PUBLIC"."OPERATIONLATESTDEPLOYEDVERSION" ADD CONSTRAINT "PUBLIC"."OPLATESTV_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;         
ALTER TABLE "PUBLIC"."OPERATIONVARIABLE" ADD CONSTRAINT "PUBLIC"."OPVARIABLE_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;     
ALTER TABLE "PUBLIC"."OPERATIONTAG" ADD CONSTRAINT "PUBLIC"."OPTAG_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;               
ALTER TABLE "PUBLIC"."VARIABLE" ADD CONSTRAINT "PUBLIC"."FKVARIABLE_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."VTCRESOURCE" ADD CONSTRAINT "PUBLIC"."FKVTCRESOURCE_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;            
ALTER TABLE "PUBLIC"."DEPTARGET" ADD CONSTRAINT "PUBLIC"."DEPTARGET_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."RULEFLOWSIBLING" ADD CONSTRAINT "PUBLIC"."FKRULEFLOW" FOREIGN KEY("ID") REFERENCES "PUBLIC"."RULEFLOW"("ID") ON DELETE CASCADE NOCHECK;  
ALTER TABLE "PUBLIC"."VARIABLESET" ADD CONSTRAINT "PUBLIC"."VARIABLESET_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."VOCABULARY" ADD CONSTRAINT "PUBLIC"."FKVOCABULARY_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."GROUPUSER" ADD CONSTRAINT "PUBLIC"."GROUPUSER_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;              
ALTER TABLE "PUBLIC"."SCENARIOSUITEKPIREPORT" ADD CONSTRAINT "PUBLIC"."SCSUITEKPIRPRT_SCENARIOSUITEREPORT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."SCENARIOSUITEREPORT"("ID") ON DELETE CASCADE NOCHECK; 
ALTER TABLE "PUBLIC"."ACTIVITYSUBSCRIPTION" ADD CONSTRAINT "PUBLIC"."ACMTSUBSCR_BSLN" FOREIGN KEY("SRCBRANCH") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK; 
ALTER TABLE "PUBLIC"."DECISIONMODEL" ADD CONSTRAINT "PUBLIC"."DECISIONMODEL_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;    
ALTER TABLE "PUBLIC"."LVIPBRCH" ADD CONSTRAINT "PUBLIC"."LVIPBRCH_VERSION" FOREIGN KEY("VERSION") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;               
ALTER TABLE "PUBLIC"."ARGUMENT" ADD CONSTRAINT "PUBLIC"."FKARGUMENT_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."RULEARTIFACT" ADD CONSTRAINT "PUBLIC"."RULEARTIFACT_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."ACTIVITYLOCK" ADD CONSTRAINT "PUBLIC"."OWNERCA" FOREIGN KEY("OWNER") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;     
ALTER TABLE "PUBLIC"."TASK" ADD CONSTRAINT "PUBLIC"."FKTASK_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;      
ALTER TABLE "PUBLIC"."VSCONFIG" ADD CONSTRAINT "PUBLIC"."FKVSCONFIG_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;  
ALTER TABLE "PUBLIC"."TASK" ADD CONSTRAINT "PUBLIC"."TASK_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;        
ALTER TABLE "PUBLIC"."VOCABULARY" ADD CONSTRAINT "PUBLIC"."VOCABULARY_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."BOMPATHENTRY" ADD CONSTRAINT "PUBLIC"."BOMPATHENTRY_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;        
ALTER TABLE "PUBLIC"."VSKPI" ADD CONSTRAINT "PUBLIC"."FKVSKPI_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;    
ALTER TABLE "PUBLIC"."MESSAGEMAP" ADD CONSTRAINT "PUBLIC"."MESSAGEMAP_PROJECTINFO" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."PROJECTINFO"("ID") ON DELETE CASCADE NOCHECK; 
ALTER TABLE "PUBLIC"."VTCASE" ADD CONSTRAINT "PUBLIC"."VTCASE_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;    
ALTER TABLE "PUBLIC"."OPERATIONVARIABLE" ADD CONSTRAINT "PUBLIC"."OPVARIABLE_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;     
ALTER TABLE "PUBLIC"."BOM" ADD CONSTRAINT "PUBLIC"."FKBOM_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;            
ALTER TABLE "PUBLIC"."VOCABULARY" ADD CONSTRAINT "PUBLIC"."VOCABULARY_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."CONNECTIONENTRY" ADD CONSTRAINT "PUBLIC"."CONNECTIONENTRY_RULEPROJECT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;       
ALTER TABLE "PUBLIC"."DSDEPLOYMENTREPORT" ADD CONSTRAINT "PUBLIC"."DSDEPLOYMENTREPORT_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."EXTRACTOR" ADD CONSTRAINT "PUBLIC"."EXTRACTOR_ABSTRACTQUERY" FOREIGN KEY("QUERY") REFERENCES "PUBLIC"."ABSTRACTQUERY"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."DEPVERSIONPOLICY" ADD CONSTRAINT "PUBLIC"."DEPVERSPOLICY_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;   
ALTER TABLE "PUBLIC"."MERGEDTLS" ADD CONSTRAINT "PUBLIC"."MERGEDTLS_MERGEINFO" FOREIGN KEY("LOCALBSLN", "REMOTEBSLN") REFERENCES "PUBLIC"."MERGEINFO"("LOCALBSLN", "REMOTEBSLN") ON DELETE CASCADE NOCHECK;    
ALTER TABLE "PUBLIC"."ACTIVITYCOMMENTLINK" ADD CONSTRAINT "PUBLIC"."ACMTLINK_ACOMMENT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."ACTIVITYCOMMENT"("ID") ON DELETE CASCADE NOCHECK;         
ALTER TABLE "PUBLIC"."SCOPEELEMENT" ADD CONSTRAINT "PUBLIC"."SCOPEELEMENT_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."OPERATIONNEWDEPLOYEDVERSION" ADD CONSTRAINT "PUBLIC"."OPNEWV_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;               
ALTER TABLE "PUBLIC"."EXTRACTOR" ADD CONSTRAINT "PUBLIC"."EXTRACTOR_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;              
ALTER TABLE "PUBLIC"."SECGRP" ADD CONSTRAINT "PUBLIC"."SECGRP_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;    
ALTER TABLE "PUBLIC"."BOM2XOMMAPPING" ADD CONSTRAINT "PUBLIC"."BOM2XOMMAPPING_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;       
ALTER TABLE "PUBLIC"."SCOPEELEMENT" ADD CONSTRAINT "PUBLIC"."FKSCOPEELEMENT_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."RTSSCHEMA" ADD CONSTRAINT "PUBLIC"."RTSSCHEMA_PROJECTINFO" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."PROJECTINFO"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."VTREPORT" ADD CONSTRAINT "PUBLIC"."REPORTTRBSLNREF" FOREIGN KEY("REPORTBASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."VSREPORT" ADD CONSTRAINT "PUBLIC"."VSREPORT_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."VSMETRIC" ADD CONSTRAINT "PUBLIC"."FKVSMETRIC_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."OPERATION" ADD CONSTRAINT "PUBLIC"."OPERATION_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK; 
ALTER TABLE "PUBLIC"."PRJRESOURCE" ADD CONSTRAINT "PUBLIC"."FKPRJRESOURCE_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."EVENTSIBLING" ADD CONSTRAINT "PUBLIC"."FKEVENT" FOREIGN KEY("ID") REFERENCES "PUBLIC"."EVENT"("ID") ON DELETE CASCADE NOCHECK;           
ALTER TABLE "PUBLIC"."GROUPUSER" ADD CONSTRAINT "PUBLIC"."GROUPUSER_USR" FOREIGN KEY("MEMBER") REFERENCES "PUBLIC"."USR"("ID") ON DELETE CASCADE NOCHECK;      
ALTER TABLE "PUBLIC"."TEMPLATE" ADD CONSTRAINT "PUBLIC"."FKTEMPLATE_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."DEPLOYMENT" ADD CONSTRAINT "PUBLIC"."FKDPLMNT_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;  
ALTER TABLE "PUBLIC"."VTREPORT" ADD CONSTRAINT "PUBLIC"."VTREPORT_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."OPERATIONNEWDEPLOYEDVERSION" ADD CONSTRAINT "PUBLIC"."OPNEWV_DSDEPLOYMENTREPORT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."DSDEPLOYMENTREPORT"("ID") ON DELETE CASCADE NOCHECK;      
ALTER TABLE "PUBLIC"."RULEARTIFACTTAG" ADD CONSTRAINT "PUBLIC"."FKRULARTTAG_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;      
ALTER TABLE "PUBLIC"."SCENARIOSUITE" ADD CONSTRAINT "PUBLIC"."SCSUITE_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;            
ALTER TABLE "PUBLIC"."VARIABLE" ADD CONSTRAINT "PUBLIC"."VARIABLE_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;
ALTER TABLE "PUBLIC"."LOCKTBL" ADD CONSTRAINT "PUBLIC"."LOCKELTTYPE" FOREIGN KEY("ELEMENTTYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK; 
ALTER TABLE "PUBLIC"."SCENARIOSUITE" ADD CONSTRAINT "PUBLIC"."FKSCSUITE_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."VTCASE" ADD CONSTRAINT "PUBLIC"."ORIGINALTCBSLNREF" FOREIGN KEY("ORIGINALBASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;      
ALTER TABLE "PUBLIC"."VTCRESOURCE" ADD CONSTRAINT "PUBLIC"."VTCRESOURCE_VTSUITE" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."VTSUITE"("ID") ON DELETE CASCADE NOCHECK;       
ALTER TABLE "PUBLIC"."INITIALVALUE" ADD CONSTRAINT "PUBLIC"."INITIALVALUE_TEMPLATE" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."TEMPLATE"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."VTCASE" ADD CONSTRAINT "PUBLIC"."FKVTCASE_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;  
ALTER TABLE "PUBLIC"."ACTIVITYSUBSCRIPTION" ADD CONSTRAINT "PUBLIC"."ACMTSUBSCR_RULEPROJECT" FOREIGN KEY("SRCPROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;      
ALTER TABLE "PUBLIC"."RULEARTIFACTTAG" ADD CONSTRAINT "PUBLIC"."RULARTTAG_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."VSKPI" ADD CONSTRAINT "PUBLIC"."FKVSKPI_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."DEPOPERATION" ADD CONSTRAINT "PUBLIC"."DEPOP_OPERATION" FOREIGN KEY("OPERATION") REFERENCES "PUBLIC"."OPERATION"("ID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."VARIABLE" ADD CONSTRAINT "PUBLIC"."VARIABLE_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;
ALTER TABLE "PUBLIC"."VTCASE" ADD CONSTRAINT "PUBLIC"."FKVTCASE_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;      
ALTER TABLE "PUBLIC"."DECISIONMODELSIBLING" ADD CONSTRAINT "PUBLIC"."FKDECISIONMODEL" FOREIGN KEY("ID") REFERENCES "PUBLIC"."DECISIONMODEL"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."VTSUITE" ADD CONSTRAINT "PUBLIC"."RUNTSBSLNREF" FOREIGN KEY("RUNBASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;               
ALTER TABLE "PUBLIC"."DECISIONMODEL" ADD CONSTRAINT "PUBLIC"."DECISIONMODEL_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;         
ALTER TABLE "PUBLIC"."DECISIONMODEL" ADD CONSTRAINT "PUBLIC"."DECISIONMODEL_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;      
ALTER TABLE "PUBLIC"."VTCASE" ADD CONSTRAINT "PUBLIC"."VTCASE_VTCRESOURCE" FOREIGN KEY("TESTCASERESOURCE") REFERENCES "PUBLIC"."VTCRESOURCE"("ID") ON DELETE CASCADE NOCHECK;  
ALTER TABLE "PUBLIC"."ARGUMENT" ADD CONSTRAINT "PUBLIC"."ARGUMENT_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;
ALTER TABLE "PUBLIC"."VOCABULARY" ADD CONSTRAINT "PUBLIC"."VOCABULARY_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;               
ALTER TABLE "PUBLIC"."BOM" ADD CONSTRAINT "PUBLIC"."FKBOM_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."VTRTSINFO" ADD CONSTRAINT "PUBLIC"."VTRTSINFO_VTREPORT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."VTREPORT"("ID") ON DELETE CASCADE NOCHECK;         
ALTER TABLE "PUBLIC"."DSDEPLOYMENTREPORT" ADD CONSTRAINT "PUBLIC"."ORIGINALDRBSINREF" FOREIGN KEY("ORIGINALBASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."RULEARTIFACTSIBLING" ADD CONSTRAINT "PUBLIC"."RULEARTIFACT_STATUS" FOREIGN KEY("STATUS") REFERENCES "PUBLIC"."STATUS"("VALUE") NOCHECK;  
ALTER TABLE "PUBLIC"."RULEFLOWTAG" ADD CONSTRAINT "PUBLIC"."FKRULEFLOWTAG_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."SCOPEELEMENT" ADD CONSTRAINT "PUBLIC"."SCOPEELEMENT_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;        
ALTER TABLE "PUBLIC"."DEFINITION" ADD CONSTRAINT "PUBLIC"."FKDEFINITION_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."VSKPI" ADD CONSTRAINT "PUBLIC"."VSKPI_OPERATION" FOREIGN KEY("OPERATION") REFERENCES "PUBLIC"."OPERATION"("ID") ON DELETE CASCADE NOCHECK;               
ALTER TABLE "PUBLIC"."TESTREPORT" ADD CONSTRAINT "PUBLIC"."TESTREPORT_SCENARIOSUITEREPORT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."SCENARIOSUITEREPORT"("ID") ON DELETE CASCADE NOCHECK; 
ALTER TABLE "PUBLIC"."MERGEREPORT" ADD CONSTRAINT "PUBLIC"."MERGEREPORT_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK; 
ALTER TABLE "PUBLIC"."TEMPLATE" ADD CONSTRAINT "PUBLIC"."TEMPLATE_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;
ALTER TABLE "PUBLIC"."RULEARTIFACTTAG" ADD CONSTRAINT "PUBLIC"."FKRULARTTAG_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."OPERATIONLATESTDEPLOYEDVERSION" ADD CONSTRAINT "PUBLIC"."OPLATESTV_DSDEPLOYMENTREPORT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."DSDEPLOYMENTREPORT"("ID") ON DELETE CASCADE NOCHECK;
ALTER TABLE "PUBLIC"."VSMODEL" ADD CONSTRAINT "PUBLIC"."VSMODEL_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;     
ALTER TABLE "PUBLIC"."VTCRESOURCE" ADD CONSTRAINT "PUBLIC"."VTCRESOURCE_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;          
ALTER TABLE "PUBLIC"."LOCKTBL" ADD CONSTRAINT "PUBLIC"."LOCKTBL_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;  
ALTER TABLE "PUBLIC"."DEPLOYMENTERROR" ADD CONSTRAINT "PUBLIC"."DEPLOYMENTERROR_DSDEPLOYMENTREPORT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."DSDEPLOYMENTREPORT"("ID") ON DELETE CASCADE NOCHECK;         
ALTER TABLE "PUBLIC"."VERSION" ADD CONSTRAINT "PUBLIC"."VERSION_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;  
ALTER TABLE "PUBLIC"."ACTIVITYCOMMENTACCESS" ADD CONSTRAINT "PUBLIC"."ACMTACCES_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;  
ALTER TABLE "PUBLIC"."RULEAPPPROPERTY" ADD CONSTRAINT "PUBLIC"."RULEAPPPROPERTY_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;  
ALTER TABLE "PUBLIC"."TASK" ADD CONSTRAINT "PUBLIC"."TASK_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."SECGRP" ADD CONSTRAINT "PUBLIC"."SECGRP_SECURITYPROFILEKIND" FOREIGN KEY("SECURITYPROFILE") REFERENCES "PUBLIC"."SECURITYPROFILEKIND"("VALUE") NOCHECK;  
ALTER TABLE "PUBLIC"."VSREPORT" ADD CONSTRAINT "PUBLIC"."VSREPORT_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;
ALTER TABLE "PUBLIC"."RULEPROJECT" ADD CONSTRAINT "PUBLIC"."RULEPROJECT_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;          
ALTER TABLE "PUBLIC"."ABSTRACTQUERY" ADD CONSTRAINT "PUBLIC"."FKABSTRACTQUERY_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."MESSAGEMAP" ADD CONSTRAINT "PUBLIC"."MESSAGEMAP_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;            
ALTER TABLE "PUBLIC"."DEPPROPERTYTAG" ADD CONSTRAINT "PUBLIC"."DEPPROPTAG_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."VTSUITE" ADD CONSTRAINT "PUBLIC"."FKVTSUITE_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;    
ALTER TABLE "PUBLIC"."OVERRIDDENRULE" ADD CONSTRAINT "PUBLIC"."OVERRIDDENRULE_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;    
ALTER TABLE "PUBLIC"."DECISIONMODEL" ADD CONSTRAINT "PUBLIC"."FKDECISIONMODEL_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;    
ALTER TABLE "PUBLIC"."DEFINITION" ADD CONSTRAINT "PUBLIC"."DEFINITION_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;            
ALTER TABLE "PUBLIC"."VSMETRIC" ADD CONSTRAINT "PUBLIC"."VSMETRIC_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;
ALTER TABLE "PUBLIC"."INITIALVALUE" ADD CONSTRAINT "PUBLIC"."INITIALVALUE_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;        
ALTER TABLE "PUBLIC"."MERGEREPORT" ADD CONSTRAINT "PUBLIC"."MERGEREPORT_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;          
ALTER TABLE "PUBLIC"."SERVER" ADD CONSTRAINT "PUBLIC"."SERVER_SERVERKIND" FOREIGN KEY("SERVERKIND") REFERENCES "PUBLIC"."SERVERKIND"("VALUE") NOCHECK;         
ALTER TABLE "PUBLIC"."DEPVERSIONPOLICY" ADD CONSTRAINT "PUBLIC"."RULEAPPDEPVERS" FOREIGN KEY("RULEAPP") REFERENCES "PUBLIC"."DEPLOYMENTVERSIONNINGKIND"("VALUE") NOCHECK;      
ALTER TABLE "PUBLIC"."RULEARTIFACT" ADD CONSTRAINT "PUBLIC"."FKRULEARTIFACT_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."CONNECTIONENTRY" ADD CONSTRAINT "PUBLIC"."CONNECTIONENTRY_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;  
ALTER TABLE "PUBLIC"."PRJRESOURCE" ADD CONSTRAINT "PUBLIC"."FKPRJRESOURCE_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;            
ALTER TABLE "PUBLIC"."ACTIVITYCOMMENTLINK" ADD CONSTRAINT "PUBLIC"."ACMTLINK_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;     
ALTER TABLE "PUBLIC"."RULEPACKAGE" ADD CONSTRAINT "PUBLIC"."RULEPACKAGE_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."VSINPUTDATA" ADD CONSTRAINT "PUBLIC"."VSINPUTDATA_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK; 
ALTER TABLE "PUBLIC"."EVENT" ADD CONSTRAINT "PUBLIC"."FKEVENT_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."ACTIVITYCOMMENT" ADD CONSTRAINT "PUBLIC"."ACOMMENT_UPDATETYPEKIND" FOREIGN KEY("UPDATETYPE") REFERENCES "PUBLIC"."UPDATETYPEKIND"("VALUE") NOCHECK;      
ALTER TABLE "PUBLIC"."VTSUITE" ADD CONSTRAINT "PUBLIC"."VTSUITE_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;  
ALTER TABLE "PUBLIC"."SCENARIOSUITE" ADD CONSTRAINT "PUBLIC"."SCSUITE_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."DECISIONMODEL" ADD CONSTRAINT "PUBLIC"."DECISIONMODEL_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;             
ALTER TABLE "PUBLIC"."VTREPORT" ADD CONSTRAINT "PUBLIC"."VTREPORT_REPORTSTATUSKIND" FOREIGN KEY("STATUS") REFERENCES "PUBLIC"."REPORTSTATUSKIND"("VALUE") NOCHECK;             
ALTER TABLE "PUBLIC"."PARAMETER" ADD CONSTRAINT "PUBLIC"."PARAMETER_DIRECTIONKIND" FOREIGN KEY("DIRECTION") REFERENCES "PUBLIC"."DIRECTIONKIND"("VALUE") NOCHECK;              
ALTER TABLE "PUBLIC"."RULESET" ADD CONSTRAINT "PUBLIC"."RULESET_RULEAPP" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."RULEAPP"("ID") ON DELETE CASCADE NOCHECK;               
ALTER TABLE "PUBLIC"."VSCONFIG" ADD CONSTRAINT "PUBLIC"."VSCONFIG_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."ACTIVITYCOMMENT" ADD CONSTRAINT "PUBLIC"."ACOMMENT_RULEPROJECT" FOREIGN KEY("SOURCERULEPROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;      
ALTER TABLE "PUBLIC"."VSCONFIG" ADD CONSTRAINT "PUBLIC"."VSCONFIG_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."SECURITYROLE" ADD CONSTRAINT "PUBLIC"."SECURITYROLE_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;        
ALTER TABLE "PUBLIC"."ACTIVITYLOCK" ADD CONSTRAINT "PUBLIC"."ACTIVITYLOCK_BSLN" FOREIGN KEY("BRANCH") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."INITIALVALUE" ADD CONSTRAINT "PUBLIC"."INITIALVALUE_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."RULEARTIFACT" ADD CONSTRAINT "PUBLIC"."RULEARTIFACT_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;               
ALTER TABLE "PUBLIC"."PRJRESOURCE" ADD CONSTRAINT "PUBLIC"."PRJRESOURCE_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."ABSTRACTQUERY" ADD CONSTRAINT "PUBLIC"."ABSTRACTQUERY_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;         
ALTER TABLE "PUBLIC"."PARAMETER" ADD CONSTRAINT "PUBLIC"."PARAMETER_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;              
ALTER TABLE "PUBLIC"."RULEPACKAGESIBLING" ADD CONSTRAINT "PUBLIC"."FKRULEPACKAGE" FOREIGN KEY("ID") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;         
ALTER TABLE "PUBLIC"."VARIABLESET" ADD CONSTRAINT "PUBLIC"."FKVARIABLESET_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."VSMETRIC" ADD CONSTRAINT "PUBLIC"."VSMETRIC_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;
ALTER TABLE "PUBLIC"."ABSTRACTQUERY" ADD CONSTRAINT "PUBLIC"."ABSTRACTQUERY_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;      
ALTER TABLE "PUBLIC"."LDAPPROPERTY" ADD CONSTRAINT "PUBLIC"."LDAPPROPERTY_LDAPCONNECTION" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."LDAPCONNECTION"("ID") ON DELETE CASCADE NOCHECK;       
ALTER TABLE "PUBLIC"."OPERATIONTAG" ADD CONSTRAINT "PUBLIC"."OPTAG_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;               
ALTER TABLE "PUBLIC"."VSCONFIG" ADD CONSTRAINT "PUBLIC"."RUNSCBSLNREF" FOREIGN KEY("RUNBASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."PROJECTINFO" ADD CONSTRAINT "PUBLIC"."PROJECTINFO_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;          
ALTER TABLE "PUBLIC"."SCENARIOSUITEREPORT" ADD CONSTRAINT "PUBLIC"."SCENARIOSUITEREPORT_BSLN" FOREIGN KEY("BRANCH") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;            
ALTER TABLE "PUBLIC"."DEPLOYMENT" ADD CONSTRAINT "PUBLIC"."FKDPLMNT_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."DEPVERSIONPOLICY" ADD CONSTRAINT "PUBLIC"."FKDEPVERSPOLICY_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK; 
ALTER TABLE "PUBLIC"."RULEFLOW" ADD CONSTRAINT "PUBLIC"."FKRULEFLOW_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."BOM" ADD CONSTRAINT "PUBLIC"."BOM_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."LDAPPROPERTY" ADD CONSTRAINT "PUBLIC"."LDAPPROPERTY_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;        
ALTER TABLE "PUBLIC"."OVERRIDDENRULE" ADD CONSTRAINT "PUBLIC"."OVERWRITTENRULEREF" FOREIGN KEY("ILRRULE") REFERENCES "PUBLIC"."RULEARTIFACT"("ID") ON DELETE CASCADE NOCHECK;  
ALTER TABLE "PUBLIC"."VSREPORT" ADD CONSTRAINT "PUBLIC"."VSREPORT_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;       
ALTER TABLE "PUBLIC"."ACTIVITYCOMMENT" ADD CONSTRAINT "PUBLIC"."ACOMMENT_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;         
ALTER TABLE "PUBLIC"."VARIABLE" ADD CONSTRAINT "PUBLIC"."FKVARIABLE_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;  
ALTER TABLE "PUBLIC"."VOCABULARY" ADD CONSTRAINT "PUBLIC"."VOCABULARY_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;            
ALTER TABLE "PUBLIC"."BRSTUDIO" ADD CONSTRAINT "PUBLIC"."BRSTUDIO_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;
ALTER TABLE "PUBLIC"."SCOPEELEMENT" ADD CONSTRAINT "PUBLIC"."FKSCOPEELEMENT_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;      
ALTER TABLE "PUBLIC"."EVENT" ADD CONSTRAINT "PUBLIC"."EVENT_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;      
ALTER TABLE "PUBLIC"."GROUPROLE" ADD CONSTRAINT "PUBLIC"."GROUPROLE_SECURITYROLE" FOREIGN KEY("ILRROLE") REFERENCES "PUBLIC"."SECURITYROLE"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."USERGROUP" ADD CONSTRAINT "PUBLIC"."USERGROUP_USR" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."USR"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."VSINPUTDATA" ADD CONSTRAINT "PUBLIC"."VSINPUTDATA_INPUTKIND" FOREIGN KEY("INPUTTYPE") REFERENCES "PUBLIC"."INPUTKIND"("VALUE") NOCHECK;  
ALTER TABLE "PUBLIC"."BOM" ADD CONSTRAINT "PUBLIC"."BOM_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;             
ALTER TABLE "PUBLIC"."RULESETPROPERTY" ADD CONSTRAINT "PUBLIC"."RULESETPROPERTY_PROJECTINFO" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."PROJECTINFO"("ID") ON DELETE CASCADE NOCHECK;       
ALTER TABLE "PUBLIC"."DEPTARGET" ADD CONSTRAINT "PUBLIC"."FKDEPTARGET_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;
ALTER TABLE "PUBLIC"."LVIPBRCH" ADD CONSTRAINT "PUBLIC"."CHILDBRCHFKNAME" FOREIGN KEY("CHILDBRCH") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;             
ALTER TABLE "PUBLIC"."RULEPACKAGE" ADD CONSTRAINT "PUBLIC"."RULEPACKAGE_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK; 
ALTER TABLE "PUBLIC"."VSMETRIC" ADD CONSTRAINT "PUBLIC"."VSMETRIC_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."DEPGROUP" ADD CONSTRAINT "PUBLIC"."DEPGROUP_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;
ALTER TABLE "PUBLIC"."DEPTARGET" ADD CONSTRAINT "PUBLIC"."DEPTARGET_DPLMNT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."DEPLOYMENT"("ID") ON DELETE CASCADE NOCHECK;         
ALTER TABLE "PUBLIC"."USERSETTING" ADD CONSTRAINT "PUBLIC"."USERSETTING_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;          
ALTER TABLE "PUBLIC"."VTREPORT" ADD CONSTRAINT "PUBLIC"."VTREPORT_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;       
ALTER TABLE "PUBLIC"."ACTIVITYLOCK" ADD CONSTRAINT "PUBLIC"."ACTIVITYLOCKELTTYPE" FOREIGN KEY("ELEMENTTYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;    
ALTER TABLE "PUBLIC"."PRJRESOURCE" ADD CONSTRAINT "PUBLIC"."PRJRESOURCE_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;          
ALTER TABLE "PUBLIC"."TEMPLATE" ADD CONSTRAINT "PUBLIC"."TEMPLATE_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."RULEARTIFACT" ADD CONSTRAINT "PUBLIC"."RULEARTIFACT_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;      
ALTER TABLE "PUBLIC"."RULEFLOW" ADD CONSTRAINT "PUBLIC"."FKRULEFLOW_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;  
ALTER TABLE "PUBLIC"."BOMPATHENTRY" ADD CONSTRAINT "PUBLIC"."BOMPATHENTRY_PROJECTINFO" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."PROJECTINFO"("ID") ON DELETE CASCADE NOCHECK;             
ALTER TABLE "PUBLIC"."VTSUITE" ADD CONSTRAINT "PUBLIC"."VTSUITE_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;     
ALTER TABLE "PUBLIC"."VTSUITE" ADD CONSTRAINT "PUBLIC"."FKVTSUITE_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;
ALTER TABLE "PUBLIC"."DEPPROPERTYTAG" ADD CONSTRAINT "PUBLIC"."FKDEPPROPTAG_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;      
ALTER TABLE "PUBLIC"."VSINPUTDATA" ADD CONSTRAINT "PUBLIC"."FKVSINPUTDATA_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."SYSTEMLOCK" ADD CONSTRAINT "PUBLIC"."SYSTEMLOCKELTTYPE" FOREIGN KEY("ELEMENTTYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;        
ALTER TABLE "PUBLIC"."OPERATION" ADD CONSTRAINT "PUBLIC"."OPERATION_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;              
ALTER TABLE "PUBLIC"."DEFINITION" ADD CONSTRAINT "PUBLIC"."DEFINITION_RULEARTIFACT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."RULEARTIFACT"("ID") ON DELETE CASCADE NOCHECK;               
ALTER TABLE "PUBLIC"."DEPTARGET" ADD CONSTRAINT "PUBLIC"."FKDEPTARGET_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;            
ALTER TABLE "PUBLIC"."VSINPUTDATA" ADD CONSTRAINT "PUBLIC"."VSINPUTDATA_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."DSDEPLOYMENTREPORT" ADD CONSTRAINT "PUBLIC"."DSDEPLOYMENTREPORT_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;               
ALTER TABLE "PUBLIC"."VTSUITE" ADD CONSTRAINT "PUBLIC"."VTSUITE_OPERATION" FOREIGN KEY("OPERATION") REFERENCES "PUBLIC"."OPERATION"("ID") ON DELETE CASCADE NOCHECK;           
ALTER TABLE "PUBLIC"."DEPGROUP" ADD CONSTRAINT "PUBLIC"."FKDEPGROUP_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;  
ALTER TABLE "PUBLIC"."EVENTSIBLING" ADD CONSTRAINT "PUBLIC"."EVENT_STATUS" FOREIGN KEY("STATUS") REFERENCES "PUBLIC"."STATUS"("VALUE") NOCHECK;
ALTER TABLE "PUBLIC"."DEPOPERATION" ADD CONSTRAINT "PUBLIC"."DEPOP_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;               
ALTER TABLE "PUBLIC"."SCENARIOSUITERESOURCE" ADD CONSTRAINT "PUBLIC"."SCSUITERS_SCSUITE" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."SCENARIOSUITE"("ID") ON DELETE CASCADE NOCHECK;         
ALTER TABLE "PUBLIC"."VSINPUTDATA" ADD CONSTRAINT "PUBLIC"."VSINPUTDATA_OPERATION" FOREIGN KEY("OPERATION") REFERENCES "PUBLIC"."OPERATION"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."INITIALVALUE" ADD CONSTRAINT "PUBLIC"."FKINITIALVALUE_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;      
ALTER TABLE "PUBLIC"."LDAPCONNECTION" ADD CONSTRAINT "PUBLIC"."LDAPCONNECTION_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;    
ALTER TABLE "PUBLIC"."VTCASE" ADD CONSTRAINT "PUBLIC"."VTCASE_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;           
ALTER TABLE "PUBLIC"."BOM2XOMMAPPING" ADD CONSTRAINT "PUBLIC"."BOM2XOMMAPPING_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;    
ALTER TABLE "PUBLIC"."ACTIVITYSUBSCRIPTION" ADD CONSTRAINT "PUBLIC"."ACMTSUBSCR_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;  
ALTER TABLE "PUBLIC"."DSDEPLOYMENTREPORT" ADD CONSTRAINT "PUBLIC"."DSDEPLOYMENTREPORT_REPORTSTATUSKIND" FOREIGN KEY("STATUS") REFERENCES "PUBLIC"."REPORTSTATUSKIND"("VALUE") NOCHECK;         
ALTER TABLE "PUBLIC"."INITIALVALUE" ADD CONSTRAINT "PUBLIC"."FKINITIALVALUE_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."BASELINE" ADD CONSTRAINT "PUBLIC"."BASELINEKINDREF" FOREIGN KEY("BASELINEKIND") REFERENCES "PUBLIC"."BASELINEKIND"("VALUE") NOCHECK;     
ALTER TABLE "PUBLIC"."DEPOPERATIONPROPERTY" ADD CONSTRAINT "PUBLIC"."DEPOPPROP_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;   
ALTER TABLE "PUBLIC"."DEPGROUP" ADD CONSTRAINT "PUBLIC"."FKDEPGROUP_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."RULEPACKAGE" ADD CONSTRAINT "PUBLIC"."RULEPACKAGE_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;          
ALTER TABLE "PUBLIC"."DEPOPERATIONPROPERTY" ADD CONSTRAINT "PUBLIC"."DEPOPPROP_DPLMNT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."DEPLOYMENT"("ID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."VSKPI" ADD CONSTRAINT "PUBLIC"."VSKPI_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;         
ALTER TABLE "PUBLIC"."VTROINFO" ADD CONSTRAINT "PUBLIC"."VTROINFO_VTREPORT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."VTREPORT"("ID") ON DELETE CASCADE NOCHECK;           
ALTER TABLE "PUBLIC"."RULEFLOW" ADD CONSTRAINT "PUBLIC"."RULEFLOW_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;       
ALTER TABLE "PUBLIC"."TEMPLATE" ADD CONSTRAINT "PUBLIC"."TEMPLATE_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."ABSTRACTQUERY" ADD CONSTRAINT "PUBLIC"."ABSTRACTQUERY_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;             
ALTER TABLE "PUBLIC"."RULEAPP" ADD CONSTRAINT "PUBLIC"."RULEAPP_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;  
ALTER TABLE "PUBLIC"."RULEAPPPROPERTY" ADD CONSTRAINT "PUBLIC"."RULEAPPPROPERTY_RULEAPP" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."RULEAPP"("ID") ON DELETE CASCADE NOCHECK;               
ALTER TABLE "PUBLIC"."ACTIVITYCOMMENTACCESS" ADD CONSTRAINT "PUBLIC"."ACMTACCES_BSLN" FOREIGN KEY("BRANCH") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;    
ALTER TABLE "PUBLIC"."VSKPI" ADD CONSTRAINT "PUBLIC"."VSKPI_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;      
ALTER TABLE "PUBLIC"."SCENARIOSUITEKPIREPORT" ADD CONSTRAINT "PUBLIC"."SCSUITEKPIRPRT_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;            
ALTER TABLE "PUBLIC"."RULEFLOWTAG" ADD CONSTRAINT "PUBLIC"."RULEFLOWTAG_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."VSCONFIG" ADD CONSTRAINT "PUBLIC"."FKVSCONFIG_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."DEPVERSIONPOLICY" ADD CONSTRAINT "PUBLIC"."RULESETDEPVERS" FOREIGN KEY("RULESET") REFERENCES "PUBLIC"."DEPLOYMENTVERSIONNINGKIND"("VALUE") NOCHECK;      
ALTER TABLE "PUBLIC"."OPERATIONVARIABLE" ADD CONSTRAINT "PUBLIC"."FKOPVARIABLE_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."VSINPUTDATA" ADD CONSTRAINT "PUBLIC"."VSINPUTDATA_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."VSCONFIG" ADD CONSTRAINT "PUBLIC"."VSCONFIG_VSINPUTDATA" FOREIGN KEY("INPUTDATA") REFERENCES "PUBLIC"."VSINPUTDATA"("ID") ON DELETE CASCADE NOCHECK;     
ALTER TABLE "PUBLIC"."VTSUITE" ADD CONSTRAINT "PUBLIC"."VTSUITE_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;  
ALTER TABLE "PUBLIC"."BASELINE" ADD CONSTRAINT "PUBLIC"."BSLN_RULEPROJECT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;         
ALTER TABLE "PUBLIC"."EVENT" ADD CONSTRAINT "PUBLIC"."EVENT_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;         
ALTER TABLE "PUBLIC"."SCOPEELEMENT" ADD CONSTRAINT "PUBLIC"."SCOPEELEMENT_RULEFLOW" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."RULEFLOW"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."PROFILE" ADD CONSTRAINT "PUBLIC"."PROFILE_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;  
ALTER TABLE "PUBLIC"."USERPROPERTY" ADD CONSTRAINT "PUBLIC"."USERPROPERTY_USR" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."USR"("ID") ON DELETE CASCADE NOCHECK;             
ALTER TABLE "PUBLIC"."SCENARIOSUITE" ADD CONSTRAINT "PUBLIC"."SCSUITE_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;               
ALTER TABLE "PUBLIC"."VSREPORT" ADD CONSTRAINT "PUBLIC"."VSREPORT_OPERATION" FOREIGN KEY("OPERATION") REFERENCES "PUBLIC"."OPERATION"("ID") ON DELETE CASCADE NOCHECK;         
ALTER TABLE "PUBLIC"."VSMODEL" ADD CONSTRAINT "PUBLIC"."VSMODEL_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;         
ALTER TABLE "PUBLIC"."VTDETAIL" ADD CONSTRAINT "PUBLIC"."VTDETAIL_VTREPORT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."VTREPORT"("ID") ON DELETE CASCADE NOCHECK;           
ALTER TABLE "PUBLIC"."VSMODEL" ADD CONSTRAINT "PUBLIC"."VSMODEL_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;  
ALTER TABLE "PUBLIC"."VSCONFIG" ADD CONSTRAINT "PUBLIC"."VSCONFIG_OPERATION" FOREIGN KEY("OPERATION") REFERENCES "PUBLIC"."OPERATION"("ID") ON DELETE CASCADE NOCHECK;         
ALTER TABLE "PUBLIC"."VSKPI" ADD CONSTRAINT "PUBLIC"."VSKPI_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;    
ALTER TABLE "PUBLIC"."BASELINE" ADD CONSTRAINT "PUBLIC"."BSLN_PARENT" FOREIGN KEY("PARENT") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;    
ALTER TABLE "PUBLIC"."RULEFLOWTAG" ADD CONSTRAINT "PUBLIC"."RULEFLOWTAG_RULEFLOW" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."RULEFLOW"("ID") ON DELETE CASCADE NOCHECK;     
ALTER TABLE "PUBLIC"."RULEARTIFACT" ADD CONSTRAINT "PUBLIC"."RULEARTIFACT_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;        
ALTER TABLE "PUBLIC"."BASELINECONTENT" ADD CONSTRAINT "PUBLIC"."BASELINECONTENT_BASELINE" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."VARIABLESET" ADD CONSTRAINT "PUBLIC"."VARIABLESET_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;             
ALTER TABLE "PUBLIC"."ACTIVITYCOMMENTATTACHMENT" ADD CONSTRAINT "PUBLIC"."ACMTATCHMT_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;             
ALTER TABLE "PUBLIC"."VSMETRIC" ADD CONSTRAINT "PUBLIC"."FKVSMETRIC_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;  
ALTER TABLE "PUBLIC"."ABSTRACTQUERY" ADD CONSTRAINT "PUBLIC"."ABSTRACTQUERY_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;    
ALTER TABLE "PUBLIC"."VARIABLESET" ADD CONSTRAINT "PUBLIC"."FKVARIABLESET_ENDV" FOREIGN KEY("ENDID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;            
ALTER TABLE "PUBLIC"."VTCASE" ADD CONSTRAINT "PUBLIC"."VTCASE_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;       
ALTER TABLE "PUBLIC"."BOM2XOMMAPPING" ADD CONSTRAINT "PUBLIC"."BOM2XOMMAPPING_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;           
ALTER TABLE "PUBLIC"."RULEARTIFACTTAG" ADD CONSTRAINT "PUBLIC"."RULARTTAG_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;        
ALTER TABLE "PUBLIC"."OPERATION" ADD CONSTRAINT "PUBLIC"."OPERATION_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;     
ALTER TABLE "PUBLIC"."DEPVERSIONPOLICY" ADD CONSTRAINT "PUBLIC"."DEPVERSPOLICY_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."ACTIVITYLOCK" ADD CONSTRAINT "PUBLIC"."ACTIVITYLOCK_RULEPACKAGE" FOREIGN KEY("ELTPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;            
ALTER TABLE "PUBLIC"."VTROINFO" ADD CONSTRAINT "PUBLIC"."VTROINFO_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;
ALTER TABLE "PUBLIC"."MERGEINFO" ADD CONSTRAINT "PUBLIC"."MERGEINFO_LCLBSLN" FOREIGN KEY("LOCALBSLN") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."RULEFLOW" ADD CONSTRAINT "PUBLIC"."RULEFLOW_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."VSKPI" ADD CONSTRAINT "PUBLIC"."VSKPI_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;             
ALTER TABLE "PUBLIC"."PRJRESOURCE" ADD CONSTRAINT "PUBLIC"."PRJRESOURCE_RULEPACKAGE" FOREIGN KEY("RULEPACKAGE") REFERENCES "PUBLIC"."RULEPACKAGE"("ID") ON DELETE CASCADE NOCHECK;             
ALTER TABLE "PUBLIC"."OPERATION" ADD CONSTRAINT "PUBLIC"."OPERATION_BSLN" FOREIGN KEY("BASELINE") REFERENCES "PUBLIC"."BASELINE"("ID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."ACTIVITYCOMMENTACCESS" ADD CONSTRAINT "PUBLIC"."ACMTACCES_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK;         
ALTER TABLE "PUBLIC"."VTREPORT" ADD CONSTRAINT "PUBLIC"."VTREPORT_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."EVENT" ADD CONSTRAINT "PUBLIC"."FKEVENT_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;    
ALTER TABLE "PUBLIC"."OPERATIONVARIABLE" ADD CONSTRAINT "PUBLIC"."OPVARIABLE_VARIABLESET" FOREIGN KEY("VARIABLESET") REFERENCES "PUBLIC"."VARIABLESET"("ID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."DEPOPERATION" ADD CONSTRAINT "PUBLIC"."DEPOP_DPLMNT" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."DEPLOYMENT"("ID") ON DELETE CASCADE NOCHECK;          
ALTER TABLE "PUBLIC"."EVENT" ADD CONSTRAINT "PUBLIC"."EVENT_NAMEDCONSTANTTYPE" FOREIGN KEY("VALUETYPE") REFERENCES "PUBLIC"."NAMEDCONSTANTTYPE"("VALUE") NOCHECK;              
ALTER TABLE "PUBLIC"."RULEFLOW" ADD CONSTRAINT "PUBLIC"."RULEFLOW_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;              
ALTER TABLE "PUBLIC"."VTDETAIL" ADD CONSTRAINT "PUBLIC"."VTDETAIL_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;
ALTER TABLE "PUBLIC"."USERPROPERTY" ADD CONSTRAINT "PUBLIC"."USERPROPERTY_METAMODEL" FOREIGN KEY("TYPE") REFERENCES "PUBLIC"."METAMODEL"("ID") NOCHECK;        
ALTER TABLE "PUBLIC"."BOM" ADD CONSTRAINT "PUBLIC"."BOM_BRSTUDIO" FOREIGN KEY("UUID") REFERENCES "PUBLIC"."BRSTUDIO"("UUID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."PROJECTINFO" ADD CONSTRAINT "PUBLIC"."PROJECTINFO_RULEPROJECT" FOREIGN KEY("PROJECT") REFERENCES "PUBLIC"."RULEPROJECT"("ID") ON DELETE CASCADE NOCHECK; 
ALTER TABLE "PUBLIC"."VSMETRIC" ADD CONSTRAINT "PUBLIC"."VSMETRIC_OPERATION" FOREIGN KEY("OPERATION") REFERENCES "PUBLIC"."OPERATION"("ID") ON DELETE CASCADE NOCHECK;         
ALTER TABLE "PUBLIC"."RULEPACKAGE" ADD CONSTRAINT "PUBLIC"."FKRULEPACKAGE_STARTV" FOREIGN KEY("STARTID") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK;        
ALTER TABLE "PUBLIC"."TASK" ADD CONSTRAINT "PUBLIC"."TASK_RULEFLOW" FOREIGN KEY("CONTAINER") REFERENCES "PUBLIC"."RULEFLOW"("ID") ON DELETE CASCADE NOCHECK;   
ALTER TABLE "PUBLIC"."BASELINECONTENT" ADD CONSTRAINT "PUBLIC"."BASELINECONTENT_VERSION" FOREIGN KEY("VERSION") REFERENCES "PUBLIC"."VERSION"("ID") ON DELETE CASCADE NOCHECK; 
