#Configure this member server after the container start but before the server start
#cmd.sh is used in /opt/ibm/wlp/bin/liberty-run
${SCRIPT}/configDS.sh